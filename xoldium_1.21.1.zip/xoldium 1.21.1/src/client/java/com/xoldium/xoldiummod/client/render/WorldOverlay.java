package com.xoldium.xoldiummod.client.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * SATU-SATUNYA tempat kode Xoldium menyentuh API render dunia 3D (event
 * Fabric + VertexConsumer) untuk Custom Block Highlight & Hit Range. Semua
 * geometri digambar sebagai QUAD berwarna per-vertex ({@code RenderLayer#getDebugQuads})
 * - hanya memakai {@code vertex(Matrix4f,x,y,z).color(argb)}, API paling
 * stabil lintas versi (tanpa normal / line-width yang berubah-ubah antar rilis).
 *
 * <p>BILA build gagal / hasil tidak tampil setelah update Fabric API atau
 * Yarn: cukup sesuaikan 4 method {@link #camera}, {@link #matrices},
 * {@link #quadConsumer} dan {@link #positionMatrix} di bawah - seluruh modul
 * lain memanggil lewat kelas ini.
 */
public final class WorldOverlay {

    private WorldOverlay() {
    }

    public static Vec3d camera(WorldRenderContext ctx) {
        return ctx.camera().getPos();
    }

    /**
     * MatrixStack event dunia. Bila API mengembalikan {@code null} (terjadi di
     * beberapa event Fabric API 1.21.9+), pakai stack identitas: koordinat
     * kita sudah RELATIF kamera dan rotasi kamera sudah ada di model-view
     * GPU saat pass dunia - jadi identitas tetap benar (dulu modul langsung
     * berhenti diam-diam bila null -> "tidak tampil").
     */
    public static MatrixStack matrices(WorldRenderContext ctx) {
        MatrixStack stack = ctx.matrixStack();
        return stack != null ? stack : new MatrixStack();
    }

    /** Buffer quad berwarna, atau {@code null} bila provider tidak tersedia di event ini. */
    public static VertexConsumer quadConsumer(WorldRenderContext ctx) {
        VertexConsumerProvider provider = ctx.consumers();
        return provider != null ? provider.getBuffer(RenderLayer.getDebugQuads()) : null;
    }

    /**
     * Gambar SEKARANG semua quad yang baru ditulis (selagi matriks pass dunia
     * masih aktif), bukan menunggu flush provider di titik lain frame yang
     * bisa memakai matriks berbeda / frame berikutnya.
     */
    public static void flush(WorldRenderContext ctx) {
        VertexConsumerProvider provider = ctx.consumers();
        if (provider instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw(RenderLayer.getDebugQuads());
        }
    }

    public static Matrix4f positionMatrix(MatrixStack stack) {
        return stack.peek().getPositionMatrix();
    }

    // ------------------------------------------------------------------
    // Primitif geometri (koordinat sudah RELATIF kamera)
    // ------------------------------------------------------------------

    public static void vertex(VertexConsumer c, Matrix4f m, double x, double y, double z, int argb) {
        c.vertex(m, (float) x, (float) y, (float) z).color(argb);
    }

    public static void quad(VertexConsumer c, Matrix4f m,
                            double x1, double y1, double z1, int c1,
                            double x2, double y2, double z2, int c2,
                            double x3, double y3, double z3, int c3,
                            double x4, double y4, double z4, int c4) {
        vertex(c, m, x1, y1, z1, c1);
        vertex(c, m, x2, y2, z2, c2);
        vertex(c, m, x3, y3, z3, c3);
        vertex(c, m, x4, y4, z4, c4);
    }

    /** Quad dua sisi (winding ganda) supaya tetap terlihat walau pipeline melakukan back-face culling. */
    public static void quadBothSides(VertexConsumer c, Matrix4f m,
                                     double x1, double y1, double z1,
                                     double x2, double y2, double z2,
                                     double x3, double y3, double z3,
                                     double x4, double y4, double z4, int argb) {
        quad(c, m, x1, y1, z1, argb, x2, y2, z2, argb, x3, y3, z3, argb, x4, y4, z4, argb);
        quad(c, m, x4, y4, z4, argb, x3, y3, z3, argb, x2, y2, z2, argb, x1, y1, z1, argb);
    }

    /**
     * Balok tipis (garis tebal) antara dua titik: 4 sisi persegi panjang.
     * {@code half} = setengah ketebalan (blok). Arah sisi memakai dua vektor
     * tegak lurus ke garis - cukup untuk garis sumbu-sejajar maupun miring.
     */
    public static void beam(VertexConsumer c, Matrix4f m,
                            double ax, double ay, double az, int ca,
                            double bx, double by, double bz, int cb, double half) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-6) return;
        dx /= len; dy /= len; dz /= len;
        // vektor referensi yang tidak sejajar dengan arah garis
        double rx = Math.abs(dy) < 0.9 ? 0 : 1, ry = Math.abs(dy) < 0.9 ? 1 : 0, rz = 0;
        // u = d x r
        double ux = dy * rz - dz * ry, uy = dz * rx - dx * rz, uz = dx * ry - dy * rx;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux = ux / ul * half; uy = uy / ul * half; uz = uz / ul * half;
        // v = d x u (dinormalkan ke half)
        double vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;
        double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
        vx = vx / vl * half; vy = vy / vl * half; vz = vz / vl * half;

        // 4 sudut penampang di A dan B
        double[][] off = {{ux + vx, uy + vy, uz + vz}, {-ux + vx, -uy + vy, -uz + vz},
                {-ux - vx, -uy - vy, -uz - vz}, {ux - vx, uy - vy, uz - vz}};
        for (int i = 0; i < 4; i++) {
            double[] p = off[i];
            double[] q = off[(i + 1) % 4];
            quad(c, m,
                    ax + p[0], ay + p[1], az + p[2], ca,
                    ax + q[0], ay + q[1], az + q[2], ca,
                    bx + q[0], by + q[1], bz + q[2], cb,
                    bx + p[0], by + p[1], bz + p[2], cb);
        }
    }
}

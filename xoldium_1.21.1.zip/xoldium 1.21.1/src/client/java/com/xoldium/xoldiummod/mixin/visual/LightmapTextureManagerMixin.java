package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.FullbrightModule;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * INTI PERBAIKAN BUG MODUL FULLBRIGHT.
 *
 * <p>Ditulis dari analisis source code referensi "Fullbright" (mod pemakai,
 * greenman999) yang disertakan pemakai - mod tsb SAMA SEKALI tidak
 * menyentuh {@code GameOptions#getGamma()}. Dia mem-Mixin langsung ke
 * {@code LightTexture#updateLightTexture} (Mojang mappings) dan menimpa
 * float gamma yang dibaca DI DALAM method itu lewat
 * {@code WrapOperation} yang menargetkan pemanggilan
 * {@code Double#floatValue()} ordinal ke-2 (ordinal=1). Instruksi bytecode
 * yang ditarget SAMA PERSIS di kedua mapping (Mojang & Yarn keduanya
 * dikompilasi dari game yang sama - hanya nama simbolnya beda), dan mod
 * referensi tsb sudah menyertakan konfigurasi build untuk versi 1.21.11
 * (lihat {@code versions/1.21.11/gradle.properties}-nya) - versi yang
 * sama persis dengan target Xoldium - sehingga ordinal ini terverifikasi
 * benar untuk build Minecraft yang sama yang dipakai Xoldium.
 *
 * <p>CATATAN PORT 1.21.1: posisi ordinal ini (ordinal=1) diverifikasi untuk
 * 1.21.11, BELUM diverifikasi ulang khusus untuk 1.21.1 - bila Mojang
 * pernah mengubah isi {@code update(float)} di antara kedua versi tsb,
 * ordinal bisa saja bergeser. {@code require = 0} di bawah sudah memastikan
 * ini aman (Fullbright cuma tidak aktif, bukan mod gagal load) bila
 * ternyata tidak cocok - kalau Fullbright terasa tidak terang penuh lagi
 * setelah pindah ke 1.21.1, ini titik pertama yang perlu dicek ulang lewat
 * {@code genSources}.
 *
 * <p>Padanan Yarn dari {@code LightTexture#updateLightTexture(float)}
 * adalah {@link LightmapTextureManager#update(float)} - dikonfirmasi
 * lewat Yarn API docs {@code yarn-1.21.11+build.4} (build resmi paling
 * dekat dengan {@code yarn_mappings} proyek ini, 1.21.11+build.6; nama
 * kelas & method ini SANGAT stabil lintas versi Yarn, sudah sama sejak
 * bertahun-tahun lalu).
 *
 * <p>Dipakai standar Mixin {@code @Redirect} (BUKAN {@code @WrapOperation}
 * dari MixinExtras seperti mod referensi) supaya proyek ini TIDAK perlu
 * menambah dependency {@code mixinextras} baru - {@code @Redirect} bawaan
 * SpongePowered Mixin (sudah otomatis tersedia lewat Fabric Loader) cukup
 * untuk kasus penggantian nilai balik satu pemanggilan method sederhana
 * seperti ini.
 */
@Mixin(LightmapTextureManager.class)
public abstract class LightmapTextureManagerMixin {

    @Redirect(
            method = "update(F)V",
            at = @At(value = "INVOKE", target = "Ljava/lang/Double;floatValue()F", ordinal = 1),
            require = 0
    )
    private float xoldium$forceFullbrightGamma(Double gammaValue) {
        if (FullbrightModule.isActive()) {
            return FullbrightModule.gamma();
        }
        return gammaValue.floatValue();
    }
}

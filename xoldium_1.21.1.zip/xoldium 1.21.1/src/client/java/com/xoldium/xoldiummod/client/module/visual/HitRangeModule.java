package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Hit Range - lingkaran jangkauan serang di kaki pemain (default radius 3
 * blok, merah) seperti mod referensi "Hit Range" (uku3lig, source dikirim
 * pemakai, build 26.3). Diikuti dari mod referensi: mode Line / Thick /
 * Filled, radius, ketebalan, tinggi, warna + warna saat pemain lain masuk
 * jangkauan, nearest-only, "Show Around Myself" (default ON - itulah
 * lingkaran merah yang terlihat di sekeliling pemain sendiri), jarak
 * maksimum dan jumlah segmen. Nilai default sama dengan mod referensi
 * (radius 3.0, Thick 0.15, merah 0x80FF0000, hijau 0x8000FF00, 60 segmen,
 * jarak maks 100).
 *
 * <p>Mod referensi menggambar lewat pipeline render 26.x per-entity
 * ({@code SubmitNodeCollector}); API itu tidak ada di 1.21.11, jadi cincin
 * digambar sebagai quad berwarna lewat {@link WorldOverlay} di event dunia
 * Fabric. Penyebab "tidak bekerja" versi lama: (1) "Show Around Myself"
 * default OFF sehingga sendirian tidak terlihat apa-apa, (2) modul berhenti
 * diam-diam bila MatrixStack event bernilai null, (3) quad tidak
 * di-flush pada matriks pass dunia. Ketiganya diperbaiki; quad digambar dua
 * sisi supaya tidak hilang oleh back-face culling.
 */
public final class HitRangeModule extends Module {

    private final DoubleSetting radius = addSetting(
            new DoubleSetting("radius", "setting.xoldiummod.hitrange.radius", 3.0, 1.0, 10.0, 0.1));
    private final ModeSetting renderMode = addSetting(
            new ModeSetting("render_mode", "setting.xoldiummod.hitrange.render_mode", 1,
                    "setting.xoldiummod.hitrange.mode.line",
                    "setting.xoldiummod.hitrange.mode.thick",
                    "setting.xoldiummod.hitrange.mode.filled"));
    private final DoubleSetting thickness = addSetting(
            new DoubleSetting("thickness", "setting.xoldiummod.hitrange.thickness", 0.15, 0.02, 0.6, 0.01),
            () -> this.renderMode.index() == 1);
    private final DoubleSetting height = addSetting(
            new DoubleSetting("height", "setting.xoldiummod.hitrange.height", 0.03, 0.0, 1.5, 0.01));
    private final ColorSetting color = addSetting(
            new ColorSetting("color", "setting.xoldiummod.hitrange.color", 0x80FF0000, true));
    private final BooleanSetting colorWhenInRange = addSetting(
            new BooleanSetting("color_in_range", "setting.xoldiummod.hitrange.color_in_range", true));
    private final ColorSetting inRangeColor = addSetting(
            new ColorSetting("in_range_color", "setting.xoldiummod.hitrange.in_range_color", 0x8000FF00, true),
            () -> this.colorWhenInRange.get());
    private final BooleanSetting nearestOnly = addSetting(
            new BooleanSetting("nearest_only", "setting.xoldiummod.hitrange.nearest_only", false));
    private final BooleanSetting showSelf = addSetting(
            new BooleanSetting("show_self", "setting.xoldiummod.hitrange.show_self", true));
    private final DoubleSetting maxDistance = addSetting(
            new DoubleSetting("max_distance", "setting.xoldiummod.hitrange.max_distance", 100.0, 8.0, 128.0, 4.0));
    private final DoubleSetting segments = addSetting(
            new DoubleSetting("segments", "setting.xoldiummod.hitrange.segments", 60.0, 16.0, 128.0, 4.0));

    private boolean loggedError = false;
    private boolean loggedFirstDraw = false;
    private boolean loggedNoConsumers = false;

    public HitRangeModule() {
        super("hit_range", "module.xoldiummod.hit_range", ModuleCategory.VISUAL, false);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onAfterEntities);
    }

    private void onAfterEntities(WorldRenderContext context) {
        if (!isEnabled()) {
            return;
        }
        try {
            draw(context);
        } catch (Throwable t) {
            if (!loggedError) {
                loggedError = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Hit Range gagal menggambar (dilewati, tidak crash).", t);
            }
        }
    }

    private void draw(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        ClientPlayerEntity self = mc.player;
        if (world == null || self == null) {
            return;
        }
        VertexConsumer vc = WorldOverlay.quadConsumer(context);
        if (vc == null) {
            if (!loggedNoConsumers) {
                loggedNoConsumers = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Hit Range: event dunia tidak menyediakan VertexConsumerProvider - tidak bisa menggambar.");
            }
            return;
        }
        MatrixStack matrices = WorldOverlay.matrices(context);
        float tickDelta = mc.getRenderTickCounter().getTickProgress(false);
        Vec3d cam = WorldOverlay.camera(context);
        Matrix4f m = WorldOverlay.positionMatrix(matrices);

        Vec3d selfPos = self.getLerpedPos(tickDelta);
        double maxDist = maxDistance.get();
        double r = radius.get();

        AbstractClientPlayerEntity nearest = null;
        if (nearestOnly.get()) {
            double best = Double.MAX_VALUE;
            for (AbstractClientPlayerEntity p : world.getPlayers()) {
                if (p == self || !p.isAlive()) continue;
                double d = p.squaredDistanceTo(self);
                if (d < best) {
                    best = d;
                    nearest = p;
                }
            }
        }

        int drawn = 0;
        for (AbstractClientPlayerEntity p : world.getPlayers()) {
            boolean isSelf = p == self;
            if (isSelf && !showSelf.get()) continue;
            if (!p.isAlive() || p.isSpectator() || p.isSleeping()) continue;
            if (!isSelf && p.isInvisibleTo(self)) continue;
            if (nearestOnly.get() && !isSelf && p != nearest) continue;

            Vec3d pos = p.getLerpedPos(tickDelta);
            if (!isSelf && pos.squaredDistanceTo(selfPos) > maxDist * maxDist) continue;

            int col = color.argb();
            if (!isSelf && colorWhenInRange.get() && pos.distanceTo(selfPos) < r) {
                col = inRangeColor.argb();
            }
            double y = pos.y + height.get() + (p.isSneaking() ? 0.125 : 0.0);
            ring(vc, m, pos.x - cam.x, y - cam.y, pos.z - cam.z, r, col);
            drawn++;
        }

        if (drawn > 0) {
            WorldOverlay.flush(context);
            if (!loggedFirstDraw) {
                loggedFirstDraw = true;
                XoldiumMod.LOGGER.info("[Xoldium] Hit Range menggambar {} cincin (radius {}).", drawn, r);
            }
        }
    }

    private void ring(VertexConsumer vc, Matrix4f m, double cx, double cy, double cz, double r, int col) {
        int n = (int) Math.round(segments.get());
        int mode = renderMode.index();
        double half = mode == 2 ? 0.0 : (mode == 0 ? 0.02 : thickness.get() / 2.0);
        double inner = Math.max(0.001, r - half);
        double outer = r + half;
        for (int i = 0; i < n; i++) {
            double a0 = 2.0 * Math.PI * i / n;
            double a1 = 2.0 * Math.PI * (i + 1) / n;
            double s0 = Math.sin(a0), c0 = Math.cos(a0), s1 = Math.sin(a1), c1 = Math.cos(a1);
            if (mode == 2) {
                // disk terisi: tiap irisan = segitiga (pusat, p0, p1) ditulis sebagai quad degenerat
                WorldOverlay.quadBothSides(vc, m,
                        cx, cy, cz,
                        cx + outer * s0, cy, cz + outer * c0,
                        cx + outer * s1, cy, cz + outer * c1,
                        cx + outer * s1, cy, cz + outer * c1, col);
            } else {
                WorldOverlay.quadBothSides(vc, m,
                        cx + inner * s0, cy, cz + inner * c0,
                        cx + outer * s0, cy, cz + outer * c0,
                        cx + outer * s1, cy, cz + outer * c1,
                        cx + inner * s1, cy, cz + inner * c1, col);
            }
        }
    }
}

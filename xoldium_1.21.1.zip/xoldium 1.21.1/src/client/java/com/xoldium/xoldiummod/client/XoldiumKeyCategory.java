package com.xoldium.xoldiummod.client;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;

/**
 * Satu-satunya tempat kategori keybind Xoldium didaftarkan.
 *
 * <p>Sejak Minecraft 1.21.9, kategori keybind bukan lagi String bebas,
 * melainkan objek {@link KeyBinding.Category} yang HARUS dibuat lewat
 * {@code KeyBinding.Category.create(Identifier)} - dan pemanggilan kedua
 * dengan Identifier yang sama melempar
 * {@code IllegalArgumentException: Category 'xoldiummod:main' is already registered}.
 * Karena itu kategori dibuat SEKALI di static field ini, lalu dipakai
 * bersama oleh semua keybind (menu, FreeLook, Zoom, dst).
 *
 * <p>Key terjemahan di lang file: {@code key.category.xoldiummod.main}.
 */
public final class XoldiumKeyCategory {

    public static final KeyBinding.Category MAIN =
            KeyBinding.Category.create(Identifier.of("xoldiummod", "main"));

    private XoldiumKeyCategory() {
    }
}

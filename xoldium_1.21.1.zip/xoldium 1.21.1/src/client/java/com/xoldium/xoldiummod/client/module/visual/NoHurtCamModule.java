package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * No Hurt Cam: mengurangi {@code LivingEntity#hurtTime} pemain lokal
 * setiap client tick - field publik yang sama yang dipakai vanilla untuk
 * animasi "squish"/tint merah dan tilt kamera saat kena damage. Pendekatan
 * ini SENGAJA tidak memakai Mixin ke {@code GameRenderer}/kalkulasi kamera
 * (yang jauh lebih rapuh & sering berubah antar versi) - field
 * {@code hurtTime} sudah stabil dipakai banyak mod lintas versi untuk
 * keperluan yang sama.
 *
 * <p>Setting "Reduction" (0.0-1.0, default 1.0 = perilaku lama persis,
 * hurtTime selalu dipaksa 0) mengatur seberapa besar efeknya dikurangi -
 * nilai di bawah 1.0 hanya meredam sebagian (mis. 0.5 = tilt kamera/tint
 * merah masih terasa tapi setengah lebih halus), bukan menghilangkannya
 * total.
 */
public final class NoHurtCamModule extends Module {

    private final DoubleSetting reduction = addSetting(
            new DoubleSetting("reduction", "setting.xoldiummod.no_hurt_cam.reduction", 1.0, 0.0, 1.0, 0.05));

    public NoHurtCamModule() {
        super("no_hurt_cam", "module.xoldiummod.no_hurt_cam", ModuleCategory.VISUAL, false);
    }

    @Override
    public void onClientTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null) {
            player.hurtTime = Math.round(player.hurtTime * (1.0f - reduction.get().floatValue()));
        }
    }
}

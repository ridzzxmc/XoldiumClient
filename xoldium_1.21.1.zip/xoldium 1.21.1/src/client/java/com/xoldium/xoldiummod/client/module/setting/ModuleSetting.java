package com.xoldium.xoldiummod.client.module.setting;

import net.minecraft.text.Text;

/** Setting generik milik sebuah Module, ditampilkan di ModuleSettingsScreen (ikon gear). */
public abstract class ModuleSetting<T> {

    private final String id;
    private final String nameKey;
    private final T defaultValue;
    protected T value;

    protected ModuleSetting(String id, String nameKey, T defaultValue) {
        this.id = id;
        this.nameKey = nameKey;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String id() {
        return id;
    }

    public String nameKey() {
        return nameKey;
    }

    public Text displayName() {
        return Text.translatable(nameKey);
    }

    public T get() {
        return value;
    }

    public T defaultValue() {
        return defaultValue;
    }

    public void set(T value) {
        this.value = value;
        com.xoldium.xoldiummod.client.module.ModuleManager.saveState();
    }

    /** Dipakai ModuleManager saat memuat dari config - tanpa memicu save ulang. */
    public void setFromConfig(T value) {
        this.value = value;
    }

    /** Kembalikan ke nilai default (tombol "Reset" di layar setting). */
    public void reset() {
        set(defaultValue);
    }

    /**
     * Bila non-null, setting ini hanya tampil di layar setting saat kondisinya
     * true (mis. warna gradient kedua hanya muncul bila Gradient aktif).
     */
    private java.util.function.BooleanSupplier visibleWhen;

    public void setVisibleWhen(java.util.function.BooleanSupplier condition) {
        this.visibleWhen = condition;
    }

    public boolean isVisible() {
        return visibleWhen == null || visibleWhen.getAsBoolean();
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.boss.BossBar;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Boss Bar - baris HUD ringkas berisi nama & persentase boss bar yang
 * sedang aktif (bisa ditempatkan bebas lewat HUD Editor, beda dengan boss
 * bar vanilla yang posisinya tetap di tengah-atas layar).
 *
 * <p>{@link BossBarHud} vanilla TIDAK punya getter publik untuk daftar
 * boss bar aktifnya (field penyimpanannya privat) - dibanding menebak
 * nama field itu lewat sebuah mixin baru (yang gagal ter-apply = crash
 * total saat start bila salah), dipakai REFLEKSI generik yang mencari
 * field bertipe {@link Map} apa pun di kelasnya lalu membaca isinya lewat
 * method PUBLIK {@link BossBar} (getName/getPercent, stabil & terdokumentasi).
 * Dibungkus try/catch penuh: bila API internal ini berubah nama fieldnya
 * di versi lain, modul ini otomatis berhenti menampilkan data (TIDAK
 * pernah crash) - lihat {@link Module#markCrashed} yang membungkus
 * pemanggilan {@link #render} dari {@link com.xoldium.xoldiummod.client.module.ModuleManager}.
 */
public final class BossBarHudModule extends HudModule {

    public BossBarHudModule() {
        super("bossbar", "module.xoldiummod.bossbar", false, 4f, 640f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.inGameHud == null) {
            return;
        }
        BossBarHud bossBarHud = client.inGameHud.getBossBarHud();
        List<String> lines = readActiveBossBars(bossBarHud);
        if (lines.isEmpty()) {
            return;
        }
        HudRenderUtil.drawLines(context, this, lines.toArray(new String[0]));
    }

    private static List<String> readActiveBossBars(BossBarHud bossBarHud) {
        List<String> lines = new ArrayList<>();
        try {
            for (Field field : bossBarHud.getClass().getDeclaredFields()) {
                if (!Map.class.isAssignableFrom(field.getType())) {
                    continue;
                }
                field.setAccessible(true);
                Object raw = field.get(bossBarHud);
                if (!(raw instanceof Map<?, ?> map)) {
                    continue;
                }
                for (Object value : map.values()) {
                    if (value instanceof BossBar bar) {
                        lines.add(bar.getName().getString() + " " + Math.round(bar.getPercent() * 100) + "%");
                    }
                }
                break; // field Map pertama yang ditemukan sudah cukup - hindari duplikasi kalau ada field Map lain
            }
        } catch (Throwable ignored) {
            // Field internal berubah/tidak ditemukan - tampilkan kosong saja, jangan pernah crash.
        }
        return lines;
    }
}

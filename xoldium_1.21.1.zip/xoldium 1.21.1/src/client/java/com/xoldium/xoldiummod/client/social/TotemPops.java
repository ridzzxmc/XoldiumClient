package com.xoldium.xoldiummod.client.social;

import com.xoldium.xoldiummod.client.module.hud.TotemCounterModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Pencatat "pop" totem SEMUA pemain (bukan hanya diri sendiri) - konsep mod
 * referensi Totem Counter (uku3lig): jumlah pop ditempel di nametag ("Nama | -3")
 * dengan warna bertingkat. Pencatatan hanya berjalan bila modul Totem Counter
 * ON di Mod Menu.
 */
public final class TotemPops {

    private static final Map<UUID, Integer> POPS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_WORLD_TIME = new ConcurrentHashMap<>();

    private TotemPops() {
    }

    /** Dipanggil dari mixin paket status entity (status 35) dan/atau LivingEntity#handleStatus - dengan dedupe per-tick. */
    public static void onPop(Entity entity) {
        if (!(entity instanceof PlayerEntity player) || !TotemCounterModule.isActive()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        long time = client.world != null ? client.world.getTime() : 0L;
        UUID id = player.getUuid();
        Long last = LAST_WORLD_TIME.put(id, time);
        if (last != null && last == time) {
            return; // event yang sama sudah dihitung oleh hook lain di tick ini
        }
        POPS.merge(id, 1, Integer::sum);
    }

    public static int get(UUID id) {
        return POPS.getOrDefault(id, 0);
    }

    public static void remove(UUID id) {
        POPS.remove(id);
        LAST_WORLD_TIME.remove(id);
    }

    public static void clear() {
        POPS.clear();
        LAST_WORLD_TIME.clear();
    }

    public static int popColor(int pops) {
        return switch (pops) {
            case 1, 2 -> 0x55FF55;
            case 3, 4 -> 0x00AA00;
            case 5, 6 -> 0xFFFF55;
            case 7, 8 -> 0xFFAA00;
            default -> 0xFF5555;
        };
    }

    public static int totemColor(int amount) {
        return switch (amount) {
            case 0 -> 0xFF5555;
            case 1, 2 -> 0xFF5555;
            case 3, 4 -> 0xFFAA00;
            case 5, 6 -> 0xFFFF55;
            case 7, 8 -> 0x00AA00;
            default -> 0x55FF55;
        };
    }

    /** Tempelkan " | -N" ke nama pemain bila ia punya pop tercatat. */
    public static Text decorate(PlayerEntity player, Text original) {
        if (!TotemCounterModule.isActive() || !TotemCounterModule.showOnNametag()) {
            return original;
        }
        if (!player.isAlive()) {
            remove(player.getUuid());
            return original;
        }
        int pops = get(player.getUuid());
        if (pops <= 0) {
            return original;
        }
        MutableText label = original.copy().append(" ");
        if (TotemCounterModule.useSeparator()) {
            label.append(Text.literal("| ").setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xAAAAAA))));
        }
        MutableText counter = Text.literal("-" + pops);
        if (TotemCounterModule.useColors()) {
            counter.setStyle(Style.EMPTY.withColor(TextColor.fromRgb(popColor(pops))));
        }
        return label.append(counter);
    }
}

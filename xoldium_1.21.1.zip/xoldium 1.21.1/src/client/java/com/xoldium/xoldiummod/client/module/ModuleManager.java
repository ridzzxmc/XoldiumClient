package com.xoldium.xoldiummod.client.module;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.hud.*;
import com.xoldium.xoldiummod.client.module.movement.SprintModule;
import com.xoldium.xoldiummod.client.module.optimization.OptimizationToggleModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.CustomBlockHighlightModule;
import com.xoldium.xoldiummod.client.module.visual.HitRangeModule;
import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import com.xoldium.xoldiummod.client.module.visual.DamageIndicatorModule;
import com.xoldium.xoldiummod.client.module.visual.FreeLookModule;
import com.xoldium.xoldiummod.client.module.visual.FullbrightModule;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import com.xoldium.xoldiummod.client.module.visual.NoHurtCamModule;
import com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule;
import com.xoldium.xoldiummod.client.module.visual.TimeChangerModule;
import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.client.ClientTickEvents;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Registry & dispatcher terpusat untuk seluruh {@link Module} Xoldium.
 *
 * <p>Setiap panggilan ke modul individual (tick, render) dibungkus
 * try/catch supaya satu modul yang error tidak pernah men-crash client -
 * lihat {@link Module#markCrashed}. Ini satu-satunya tempat
 * {@code HudRenderCallback} & {@code ClientTickEvents} Xoldium didaftarkan.
 */
public final class ModuleManager {

    private static final Map<String, Module> BY_ID = new LinkedHashMap<>();
    private static final List<Module> ALL = new ArrayList<>();
    private static boolean initialized = false;

    private ModuleManager() {
    }

    /** Dipanggil sekali dari {@code XoldiumModClient#onInitializeClient()}. */
    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;

        registerHudModules();
        registerOptimizationModules();
        registerMovementModules();
        registerVisualModules();

        loadState();

        HudRenderCallback.EVENT.register(ModuleManager::onHudRender);
        ClientTickEvents.END_CLIENT_TICK.register(client -> onClientTick());

        XoldiumMod.LOGGER.info("[Xoldium] {} modul terdaftar (HUD/Optimization/Movement/Visual).", ALL.size());
    }

    private static void registerHudModules() {
        register(new CreditHudModule());
        register(new FpsModule());
        register(new PingDisplayModule());
        register(new CpsCounterModule());
        register(new CoordinatesModule());
        register(new ClockHudModule());
        register(new DayCounterModule());
        register(new DirectionHudModule());
        register(new BiomeHudModule());
        register(new ArmorHudModule());
        register(new PotionHudModule());
        register(new SaturationHudModule());
        register(new KeystrokesModule());
        register(new ArrayListModule());
        register(new ComboCounterModule());
        register(new MemoryHudModule());
        register(new ServerInfoHudModule());
        register(new PackDisplayModule());
        register(new ChatTimestampsModule());

        // --- Modul baru (permintaan pemakai - daftar module id lengkap) ---
        register(new ActionBarHudModule());
        register(new BossBarHudModule());
        register(new BowChargeHudModule());
        register(new CrosshairTargetModule());
        register(new HotbarInfoModule());
        register(new ItemChangeHudModule());
        register(new PlayerInfoHudModule());
        register(new ScoreboardHudModule());
        register(new SettingsHintHudModule());
        register(new SpeedHudModule());
        register(new TimeHudModule());
        register(new TpsHudModule());
        register(new TotemCounterModule());
        register(new UhcOverlayModule());
    }

    private static void registerOptimizationModules() {
        XoldiumConfig cfg = XoldiumConfig.get();

        register(new OptimizationToggleModule("opt_master", "module.xoldiummod.opt_master",
                () -> cfg.enabled, v -> cfg.enabled = v, true));
        register(new OptimizationToggleModule("opt_entity_frustum", "module.xoldiummod.opt_entity_frustum",
                () -> cfg.entityFrustumCulling, v -> cfg.entityFrustumCulling = v, true)
                .withDoubleSetting("frustum_margin", "setting.xoldiummod.opt.frustum_margin",
                        cfg.frustumCullMargin, 0.0, 4.0, 0.25, v -> cfg.frustumCullMargin = v));
        register(new OptimizationToggleModule("opt_player_culling", "module.xoldiummod.opt_player_culling",
                () -> cfg.playerCulling, v -> cfg.playerCulling = v, false)
                .withDoubleSetting("min_distance", "setting.xoldiummod.opt.min_distance",
                        cfg.playerCullMinDistance, 0.0, 32.0, 2.0, v -> cfg.playerCullMinDistance = v));
        register(new OptimizationToggleModule("opt_block_entity_culling", "module.xoldiummod.opt_block_entity_culling",
                () -> cfg.blockEntityCulling, v -> cfg.blockEntityCulling = v, true)
                .withDoubleSetting("cull_margin", "setting.xoldiummod.opt.cull_margin",
                        cfg.blockEntityCullMargin, 0.0, 4.0, 0.25, v -> cfg.blockEntityCullMargin = v));
        register(new OptimizationToggleModule("opt_particle_frustum", "module.xoldiummod.opt_particle_frustum",
                () -> cfg.particleFrustumCulling, v -> cfg.particleFrustumCulling = v, true));
        register(new OptimizationToggleModule("opt_tile_entity_distance", "module.xoldiummod.opt_tile_entity_distance",
                () -> cfg.tileEntityDistanceCulling, v -> cfg.tileEntityDistanceCulling = v, false)
                .withDoubleSetting("cull_distance", "setting.xoldiummod.opt.cull_distance",
                        cfg.tileEntityCullDistance, 8.0, 128.0, 4.0, v -> cfg.tileEntityCullDistance = v));
        register(new OptimizationToggleModule("opt_fast_entity_rendering", "module.xoldiummod.opt_fast_entity_rendering",
                () -> cfg.fastEntityRendering, v -> cfg.fastEntityRendering = v, true)
                .withDoubleSetting("render_distance", "setting.xoldiummod.opt.render_distance",
                        cfg.fastEntityRenderDistance, 8.0, 96.0, 4.0, v -> cfg.fastEntityRenderDistance = v));
        register(new OptimizationToggleModule("opt_direct_particle_fastpath", "module.xoldiummod.opt_direct_particle_fastpath",
                () -> cfg.directParticleFastPath, v -> cfg.directParticleFastPath = v, true)
                .withDoubleSetting("safe_radius", "setting.xoldiummod.opt.safe_radius",
                        cfg.particleCullSafeRadius, 1.0, 16.0, 0.5, v -> cfg.particleCullSafeRadius = v));
        register(new OptimizationToggleModule("opt_occlusion_boost", "module.xoldiummod.opt_occlusion_boost",
                () -> cfg.occlusionCullingBoost, v -> cfg.occlusionCullingBoost = v, true)
                .withDoubleSetting("extra_margin", "setting.xoldiummod.opt.extra_margin",
                        com.xoldium.xoldiummod.client.core.FrustumContext.extraCullMargin, 0.0, 128.0, 8.0,
                        v -> com.xoldium.xoldiummod.client.core.FrustumContext.extraCullMargin = v));
        register(new OptimizationToggleModule("opt_mob_ai_throttle", "module.xoldiummod.opt_mob_ai_throttle",
                () -> cfg.mobAiThrottling, v -> cfg.mobAiThrottling = v, true)
                .withDoubleSetting("freeze_distance", "setting.xoldiummod.opt.freeze_distance",
                        cfg.mobAiFreezeDistance, 32.0, 256.0, 8.0, v -> cfg.mobAiFreezeDistance = v));
    }

    private static void registerMovementModules() {
        register(new SprintModule());
    }

    private static void registerVisualModules() {
        // Custom Block Highlight menggantikan Block Overlay & Blocks Modifier (dihapus).
        register(new CustomBlockHighlightModule());
        register(new HitRangeModule());
        register(new XoldiumTagModule());
        register(new DamageIndicatorModule());
        register(new FullbrightModule());
        register(new NoHurtCamModule());

        // --- Modul baru ---
        register(new FreeLookModule());
        register(new MotionBlurModule());
        register(new ScrollSettingsModule());
        register(new TimeChangerModule());
        register(new ZoomModule());
    }

    private static void register(Module module) {
        BY_ID.put(module.id(), module);
        ALL.add(module);
    }

    public static Module get(String id) {
        return BY_ID.get(id);
    }

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> byCategory(ModuleCategory category) {
        if (category == ModuleCategory.ALL) {
            return ALL;
        }
        return ALL.stream().filter(m -> m.category() == category).collect(Collectors.toList());
    }

    public static List<Module> search(ModuleCategory category, String query) {
        List<Module> base = byCategory(category);
        if (query == null || query.isBlank()) {
            return base;
        }
        String needle = query.toLowerCase(Locale.ROOT);
        return base.stream()
                .filter(m -> m.displayName().getString().toLowerCase(Locale.ROOT).contains(needle))
                .collect(Collectors.toList());
    }

    public static List<HudModule> hudModules() {
        List<HudModule> out = new ArrayList<>();
        for (Module m : ALL) {
            if (m instanceof HudModule hud) {
                out.add(hud);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------
    // Auto FPS Boost preset (tombol di tab Optimization)
    // ------------------------------------------------------------------

    /** Menyalakan seluruh toggle Optimization dengan nilai agresif yang direkomendasikan. */
    public static void applyAutoFpsBoostPreset() {
        for (Module m : byCategory(ModuleCategory.OPTIMIZATION)) {
            m.setEnabled(true);
        }
        XoldiumConfig cfg = XoldiumConfig.get();
        cfg.mobAiThrottleDistance = 32;
        cfg.mobAiFreezeDistance = 64.0;
        cfg.fastEntityRenderDistance = 24.0;
        cfg.tileEntityCullDistance = 32.0;
        cfg.frustumCullMargin = 0.5;
        saveState();
        XoldiumMod.LOGGER.info("[Xoldium] Preset 'Auto FPS Boost' diterapkan.");
    }

    // ------------------------------------------------------------------
    // Dispatch per-frame / per-tick (dibungkus try/catch per modul)
    // ------------------------------------------------------------------

    private static void onHudRender(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        for (HudModule hud : hudModules()) {
            if (!hud.isEnabled()) {
                continue;
            }
            try {
                hud.render(context, tickCounter);
            } catch (Throwable t) {
                hud.markCrashed(t);
            }
        }
    }

    private static void onClientTick() {
        for (Module m : ALL) {
            if (!m.isEnabled()) {
                continue;
            }
            try {
                m.onClientTick();
            } catch (Throwable t) {
                m.markCrashed(t);
            }
        }
    }

    // ------------------------------------------------------------------
    // Persistence
    // ------------------------------------------------------------------

    private static void loadState() {
        XoldiumConfig cfg = XoldiumConfig.get();
        for (Module m : ALL) {
            Boolean en = cfg.moduleEnabled.get(m.id());
            if (en != null) {
                m.setEnabledFromConfig(en);
            }

            if (m instanceof HudModule hud) {
                float[] t = cfg.hudTransform.get(m.id());
                if (t != null && t.length == 3) {
                    hud.setPosition(t[0], t[1]);
                    hud.setScale(t[2]);
                }
            }

            for (ModuleSetting<?> setting : m.settings()) {
                String key = m.id() + "." + setting.id();
                if (setting instanceof BooleanSetting bs) {
                    Boolean v = cfg.moduleBoolSettings.get(key);
                    if (v != null) bs.setFromConfig(v);
                } else if (setting instanceof DoubleSetting ds) {
                    Double v = cfg.moduleDoubleSettings.get(key);
                    if (v != null) ds.setFromConfig(v);
                } else if (setting instanceof ColorSetting cs) {
                    Integer v = cfg.moduleColorSettings.get(key);
                    if (v != null) cs.setFromConfig(v);
                } else if (setting instanceof ModeSetting ms) {
                    Integer v = cfg.moduleModeSettings.get(key);
                    if (v != null) ms.setFromConfig(v);
                }
            }
        }
    }

    /** Menyimpan state seluruh modul (enabled, posisi HUD, setting) ke {@link XoldiumConfig} dan menulis file. */
    public static void saveState() {
        if (!initialized) {
            return; // hindari menulis config parsial saat modul masih didaftarkan
        }
        XoldiumConfig cfg = XoldiumConfig.get();
        for (Module m : ALL) {
            cfg.moduleEnabled.put(m.id(), m.isToggledOn());

            if (m instanceof HudModule hud) {
                cfg.hudTransform.put(m.id(), new float[]{hud.x(), hud.y(), hud.scale()});
            }

            for (ModuleSetting<?> setting : m.settings()) {
                String key = m.id() + "." + setting.id();
                if (setting instanceof BooleanSetting bs) {
                    cfg.moduleBoolSettings.put(key, bs.get());
                } else if (setting instanceof DoubleSetting ds) {
                    cfg.moduleDoubleSettings.put(key, ds.get());
                } else if (setting instanceof ColorSetting cs) {
                    cfg.moduleColorSettings.put(key, cs.get());
                } else if (setting instanceof ModeSetting ms) {
                    cfg.moduleModeSettings.put(key, ms.get());
                }
            }
        }
        XoldiumConfig.save();
    }
}

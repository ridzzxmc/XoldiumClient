package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * TPS - PERKIRAAN tick rate dari jarak waktu nyata antar client tick
 * (client mod TIDAK punya akses ke waktu tick server sungguhan tanpa
 * plugin/mod sisi server) - paling akurat di singleplayer (client & server
 * terintegrasi berjalan di loop yang sama, jadi lag server ikut menunda
 * tick client juga); di server multiplayer ini hanya perkiraan kasar.
 */
public final class TpsHudModule extends HudModule {

    private long lastTickMs = System.currentTimeMillis();
    private double smoothedMspt = 50.0;

    public TpsHudModule() {
        super("tps", "module.xoldiummod.tps", false, 4f, 600f);
    }

    @Override
    public void onClientTick() {
        long now = System.currentTimeMillis();
        double delta = now - lastTickMs;
        lastTickMs = now;
        if (delta > 0 && delta < 2000) {
            smoothedMspt = smoothedMspt * 0.9 + delta * 0.1;
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        double tps = Math.min(20.0, 1000.0 / Math.max(1.0, smoothedMspt));
        HudRenderUtil.drawLine(context, this, String.format("TPS: ~%.1f", tps));
    }
}

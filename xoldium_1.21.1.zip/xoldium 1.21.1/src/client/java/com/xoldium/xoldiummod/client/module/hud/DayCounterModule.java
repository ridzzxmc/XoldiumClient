package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class DayCounterModule extends HudModule {

    public DayCounterModule() {
        super("day_counter", "module.xoldiummod.day_counter", false, 4f, 60f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        long day = client.world.getTimeOfDay() / 24000L;
        HudRenderUtil.drawLine(context, this, "Day: " + day);
    }
}

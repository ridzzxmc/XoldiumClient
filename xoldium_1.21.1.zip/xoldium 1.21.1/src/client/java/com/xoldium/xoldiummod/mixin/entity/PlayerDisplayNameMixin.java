package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.social.TotemPops;
import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Satu hook pada {@code PlayerEntity#getDisplayName} (teks yang dipakai
 * nametag) untuk dua fitur: logo Xoldium di depan nama (Xoldium Tag) dan
 * hitungan pop totem di belakang nama (Totem Counter - pola yang sama dengan
 * mod referensi Totem Counter). {@code require = 0}: bila target berubah di
 * versi lain, fitur ini hanya tidak tampil - game tidak crash.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerDisplayNameMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$decorateName(CallbackInfoReturnable<Text> cir) {
        try {
            PlayerEntity self = (PlayerEntity) (Object) this;
            Text text = cir.getReturnValue();
            Text decorated = TotemPops.decorate(self, text);
            decorated = XoldiumUsers.decorate(self, decorated);
            if (decorated != text) {
                cir.setReturnValue(decorated);
            }
        } catch (Throwable ignored) {
            // dekorasi nametag murni kosmetik - jangan pernah mengganggu game.
        }
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

/**
 * Action Bar - menyimpan & menampilkan ulang pesan action-bar (overlay)
 * terakhir yang diterima selama beberapa detik, ditangkap lewat
 * {@code mixin.hud.ActionBarCaptureMixin} (meng-inject
 * {@code InGameHud#setOverlayMessage}) - berguna bila pesannya sempat
 * terlewat/tertimpa vanilla terlalu cepat.
 */
public final class ActionBarHudModule extends HudModule {

    private static final long DISPLAY_DURATION_MS = 4000;

    private static volatile String lastMessage = "";
    private static volatile long capturedAtMs = 0L;

    public ActionBarHudModule() {
        super("actionbar", "module.xoldiummod.actionbar", false, 4f, 400f);
    }

    /** Dipanggil {@code ActionBarCaptureMixin} tiap kali vanilla menerima pesan overlay baru. */
    public static void capture(Text message) {
        if (message == null) {
            return;
        }
        lastMessage = message.getString();
        capturedAtMs = System.currentTimeMillis();
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (lastMessage.isEmpty() || System.currentTimeMillis() - capturedAtMs > DISPLAY_DURATION_MS) {
            return;
        }
        HudRenderUtil.drawLine(context, this, lastMessage);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawLine(context, this, lastMessage.isEmpty() ? "Action Bar" : lastMessage);
    }
}

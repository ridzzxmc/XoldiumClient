package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.FreeLookModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CATATAN VERIFIKASI MAPPING: {@code Camera#update(BlockView, Entity,
 * boolean, boolean, float)} adalah signature Yarn yang sudah stabil untuk
 * waktu yang sangat lama (kelas {@code Camera} jarang sekali dirombak).
 * Di-inject di {@code TAIL} (SETELAH vanilla selesai menyelaraskan rotasi
 * kamera ke entitas fokus seperti biasa) lalu ditimpa ulang lewat
 * {@code setRotation} - pendekatan ini SENGAJA dipilih dibanding meniru
 * ordinal injection ke method privat {@code alignWithEntity} pada mod
 * referensi (yang memakai mapping Mojang berbeda & tidak bisa dipastikan
 * ordinal call-nya tetap sama di Yarn), supaya risiko mixin gagal
 * ter-apply (= crash total saat start, lihat catatan Sesi 4 di
 * PERUBAHAN_XOLDIUM.md) jauh lebih kecil.
 *
 * <p><b>BUG SESI 10 (DIPERBAIKI):</b> parameter pertama method ini
 * SEBELUMNYA salah ditulis sebagai {@code World} - descriptor bytecode asli
 * Yarn-nya memakai tipe {@code BlockView} (superinterface {@code World}),
 * dan Mixin mencocokkan descriptor method APA ADANYA (nominal, bukan
 * structural/subtype) - {@code World} != {@code BlockView} di level
 * bytecode walau {@code World implements BlockView}. Akibatnya mixin ini
 * SELALU gagal ter-apply (dibungkam oleh {@code require = 0}, jadi tidak
 * crash, tapi juga tidak pernah aktif) -> {@link FreeLookModule#markCameraHookAlive()}
 * tidak pernah terpanggil -> {@link FreeLookModule#cameraHookAlive()} selalu
 * {@code false} -> {@code FreeLookEntityMixin} tidak pernah membatalkan
 * input mouse -> FreeLook TIDAK PERNAH benar-benar aktif sama sekali,
 * walau tombolnya ditekan. Ini penyebab tunggal laporan "FreeLook rusak"
 * di 1.21.1 MAUPUN 1.21.11 (bug yang sama persis ada di kedua port).
 */
@Mixin(Camera.class)
public abstract class FreeLookCameraMixin {

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V", at = @At("TAIL"), require = 0)
    private void xoldium$applyFreeLook(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        FreeLookModule.markCameraHookAlive();
        if (FreeLookModule.isActive() && focusedEntity == MinecraftClient.getInstance().player) {
            this.setRotation(FreeLookModule.getCameraYaw(), FreeLookModule.getCameraPitch());
        }
    }
}

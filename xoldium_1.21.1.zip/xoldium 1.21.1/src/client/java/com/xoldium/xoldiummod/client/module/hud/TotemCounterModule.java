package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.social.TotemPops;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

/**
 * Totem Counter (diperbaiki, mengikuti mod referensi Totem Counter uku3lig):
 * <ul>
 *   <li>HUD: ikon totem + jumlah totem di inventory ATAU jumlah pop milik sendiri.</li>
 *   <li>Nametag: "Nama | -N" untuk SEMUA pemain yang pernah pop (lihat {@link TotemPops}).</li>
 *   <li>Reset lewat keybind (default tidak diikat - atur di Module Setting).</li>
 * </ul>
 *
 * <p>Bug lama: hook {@code LivingEntity#handleStatus} TIDAK PERNAH terpanggil
 * untuk status totem (35) karena {@code ClientPlayNetworkHandler#onEntityStatus}
 * menanganinya sendiri (partikel + suara) tanpa meneruskan ke entity - itu
 * sebabnya counter selalu 0. Sekarang hook dipasang di
 * {@code onEntityStatus} ({@code mixin.entity.TotemPacketMixin}).
 */
public final class TotemCounterModule extends HudModule {

    private static TotemCounterModule instance;

    private final ModeSetting displayMode = addSetting(
            new ModeSetting("display_mode", "setting.xoldiummod.totem.display_mode", 0,
                    "setting.xoldiummod.totem.mode.inventory", "setting.xoldiummod.totem.mode.pops"));
    private final BooleanSetting colors = addSetting(
            new BooleanSetting("colors", "setting.xoldiummod.totem.colors", true));
    private final BooleanSetting nametag = addSetting(
            new BooleanSetting("nametag", "setting.xoldiummod.totem.nametag", true));
    private final BooleanSetting separator = addSetting(
            new BooleanSetting("separator", "setting.xoldiummod.totem.separator", true));
    private final KeyBinding resetKey;

    public TotemCounterModule() {
        super("totem_counter", "module.xoldiummod.totem_counter", false, 4f, 240f);
        instance = this;
        resetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.totem_reset", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("reset_key", "setting.xoldiummod.totem.reset_key", resetKey));
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static boolean showOnNametag() {
        return instance != null && instance.nametag.get();
    }

    public static boolean useSeparator() {
        return instance == null || instance.separator.get();
    }

    public static boolean useColors() {
        return instance == null || instance.colors.get();
    }

    @Override
    protected void onToggle(boolean enabled) {
        if (!enabled) {
            TotemPops.clear();
        }
    }

    @Override
    public void onClientTick() {
        while (resetKey.wasPressed()) {
            TotemPops.clear();
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            for (PlayerEntity p : client.world.getPlayers()) {
                if (!p.isAlive()) {
                    TotemPops.remove(p.getUuid());
                }
            }
        }
    }

    private static int inventoryTotems(PlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int count = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                count += stack.getCount();
            }
        }
        return count;
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        boolean pops = displayMode.index() == 1;
        int count = pops ? TotemPops.get(client.player.getUuid()) : inventoryTotems(client.player);
        String text = pops ? "-" + count : String.valueOf(count);
        int rgb = pops ? TotemPops.popColor(count) : TotemPops.totemColor(count);
        int color = colors.get() ? (0xFF000000 | rgb) : 0xFFFFFFFF;
        if (pops && count == 0) {
            color = 0xFFFFFFFF;
        }

        TextRenderer tr = client.textRenderer;
        int rawWidth = 22 + tr.getWidth(text) + 6;
        int rawHeight = 20;
        setMeasuredSize(rawWidth, rawHeight);

        int alpha = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0);
        // CATATAN VERIFIKASI MAPPING (port 1.21.1): getMatrices() di 1.21.1
        // masih MatrixStack lama (push/pop, translate & scale 3-argumen) -
        // Matrix3x2fStack/pushMatrix() baru ada mulai 1.21.8, lihat HudRenderUtil.
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0);
        context.getMatrices().scale(scale, scale, 1);
        context.fill(0, 0, rawWidth, rawHeight, alpha << 24);
        context.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), 2, 2);
        context.drawText(tr, text, 22, 6, color, true);
        context.getMatrices().pop();
    }
}

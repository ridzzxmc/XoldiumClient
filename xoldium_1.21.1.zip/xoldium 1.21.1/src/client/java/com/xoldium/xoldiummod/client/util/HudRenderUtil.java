package com.xoldium.xoldiummod.client.util;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Util render HUD bersama supaya seluruh modul teks Xoldium (FPS, Ping,
 * Coordinates, dst) punya gaya kotak label yang konsisten & satu tempat
 * untuk diperbaiki bila ada masalah tampilan - alih-alih setiap modul
 * menggambar kotaknya sendiri secara terpisah.
 *
 * <p>CATATAN VERIFIKASI MAPPING (diperbaiki untuk port 1.21.1): versi
 * SEBELUMNYA proyek ini (target 1.21.11) memakai
 * {@code org.joml.Matrix3x2fStack} ({@code pushMatrix()}, {@code popMatrix()},
 * {@code translate(x, y)} 2 argumen, {@code scale(x, y)} 2 argumen) dengan
 * asumsi API 2D itu sudah berlaku sejak ~1.21.2 - asumsi itu SALAH.
 * Dikonfirmasi lewat dokumentasi resmi Fabric: transform GUI 2D
 * ({@code Matrix3x2fStack}) baru dipakai mulai Minecraft <b>1.21.8</b>
 * (bagian dari perombakan render pipeline yang dimulai 1.21.6). Di 1.21.1,
 * {@link DrawContext#getMatrices()} masih mengembalikan
 * {@code net.minecraft.client.util.math.MatrixStack} gaya lama (3D 4x4,
 * dipakai bersama render dunia juga) dengan method {@code push()},
 * {@code pop()}, {@code translate(float x, float y, float z)} (3 argumen,
 * z=0 untuk GUI), dan {@code scale(float x, float y, float z)} (3 argumen,
 * z=1 untuk GUI 2D). Kode di bawah sudah disesuaikan ke API ini - JANGAN
 * dikembalikan ke {@code pushMatrix()}/{@code Matrix3x2fStack} selama masih
 * menyasar 1.21.1.
 */
public final class HudRenderUtil {

    public static final int TEXT_COLOR = 0xFFFFFFFF;
    /** Dulu biru ({@code 0xFF55C7F0}) - diganti abu sangat terang supaya baris "aksen" tetap sedikit beda dari teks biasa tanpa keluar dari skema hitam-putih. */
    public static final int ACCENT_COLOR = 0xFFE6E6E6;

    private HudRenderUtil() {
    }

    /** Warna latar hitam dengan alpha dari {@link HudModule#backgroundOpacity()} - 0.0 = transparan penuh (permintaan pemakai: "setting FPS background jadi transparan"). */
    private static int backgroundColor(HudModule module) {
        int alpha = (int) Math.round(module.backgroundOpacity() * 255.0);
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24);
    }

    /** Menggambar satu baris teks dengan latar semi-transparan pada posisi & skala modul, lalu mencatat ukuran terukur ke modul. */
    public static void drawLine(DrawContext context, HudModule module, String text) {
        drawLine(context, module, text, TEXT_COLOR);
    }

    public static void drawLine(DrawContext context, HudModule module, String text, int textColor) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = tr.getWidth(text) + 6;
        int rawHeight = tr.fontHeight + 4;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().push();
        context.getMatrices().translate(module.x(), module.y(), 0);
        context.getMatrices().scale(module.scale(), module.scale(), 1);

        context.fill(0, 0, rawWidth, rawHeight, backgroundColor(module));
        context.drawText(tr, text, 3, 2, textColor, true);

        context.getMatrices().pop();
    }

    /** Varian multi-baris (satu kotak latar menaungi semua baris). */
    public static void drawLines(DrawContext context, HudModule module, String... lines) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = 0;
        for (String line : lines) {
            rawWidth = Math.max(rawWidth, tr.getWidth(line));
        }
        rawWidth += 6;
        int lineHeight = tr.fontHeight + 1;
        int rawHeight = lineHeight * lines.length + 3;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().push();
        context.getMatrices().translate(module.x(), module.y(), 0);
        context.getMatrices().scale(module.scale(), module.scale(), 1);

        context.fill(0, 0, rawWidth, rawHeight, backgroundColor(module));
        int y = 2;
        for (String line : lines) {
            context.drawText(tr, line, 3, y, TEXT_COLOR, true);
            y += lineHeight;
        }

        context.getMatrices().pop();
    }
}

package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.AccountBadge;
import com.xoldium.xoldiummod.client.gui.IconRenderer;
import com.xoldium.xoldiummod.client.gui.XoldiumFonts;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumConfigScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * UI khas Xoldium Client di title screen - permintaan pemakai: "Buatkan
 * juga XoldiumClient ada UI nya sendiri seperti di foto Hyper Client yang
 * sudah aku kirim". Ditiru dari struktur foto referensi tsb: wordmark
 * brand + versi kecil di atas, dan kolom tombol kecil (Mod Menu/HUD
 * Editor/Settings - padanan "Language/Shots/Switch UI/Mod Menu" pada
 * referensi; tiga di sini sengaja hanya yang SUNGGUHAN fungsional di
 * Xoldium, bukan tombol dekorasi kosong) di sisi kiri layar - SEMUA murni
 * TAMBAHAN (additive) di atas title screen vanilla, sama seperti pada
 * foto referensi yang juga masih menampilkan tombol Singleplayer/
 * Multiplayer/Options/Quit Game bawaan Minecraft apa adanya di tengah,
 * tidak diganti/di-relayout sama sekali.
 *
 * <p>CATATAN VERIFIKASI PENTING: di Minecraft 1.21.11, {@code TitleScreen}
 * TERNYATA TIDAK LAGI meng-override {@code render(DrawContext,int,int,float)}
 * sendiri (dikonfirmasi lewat Yarn API docs {@code yarn-1.21.11+build.3} -
 * method itu sudah tidak ada di daftar method deklarasi {@code TitleScreen},
 * kemungkinan digantikan komponen {@code LogoDrawer} terpisah menyusul
 * perombakan render pipeline). Meng-Mixin {@code @Inject} ke {@code render}
 * pada {@code TitleScreen.class} langsung akan GAGAL dipasang (Mixin
 * apply error saat game start, karena method target harus benar-benar
 * DIDEKLARASIKAN di kelas yang di-{@code @Mixin}, bukan sekadar
 * ter-inherit). Solusinya: branding digambar lewat
 * {@code Screen#addDrawable(Drawable)} yang didaftarkan di dalam
 * {@code init()} (method yang TERKONFIRMASI ADA langsung di
 * {@code TitleScreen}) - {@code Drawable} adalah functional interface
 * ({@code render(DrawContext,int,int,float)}) sehingga bisa didaftarkan
 * sebagai lambda tanpa perlu Mixin kedua ke method render manapun sama
 * sekali.
 *
 * <p>Pola "mixin class extends Screen" di bawah ini standar untuk mixin
 * yang perlu memanggil method ter-inherit yang protected (di sini
 * {@code addDrawableChild}/{@code addDrawable}, dideklarasikan di
 * {@link Screen}, ter-inherit oleh {@link TitleScreen}) - constructor
 * tidak pernah benar-benar dipanggil saat runtime (Mixin transformer
 * menyuntikkan body method ke kelas target asli, {@code TitleScreen}),
 * murni supaya kelas ini kompilasi bersih.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    /**
     * BUG FIX (dilaporkan pemakai - screenshot menunjukkan kotak
     * hitam-magenta/checkerboard "missing texture" menimpa logo di title
     * screen): sebelumnya konstanta ini menunjuk ke
     * {@code textures/gui/title_logo.png}, sebuah file yang TIDAK PERNAH
     * ada di {@code src/main/resources/assets/xoldiummod/} (hanya
     * {@code logo.png} - badge "X" persegi, bukan banner lebar - yang
     * benar-benar ada). Minecraft otomatis mengganti tekstur yang gagal
     * di-load dengan pola checkerboard hitam-magenta bawaan - PERSIS
     * bentuk bug pada screenshot pemakai.
     *
     * <p>Banner "XOLDIUM CLIENT" itu sendiri SUDAH tampil benar tanpa
     * kode ini sama sekali - project ini juga meng-override tekstur
     * vanilla {@code assets/minecraft/textures/gui/title/minecraft.png}
     * (wordmark asli, 1024x265) yang digambar oleh {@code TitleScreen}
     * bawaan sendiri. Drawable kedua di sini dulu MENIMPA wordmark yang
     * sudah benar itu dengan file yang hilang - jadi solusinya bukan
     * mencari ganti file bannernya, tapi menghapus drawable kedua yang
     * duplikat & rusak ini sepenuhnya. Badge kecil {@code logo.png} (yang
     * BENAR-BENAR ada) dipakai sebagai gantinya, ukuran kecil di pojok
     * kiri-bawah dekat teks versi - bukan lagi banner lebar di tengah.
     */
    private static final Identifier BADGE_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int BADGE_SIZE = 14;

    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Unique
    private final Anim.Timeline xoldium$intro = new Anim.Timeline(520f);

    @Inject(method = "init()V", at = @At("TAIL"), require = 0)
    private void xoldium$addBrandingButtons(CallbackInfo ci) {
        int buttonWidth = 88;
        int buttonHeight = 18;
        int gap = 3;
        int x = 8;
        int startY = this.height / 2 - 30;

        ButtonWidget modMenu = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.mod_menu")), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(x, startY, buttonWidth, buttonHeight)
                .build());

        ButtonWidget hudEditor = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.hud_editor")), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new XoldiumHomeScreen(this));
                    }
                })
                .dimensions(x, startY + (buttonHeight + gap), buttonWidth, buttonHeight)
                .build());

        ButtonWidget settings = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.settings")), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new XoldiumConfigScreen(this));
                    }
                })
                .dimensions(x, startY + 2 * (buttonHeight + gap), buttonWidth, buttonHeight)
                .build());

        // Animasi masuk: kolom tombol meluncur dari kiri layar dengan jeda bertahap + fade.
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            ButtonWidget[] column = {modMenu, hudEditor, settings};
            for (int i = 0; i < column.length; i++) {
                float t = Anim.easeOutCubic(Anim.clamp01((xoldium$intro.elapsedMs() - i * 70f) / 380f));
                column[i].setX(Math.round(Anim.lerp(-buttonWidth - 8, x, t)));
                column[i].setAlpha(t);
            }
        });

        // Lencana akun Minecraft (username + kepala skin) di atas menu awal.
        this.addDrawable((context, mouseX, mouseY, delta) ->
                AccountBadge.render(context, this.textRenderer, this.width, 8));

        String version = FabricLoader.getInstance().getModContainer(XoldiumMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");

        // Drawable murni (bukan tombol) untuk badge kecil + teks versi - lihat javadoc
        // konstanta BADGE_TEXTURE di atas kenapa banner lebar lama DIHAPUS (bukan diganti
        // file lain) - wordmark "XOLDIUM CLIENT" sendiri sudah tampil dari override tekstur
        // vanilla, tidak digambar lagi di sini. Lihat juga javadoc kelas ini kenapa ini TIDAK
        // lewat @Inject ke render().
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            int textY = this.height - 20;
            IconRenderer.drawTexture(context, BADGE_TEXTURE, 4, textY - 3, BADGE_SIZE, BADGE_SIZE);
            context.drawText(this.textRenderer, Text.literal("Xoldium v" + version),
                    4 + BADGE_SIZE + 4, textY, 0xFFAAAAAA, true);
        });
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class DirectionHudModule extends HudModule {

    private static final String[] DIRECTIONS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

    public DirectionHudModule() {
        super("direction_hud", "module.xoldiummod.direction_hud", false, 4f, 74f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        float yaw = client.player.getYaw() % 360f;
        if (yaw < 0) yaw += 360f;
        int index = Math.round(yaw / 45f) & 7;
        HudRenderUtil.drawLine(context, this, DIRECTIONS[index] + " (" + Math.round(yaw) + "\u00B0)");
    }
}

package com.xoldium.xoldiummod.mixin.network;

import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Menyalakan bit penanda Xoldium ({@link XoldiumUsers#MARKER_BIT}) pada
 * {@code playerModelParts} di opsi klien yang dikirim ke server.
 *
 * <p>PENGGANTI {@code SyncedClientOptionsMixin} (dihapus): mixin lama
 * memodifikasi konstruktor record {@code SyncedClientOptions} di titik
 * HEAD sehingga Mixin menolaknya ("@ModifyVariable handler before this()
 * invocation must be static") dan koneksi ke server gagal dengan
 * "Mixin transformation of class_8791 failed". Sekarang hook berada di
 * {@code GameOptions#getSyncedOptions} pada titik RETURN (tanpa argumen
 * handler, tanpa variabel lokal, tanpa konstruktor) dan hasilnya diganti
 * lewat refleksi. Bila nama method tidak cocok -> mixin dilewati diam-diam
 * ({@code require = 0}); game & koneksi server tetap normal.
 */
@Mixin(GameOptions.class)
public abstract class SyncedOptionsMarkerMixin {

    @Inject(method = {"getSyncedOptions", "getClientOptions"}, at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$markOptions(CallbackInfoReturnable<Object> cir) {
        try {
            if (XoldiumTagModule.shouldBroadcast()) {
                Object original = cir.getReturnValue();
                Object marked = XoldiumUsers.markOptions(original);
                if (marked != original) {
                    cir.setReturnValue(marked);
                }
            }
        } catch (Throwable ignored) {
            // penanda kosmetik - jangan pernah mengganggu pembuatan opsi klien.
        }
    }
}

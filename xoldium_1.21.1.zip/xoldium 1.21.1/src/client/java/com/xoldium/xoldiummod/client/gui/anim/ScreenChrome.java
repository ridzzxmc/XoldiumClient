package com.xoldium.xoldiummod.client.gui.anim;

import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.gui.DrawContext;

/**
 * Gaya visual bersama layar Xoldium (panel gelap membulat + garis tepi) supaya
 * Mod Menu, Module Setting, HUD Editor, dll tampil seragam & profesional.
 */
public final class ScreenChrome {

    public static final int PANEL_BORDER = 0x55FFFFFF;
    public static final int CARD_BORDER = 0x30FFFFFF;
    public static final int ACCENT = 0xFFFFFFFF;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFF9A9AA0;

    /** Gaya latar menu (Settings > Menu Style): 0 = Transparent (default), 1 = Glass, 2 = Solid (gaya lama). */
    public static final int STYLE_COUNT = 3;

    // urutan: [Transparent, Glass, Solid]
    private static final int[] PANEL_BG = {0x80070708, 0xB00B0B0D, 0xF00B0B0D};
    private static final int[] CARD_BG = {0x70141416, 0xA0141416, 0xF0141416};
    private static final int[] CARD_BG_HOVER = {0x9022222A, 0xC01F1F23, 0xF01F1F23};
    private static final int[] DIM_TOP = {0x0C000000, 0x30050507, 0xC0050507};
    private static final int[] DIM_BOTTOM = {0x30000000, 0x60000000, 0xE0000000};

    private ScreenChrome() {
    }

    /** Gaya latar aktif (0..2) dari config. */
    public static int style() {
        int v = XoldiumConfig.get().menuStyle;
        return Math.max(0, Math.min(STYLE_COUNT - 1, v));
    }

    public static int panelBg() {
        return PANEL_BG[style()];
    }

    public static int cardBg() {
        return CARD_BG[style()];
    }

    public static int cardBgHover() {
        return CARD_BG_HOVER[style()];
    }

    /** Warna redup layar penuh (atas). Gaya Transparent hampir tidak meredupkan dunia sama sekali. */
    public static int dimTop() {
        return DIM_TOP[style()];
    }

    public static int dimBottom() {
        return DIM_BOTTOM[style()];
    }

    /** Persegi panjang dengan sudut "terpotong" 1px (kesan membulat tanpa tekstur). */
    public static void roundedFill(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        if (x2 - x1 < 4 || y2 - y1 < 4) {
            ctx.fill(x1, y1, x2, y2, color);
            return;
        }
        ctx.fill(x1 + 1, y1, x2 - 1, y2, color);
        ctx.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
        ctx.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    /** Border tipis 1px mengikuti bentuk {@link #roundedFill}. */
    public static void roundedBorder(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1 + 1, y1, x2 - 1, y1 + 1, color);
        ctx.fill(x1 + 1, y2 - 1, x2 - 1, y2, color);
        ctx.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
        ctx.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    /** Gradien vertikal sederhana (dipakai header panel). */
    public static void verticalGradient(DrawContext ctx, int x1, int y1, int x2, int y2, int top, int bottom) {
        int h = y2 - y1;
        for (int i = 0; i < h; i++) {
            ctx.fill(x1, y1 + i, x2, y1 + i + 1, Anim.lerpColor(top, bottom, h <= 1 ? 0f : i / (float) (h - 1)));
        }
    }
}

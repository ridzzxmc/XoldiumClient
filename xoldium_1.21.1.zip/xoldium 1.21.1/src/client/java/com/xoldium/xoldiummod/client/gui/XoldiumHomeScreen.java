package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Layar awal Xoldium (Right Shift) + HUD Editor.
 *
 * <p>HUD Editor (Sesi 8):
 * <ul>
 *   <li><b>Drag</b> elemen HUD dengan mouse/sentuhan. Drag dibaca dengan
 *       polling tombol kiri GLFW di {@link #render} - TANPA override
 *       {@code mouseClicked/mouseDragged/mouseReleased} (signature-nya
 *       berubah di 1.21.9+ menjadi Click/KeyInput), jadi aman di semua
 *       build.</li>
 *   <li><b>Tombol - / +</b> mengecilkan/membesarkan HUD terpilih (0.3x - 4.0x;
 *       HP tidak punya scroll wheel, itu sebabnya dulu "tidak bisa"), scroll
 *       wheel tetap berfungsi. Tombol panah menggeser 1 piksel, "1x"
 *       mengembalikan skala, Prev/Next memilih HUD tanpa perlu menyentuhnya.</li>
 *   <li><b>Garis sejajar (snap)</b> seperti di editor desain: sisi kiri/tengah/
 *       kanan &amp; atas/tengah/bawah menempel ke HUD lain dan ke tepi/tengah
 *       layar (garis merah muda = sumbu X, biru = sumbu Y), plus pembaca
 *       koordinat X/Y saat drag.</li>
 * </ul>
 * Dunia game tetap terlihat & berjalan di belakangnya (tanpa blur).
 */
public final class XoldiumHomeScreen extends Screen {

    private static final Identifier LOGO_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int LOGO_WIDTH = 68;
    private static final int LOGO_HEIGHT = 102;
    private static final float SNAP_THRESHOLD = 5f;
    private static final int GUIDE_X_COLOR = 0xFFFF5CC8;
    private static final int GUIDE_Y_COLOR = 0xFF5CD6FF;
    private static final int SELECT_COLOR = 0xFF5CD6FF;

    private HudModule selected;
    private boolean dragging;
    private float dragOffsetX;
    private float dragOffsetY;
    private boolean prevLeftDown;
    private boolean firstFrame = true;
    private float guideX = Float.NaN;
    private float guideY = Float.NaN;

    private final Screen parent;

    private final Anim.Timeline openTimeline = new Anim.Timeline(320f);
    private Anim.Timeline closeTimeline;
    private final Map<String, Anim.Smooth> hudHover = new HashMap<>();
    private ButtonWidget modMenuButton;
    private ButtonWidget settingsButton;
    private final List<ClickableWidget> toolButtons = new ArrayList<>();

    /** Dibuka lewat keybind saat bermain - tidak ada layar induk, menutup akan kembali ke game. */
    public XoldiumHomeScreen() {
        this(null);
    }

    /** Dibuka dari layar lain (mis. Mod Menu) - menutup akan kembali ke layar tsb. */
    public XoldiumHomeScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.home.title"));
        this.parent = parent;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Dunia game harus tetap jernih: tidak ada latar/blur bawaan Screen. */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    private float alpha() {
        if (closeTimeline != null) {
            return 1f - Anim.easeInOutCubic(closeTimeline.progress());
        }
        return Anim.easeOutCubic(openTimeline.progress());
    }

    @Override
    protected void init() {
        int buttonWidth = 180;
        int centerX = this.width / 2 - buttonWidth / 2;
        int buttonsY = this.height / 2 + 20;

        modMenuButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.open_mod_menu"), button -> {
                    if (this.client != null && closeTimeline == null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY, buttonWidth, 20)
                .build();
        this.addDrawableChild(modMenuButton);

        settingsButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.settings"), button -> {
                    if (this.client != null && closeTimeline == null) {
                        this.client.setScreen(new XoldiumConfigScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY + 24, buttonWidth, 20)
                .build();
        this.addDrawableChild(settingsButton);

        toolButtons.clear();
        addTool("Prev", 34, () -> cycleSelection(-1));
        addTool("Next", 34, () -> cycleSelection(1));
        addTool("-", 20, () -> changeScale(-0.1f));
        addTool("+", 20, () -> changeScale(0.1f));
        addTool("<", 20, () -> nudge(-1, 0));
        addTool("^", 20, () -> nudge(0, -1));
        addTool("v", 20, () -> nudge(0, 1));
        addTool(">", 20, () -> nudge(1, 0));
        addTool("1x", 24, this::resetScale);

        if (selected == null || !selected.isEnabled()) {
            selected = firstEnabledHud();
        }
    }

    private void addTool(String label, int width, Runnable action) {
        ButtonWidget b = ButtonWidget.builder(Text.literal(label), button -> {
                    if (closeTimeline == null) {
                        action.run();
                    }
                })
                .dimensions(0, 0, width, 20)
                .build();
        toolButtons.add(b);
        this.addDrawableChild(b);
    }

    // ------------------------------------------------------------------
    // Aksi HUD Editor
    // ------------------------------------------------------------------

    private static HudModule firstEnabledHud() {
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled()) {
                return hud;
            }
        }
        return null;
    }

    private void cycleSelection(int dir) {
        List<HudModule> enabled = new ArrayList<>();
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled()) {
                enabled.add(hud);
            }
        }
        if (enabled.isEmpty()) {
            selected = null;
            return;
        }
        int idx = selected == null ? -1 : enabled.indexOf(selected);
        idx = Math.floorMod(idx + dir, enabled.size());
        selected = enabled.get(idx);
    }

    private void changeScale(float delta) {
        if (selected == null) {
            return;
        }
        float value = Math.round((selected.scale() + delta) * 100f) / 100f;
        selected.setScale(value);
        clampInside(selected);
        ModuleManager.saveState();
    }

    private void resetScale() {
        if (selected == null) {
            return;
        }
        selected.setScale(1.0f);
        clampInside(selected);
        ModuleManager.saveState();
    }

    private void nudge(int dx, int dy) {
        if (selected == null) {
            return;
        }
        selected.setPosition(selected.x() + dx, selected.y() + dy);
        clampInside(selected);
        ModuleManager.saveState();
    }

    private void clampInside(HudModule hud) {
        float x = Math.max(0f, Math.min(this.width - hud.measuredWidth(), hud.x()));
        float y = Math.max(0f, Math.min(this.height - hud.measuredHeight(), hud.y()));
        hud.setPosition(x, y);
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float a = alpha();
        int slide = Math.round(16f * (1f - a));
        int buttonsY = this.height / 2 + 20 + slide;
        modMenuButton.setY(buttonsY);
        settingsButton.setY(buttonsY + 24);
        modMenuButton.setAlpha(a);
        settingsButton.setAlpha(a);

        pollPointer(mouseX, mouseY);
        layoutTools(a);

        // Tidak memanggil renderBackground() - dunia game tetap tampil apa adanya di belakang layar ini.
        context.fillGradient(0, 0, this.width, 46, Anim.withAlpha(0x70000000, a), 0x00000000);
        context.fillGradient(0, this.height - 76, this.width, this.height, 0x00000000, Anim.withAlpha(0x90000000, a));

        renderLogo(context, a, slide);
        renderHudEditorOverlay(context, mouseX, mouseY, a);
        renderGuides(context, a);
        renderInfoLine(context, a);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("gui.xoldiummod.home.hint"),
                this.width / 2, this.height - 14, Anim.withAlpha(0xFFB0B0B8, a));

        super.render(context, mouseX, mouseY, delta);

        if (closeTimeline != null && closeTimeline.progress() >= 1f && this.client != null) {
            this.client.setScreen(parent);
        }
    }

    private void layoutTools(float a) {
        int total = 0;
        for (ClickableWidget w : toolButtons) {
            total += w.getWidth() + 3;
        }
        total -= 3;
        int x = this.width / 2 - total / 2;
        int y = this.height - 40;
        boolean has = selected != null && selected.isEnabled();
        for (ClickableWidget w : toolButtons) {
            w.setX(x);
            w.setY(y);
            w.setAlpha(a);
            w.visible = true;
            w.active = has || w == toolButtons.get(0) || w == toolButtons.get(1);
            x += w.getWidth() + 3;
        }
    }

    private void renderInfoLine(DrawContext context, float a) {
        String text;
        if (selected != null && selected.isEnabled()) {
            text = String.format(Locale.ROOT, "%s   X: %d   Y: %d   %.2fx",
                    selected.displayName().getString(),
                    Math.round(selected.x()), Math.round(selected.y()), selected.scale());
        } else {
            text = Text.translatable("gui.xoldiummod.home.none_selected").getString();
        }
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(text),
                this.width / 2, this.height - 54, Anim.withAlpha(0xFFFFFFFF, a));
    }

    private void renderLogo(DrawContext context, float a, int slide) {
        int centerX = this.width / 2;
        int buttonsY = this.height / 2 + 20; // harus sama dengan init()
        int gapBeforeButtons = 14;
        int textHeight = this.textRenderer.fontHeight;

        int textY = buttonsY - gapBeforeButtons - textHeight;
        int logoY = Math.max(8, textY - 10 - LOGO_HEIGHT);

        if (a > 0.02f) {
            IconRenderer.drawTexture(context, LOGO_TEXTURE, centerX - LOGO_WIDTH / 2, logoY + slide, LOGO_WIDTH, LOGO_HEIGHT);
        }
        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold("XOLDIUM"),
                centerX, textY + slide, Anim.withAlpha(0xFFFFFFFF, a));
    }

    private void renderHudEditorOverlay(DrawContext context, int mouseX, int mouseY, float a) {
        List<HudModule> hudModules = ModuleManager.hudModules();
        RenderTickCounter tickCounter = this.client != null ? this.client.getRenderTickCounter() : null;
        if (tickCounter == null) {
            return;
        }

        for (HudModule hud : hudModules) {
            if (!hud.isEnabled()) {
                continue;
            }
            try {
                hud.renderPreview(context, tickCounter);
            } catch (Throwable t) {
                hud.markCrashed(t);
                continue;
            }

            boolean isSelected = hud == selected;
            boolean hovered = isHovering(hud, mouseX, mouseY);
            float target = hud == selected && dragging ? 1f : (isSelected ? 0.9f : (hovered ? 0.65f : 0.3f));
            float h = hudHover.computeIfAbsent(hud.id(), k -> new Anim.Smooth(0.3f, 14f)).update(target);
            int base = isSelected ? SELECT_COLOR : 0xFFFFFFFF;
            int borderColor = Anim.withAlpha(base, h * a);
            context.drawBorder((int) hud.x() - 1, (int) hud.y() - 1,
                    (int) hud.measuredWidth() + 2, (int) hud.measuredHeight() + 2, borderColor);
            if (h > 0.5f) {
                context.fill((int) hud.x() - 1, (int) hud.y() - 1,
                        (int) (hud.x() + hud.measuredWidth() + 1), (int) (hud.y() + hud.measuredHeight() + 1),
                        Anim.withAlpha(0x18FFFFFF, (h - 0.5f) * 2f * a));
            }
        }
    }

    private void renderGuides(DrawContext context, float a) {
        if (!dragging || selected == null) {
            return;
        }
        if (!Float.isNaN(guideX)) {
            int gx = Math.round(guideX);
            context.fill(gx, 0, gx + 1, this.height, Anim.withAlpha(GUIDE_X_COLOR, a));
        }
        if (!Float.isNaN(guideY)) {
            int gy = Math.round(guideY);
            context.fill(0, gy, this.width, gy + 1, Anim.withAlpha(GUIDE_Y_COLOR, a));
        }
        // pembaca koordinat X/Y di dekat HUD yang di-drag
        String label = String.format(Locale.ROOT, "X: %d  Y: %d", Math.round(selected.x()), Math.round(selected.y()));
        int lw = this.textRenderer.getWidth(label) + 6;
        int lx = Math.round(Math.max(2, Math.min(this.width - lw - 2, selected.x())));
        int ly = Math.round(selected.y()) - 13;
        if (ly < 2) {
            ly = Math.round(selected.y() + selected.measuredHeight()) + 3;
        }
        context.fill(lx, ly, lx + lw, ly + 11, Anim.withAlpha(0xC0000000, a));
        context.drawText(this.textRenderer, Text.literal(label), lx + 3, ly + 2, Anim.withAlpha(0xFFFFFFFF, a), false);
    }

    private boolean isHovering(HudModule hud, double mouseX, double mouseY) {
        return mouseX >= hud.x() && mouseX <= hud.x() + hud.measuredWidth()
                && mouseY >= hud.y() && mouseY <= hud.y() + hud.measuredHeight();
    }

    // ------------------------------------------------------------------
    // Pointer (polling GLFW - tanpa override input)
    // ------------------------------------------------------------------

    private static boolean leftDown(long handle) {
        try {
            return GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean overWidget(int mx, int my) {
        if (modMenuButton.isMouseOver(mx, my) || settingsButton.isMouseOver(mx, my)) {
            return true;
        }
        for (ClickableWidget w : toolButtons) {
            if (w.isMouseOver(mx, my)) {
                return true;
            }
        }
        return false;
    }

    private void pollPointer(int mx, int my) {
        if (this.client == null) {
            return;
        }
        boolean down = leftDown(this.client.getWindow().getHandle());
        if (firstFrame) {
            firstFrame = false;
            prevLeftDown = down; // klik yang membuka layar ini jangan dihitung sebagai press
            return;
        }
        if (closeTimeline != null) {
            prevLeftDown = down;
            return;
        }
        if (down && !prevLeftDown) {
            onPress(mx, my);
        } else if (down && dragging) {
            onDrag(mx, my);
        } else if (!down && prevLeftDown && dragging) {
            dragging = false;
            guideX = Float.NaN;
            guideY = Float.NaN;
            ModuleManager.saveState();
        }
        prevLeftDown = down;
    }

    private void onPress(int mx, int my) {
        if (overWidget(mx, my)) {
            return;
        }
        HudModule hit = null;
        float bestArea = Float.MAX_VALUE;
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled() && isHovering(hud, mx, my)) {
                float area = hud.measuredWidth() * hud.measuredHeight();
                if (area < bestArea) { // HUD paling kecil di bawah pointer menang (tidak tertutup yang besar)
                    bestArea = area;
                    hit = hud;
                }
            }
        }
        if (hit != null) {
            selected = hit;
            dragging = true;
            dragOffsetX = mx - hit.x();
            dragOffsetY = my - hit.y();
        }
    }

    private void onDrag(int mx, int my) {
        HudModule hud = selected;
        if (hud == null) {
            dragging = false;
            return;
        }
        float w = hud.measuredWidth();
        float h = hud.measuredHeight();
        float x = mx - dragOffsetX;
        float y = my - dragOffsetY;

        // ---- snap sumbu X: kiri/tengah/kanan HUD -> tepi/tengah layar & sisi HUD lain
        List<Float> xTargets = new ArrayList<>();
        List<Float> yTargets = new ArrayList<>();
        xTargets.add(0f);
        xTargets.add(this.width / 2f);
        xTargets.add((float) this.width);
        yTargets.add(0f);
        yTargets.add(this.height / 2f);
        yTargets.add((float) this.height);
        for (HudModule other : ModuleManager.hudModules()) {
            if (other == hud || !other.isEnabled()) {
                continue;
            }
            xTargets.add(other.x());
            xTargets.add(other.x() + other.measuredWidth() / 2f);
            xTargets.add(other.x() + other.measuredWidth());
            yTargets.add(other.y());
            yTargets.add(other.y() + other.measuredHeight() / 2f);
            yTargets.add(other.y() + other.measuredHeight());
        }

        guideX = Float.NaN;
        guideY = Float.NaN;
        float[] xEdges = {x, x + w / 2f, x + w};
        float bestDx = SNAP_THRESHOLD;
        for (float edge : xEdges) {
            for (float t : xTargets) {
                float d = t - edge;
                if (Math.abs(d) < Math.abs(bestDx)) {
                    bestDx = d;
                    guideX = t;
                }
            }
        }
        if (!Float.isNaN(guideX)) {
            x += bestDx;
        }

        float[] yEdges = {y, y + h / 2f, y + h};
        float bestDy = SNAP_THRESHOLD;
        for (float edge : yEdges) {
            for (float t : yTargets) {
                float d = t - edge;
                if (Math.abs(d) < Math.abs(bestDy)) {
                    bestDy = d;
                    guideY = t;
                }
            }
        }
        if (!Float.isNaN(guideY)) {
            y += bestDy;
        }

        x = Math.max(0f, Math.min(this.width - w, x));
        y = Math.max(0f, Math.min(this.height - h, y));
        hud.setPosition(Math.round(x), Math.round(y));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.allowHudScaleScroll()) {
            return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled() && isHovering(hud, mouseX, mouseY)) {
                selected = hud;
                hud.setScale(hud.scale() + (float) verticalAmount * com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.scaleStep());
                clampInside(hud);
                ModuleManager.saveState();
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    /** Menutup dengan fade halus (layar induk baru dipasang setelah animasi selesai). */
    @Override
    public void close() {
        if (closeTimeline == null) {
            ModuleManager.saveState();
            closeTimeline = new Anim.Timeline(160f);
        }
    }
}

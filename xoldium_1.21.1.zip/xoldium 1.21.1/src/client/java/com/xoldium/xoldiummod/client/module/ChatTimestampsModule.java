package com.xoldium.xoldiummod.client.module;

/**
 * Menambahkan timestamp "[HH:mm:ss]" di depan setiap pesan chat (lihat
 * {@code ChatHudTimestampMixin}). Bukan {@link HudModule} karena efeknya
 * mengubah rendering chat vanilla secara langsung, bukan menggambar
 * kotak HUD baru yang punya posisi/skala sendiri untuk di-drag di HUD
 * Editor - modul ini tetap muncul di tab "HUD" pada Mod Menu (toggle
 * biasa), hanya tidak muncul sebagai elemen yang bisa digeser di layar
 * HUD Editor.
 */
public final class ChatTimestampsModule extends Module {

    private static volatile ChatTimestampsModule instance;

    public ChatTimestampsModule() {
        super("chat_timestamps", "module.xoldiummod.chat_timestamps", ModuleCategory.HUD, false);
        instance = this;
    }

    /** Dibaca oleh {@code ChatHudTimestampMixin} - aman dipanggil sebelum modul terdaftar (fail-open ke false). */
    public static boolean isActive() {
        ChatTimestampsModule i = instance;
        return i != null && i.isEnabled();
    }
}

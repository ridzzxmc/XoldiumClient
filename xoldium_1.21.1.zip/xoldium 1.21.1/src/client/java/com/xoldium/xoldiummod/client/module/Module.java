package com.xoldium.xoldiummod.client.module;

import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Kelas dasar seluruh modul Xoldium (HUD/Optimization/Movement/Visual).
 *
 * <p>{@link ModuleManager} memanggil {@link #onClientTick()} (dan, untuk
 * {@link HudModule}, method render) lewat pembungkus try/catch per-modul:
 * bila satu modul melempar exception, HANYA modul itu yang otomatis
 * dimatikan (lihat {@link #markCrashed(Throwable)}) - modul lain & client
 * secara keseluruhan tetap berjalan normal. Ini adalah lapisan pertahanan
 * utama Xoldium terhadap crash akibat bug di satu modul.
 */
public abstract class Module {

    private final String id;
    private final String nameKey;
    private final ModuleCategory category;
    private final List<ModuleSetting<?>> settings = new ArrayList<>();

    private boolean enabled;
    private boolean crashed = false;

    protected Module(String id, String nameKey, ModuleCategory category, boolean defaultEnabled) {
        this.id = id;
        this.nameKey = nameKey;
        this.category = category;
        this.enabled = defaultEnabled;
    }

    public final String id() {
        return id;
    }

    public final String nameKey() {
        return nameKey;
    }

    public Text displayName() {
        return Text.translatable(nameKey);
    }

    public final ModuleCategory category() {
        return category;
    }

    public final boolean isEnabled() {
        return enabled && !crashed;
    }

    public final boolean isToggledOn() {
        return enabled;
    }

    public final boolean isCrashed() {
        return crashed;
    }

    /** Dipanggil GUI saat user menekan toggle. Menyimpan state lewat {@link ModuleManager}. */
    public final void setEnabled(boolean value) {
        boolean was = this.enabled;
        this.enabled = value;
        if (was != value) {
            try {
                onToggle(value);
            } catch (Throwable t) {
                markCrashed(t);
            }
        }
        ModuleManager.saveState();
    }

    /** Set enabled tanpa memicu {@link #onToggle} - hanya dipakai saat memuat config di awal. */
    public final void setEnabledFromConfig(boolean value) {
        this.enabled = value;
    }

    /** Hook opsional dipanggil saat modul di-toggle ON/OFF lewat GUI (bukan saat load config). */
    protected void onToggle(boolean enabled) {
    }

    /** Hook opsional: dipanggil setiap client tick bila modul aktif. Default no-op. */
    public void onClientTick() {
    }

    protected <T extends ModuleSetting<?>> T addSetting(T setting) {
        settings.add(setting);
        return setting;
    }

    /** Tambah setting yang hanya tampil di layar setting bila {@code visibleWhen} true. */
    protected <T extends ModuleSetting<?>> T addSetting(T setting, java.util.function.BooleanSupplier visibleWhen) {
        setting.setVisibleWhen(visibleWhen);
        settings.add(setting);
        return setting;
    }

    public List<ModuleSetting<?>> settings() {
        return settings;
    }

    public boolean hasSettings() {
        return !settings.isEmpty();
    }

    /** Dipanggil {@link ModuleManager} saat modul melempar exception - menonaktifkan modul secara aman. */
    public final void markCrashed(Throwable t) {
        if (!crashed) {
            crashed = true;
            com.xoldium.xoldiummod.XoldiumMod.LOGGER.error(
                    "[Xoldium] Modul '{}' dinonaktifkan otomatis karena error (client tetap berjalan normal).", id, t);
        }
    }
}

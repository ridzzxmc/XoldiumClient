package com.xoldium.xoldiummod.client.core;

import com.xoldium.xoldiummod.config.XoldiumConfig;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Sumber tunggal informasi frustum kamera untuk satu frame render.
 * Diperbarui lewat {@link net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents#START}
 * (API resmi Fabric Rendering, bukan mixin langsung ke internal
 * {@code WorldRenderer}), sehingga risiko konflik Mixin dengan mod
 * rendering lain (mis. Sodium/VulkanMod) praktis nihil.
 *
 * <p>Hasil visibilitas di-cache per frame untuk mengurangi kerja & alokasi
 * berulang. "Occlusion Culling Boost" menambahkan uji broad-phase murah
 * (jarak lurus ke kamera) sebelum uji frustum 6-plane penuh yang lebih mahal.
 */
public final class FrustumContext {

    private static volatile Frustum frustum;
    private static volatile Camera camera;
    private static volatile long frameId = 0L;
    private static volatile double cullSphereRadiusSq = Double.MAX_VALUE;
    /** Margin tambahan (blok) di atas radius otomatis berbasis render distance - setting "Extra Margin" milik modul Occlusion Culling Boost. */
    public static volatile double extraCullMargin = 0.0;

    // Cache TERPISAH untuk entity vs block-entity supaya key int/long dari
    // dua domain berbeda tidak pernah bentrok nilainya di satu set.
    private static final LongOpenHashSet visibleEntitiesThisFrame = new LongOpenHashSet(256);
    private static final LongOpenHashSet visibleBlockEntitiesThisFrame = new LongOpenHashSet(64);

    private FrustumContext() {
    }

    /** Dipanggil sekali per frame oleh {@link com.xoldium.xoldiummod.client.XoldiumModClient}. */
    public static void beginFrame(WorldRenderContext context) {
        frustum = context.frustum();
        camera = context.camera();
        frameId++;
        visibleEntitiesThisFrame.clear();
        visibleBlockEntitiesThisFrame.clear();

        int viewDistanceChunks = MinecraftClient.getInstance().options.getViewDistance().getValue();
        double radius = (viewDistanceChunks * 16.0) + 32.0 + extraCullMargin;
        cullSphereRadiusSq = radius * radius;
    }

    public static boolean isEntityVisible(long entityId, Box box) {
        return isVisible(visibleEntitiesThisFrame, entityId, box, XoldiumConfig.get().frustumCullMargin);
    }

    public static boolean isEntityVisible(long entityId, Box box, double marginOverride) {
        return isVisible(visibleEntitiesThisFrame, entityId, box, marginOverride);
    }

    public static boolean isBlockEntityVisible(long packedBlockPos, Box box) {
        return isVisible(visibleBlockEntitiesThisFrame, packedBlockPos, box, XoldiumConfig.get().frustumCullMargin);
    }

    /** Uji visibilitas TANPA cache per-frame - untuk posisi yang praktis selalu unik antar panggilan (mis. partikel). */
    public static boolean isPointVisible(Box box) {
        Frustum currentFrustum = frustum;
        if (currentFrustum == null) {
            return true;
        }
        if (XoldiumConfig.get().occlusionCullingBoost && failsBroadPhase(box)) {
            return false;
        }
        return currentFrustum.isVisible(box);
    }

    private static boolean isVisible(LongOpenHashSet cache, long cacheKey, Box box, double margin) {
        Frustum currentFrustum = frustum;
        if (currentFrustum == null) {
            return true; // fail-open: context belum tersedia
        }
        if (cache.contains(cacheKey)) {
            return true;
        }

        if (XoldiumConfig.get().occlusionCullingBoost && failsBroadPhase(box)) {
            return false;
        }

        Box tested = margin > 0.0 ? box.expand(margin) : box;

        boolean visible = currentFrustum.isVisible(tested);
        if (visible) {
            cache.add(cacheKey);
        }
        return visible;
    }

    private static boolean failsBroadPhase(Box box) {
        Camera currentCamera = camera;
        if (currentCamera == null) {
            return false;
        }
        Vec3d camPos = currentCamera.getPos();
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double dx = cx - camPos.x;
        double dy = cy - camPos.y;
        double dz = cz - camPos.z;
        return (dx * dx + dy * dy + dz * dz) > cullSphereRadiusSq;
    }

    public static Camera camera() {
        return camera;
    }

    public static long frameId() {
        return frameId;
    }
}

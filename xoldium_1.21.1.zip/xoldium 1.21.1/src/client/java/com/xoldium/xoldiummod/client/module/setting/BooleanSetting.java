package com.xoldium.xoldiummod.client.module.setting;

public final class BooleanSetting extends ModuleSetting<Boolean> {

    public BooleanSetting(String id, String nameKey, boolean defaultValue) {
        super(id, nameKey, defaultValue);
    }

    public void toggle() {
        set(!get());
    }
}

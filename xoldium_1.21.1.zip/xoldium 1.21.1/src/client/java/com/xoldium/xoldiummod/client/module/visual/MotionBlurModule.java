package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;

/**
 * Motion Blur - blur berbasis reprojection kecepatan kamera/dunia (lihat
 * {@link MotionBlurRenderer} untuk implementasi GPU-nya, hasil porting
 * dari source code "Smooth Motion Blur" yang dikirim pemakai).
 *
 * <p>Dua setting (muncul di gear-icon {@code ModuleSettingsScreen} kartu
 * ini) menjawab permintaan pemakai "setting Motion Blur kekuatan nya
 * seberapa": {@link #strengthSetting} (slider 0.05-5.0, dipetakan
 * langsung ke faktor blend internal shader) & {@link #pauseInGuisSetting}
 * (lewati blur saat GUI/inventory terbuka, supaya teks menu tidak ikut buram).
 */
public final class MotionBlurModule extends Module {

    private static MotionBlurModule instance;

    private final DoubleSetting strengthSetting = addSetting(
            new DoubleSetting("strength", "setting.xoldiummod.motionblur.strength", 1.0, 0.05, 5.0, 0.05));
    private final BooleanSetting pauseInGuisSetting = addSetting(
            new BooleanSetting("pause_in_guis", "setting.xoldiummod.motionblur.pause_in_guis", true));

    public MotionBlurModule() {
        super("motionblur", "module.xoldiummod.motionblur", ModuleCategory.VISUAL, false);
        instance = this;
    }

    @Override
    protected void onToggle(boolean enabled) {
        // Lupakan frame sebelumnya baik saat dimatikan (hindari sisa state basi)
        // maupun saat dinyalakan lagi (hindari lonjakan blur dari frame lama).
        MotionBlurRenderer.reset();
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static float strength() {
        return instance != null ? instance.strengthSetting.get().floatValue() : 1.0f;
    }

    public static boolean pauseInGuis() {
        return instance == null || instance.pauseInGuisSetting.get();
    }
}

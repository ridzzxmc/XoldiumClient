package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.social.TotemPops;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * INTI PERBAIKAN Totem Counter: status 35 ("pakai totem") ditangani langsung di
 * {@code onEntityStatus} (partikel + suara) dan TIDAK diteruskan ke
 * {@code Entity#handleStatus}. Mod referensi juga menghitung di titik ini
 * ({@code ClientPacketListener#handleEntityEvent}).
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class TotemPacketMixin {

    @Inject(method = "onEntityStatus(Lnet/minecraft/network/packet/s2c/play/EntityStatusS2CPacket;)V",
            at = @At("HEAD"), require = 0)
    private void xoldium$countTotemPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
        try {
            if (packet.getStatus() == 35 && MinecraftClient.getInstance().world != null) {
                Entity entity = packet.getEntity(MinecraftClient.getInstance().world);
                TotemPops.onPop(entity);
            }
        } catch (Throwable ignored) {
            // penghitung hanya kosmetik - jangan pernah mengganggu penanganan paket.
        }
    }
}

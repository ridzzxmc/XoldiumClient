package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.resource.ResourcePackManager;

import java.util.Collection;

public final class PackDisplayModule extends HudModule {

    public PackDisplayModule() {
        super("pack_display", "module.xoldiummod.pack_display", false, 4f, 148f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        ResourcePackManager manager = MinecraftClient.getInstance().getResourcePackManager();
        Collection<String> enabled = manager.getEnabledNames();
        String text = enabled.isEmpty() ? "Resource Pack: default" : "Pack: " + String.join(", ", enabled);
        HudRenderUtil.drawLine(context, this, text);
    }
}

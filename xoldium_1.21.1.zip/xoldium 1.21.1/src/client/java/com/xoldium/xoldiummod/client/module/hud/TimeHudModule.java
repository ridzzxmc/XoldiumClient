package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Time - waktu DALAM GAME (tick hari & fase siang/malam), beda dengan Clock HUD yang menampilkan jam dunia nyata. */
public final class TimeHudModule extends HudModule {

    public TimeHudModule() {
        super("time", "module.xoldiummod.time", false, 4f, 580f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        long time = client.world.getTimeOfDay() % 24000L;
        String phase;
        if (time < 12000) {
            phase = "Day";
        } else if (time < 13000) {
            phase = "Sunset";
        } else if (time < 23000) {
            phase = "Night";
        } else {
            phase = "Sunrise";
        }
        HudRenderUtil.drawLine(context, this, "Time: " + time + " (" + phase + ")");
    }
}

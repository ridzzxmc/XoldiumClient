package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** HUD credit permanen (bisa di-toggle): "Xoldium by ridzzxmc". Aktif secara default. */
public final class CreditHudModule extends HudModule {

    public CreditHudModule() {
        super("credit_hud", "module.xoldiummod.credit_hud", true, 4f, -1f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (y < 0) {
            // Posisi default: pojok kanan-bawah layar, dihitung sekali saat layar tersedia.
            int screenWidth = MinecraftClient.getInstance().getWindow().getScaledWidth();
            int screenHeight = MinecraftClient.getInstance().getWindow().getScaledHeight();
            x = screenWidth - 90f;
            y = screenHeight - 14f;
        }
        HudRenderUtil.drawLine(context, this, "Xoldium by ridzzxmc", HudRenderUtil.ACCENT_COLOR);
    }
}

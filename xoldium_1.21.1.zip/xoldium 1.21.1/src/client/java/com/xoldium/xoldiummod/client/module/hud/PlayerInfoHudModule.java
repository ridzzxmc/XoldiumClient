package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Player - baris info ringkas nyawa (HP) & absorption pemain dengan angka presisi (vanilla hanya menampilkan setengah-hati bulat). */
public final class PlayerInfoHudModule extends HudModule {

    public PlayerInfoHudModule() {
        super("player", "module.xoldiummod.player", false, 4f, 500f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        float hp = client.player.getHealth();
        float maxHp = client.player.getMaxHealth();
        float absorption = client.player.getAbsorptionAmount();
        HudRenderUtil.drawLine(context, this, String.format("HP: %.1f/%.1f  Absorb: %.1f", hp, maxHp, absorption));
    }
}

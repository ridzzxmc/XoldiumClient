package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.client.gui.AccountBadge;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumFonts;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Game Menu (pause): tombol "XoldiumClient" tepat di BAWAH tombol paling
 * bawah (Disconnect / Save and Quit) - klik membuka Mod Menu Xoldium; plus
 * lencana akun di pojok kanan-atas.
 *
 * <p>Posisi dihitung dari tombol paling bawah yang benar-benar ada (bukan
 * angka tetap) sehingga tetap pas walau layout tombol berubah / ditambah mod
 * lain (mis. Mod Menu menambah tombol "Mods"). {@code require = 0}: bila
 * target berubah, fitur ini hanya tidak muncul - game tetap normal.
 */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {

    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init()V", at = @At("TAIL"), require = 0)
    private void xoldium$addXoldiumButton(CallbackInfo ci) {
        ButtonWidget lowest = null;
        for (Element child : this.children()) {
            if (child instanceof ButtonWidget button && button.visible) {
                if (lowest == null || button.getY() + button.getHeight() > lowest.getY() + lowest.getHeight()) {
                    lowest = button;
                }
            }
        }
        if (lowest == null) {
            return; // menu jeda tanpa tombol (mis. F3+Esc) - tidak ada yang perlu ditambah
        }

        int y = lowest.getY() + lowest.getHeight() + 4;
        if (y + 20 > this.height - 2) {
            y = this.height - 22;
        }
        this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("XoldiumClient"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(lowest.getX(), y, lowest.getWidth(), 20)
                .build());

        this.addDrawable((context, mouseX, mouseY, delta) ->
                AccountBadge.render(context, this.textRenderer, this.width, 8));
    }
}

package com.xoldium.xoldiummod.client.gui.anim;

/**
 * Utilitas animasi GUI Xoldium: easing + nilai "halus" berbasis WAKTU NYATA
 * (bukan hitungan frame) supaya kecepatan animasi sama di berapa pun FPS.
 */
public final class Anim {

    private Anim() {
    }

    public static long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(1f, v);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float easeOutCubic(float t) {
        t = clamp01(t);
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    public static float easeInOutCubic(float t) {
        t = clamp01(t);
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    public static float easeOutBack(float t) {
        t = clamp01(t);
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        float x = t - 1f;
        return 1f + c3 * x * x * x + c1 * x * x;
    }

    /** Interpolasi linear warna ARGB. */
    public static int lerpColor(int from, int to, float t) {
        t = clamp01(t);
        int a = Math.round(lerp((from >>> 24) & 0xFF, (to >>> 24) & 0xFF, t));
        int r = Math.round(lerp((from >> 16) & 0xFF, (to >> 16) & 0xFF, t));
        int g = Math.round(lerp((from >> 8) & 0xFF, (to >> 8) & 0xFF, t));
        int b = Math.round(lerp(from & 0xFF, to & 0xFF, t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int withAlpha(int argb, float factor) {
        int a = Math.round(((argb >>> 24) & 0xFF) * clamp01(factor));
        return (a << 24) | (argb & 0x00FFFFFF);
    }

    /** Progres animasi sekali-jalan (mis. buka layar) 0..1 dari waktu mulai. */
    public static final class Timeline {
        private final long startMs = nowMs();
        private final float durationMs;

        public Timeline(float durationMs) {
            this.durationMs = durationMs;
        }

        public float progress() {
            return clamp01((nowMs() - startMs) / durationMs);
        }

        public float elapsedMs() {
            return nowMs() - startMs;
        }

        public float progress(float delayMs) {
            return clamp01((nowMs() - startMs - delayMs) / durationMs);
        }
    }

    /** Nilai yang bergerak halus menuju target (hover, scroll, posisi underline, dst). */
    public static final class Smooth {
        private float value;
        private long last = nowMs();
        private final float speed;

        /** speed ~ 12 = cepat (~150ms), ~6 = lambat. */
        public Smooth(float initial, float speed) {
            this.value = initial;
            this.speed = speed;
        }

        public float update(float target) {
            long now = nowMs();
            float dt = Math.min(0.1f, (now - last) / 1000f);
            last = now;
            value += (target - value) * Math.min(1f, speed * dt);
            if (Math.abs(target - value) < 0.002f) {
                value = target;
            }
            return value;
        }

        public float get() {
            return value;
        }

        public void snap(float v) {
            value = v;
            last = nowMs();
        }
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Item Update - menampilkan sekilas nama item di tangan tiap kali berganti (bukan tiap tick). */
public final class ItemChangeHudModule extends HudModule {

    private static final long DISPLAY_DURATION_MS = 2000;

    private Item lastItem = Items.AIR;
    private String cachedLabel = "";
    private long changedAtMs = 0L;

    public ItemChangeHudModule() {
        super("itemupdate", "module.xoldiummod.itemupdate", false, 4f, 480f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        ItemStack current = client.player.getMainHandStack();
        Item currentItem = current.getItem();
        if (currentItem != lastItem) {
            lastItem = currentItem;
            cachedLabel = current.isEmpty() ? "(empty hand)" : current.getName().getString();
            changedAtMs = System.currentTimeMillis();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (cachedLabel.isEmpty() || System.currentTimeMillis() - changedAtMs > DISPLAY_DURATION_MS) {
            return;
        }
        HudRenderUtil.drawLine(context, this, cachedLabel);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawLine(context, this, cachedLabel.isEmpty() ? "Item Update" : cachedLabel);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

public final class PingDisplayModule extends HudModule {

    public PingDisplayModule() {
        super("ping_display", "module.xoldiummod.ping_display", false, 4f, 18f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        int ping = -1;
        if (client.getNetworkHandler() != null && client.player != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) {
                ping = entry.getLatency();
            }
        }
        HudRenderUtil.drawLine(context, this, ping >= 0 ? "Ping: " + ping + "ms" : "Ping: --");
    }
}

package com.xoldium.xoldiummod.client.module.setting;

import net.minecraft.text.Text;

/** Setting pilihan (klik untuk berganti ke opsi berikutnya). Nilai = indeks opsi. */
public final class ModeSetting extends ModuleSetting<Integer> {

    private final String[] optionKeys;

    public ModeSetting(String id, String nameKey, int defaultIndex, String... optionKeys) {
        super(id, nameKey, Math.max(0, Math.min(optionKeys.length - 1, defaultIndex)));
        this.optionKeys = optionKeys;
    }

    public int count() {
        return optionKeys.length;
    }

    public int index() {
        return get();
    }

    public Text optionName(int index) {
        return Text.translatable(optionKeys[Math.floorMod(index, optionKeys.length)]);
    }

    public Text currentName() {
        return optionName(get());
    }

    public void cycle() {
        set((get() + 1) % optionKeys.length);
    }

    @Override
    public void setFromConfig(Integer value) {
        super.setFromConfig(Math.max(0, Math.min(optionKeys.length - 1, value)));
    }
}

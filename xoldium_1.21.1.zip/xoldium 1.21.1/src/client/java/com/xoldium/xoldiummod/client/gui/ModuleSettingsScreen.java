package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Layar Module Setting (ikon gear di kartu Mod Menu): panel animasi dengan
 * daftar setting yang bisa di-scroll - toggle, slider, pilihan (mode), warna
 * (pratinjau + slider R/G/B/Opacity) dan keybind. Setting bisa disembunyikan
 * kondisional (mis. warna gradient hanya muncul bila gradient dipilih).
 *
 * <p>Tidak ada override input (kecuali scroll): keybind ditangkap dengan
 * polling GLFW di {@link #render} - lihat {@link #pollCapture()}.
 */
public final class ModuleSettingsScreen extends XoldiumScreen {

    private static final int PANEL_W = 380;
    private static final int PAD = 12;
    private static final int HEADER_H = 40;
    private static final int FOOTER_H = 34;

    private final Module module;
    private final List<Row> rows = new ArrayList<>();
    private ButtonWidget resetButton;
    private ButtonWidget doneButton;

    private KeybindSetting capturing;
    private ButtonWidget capturingButton;
    private boolean captureArmed;

    private final Anim.Smooth scroll = new Anim.Smooth(0f, 14f);
    private float scrollTarget = 0f;
    private float contentHeight = 0f;

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(module.displayName(), parent);
        this.module = module;
    }

    @Override
    protected void init() {
        panelW = Math.min(PANEL_W, this.width - 16);
        panelH = Math.min(330, this.height - 16);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        rows.clear();

        int innerW = panelW - PAD * 2 - 6;

        // baris pertama: ON/OFF modul
        CyclingButtonWidget<Boolean> enabledButton = CyclingButtonWidget.onOffBuilder(module.isToggledOn())
                .build(0, 0, innerW, 20, Text.translatable("gui.xoldiummod.settings.module_enabled"),
                        (button, value) -> module.setEnabled(value));
        rows.add(new SingleRow(null, enabledButton, () -> enabledButton.setValue(module.isToggledOn())));
        this.addSelectableChild(enabledButton);

        for (ModuleSetting<?> setting : module.settings()) {
            if (setting instanceof BooleanSetting boolSetting) {
                CyclingButtonWidget<Boolean> widget = CyclingButtonWidget.onOffBuilder(boolSetting.get())
                        .build(0, 0, innerW, 20, boolSetting.displayName(), (button, value) -> boolSetting.set(value));
                rows.add(new SingleRow(setting, widget, () -> widget.setValue(boolSetting.get())));
                this.addSelectableChild(widget);
            } else if (setting instanceof DoubleSetting doubleSetting) {
                DoubleSettingSlider slider = new DoubleSettingSlider(innerW, 20, doubleSetting);
                rows.add(new SingleRow(setting, slider, slider::sync));
                this.addSelectableChild(slider);
            } else if (setting instanceof ModeSetting modeSetting) {
                ButtonWidget button = ButtonWidget.builder(modeLabel(modeSetting), b -> {
                            modeSetting.cycle();
                            b.setMessage(modeLabel(modeSetting));
                        })
                        .dimensions(0, 0, innerW, 20)
                        .build();
                rows.add(new SingleRow(setting, button, () -> button.setMessage(modeLabel(modeSetting))));
                this.addSelectableChild(button);
            } else if (setting instanceof ColorSetting colorSetting) {
                ColorRow row = new ColorRow(colorSetting, innerW);
                rows.add(row);
                for (ClickableWidget w : row.widgets()) {
                    this.addSelectableChild(w);
                }
            } else if (setting instanceof KeybindSetting keybindSetting) {
                ButtonWidget[] holder = new ButtonWidget[1];
                holder[0] = ButtonWidget.builder(keybindLabel(keybindSetting), b -> beginCapture(keybindSetting, b))
                        .dimensions(0, 0, innerW, 20)
                        .build();
                rows.add(new SingleRow(setting, holder[0], () -> holder[0].setMessage(keybindLabel(keybindSetting))));
                this.addSelectableChild(holder[0]);
            }
        }

        resetButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.settings.reset"), b -> resetAll())
                .dimensions(0, 0, 100, 20).build();
        doneButton = ButtonWidget.builder(Text.translatable("gui.done"), b -> this.close())
                .dimensions(0, 0, 100, 20).build();
        this.addDrawableChild(resetButton);
        this.addDrawableChild(doneButton);
    }

    private void resetAll() {
        if (isClosing()) {
            return;
        }
        for (ModuleSetting<?> setting : module.settings()) {
            if (!(setting instanceof KeybindSetting)) {
                setting.reset();
            }
        }
        for (Row row : rows) {
            row.sync();
        }
    }

    private static Text modeLabel(ModeSetting setting) {
        return setting.displayName().copy().append(": ").append(setting.currentName());
    }

    private static Text keybindLabel(KeybindSetting setting) {
        return setting.displayName().copy().append(": ").append(setting.binding().getBoundKeyLocalizedText());
    }

    // ------------------------------------------------------------------
    // Keybind capture (polling GLFW - tanpa override keyPressed/mouseClicked)
    // ------------------------------------------------------------------

    private void beginCapture(KeybindSetting setting, ButtonWidget button) {
        this.capturing = setting;
        this.capturingButton = button;
        this.captureArmed = false;
        button.setMessage(setting.displayName().copy()
                .append(": ").append(Text.translatable("gui.xoldiummod.settings.press_any_key")));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return capturing == null;
    }

    /**
     * Daftar tombol keyboard yang aman di-poll. Stub GLFW di Android
     * (Zalith/Pojav) memakai buffer kecil: memanggil
     * {@code glfwGetKey} untuk SEMUA kode 32..348 melempar
     * {@code IndexOutOfBoundsException} (crash "Rendering screen" yang
     * dilaporkan pemakai). Di sini hanya kode yang benar-benar dipakai
     * keyboard yang di-poll, tiap panggilan dibungkus try/catch, dan kode
     * yang pernah gagal dibuang dari daftar - jadi tidak mungkin crash.
     */
    private static final int[] POLL_KEYS = buildPollKeys();
    private static final boolean[] POLL_DEAD = new boolean[POLL_KEYS.length];

    private static int[] buildPollKeys() {
        List<Integer> keys = new ArrayList<>();
        keys.add(GLFW.GLFW_KEY_SPACE);
        keys.add(GLFW.GLFW_KEY_APOSTROPHE);
        for (int k = GLFW.GLFW_KEY_COMMA; k <= GLFW.GLFW_KEY_9; k++) keys.add(k);   // , - . / 0-9
        keys.add(GLFW.GLFW_KEY_SEMICOLON);
        keys.add(GLFW.GLFW_KEY_EQUAL);
        for (int k = GLFW.GLFW_KEY_A; k <= GLFW.GLFW_KEY_RIGHT_BRACKET; k++) keys.add(k); // A-Z [ \ ]
        keys.add(GLFW.GLFW_KEY_GRAVE_ACCENT);
        for (int k = GLFW.GLFW_KEY_ESCAPE; k <= GLFW.GLFW_KEY_END; k++) keys.add(k);      // Esc..End
        for (int k = GLFW.GLFW_KEY_CAPS_LOCK; k <= GLFW.GLFW_KEY_PAUSE; k++) keys.add(k);
        for (int k = GLFW.GLFW_KEY_F1; k <= GLFW.GLFW_KEY_F12; k++) keys.add(k);
        for (int k = GLFW.GLFW_KEY_KP_0; k <= GLFW.GLFW_KEY_KP_EQUAL; k++) keys.add(k);
        for (int k = GLFW.GLFW_KEY_LEFT_SHIFT; k <= GLFW.GLFW_KEY_RIGHT_SUPER; k++) keys.add(k);
        int[] out = new int[keys.size()];
        for (int i = 0; i < out.length; i++) out[i] = keys.get(i);
        return out;
    }

    private static int safeKey(long handle, int index) {
        if (POLL_DEAD[index]) {
            return GLFW.GLFW_RELEASE;
        }
        try {
            return GLFW.glfwGetKey(handle, POLL_KEYS[index]);
        } catch (Throwable t) {
            POLL_DEAD[index] = true; // kode ini tidak didukung stub GLFW perangkat - lewati selamanya
            return GLFW.GLFW_RELEASE;
        }
    }

    private static int safeMouse(long handle, int button) {
        try {
            return GLFW.glfwGetMouseButton(handle, button);
        } catch (Throwable t) {
            return GLFW.GLFW_RELEASE;
        }
    }

    private void pollCapture() {
        if (capturing == null || this.client == null) {
            return;
        }
        long handle = this.client.getWindow().getHandle();
        int pressedKey = -1;
        for (int i = 0; i < POLL_KEYS.length; i++) {
            if (safeKey(handle, i) == GLFW.GLFW_PRESS) {
                pressedKey = POLL_KEYS[i];
                break;
            }
        }
        int pressedMouse = -1;
        for (int b = 1; b <= 4; b++) { // tombol kiri (0) sengaja dilewati - itu yang memulai capture
            if (safeMouse(handle, b) == GLFW.GLFW_PRESS) {
                pressedMouse = b;
                break;
            }
        }
        if (pressedKey == -1 && pressedMouse == -1) {
            captureArmed = true; // semua tombol sudah dilepas sekali - mulai mendengarkan
            return;
        }
        if (!captureArmed) {
            return;
        }
        if (pressedKey == GLFW.GLFW_KEY_ESCAPE) {
            finishCapture(null);
            return;
        }
        try {
            InputUtil.Key key = pressedKey != -1
                    ? InputUtil.Type.KEYSYM.createFromCode(pressedKey)
                    : InputUtil.Type.MOUSE.createFromCode(pressedMouse);
            finishCapture(key);
        } catch (Throwable t) {
            finishCapture(null);
        }
    }

    private void finishCapture(InputUtil.Key key) {
        KeybindSetting setting = capturing;
        ButtonWidget button = capturingButton;
        capturing = null;
        capturingButton = null;
        if (setting != null && key != null) {
            setting.binding().setBoundKey(key);
            KeyBinding.updateKeysByCode();
            try {
                MinecraftClient.getInstance().options.write();
            } catch (Throwable ignored) {
                // simpan options.txt hanya kenyamanan - Minecraft menyimpannya sendiri saat keluar.
            }
        }
        if (setting != null && button != null) {
            button.setMessage(keybindLabel(setting));
        }
    }

    // ------------------------------------------------------------------
    // Layout & render
    // ------------------------------------------------------------------

    private int listTop() {
        return panelY + HEADER_H;
    }

    private int listBottom() {
        return panelY + panelH - FOOTER_H;
    }

    private void layout(int oy) {
        int viewH = listBottom() - listTop();
        float maxScroll = Math.max(0f, contentHeight - viewH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        float scrolled = scroll.update(scrollTarget);

        int x = panelX + PAD;
        float y = listTop() + 6 + oy - scrolled;
        float alpha = screenAlpha();
        for (Row row : rows) {
            if (!row.visible()) {
                row.setVisible(false);
                continue;
            }
            row.setVisible(true);
            row.layout(x, Math.round(y));
            row.setAlpha(alpha);
            y += row.height() + 4;
        }
        contentHeight = (y + scrolled) - (listTop() + 6 + oy) + 6;

        int fy = panelY + panelH - FOOTER_H + 7 + oy;
        int half = (panelW - PAD * 2 - 8) / 2;
        place(resetButton, panelX + PAD, fy, half, 20);
        place(doneButton, panelX + PAD + half + 8, fy, half, 20);
        resetButton.setAlpha(alpha);
        doneButton.setAlpha(alpha);
    }

    private static void place(ClickableWidget w, int x, int y, int width, int height) {
        w.setX(x);
        w.setY(y);
        w.setWidth(width);
        w.setHeight(height);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);
        pollCapture();

        int oy = slideOffset(18);
        layout(oy);
        float alpha = screenAlpha();

        int px1 = panelX;
        int py1 = panelY + oy;
        int px2 = panelX + panelW;
        int py2 = panelY + panelH + oy;

        ScreenChrome.roundedFill(context, px1, py1, px2, py2, Anim.withAlpha(ScreenChrome.panelBg(), alpha));
        ScreenChrome.roundedBorder(context, px1, py1, px2, py2, Anim.withAlpha(ScreenChrome.PANEL_BORDER, alpha));
        ScreenChrome.verticalGradient(context, px1 + 1, py1 + 1, px2 - 1, py1 + 30,
                Anim.withAlpha(0x22FFFFFF, alpha), Anim.withAlpha(0x00FFFFFF, alpha));

        context.drawText(this.textRenderer, XoldiumFonts.bold(this.title), px1 + PAD, py1 + 10,
                Anim.withAlpha(0xFFFFFFFF, alpha), false);
        context.drawText(this.textRenderer, Text.translatable("gui.xoldiummod.settings.subtitle"), px1 + PAD, py1 + 23,
                Anim.withAlpha(ScreenChrome.TEXT_DIM, alpha), false);
        context.fill(px1 + 8, py1 + HEADER_H - 2, px2 - 8, py1 + HEADER_H - 1, Anim.withAlpha(0x30FFFFFF, alpha));
        context.fill(px1 + 8, py2 - FOOTER_H, px2 - 8, py2 - FOOTER_H + 1, Anim.withAlpha(0x30FFFFFF, alpha));

        // daftar (di-clip ke area tengah)
        int top = listTop() + oy;
        int bottom = listBottom() + oy;
        context.enableScissor(px1 + 1, top, px2 - 1, bottom);
        for (Row row : rows) {
            if (row.visible()) {
                row.renderDecor(context, alpha);
                row.renderWidgets(context, mouseX, mouseY, delta);
            }
        }
        context.disableScissor();

        // scrollbar
        float viewH = bottom - top;
        float max = Math.max(0f, contentHeight - viewH);
        if (max > 0f) {
            int barH = Math.max(14, Math.round(viewH * (viewH / (viewH + max))));
            int barY = top + Math.round((viewH - barH) * (scroll.get() / max));
            context.fill(px2 - 5, barY, px2 - 3, barY + barH, Anim.withAlpha(0x66FFFFFF, alpha));
        }

        super.render(context, mouseX, mouseY, delta);

        endFrame();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isClosing()) {
            return true;
        }
        float viewH = listBottom() - listTop();
        float max = Math.max(0f, contentHeight - viewH);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget - (float) (verticalAmount * 30)));
        return true;
    }

    @Override
    protected void onClosing() {
        ModuleManager.saveState();
    }

    // ------------------------------------------------------------------
    // Row model
    // ------------------------------------------------------------------

    private abstract static class Row {
        abstract boolean visible();
        abstract int height();
        abstract void layout(int x, int y);
        abstract void setVisible(boolean v);
        abstract void setAlpha(float a);
        abstract void sync();
        void renderDecor(DrawContext context, float alpha) {
        }
        abstract void renderWidgets(DrawContext context, int mouseX, int mouseY, float delta);
    }

    private static final class SingleRow extends Row {
        private final ModuleSetting<?> setting;
        private final ClickableWidget widget;
        private final Runnable syncAction;

        SingleRow(ModuleSetting<?> setting, ClickableWidget widget, Runnable syncAction) {
            this.setting = setting;
            this.widget = widget;
            this.syncAction = syncAction;
        }

        @Override boolean visible() { return setting == null || setting.isVisible(); }
        @Override int height() { return widget.getHeight(); }
        @Override void layout(int x, int y) { widget.setX(x); widget.setY(y); }
        @Override void setVisible(boolean v) { widget.visible = v; }
        @Override void setAlpha(float a) { widget.setAlpha(a); }
        @Override void sync() { syncAction.run(); }
        @Override void renderWidgets(DrawContext context, int mouseX, int mouseY, float delta) {
            widget.render(context, mouseX, mouseY, delta);
        }
    }

    /** Grup warna: judul + kotak pratinjau + slider R/G/B(/A). */
    private final class ColorRow extends Row {
        private final ColorSetting setting;
        private final List<ChannelSlider> sliders = new ArrayList<>();
        private int x;
        private int y;
        private final int width;

        ColorRow(ColorSetting setting, int width) {
            this.setting = setting;
            this.width = width;
            int channels = setting.hasAlpha() ? 4 : 3;
            for (int c = 0; c < channels; c++) {
                int channel = c == 3 ? 3 : c;
                sliders.add(new ChannelSlider(width, 16, setting, channel));
            }
        }

        List<ClickableWidget> widgets() {
            return new ArrayList<>(sliders);
        }

        @Override boolean visible() { return setting.isVisible(); }
        @Override int height() { return 16 + sliders.size() * 18; }
        @Override void layout(int x, int y) {
            this.x = x;
            this.y = y;
            int sy = y + 16;
            for (ChannelSlider s : sliders) {
                s.setX(x);
                s.setY(sy);
                sy += 18;
            }
        }
        @Override void setVisible(boolean v) { for (ChannelSlider s : sliders) s.visible = v; }
        @Override void setAlpha(float a) { for (ChannelSlider s : sliders) s.setAlpha(a); }
        @Override void sync() { for (ChannelSlider s : sliders) s.sync(); }

        @Override void renderDecor(DrawContext context, float alpha) {
            context.drawText(textRenderer, setting.displayName(), x + 1, y + 3, Anim.withAlpha(0xFFFFFFFF, alpha), false);
            int sw = 34;
            int sx = x + width - sw;
            context.fill(sx - 1, y, sx + sw + 1, y + 13, Anim.withAlpha(0xFFFFFFFF, alpha * 0.8f));
            // papan catur tipis di belakang supaya transparansi terlihat
            context.fill(sx, y + 1, sx + sw, y + 12, Anim.withAlpha(0xFF3A3A3A, alpha));
            context.fill(sx, y + 1, sx + sw / 2, y + 6, Anim.withAlpha(0xFF6A6A6A, alpha));
            context.fill(sx + sw / 2, y + 6, sx + sw, y + 12, Anim.withAlpha(0xFF6A6A6A, alpha));
            int color = setting.hasAlpha() ? setting.argb() : (0xFF000000 | setting.argb());
            context.fill(sx, y + 1, sx + sw, y + 12, Anim.withAlpha(color, alpha));
        }

        @Override void renderWidgets(DrawContext context, int mouseX, int mouseY, float delta) {
            for (ChannelSlider s : sliders) {
                s.render(context, mouseX, mouseY, delta);
            }
        }
    }

    private static final String[] CHANNEL_NAMES = {"Red", "Green", "Blue", "Opacity"};

    private static final class ChannelSlider extends SliderWidget {
        private final ColorSetting setting;
        private final int channel;

        ChannelSlider(int width, int height, ColorSetting setting, int channel) {
            super(0, 0, width, height, Text.empty(), setting.channel(channel) / 255.0);
            this.setting = setting;
            this.channel = channel;
            updateMessage();
        }

        void sync() {
            this.value = setting.channel(channel) / 255.0;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Text.literal(CHANNEL_NAMES[channel] + ": " + setting.channel(channel)));
        }

        @Override
        protected void applyValue() {
            setting.setChannel(channel, (int) Math.round(this.value * 255.0));
        }
    }

    /** Slider vanilla yang terikat langsung ke satu {@link DoubleSetting}. */
    private static final class DoubleSettingSlider extends SliderWidget {

        private final DoubleSetting setting;

        DoubleSettingSlider(int width, int height, DoubleSetting setting) {
            super(0, 0, width, height, Text.empty(), setting.sliderProgress());
            this.setting = setting;
            updateMessage();
        }

        void sync() {
            this.value = setting.sliderProgress();
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(setting.displayName().copy()
                    .append(": ")
                    .append(Text.literal(setting.formatted())));
        }

        @Override
        protected void applyValue() {
            setting.setFromSliderProgress(this.value);
        }
    }
}

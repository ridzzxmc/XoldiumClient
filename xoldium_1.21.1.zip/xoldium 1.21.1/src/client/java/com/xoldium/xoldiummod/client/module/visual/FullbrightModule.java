package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * Fullbright - DUA lapis supaya PASTI bekerja:
 *
 * <ol>
 *   <li><b>Gamma</b>: {@code LightmapTextureManagerMixin} menimpa float gamma
 *       yang dibaca saat lightmap dihitung (teknik mod referensi Fullbright
 *       greenman999 - tidak menyentuh opsi Brightness pemain).</li>
 *   <li><b>Night Vision</b>: efek Night Vision KLIEN-saja tak terbatas
 *       (tanpa partikel/ikon) - tidak bergantung pada mixin sama sekali, jadi
 *       tetap bekerja walau hook gamma gagal terpasang di build tertentu.</li>
 * </ol>
 * Mode default "Both". Semua efek hanya aktif saat modul ON di Mod Menu;
 * saat OFF, efek Night Vision yang kita tambahkan dicabut lagi.
 */
public final class FullbrightModule extends Module {

    private final DoubleSetting brightness = addSetting(
            new DoubleSetting("brightness", "setting.xoldiummod.fullbright.brightness", 15.0, 1.0, 15.0, 0.5));
    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.fullbright.mode", 2,
                    "setting.xoldiummod.fullbright.mode.gamma",
                    "setting.xoldiummod.fullbright.mode.night_vision",
                    "setting.xoldiummod.fullbright.mode.both"));

    private static volatile FullbrightModule instance;
    private boolean appliedNightVision = false;

    public FullbrightModule() {
        super("fullbright", "module.xoldiummod.fullbright", ModuleCategory.VISUAL, false);
        instance = this;
    }

    private boolean useGamma() {
        return mode.index() == 0 || mode.index() == 2;
    }

    private boolean useNightVision() {
        return mode.index() == 1 || mode.index() == 2;
    }

    /** Dibaca {@code LightmapTextureManagerMixin} tiap frame (aman sebelum modul terdaftar). */
    public static boolean isActive() {
        FullbrightModule i = instance;
        return i != null && i.isEnabled() && i.useGamma();
    }

    public static float gamma() {
        FullbrightModule i = instance;
        return i != null ? i.brightness.get().floatValue() : 15.0f;
    }

    @Override
    protected void onToggle(boolean enabled) {
        if (!enabled) {
            removeNightVision();
        }
    }

    @Override
    public void onClientTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null) {
            appliedNightVision = false;
            return;
        }
        if (useNightVision()) {
            if (!player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, -1, 0, false, false, false));
                appliedNightVision = true;
            }
        } else if (appliedNightVision) {
            removeNightVision();
        }
    }

    private void removeNightVision() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (appliedNightVision && player != null) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        appliedNightVision = false;
    }
}

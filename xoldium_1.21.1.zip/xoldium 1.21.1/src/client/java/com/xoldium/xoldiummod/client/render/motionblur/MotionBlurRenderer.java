package com.xoldium.xoldiummod.client.render.motionblur;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.util.math.MathHelper;

/**
 * Motion Blur untuk build 1.21.1 - teknik "frame blending" (ghosting),
 * BUKAN velocity-based reprojection seperti versi 1.21.11.
 *
 * <p>PORTING NOTE (baca sebelum mengubah file ini): source "Smooth Motion
 * Blur" yang dikirim pemakai & implementasi {@code MotionBlurRenderer}
 * versi 1.21.11 proyek ini SAMA-SAMA ditulis langsung di atas abstraksi
 * GPU baru ({@code com.mojang.blaze3d.systems.GpuDevice}/{@code RenderPass}/
 * {@code RenderPipeline}, dst) yang menjadi bagian dari perombakan render
 * pipeline Minecraft - paket itu TIDAK ADA di 1.21.1 (dikonfirmasi lewat
 * riset & lewat audit "Sesi 9" proyek ini sendiri di PERUBAHAN_XOLDIUM.md,
 * yang sebelumnya melepas total fitur ini untuk 1.21.1 karena alasan yang
 * sama). Teknik reprojection berbasis matriks kamera & depth buffer milik
 * versi 1.21.11 karena itu TIDAK dipindah apa adanya ke sini.
 *
 * <p>Sebagai gantinya, kelas ini memakai teknik "Frame Blending" - salah
 * satu metode blur yang MEMANG disediakan mod referensi "Natural Motion
 * Blur" sendiri (lihat README-nya: "Multiple Blur Methods: Velocity
 * Based (Default), Frame Blending, ..."), dan bisa diimplementasikan
 * penuh di atas API {@link Framebuffer}/{@link SimpleFramebuffer} lama
 * yang sudah ada sejak lama & TIDAK terpengaruh perombakan pipeline di
 * atas. Cara kerja: dua {@link SimpleFramebuffer} dipakai bergantian
 * (ping-pong) sebagai "histori" - tiap frame, isi framebuffer utama
 * ({@code MinecraftClient#getFramebuffer()}) ditumpuk secara transparan
 * (alpha blend) di atas histori frame sebelumnya, menghasilkan efek jejak
 * (trailing ghost) yang mengaburkan gerakan - lalu hasilnya ditempel balik
 * ke framebuffer utama SEBELUM HUD/GUI digambar (supaya teks HUD tetap
 * tajam, tidak ikut buram, sama seperti perilaku versi 1.21.11).
 *
 * <p>Setting "strength" (0.05-5.0, warisan dari mod referensi & skala
 * shader velocity-nya) dipetakan ke faktor "decay" ghosting 0.0-0.9 lewat
 * {@link #decay()} - angka pastinya cuma perkiraan wajar (tidak ada
 * shader asli untuk dicocokkan formulanya di teknik ini), silakan
 * disesuaikan lewat slider di Mod Menu sampai terasa pas.
 *
 * <p>KENDALA JUJUR: environment pembuatan porting ini tidak punya
 * Minecraft/Gradle/internet untuk compile-test sungguhan (lihat
 * PERUBAHAN_XOLDIUM.md) - nama method {@link SimpleFramebuffer} &
 * {@link Framebuffer} di bawah diverifikasi lewat riset dokumentasi Yarn,
 * BUKAN lewat compiler. Bila proyek gagal compile tepat di file ini,
 * kemungkinan besar hanya nama/arity method {@code draw}/{@code beginWrite}/
 * {@code endWrite} pada {@link Framebuffer} atau konstruktor
 * {@link SimpleFramebuffer} yang sedikit berbeda di build Yarn yang
 * dipakai - cek {@code genSources} lalu sesuaikan baris terkait saja,
 * struktur/alur kelas ini sendiri tidak perlu diubah.
 */
public final class MotionBlurRenderer {

    private static SimpleFramebuffer bufferA;
    private static SimpleFramebuffer bufferB;
    private static int fbWidth;
    private static int fbHeight;
    private static boolean useAAsHistory = true;
    private static boolean historyReady;
    private static boolean disabledAfterError;
    private static boolean loggedFirstPass;

    private MotionBlurRenderer() {
    }

    /** Lupakan histori frame sebelumnya - dipanggil saat modul di-toggle, supaya tidak ada lonjakan blur dari state basi. */
    public static void reset() {
        historyReady = false;
    }

    /** Dipanggil dari {@code MotionBlurGameRendererMixin} tepat setelah dunia selesai dirender, sebelum HUD/GUI. */
    public static void onWorldRendered(MinecraftClient client) {
        if (disabledAfterError) {
            return;
        }
        boolean wantBlur = MotionBlurModule.isActive()
                && client.world != null
                && (!MotionBlurModule.pauseInGuis() || client.currentScreen == null);

        if (!wantBlur) {
            historyReady = false;
            return;
        }

        try {
            render(client);
        } catch (Throwable t) {
            disabledAfterError = true;
            closeAll();
            XoldiumMod.LOGGER.warn("[Xoldium] Motion blur dimatikan otomatis (galat render, kemungkinan API framebuffer "
                    + "sedikit berbeda di build Yarn ini) - modul tetap aman dipakai, hanya efek visualnya berhenti.", t);
        }
    }

    private static void render(MinecraftClient client) {
        Framebuffer main = client.getFramebuffer();
        int width = main.textureWidth;
        int height = main.textureHeight;
        if (width <= 0 || height <= 0) {
            return;
        }
        ensureSize(width, height);

        SimpleFramebuffer history = useAAsHistory ? bufferA : bufferB;
        SimpleFramebuffer target = useAAsHistory ? bufferB : bufferA;

        target.beginWrite(true);
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        if (historyReady) {
            history.draw(width, height);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f - decay());
            main.draw(width, height);
            RenderSystem.disableBlend();
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        } else {
            // Frame pertama sejak diaktifkan/di-resize - belum ada histori, isi apa adanya.
            main.draw(width, height);
        }
        target.endWrite();

        // Pastikan framebuffer utama kembali aktif secara eksplisit (jangan andalkan
        // asumsi arah bind balik endWrite() di atas) sebelum menempel hasil blend -
        // supaya render HUD/GUI sesudah hook ini tetap menuju target yang benar.
        main.beginWrite(true);
        target.draw(width, height);

        if (!loggedFirstPass) {
            loggedFirstPass = true;
            XoldiumMod.LOGGER.info("[Xoldium] Motion blur (frame blending) berjalan: {}x{}, decay={}", width, height, decay());
        }

        historyReady = true;
        useAAsHistory = !useAAsHistory;
    }

    /** strength 0.05-5.0 (skala warisan mod referensi) -> faktor ghosting 0.0-0.9 yang masuk akal untuk teknik ini. */
    private static float decay() {
        return MathHelper.clamp(MotionBlurModule.strength() * 0.3f, 0f, 0.9f);
    }

    private static void ensureSize(int width, int height) {
        if (bufferA != null && fbWidth == width && fbHeight == height) {
            return;
        }
        closeAll();
        bufferA = new SimpleFramebuffer(width, height, false, MinecraftClient.IS_SYSTEM_MAC);
        bufferB = new SimpleFramebuffer(width, height, false, MinecraftClient.IS_SYSTEM_MAC);
        fbWidth = width;
        fbHeight = height;
        historyReady = false;
    }

    private static void closeAll() {
        if (bufferA != null) {
            bufferA.delete();
            bufferA = null;
        }
        if (bufferB != null) {
            bufferB.delete();
            bufferB = null;
        }
        fbWidth = 0;
        fbHeight = 0;
        historyReady = false;
    }
}

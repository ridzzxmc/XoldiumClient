package com.xoldium.xoldiummod.mixin.hud;

import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * SESI 10: permintaan pemakai - "tambahkan dari tab juga ada icon
 * XoldiumClient nya" (daftar pemain yang muncul saat menahan Tab).
 *
 * <p>{@code PlayerListHud#getPlayerName(PlayerListEntry)} adalah method
 * Yarn yang sudah stabil bertahun-tahun (dikonfirmasi tidak berubah nama
 * ataupun signature sejak snapshot 1.16 hingga rilis-rilis terbaru).
 * Dekorasinya memakai logo & deteksi yang SAMA PERSIS dengan nametag
 * ({@link XoldiumUsers#decorate}) - jadi otomatis kompatibel silang: baik
 * yang memakai Xoldium versi 1.21.1 maupun 1.21.11 saling terlihat, karena
 * keduanya membaca bit penanda yang sama di data pemain ({@link XoldiumUsers#MARKER_BIT}).
 *
 * <p>Batasan yang disengaja: {@link PlayerListEntry} adalah data jaringan
 * (nama, skin, ping) yang TIDAK selalu terhubung ke entitas dunia nyata
 * (mis. pemain yang belum ter-render karena jarak) - deteksi bit penanda
 * di sini hanya berjalan untuk pemain yang entitasnya sudah dimuat client
 * (lewat {@code World#getPlayerByUuid}), sama seperti batasan alami HUD
 * nametag itu sendiri. {@code require = 0}: bila signature berubah di
 * versi lain, tab list tetap tampil normal tanpa ikon tambahan.
 */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$decorateTabName(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        try {
            if (entry == null || entry.getProfile() == null) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world == null) {
                return;
            }
            PlayerEntity player = client.world.getPlayerByUuid(entry.getProfile().getId());
            if (player == null) {
                return;
            }
            Text original = cir.getReturnValue();
            Text decorated = XoldiumUsers.decorate(player, original);
            if (decorated != original) {
                cir.setReturnValue(decorated);
            }
        } catch (Throwable ignored) {
            // dekorasi tab list murni kosmetik - jangan pernah mengganggu render.
        }
    }
}

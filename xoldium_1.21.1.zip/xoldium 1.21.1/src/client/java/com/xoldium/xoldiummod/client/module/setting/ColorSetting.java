package com.xoldium.xoldiummod.client.module.setting;

/**
 * Setting warna ARGB (0xAARRGGBB). Di layar setting tampil sebagai kotak
 * pratinjau + slider Red/Green/Blue (+ Opacity bila {@code withAlpha}).
 */
public final class ColorSetting extends ModuleSetting<Integer> {

    private final boolean hasAlpha;

    public ColorSetting(String id, String nameKey, int defaultArgb, boolean hasAlpha) {
        super(id, nameKey, defaultArgb);
        this.hasAlpha = hasAlpha;
    }

    public boolean hasAlpha() {
        return hasAlpha;
    }

    public int argb() {
        return get();
    }

    public int alpha() { return (get() >>> 24) & 0xFF; }
    public int red() { return (get() >> 16) & 0xFF; }
    public int green() { return (get() >> 8) & 0xFF; }
    public int blue() { return get() & 0xFF; }

    /** channel: 0=R 1=G 2=B 3=A */
    public void setChannel(int channel, int v) {
        v = Math.max(0, Math.min(255, v));
        int c = get();
        switch (channel) {
            case 0 -> c = (c & 0xFF00FFFF) | (v << 16);
            case 1 -> c = (c & 0xFFFF00FF) | (v << 8);
            case 2 -> c = (c & 0xFFFFFF00) | v;
            default -> c = (c & 0x00FFFFFF) | (v << 24);
        }
        set(c);
    }

    public int channel(int channel) {
        return switch (channel) {
            case 0 -> red();
            case 1 -> green();
            case 2 -> blue();
            default -> alpha();
        };
    }
}

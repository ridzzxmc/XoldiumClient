package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;
import java.util.Deque;

/** Menghitung klik kiri/kanan per detik lewat deteksi tepi (edge) tombol setiap client tick. */
public final class CpsCounterModule extends HudModule {

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public CpsCounterModule() {
        super("cps_counter", "module.xoldiummod.cps_counter", false, 90f, 4f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();

        boolean leftPressed = client.options.attackKey.isPressed();
        if (leftPressed && !wasLeftPressed) {
            leftClicks.addLast(now);
        }
        wasLeftPressed = leftPressed;

        boolean rightPressed = client.options.useKey.isPressed();
        if (rightPressed && !wasRightPressed) {
            rightClicks.addLast(now);
        }
        wasRightPressed = rightPressed;

        trim(leftClicks, now);
        trim(rightClicks, now);
    }

    private void trim(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawLine(context, this, "CPS: " + leftClicks.size() + " / " + rightClicks.size());
    }
}

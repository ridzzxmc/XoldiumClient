package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Jam waktu nyata (real-life clock) di sudut layar - bukan waktu in-game. */
public final class ClockHudModule extends HudModule {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ClockHudModule() {
        super("clock_hud", "module.xoldiummod.clock_hud", false, 4f, 46f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawLine(context, this, LocalTime.now().format(FORMAT));
    }
}

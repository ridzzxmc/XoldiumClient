package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;

/**
 * Scoreboard - baris ringkas judul & jumlah entri scoreboard sidebar aktif
 * (bila ada), memakai API publik {@link Scoreboard} langsung - TIDAK
 * mengganti/menyembunyikan render sidebar vanilla (menghindari mixin ke
 * bagian {@code InGameHud}/{@code ScoreboardHud} yang mappingnya kurang
 * pasti untuk versi ini), jadi ini murni info tambahan yang bisa
 * ditempatkan bebas lewat HUD Editor.
 */
public final class ScoreboardHudModule extends HudModule {

    public ScoreboardHudModule() {
        super("scoreboard", "module.xoldiummod.scoreboard", false, 4f, 520f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        Scoreboard scoreboard = client.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective == null) {
            return;
        }
        int count = scoreboard.getScoreboardEntries(objective).size();
        HudRenderUtil.drawLine(context, this, objective.getDisplayName().getString() + " (" + count + ")");
    }
}

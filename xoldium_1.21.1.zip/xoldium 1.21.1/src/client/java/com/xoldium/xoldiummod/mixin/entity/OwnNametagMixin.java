package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Vanilla tidak pernah menggambar nametag entitas kamera (diri sendiri).
 * Feather Client menampilkannya di third-person (F5) lengkap dengan
 * ikon - hook ini melakukan hal yang sama untuk Xoldium Tag. Descriptor
 * eksplisit + {@code require = 0}: bila tidak cocok, dilewati tanpa crash.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class OwnNametagMixin {

    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z", at = @At("RETURN"),
            cancellable = true, require = 0)
    private void xoldium$showOwnTag(LivingEntity entity, double squaredDistanceToCamera,
                                    CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValueZ() || !XoldiumTagModule.showOwnTag()) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || entity != client.player || entity.isInvisible()) {
                return;
            }
            if (client.options.hudHidden || client.options.getPerspective().isFirstPerson()) {
                return;
            }
            cir.setReturnValue(true);
        } catch (Throwable ignored) {
            // kosmetik - jangan pernah mengganggu render.
        }
    }
}

package com.xoldium.xoldiummod.mixin.hud;

import com.xoldium.xoldiummod.client.module.ChatTimestampsModule;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Menyisipkan prefix "[HH:mm:ss] " ke pesan chat sebelum ditambahkan ke
 * {@link ChatHud}, hanya bila {@link ChatTimestampsModule#isActive()}.
 *
 * <p>CATATAN VERIFIKASI MAPPING: menargetkan overload publik paling
 * sederhana {@code ChatHud#addMessage(Text)} (titik masuk pesan sistem/
 * chat biasa yang stabil di banyak versi Yarn). Verifikasi ulang lewat
 * {@code genSources}/IDE bila signature ini berubah pada mapping target.
 */
@Mixin(ChatHud.class)
public abstract class ChatHudTimestampMixin {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    @ModifyVariable(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), argsOnly = true, require = 0)
    private Text xoldium$prependTimestamp(Text message) {
        if (!ChatTimestampsModule.isActive()) {
            return message;
        }
        String prefix = "[" + LocalTime.now().format(TIME_FORMAT) + "] ";
        return Text.literal(prefix).formatted(net.minecraft.util.Formatting.GRAY).append(message);
    }
}

package com.xoldium.xoldiummod.client.module;

/**
 * Lima kategori modul Xoldium. {@code ALL} bukan kategori penyimpanan
 * modul sungguhan - hanya nilai filter tab di GUI yang berarti "tampilkan
 * gabungan seluruh kategori di bawah" (lihat ModListScreen).
 */
public enum ModuleCategory {
    ALL("category.xoldiummod.all"),
    HUD("category.xoldiummod.hud"),
    OPTIMIZATION("category.xoldiummod.optimization"),
    MOVEMENT("category.xoldiummod.movement"),
    VISUAL("category.xoldiummod.visual");

    private final String translationKey;

    ModuleCategory(String translationKey) {
        this.translationKey = translationKey;
    }

    public String translationKey() {
        return translationKey;
    }
}

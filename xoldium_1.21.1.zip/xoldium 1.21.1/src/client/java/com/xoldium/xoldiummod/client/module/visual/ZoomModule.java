package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom - model zoom diadaptasi dari Zoomify 2.15.2 (isXander, LGPL-3.0-or-later;
 * source untuk 1.21.11 dikirim pemakai). Yang diambil dari Zoomify:
 * <ul>
 *   <li><b>Initial Zoom</b> + <b>scroll bertingkat (tier)</b>: pembagi FOV =
 *       initialZoom x stepMultiplier^tier, tier 0..maxTier (geometris,
 *       supaya tiap langkah terasa sama besar).</li>
 *   <li>Transisi halus keluar-masuk zoom (di sini easing eksponensial di
 *       ruang logaritmik, berbasis WAKTU NYATA per frame).</li>
 *   <li><b>Relative Sensitivity</b>: sensitivitas mouse dibagi
 *       lerp(1, divisor, persen) - rumus yang sama dengan Zoomify.</li>
 *   <li>Mode Hold / Toggle, tombol Zoom In / Zoom Out terpisah (berguna di
 *       HP/tanpa scroll wheel), Reset otomatis saat zoom dilepas.</li>
 *   <li>Tangan (hand FOV) TIDAK ikut ter-zoom secara default - di
 *       {@code GameRenderer#getFov} panggilan world memakai
 *       {@code changingFov = true}, panggilan tangan {@code false}.</li>
 * </ul>
 * Kodenya ditulis ulang (bukan disalin) untuk Yarn/Java; karena tetap
 * turunan ide Zoomify, kredit & lisensinya dicantumkan di README.
 *
 * <p>Penyebab zoom "tidak bisa" versi lama: (1) tombol Zoom tidak bisa
 * diganti karena layar keybind crash di Android (GLFW stub) sehingga
 * tombol bawaan {@code C} tidak terjangkau kontrol sentuh; (2) semua
 * efek dikunci oleh modul harus ON. Sekarang layar keybind aman dan ada
 * tombol Zoom In / Zoom Out terpisah.
 */
public final class ZoomModule extends Module {

    private static ZoomModule instance;

    private final KeyBinding zoomKey;
    private final KeyBinding zoomInKey;
    private final KeyBinding zoomOutKey;

    private final DoubleSetting initialZoom = addSetting(
            new DoubleSetting("amount", "setting.xoldiummod.zoom.amount", 4.0, 1.5, 30.0, 0.5));
    private final DoubleSetting smoothness = addSetting(
            new DoubleSetting("smoothness", "setting.xoldiummod.zoom.smoothness", 12.0, 1.0, 40.0, 1.0));
    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", 0,
                    "setting.xoldiummod.zoom.mode.hold", "setting.xoldiummod.zoom.mode.toggle"));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final DoubleSetting scrollSteps = addSetting(
            new DoubleSetting("scroll_steps", "setting.xoldiummod.zoom.scroll_steps", 10.0, 1.0, 30.0, 1.0));
    private final DoubleSetting stepPercent = addSetting(
            new DoubleSetting("step_percent", "setting.xoldiummod.zoom.step_percent", 150.0, 105.0, 300.0, 5.0));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));
    private final DoubleSetting relativeSensitivity = addSetting(
            new DoubleSetting("relative_sensitivity", "setting.xoldiummod.zoom.relative_sensitivity", 50.0, 0.0, 100.0, 5.0),
            () -> this.reduceSensitivity.get());
    private final BooleanSetting affectHand = addSetting(
            new BooleanSetting("affect_hand", "setting.xoldiummod.zoom.affect_hand", false));

    private boolean zooming = false;
    private int tier = 0;
    /** Pembagi FOV yang sedang tampil (1.0 = tidak zoom). Di-ease di ruang logaritmik. */
    private double currentDivisor = 1.0;
    private long lastNanos = System.nanoTime();
    private boolean fovHookAlive = false;
    private boolean warnedNoHook = false;
    private int framesZoomingWithoutHook = 0;

    public ZoomModule() {
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, false);
        instance = this;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", zoomKey));
        addSetting(new KeybindSetting("key_in", "setting.xoldiummod.zoom.key_in", zoomInKey));
        addSetting(new KeybindSetting("key_out", "setting.xoldiummod.zoom.key_out", zoomOutKey));
    }

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        tier = 0;
        if (!enabled) {
            currentDivisor = 1.0;
        }
    }

    private int maxTier() {
        return (int) Math.round(scrollSteps.get());
    }

    @Override
    public void onClientTick() {
        boolean was = zooming;
        if (mode.index() == 0) {
            zooming = zoomKey.isPressed();
            while (zoomKey.wasPressed()) {
                // habiskan antrean klik supaya tidak menumpuk saat mode Hold
            }
        } else {
            while (zoomKey.wasPressed()) {
                zooming = !zooming;
            }
        }
        if (zooming) {
            while (zoomInKey.wasPressed()) {
                tier = Math.min(maxTier(), tier + 1);
            }
            while (zoomOutKey.wasPressed()) {
                tier = Math.max(0, tier - 1);
            }
        } else {
            while (zoomInKey.wasPressed()) {
                // abaikan saat tidak zoom
            }
            while (zoomOutKey.wasPressed()) {
                // abaikan saat tidak zoom
            }
            tier = 0; // seperti Zoomify: langkah scroll di-reset begitu zoom dilepas
        }
        tier = Math.max(0, Math.min(maxTier(), tier));

        // Diagnostik: bila zoom aktif tapi hook FOV tidak pernah terpanggil, beri tahu SEKALI di log.
        if (zooming && !fovHookAlive) {
            framesZoomingWithoutHook++;
            if (framesZoomingWithoutHook > 20 && !warnedNoHook) {
                warnedNoHook = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Zoom aktif tapi hook GameRenderer#getFov belum terpanggil - "
                        + "mixin ZoomFovMixin kemungkinan tidak ter-apply di versi ini (cek log 'ZoomFovMixin').");
            }
        }
        if (zooming != was && zooming) {
            framesZoomingWithoutHook = 0;
        }
    }

    private double targetDivisor() {
        if (!zooming) {
            return 1.0;
        }
        double perStep = stepPercent.get() / 100.0;
        return Math.max(1.0, initialZoom.get() * Math.pow(perStep, tier));
    }

    private void step() {
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - lastNanos) / 1_000_000_000.0);
        lastNanos = now;
        double target = Math.log(targetDivisor());
        double cur = Math.log(currentDivisor);
        double k = 1.0 - Math.exp(-smoothness.get() * dt);
        cur += (target - cur) * k;
        currentDivisor = Math.exp(cur);
        if (Math.abs(cur - target) < 0.0005) {
            currentDivisor = Math.exp(target);
        }
        if (currentDivisor < 1.0005 && !zooming) {
            currentDivisor = 1.0;
        }
    }

    // ------------------------------------------------------------------
    // API untuk mixin
    // ------------------------------------------------------------------

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.currentDivisor > 1.001);
    }

    /**
     * Dipanggil hook FOV. {@code worldPass} = argumen {@code changingFov} pada
     * {@code GameRenderer#getFov} (true = kamera dunia, false = tangan).
     */
    public static float applyZoom(float baseFov, boolean worldPass) {
        ZoomModule z = instance;
        if (z == null) {
            return baseFov;
        }
        z.fovHookAlive = true;
        if (!z.isEnabled()) {
            return baseFov;
        }
        if (worldPass) {
            z.step(); // satu kali per frame (pass dunia)
        }
        if (!worldPass && !z.affectHand.get()) {
            return baseFov;
        }
        if (z.currentDivisor <= 1.0005) {
            return baseFov;
        }
        return (float) Math.max(0.1, baseFov / z.currentDivisor);
    }

    /** Pengali delta kamera (sensitivitas) saat zoom - rumus Zoomify: 1 / lerp(1, divisor, persen). */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.reduceSensitivity.get() || z.currentDivisor <= 1.0005) {
            return 1.0;
        }
        double t = z.relativeSensitivity.get() / 100.0;
        double divisor = 1.0 + (z.currentDivisor - 1.0) * t;
        return 1.0 / Math.max(1.0, divisor);
    }

    /** Scroll mouse: true bila event dipakai zoom (jangan ganti slot hotbar). */
    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        z.tier = Math.max(0, Math.min(z.maxTier(), z.tier + (vertical > 0 ? 1 : -1)));
        return true;
    }

    /** Dipakai UI/HUD bila perlu tahu tier saat ini. */
    public static int currentTier() {
        return instance != null ? instance.tier : 0;
    }
}

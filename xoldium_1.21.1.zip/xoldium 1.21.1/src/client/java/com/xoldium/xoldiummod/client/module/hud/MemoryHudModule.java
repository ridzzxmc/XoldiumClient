package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class MemoryHudModule extends HudModule {

    public MemoryHudModule() {
        super("memory_hud", "module.xoldiummod.memory_hud", false, 4f, 102f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L);
        long maxMb = rt.maxMemory() / (1024L * 1024L);
        HudRenderUtil.drawLine(context, this, usedMb + " / " + maxMb + " MB");
    }
}

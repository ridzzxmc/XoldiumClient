package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hook FOV Zoom (pola yang sama dengan Zoomify: {@code getFov} di titik
 * RETURN). Di 1.21.11 {@code GameRenderer#getFov(Camera, float, boolean)}
 * mengembalikan {@code float}; argumen ketiga {@code true} = kamera dunia,
 * {@code false} = tangan (FOV tangan tidak ikut zoom kecuali diaktifkan).
 *
 * <p>Descriptor eksplisit + {@code require = 0}: bila tidak cocok, mixin
 * dilewati tanpa crash (ZoomModule mencatat peringatan di log).
 */
@Mixin(GameRenderer.class)
public abstract class ZoomFovMixin {

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F", at = @At("RETURN"),
            cancellable = true, require = 0)
    private void xoldium$zoomFov(Camera camera, float tickProgress, boolean changingFov,
                                 CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(ZoomModule.applyZoom(cir.getReturnValueF(), changingFov));
    }
}

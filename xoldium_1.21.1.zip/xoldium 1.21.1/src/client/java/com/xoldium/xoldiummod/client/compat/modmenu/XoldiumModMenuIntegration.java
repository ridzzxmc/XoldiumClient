package com.xoldium.xoldiummod.client.compat.modmenu;

import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Entrypoint {@code "modmenu"} - HANYA pernah di-load Fabric Loader bila
 * mod {@code modmenu} benar-benar ter-install, jadi TIDAK butuh dependency
 * wajib ke ModMenu di {@code fabric.mod.json}. Tombol "Config" Xoldium di
 * ModMenu membuka langsung {@link XoldiumHomeScreen} (layar awal + HUD
 * Editor + akses ke Mod Menu Xoldium sendiri) supaya pengalamannya identik
 * dengan membuka lewat keybind Right Shift.
 */
public final class XoldiumModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return XoldiumHomeScreen::new;
    }
}

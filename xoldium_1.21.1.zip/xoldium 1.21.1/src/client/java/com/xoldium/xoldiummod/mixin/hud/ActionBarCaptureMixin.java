package com.xoldium.xoldiummod.mixin.hud;

import com.xoldium.xoldiummod.client.module.hud.ActionBarHudModule;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CATATAN VERIFIKASI MAPPING: {@code InGameHud#setOverlayMessage(Text, boolean)}
 * adalah method Yarn yang dipanggil setiap kali server mengirim pesan
 * action-bar (overlay) - nama ini sudah dipakai luas & stabil selama
 * bertahun-tahun oleh mod pencatat pesan. Tetap verifikasi ulang lewat
 * {@code genSources}/IDE bila build Yarn proyek berubah.
 */
@Mixin(InGameHud.class)
public abstract class ActionBarCaptureMixin {

    @Inject(method = "setOverlayMessage(Lnet/minecraft/text/Text;Z)V", at = @At("HEAD"), require = 0)
    private void xoldium$captureOverlay(Text message, boolean tinted, CallbackInfo ci) {
        ActionBarHudModule.capture(message);
    }
}

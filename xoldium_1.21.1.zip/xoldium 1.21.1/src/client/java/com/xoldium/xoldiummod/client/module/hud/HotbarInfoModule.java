package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;

/** Hotbar - menampilkan nomor slot hotbar terpilih & nama item-nya sebagai elemen HUD yang bisa dipindah bebas. */
public final class HotbarInfoModule extends HudModule {

    public HotbarInfoModule() {
        super("hotbar", "module.xoldiummod.hotbar", false, 4f, 460f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        int slot = client.player.getInventory().getSelectedSlot() + 1;
        ItemStack stack = client.player.getInventory().getMainHandStack();
        String itemName = stack.isEmpty() ? "-" : stack.getName().getString();
        HudRenderUtil.drawLine(context, this, "Slot " + slot + ": " + itemName);
    }
}

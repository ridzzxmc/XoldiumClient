package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

/** Speed - kecepatan gerak horizontal pemain saat ini dalam block/detik, dihitung dari vektor kecepatan (20 tick/detik). */
public final class SpeedHudModule extends HudModule {

    public SpeedHudModule() {
        super("speed", "module.xoldiummod.speed", false, 4f, 560f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        Vec3d velocity = client.player.getVelocity();
        double speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z) * 20.0;
        HudRenderUtil.drawLine(context, this, String.format("Speed: %.2f b/s", speed));
    }
}

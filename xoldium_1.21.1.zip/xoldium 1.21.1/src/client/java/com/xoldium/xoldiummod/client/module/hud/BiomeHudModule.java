package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;

public final class BiomeHudModule extends HudModule {

    public BiomeHudModule() {
        super("biome_hud", "module.xoldiummod.biome_hud", false, 4f, 88f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }
        RegistryEntry<Biome> biome = client.world.getBiome(client.player.getBlockPos());
        String name = biome.getKey().map(key -> key.getValue().getPath()).orElse("unknown");
        HudRenderUtil.drawLine(context, this, "Biome: " + name);
    }
}

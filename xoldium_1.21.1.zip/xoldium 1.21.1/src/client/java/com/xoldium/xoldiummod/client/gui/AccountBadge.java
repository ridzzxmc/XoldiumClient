package com.xoldium.xoldiummod.client.gui;

import com.mojang.authlib.GameProfile;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.font.TextRenderer;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Lencana akun Minecraft (kepala skin + username) di pojok kanan-atas title
 * screen & game menu - meniru layout referensi (Feather): akun bernama "Ridzz"
 * tampil "Ridzz" dengan kepala skin yang sedang dipakai pemain.
 *
 * <p>Skin dicari lewat refleksi berbasis TIPE (bukan nama method) supaya tidak
 * pecah oleh perubahan nama antar versi Yarn: method {@code PlayerSkinProvider}
 * yang menerima {@link GameProfile} dan mengembalikan SkinTextures / Supplier /
 * CompletableFuture dicoba berurutan; kepala digambar lewat
 * {@link PlayerSkinDrawer} (juga via refleksi tipe). Bila SEMUA cara gagal
 * (mis. akun offline tanpa skin), jatuh ke avatar berhuruf inisial - lencana
 * tidak pernah menyebabkan crash.
 */
public final class AccountBadge {

    private static final long REFRESH_MS = 1500L;

    private static Object cachedSkin;
    private static long lastLookupMs = 0L;
    private static boolean lookupBroken = false;
    private static Method drawerMethod;
    private static boolean drawerResolved = false;
    private static final Anim.Timeline SHOWN = new Anim.Timeline(500f);

    private AccountBadge() {
    }

    public static String username() {
        try {
            return MinecraftClient.getInstance().getSession().getUsername();
        } catch (Throwable t) {
            return "Player";
        }
    }

    /** Gambar lencana rata kanan di (screenWidth - 8, y). */
    public static void render(DrawContext context, TextRenderer tr, int screenWidth, int y) {
        float a = Anim.easeOutCubic(SHOWN.progress());
        String name = username();
        var label = XoldiumFonts.medium(name);
        int textW = tr.getWidth(label);
        int face = 16;
        int w = 6 + face + 6 + textW + 10;
        int h = 26;
        int slide = Math.round((1f - a) * 10f);
        int x2 = screenWidth - 8;
        int x1 = x2 - w;
        int y1 = y - slide;

        ScreenChrome.roundedFill(context, x1, y1, x2, y1 + h, Anim.withAlpha(0xD0101012, a));
        ScreenChrome.roundedBorder(context, x1, y1, x2, y1 + h, Anim.withAlpha(0x60FFFFFF, a));

        int fx = x1 + 6;
        int fy = y1 + (h - face) / 2;
        if (!drawHead(context, fx, fy, face)) {
            int color = 0xFF000000 | (name.hashCode() & 0x00FFFFFF) | 0x00404040;
            context.fill(fx, fy, fx + face, fy + face, Anim.withAlpha(color, a));
            String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
            context.drawCenteredTextWithShadow(tr, initial, fx + face / 2, fy + 4, Anim.withAlpha(0xFFFFFFFF, a));
        }
        context.drawText(tr, label, fx + face + 6, y1 + (h - tr.fontHeight) / 2 + 1,
                Anim.withAlpha(0xFFFFFFFF, a), false);
    }

    // ------------------------------------------------------------------

    private static boolean drawHead(DrawContext context, int x, int y, int size) {
        if (lookupBroken) {
            return false;
        }
        try {
            resolveDrawer();
            if (drawerMethod == null) {
                return false;
            }
            long now = System.currentTimeMillis();
            if (cachedSkin == null || now - lastLookupMs > REFRESH_MS) {
                lastLookupMs = now;
                Object found = lookupSkin();
                if (found != null) {
                    cachedSkin = found;
                }
            }
            if (cachedSkin == null) {
                return false;
            }
            drawerMethod.invoke(null, context, cachedSkin, x, y, size);
            return true;
        } catch (Throwable t) {
            lookupBroken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Kepala skin akun tidak bisa digambar - memakai avatar inisial.", t);
            return false;
        }
    }

    /** PlayerSkinDrawer.draw(DrawContext, SkinTextures, int, int, int) - dicari lewat bentuk parameternya. */
    private static void resolveDrawer() {
        if (drawerResolved) {
            return;
        }
        drawerResolved = true;
        for (Method m : PlayerSkinDrawer.class.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (Modifier.isStatic(m.getModifiers()) && p.length == 5
                    && p[0] == DrawContext.class
                    && !p[1].isPrimitive() && p[1] != net.minecraft.util.Identifier.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) {
                m.setAccessible(true);
                drawerMethod = m;
                return;
            }
        }
    }

    private static Object lookupSkin() throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        Object provider = client.getSkinProvider();
        GameProfile profile = client.getGameProfile();
        if (provider == null || profile == null || drawerMethod == null) {
            return null;
        }
        Class<?> skinType = drawerMethod.getParameterTypes()[1];

        Method[] methods = provider.getClass().getMethods();
        // urutan prioritas: langsung SkinTextures -> Supplier -> CompletableFuture
        for (int pass = 0; pass < 3; pass++) {
            for (Method m : methods) {
                Class<?>[] p = m.getParameterTypes();
                if (p.length < 1 || p.length > 2 || p[0] != GameProfile.class) {
                    continue;
                }
                if (p.length == 2 && p[1] != boolean.class) {
                    continue;
                }
                Class<?> r = m.getReturnType();
                boolean match = switch (pass) {
                    case 0 -> skinType.isAssignableFrom(r);
                    case 1 -> Supplier.class.isAssignableFrom(r);
                    default -> CompletableFuture.class.isAssignableFrom(r);
                };
                if (!match) {
                    continue;
                }
                try {
                    Object result = p.length == 1 ? m.invoke(provider, profile) : m.invoke(provider, profile, false);
                    result = unwrap(result);
                    if (result != null && skinType.isInstance(result)) {
                        return result;
                    }
                } catch (Throwable ignored) {
                    // coba kandidat berikutnya
                }
            }
        }
        return null;
    }

    private static Object unwrap(Object o) {
        for (int i = 0; i < 4 && o != null; i++) {
            if (o instanceof Supplier<?> s) {
                o = s.get();
            } else if (o instanceof CompletableFuture<?> f) {
                o = f.getNow(null);
            } else if (o instanceof Optional<?> opt) {
                o = opt.orElse(null);
            } else {
                break;
            }
        }
        return o;
    }
}

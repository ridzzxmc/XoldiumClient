package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;

/**
 * Time Changer - mengunci waktu dunia ke nilai tertentu dengan mengirim
 * ulang perintah {@code /time set <ticks>} secara berkala selagi aktif.
 *
 * <p>CATATAN: ini BUKAN trik render client-only (Minecraft tidak
 * menyediakan cara resmi mengubah tampilan waktu di client tanpa
 * memengaruhi logika lain seperti waktu mob terbakar/spawn) - modul ini
 * betulan mengirim perintah command, jadi HANYA berefek bila pemain
 * berwenang menjalankannya (singleplayer dengan cheat aktif, atau operator
 * di server). Bila tidak berwenang, server akan menolak & perintah
 * ini tidak berefek apa pun (aman, tidak error).
 *
 * <p>CATATAN VERIFIKASI MAPPING: {@code ClientPlayNetworkHandler#sendChatCommand(String)}
 * adalah method Yarn yang sudah lama stabil untuk mengirim command dari
 * client (dipakai command-suggestion & banyak mod command lain). Tetap
 * verifikasi ulang lewat {@code genSources}/IDE bila build Yarn proyek
 * berubah, sesuai kebiasaan proyek ini.
 */
public final class TimeChangerModule extends Module {

    private static final int RESEND_INTERVAL_TICKS = 100; // 5 detik

    private final DoubleSetting targetTicks = addSetting(
            new DoubleSetting("target_ticks", "setting.xoldiummod.time_changer.target", 6000, 0, 24000, 1000));

    private int tickCounter = 0;

    public TimeChangerModule() {
        super("time_changer", "module.xoldiummod.time_changer", ModuleCategory.VISUAL, false);
    }

    @Override
    protected void onToggle(boolean enabled) {
        tickCounter = 0;
        if (enabled) {
            sendTimeCommand();
        }
    }

    @Override
    public void onClientTick() {
        tickCounter++;
        if (tickCounter >= RESEND_INTERVAL_TICKS) {
            tickCounter = 0;
            sendTimeCommand();
        }
    }

    private void sendTimeCommand() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.player.networkHandler == null) {
            return;
        }
        try {
            client.player.networkHandler.sendChatCommand("time set " + Math.round(targetTicks.get()));
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Time Changer gagal mengirim command (kemungkinan API berubah).", t);
        }
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Turunkan sensitivitas kamera pemain lokal selagi zoom (delta X & Y). */
@Mixin(Entity.class)
public abstract class ZoomLookMixin {

    @ModifyVariable(method = "changeLookDirection(DD)V", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private double xoldium$scaleYaw(double delta) {
        return (Object) this == MinecraftClient.getInstance().player ? delta * ZoomModule.lookScale() : delta;
    }

    @ModifyVariable(method = "changeLookDirection(DD)V", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private double xoldium$scalePitch(double delta) {
        return (Object) this == MinecraftClient.getInstance().player ? delta * ZoomModule.lookScale() : delta;
    }
}

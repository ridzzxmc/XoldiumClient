package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Penghitung "combo" sederhana (jumlah serangan beruntun ke entitas tanpa
 * jeda lama) berbasis deteksi tepi tombol serang + target crosshair -
 * murni visual/kasual, bukan penghitung hit-registration presisi server.
 */
public final class ComboCounterModule extends HudModule {

    private static final int TIMEOUT_TICKS = 60; // 3 detik tanpa serangan -> reset

    private int combo = 0;
    private int ticksSinceHit = 0;
    private boolean wasAttackPressed = false;

    public ComboCounterModule() {
        super("combo_counter", "module.xoldiummod.combo_counter", false, 90f, 18f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean attackPressed = client.options.attackKey.isPressed();

        if (attackPressed && !wasAttackPressed && client.crosshairTarget instanceof EntityHitResult) {
            combo++;
            ticksSinceHit = 0;
        }
        wasAttackPressed = attackPressed;

        if (combo > 0) {
            ticksSinceHit++;
            if (ticksSinceHit > TIMEOUT_TICKS) {
                combo = 0;
            }
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (combo <= 0) {
            return;
        }
        HudRenderUtil.drawLine(context, this, "Combo: x" + combo, HudRenderUtil.ACCENT_COLOR);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Crosshair - menampilkan nama block/entity yang sedang dibidik crosshair (bukan mengganti gambar crosshair itu sendiri). */
public final class CrosshairTargetModule extends HudModule {

    public CrosshairTargetModule() {
        super("crosshair", "module.xoldiummod.crosshair", false, 4f, 440f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        HitResult target = client.crosshairTarget;
        if (target == null || client.world == null) {
            return;
        }

        String label = switch (target.getType()) {
            case BLOCK -> {
                BlockHitResult blockHit = (BlockHitResult) target;
                yield client.world.getBlockState(blockHit.getBlockPos()).getBlock().getName().getString();
            }
            case ENTITY -> {
                Entity entity = ((EntityHitResult) target).getEntity();
                yield entity.getName().getString();
            }
            default -> null;
        };

        if (label == null) {
            return;
        }
        HudRenderUtil.drawLine(context, this, label);
    }
}

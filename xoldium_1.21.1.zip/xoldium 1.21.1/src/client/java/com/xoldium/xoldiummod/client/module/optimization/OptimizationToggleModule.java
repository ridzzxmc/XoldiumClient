package com.xoldium.xoldiummod.client.module.optimization;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.Supplier;

/**
 * Membungkus satu field boolean {@link XoldiumConfig} (culling/throttle
 * milik Xoldium sendiri) sebagai entri yang bisa di-toggle lewat Mod Menu,
 * kategori OPTIMIZATION. Toggle langsung menulis-tembus ke field config
 * yang sama yang dibaca oleh Mixin culling/throttle - tidak ada state
 * ganda yang bisa saling menyimpang.
 *
 * <p>Beberapa instance (lihat pemanggilan {@link #withDoubleSetting} di
 * {@code ModuleManager}) juga punya SATU parameter numerik nyata yang
 * memang sudah ada di {@link XoldiumConfig} (jarak render/cull) - muncul
 * sebagai slider di gear-icon-nya sendiri, nilainya ditulis-tembus ke
 * field config yang sama persis yang dibaca Mixin culling (lewat
 * {@link #onClientTick()}/{@link #onToggle}, BUKAN penyimpanan terpisah)
 * supaya tidak ada dua sumber kebenaran yang bisa saling menyimpang.
 * Instance yang TIDAK memanggil {@code withDoubleSetting} (mis. Player
 * Culling, Block Entity Culling, Occlusion Boost) sengaja dibiarkan tanpa
 * gear-icon - toggle ON/OFF-nya sendiri memang satu-satunya parameter yang
 * ada, menambah slider palsu yang tidak mengubah apa pun hanya akan
 * menyesatkan.
 */
public final class OptimizationToggleModule extends Module {

    private final Consumer<Boolean> setter;

    private DoubleSetting extraSetting;
    private DoubleConsumer extraSetter;

    /**
     * Setting UNIVERSAL kedua (setelah "Background Opacity" milik semua
     * modul HUD) - dimiliki SEMUA modul Optimization, termasuk yang tidak
     * punya parameter numerik tersendiri (Master Switch, Player Culling)
     * supaya tetap ada gear-icon dengan setting yang BENAR-BENAR berefek,
     * bukan sekadar hiasan.
     */
    private final BooleanSetting notifyOnToggle = addSetting(
            new BooleanSetting("notify_on_toggle", "setting.xoldiummod.optimization.notify_on_toggle", false));

    public OptimizationToggleModule(String id, String nameKey,
                                     Supplier<Boolean> getter, Consumer<Boolean> setter,
                                     boolean fallbackDefault) {
        super(id, nameKey, ModuleCategory.OPTIMIZATION, safeGet(getter, fallbackDefault));
        this.setter = setter;
    }

    /** Menambahkan satu slider numerik yang terhubung langsung ke field {@link XoldiumConfig} tertentu. Dipanggil langsung setelah konstruktor (gaya fluent) di {@code ModuleManager}. */
    public OptimizationToggleModule withDoubleSetting(String settingId, String settingNameKey,
                                                       double initialValue, double min, double max, double step,
                                                       DoubleConsumer configSetter) {
        this.extraSetting = addSetting(new DoubleSetting(settingId, settingNameKey, initialValue, min, max, step));
        this.extraSetter = configSetter;
        return this;
    }

    private static boolean safeGet(Supplier<Boolean> getter, boolean fallback) {
        try {
            Boolean v = getter.get();
            return v != null ? v : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        setter.accept(enabled);
        pushExtraSetting();
        XoldiumConfig.save();
        if (notifyOnToggle.get()) {
            notifyChat(enabled);
        }
    }

    private void notifyChat(boolean enabled) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.inGameHud != null) {
                client.inGameHud.getChatHud().addMessage(
                        Text.literal("[Xoldium] " + displayName().getString() + ": " + (enabled ? "ON" : "OFF")));
            }
        } catch (Throwable ignored) {
            // Notifikasi murni kosmetik - jangan sampai gagalnya ini mengganggu toggle sungguhan.
        }
    }

    @Override
    public void onClientTick() {
        pushExtraSetting();
    }

    private void pushExtraSetting() {
        if (extraSetting != null && extraSetter != null) {
            extraSetter.accept(extraSetting.get());
        }
    }
}

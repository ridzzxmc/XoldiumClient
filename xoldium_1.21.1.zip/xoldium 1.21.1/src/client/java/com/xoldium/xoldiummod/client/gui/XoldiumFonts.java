package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Font kustom "Inter" (regular/medium/bold) - diambil dari paket font yang
 * disiapkan pemakai (persis provider TTF yang dipakai Hyper Client sebagai
 * referensi UI, hanya namespace file diganti dari {@code hyperclient:} ke
 * {@code xoldiummod:} - lihat {@code assets/xoldiummod/font/inter*.json}).
 *
 * <p>Font kustom di Minecraft SELALU per-{@link Text} lewat
 * {@link Style#withFont(Identifier)} - TextRenderer global tidak diganti
 * total, hanya potongan teks yang secara eksplisit memakai {@link Style}
 * ini yang dirender pakai glyph Inter. Dipakai di teks branding/UI
 * kustom Xoldium sendiri (wordmark, tab, judul kartu, tombol Title
 * Screen) - widget vanilla murni (mis. {@code ButtonWidget} bawaan,
 * {@code SliderWidget} di {@link ModuleSettingsScreen}) TETAP pakai font
 * default vanilla karena rendering labelnya ditangani internal oleh
 * kelas widget itu sendiri, di luar kendali langsung kode ini.
 */
public final class XoldiumFonts {

    public static final Identifier REGULAR = Identifier.of(XoldiumMod.MOD_ID, "inter");
    public static final Identifier MEDIUM = Identifier.of(XoldiumMod.MOD_ID, "inter_medium");
    public static final Identifier BOLD = Identifier.of(XoldiumMod.MOD_ID, "inter_bold");

    private static final Style REGULAR_STYLE = Style.EMPTY.withFont(REGULAR);
    private static final Style MEDIUM_STYLE = Style.EMPTY.withFont(MEDIUM);
    private static final Style BOLD_STYLE = Style.EMPTY.withFont(BOLD);

    private XoldiumFonts() {
    }

    public static MutableText regular(String text) {
        return Text.literal(text).setStyle(REGULAR_STYLE);
    }

    public static MutableText medium(String text) {
        return Text.literal(text).setStyle(MEDIUM_STYLE);
    }

    public static MutableText bold(String text) {
        return Text.literal(text).setStyle(BOLD_STYLE);
    }

    /** Menempelkan style Inter Medium ke {@link Text} yang sudah ada (mis. hasil {@code Text.translatable}). */
    public static Text medium(Text text) {
        return text.copy().setStyle(MEDIUM_STYLE);
    }

    /** Menempelkan style Inter Bold ke {@link Text} yang sudah ada. */
    public static Text bold(Text text) {
        return text.copy().setStyle(BOLD_STYLE);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Settings - pengingat kecil keybind pembuka Mod Menu/HUD Editor Xoldium
 * saat ini (berguna bila lupa sudah diubah ke tombol apa lewat Controls).
 * Dicari lewat {@code client.options.allKeys} berdasarkan translation key
 * ("key.xoldiummod.open_menu") - BUKAN referensi langsung ke
 * {@code XoldiumModClient} - supaya tidak ada dependency balik dari paket
 * module ke client init.
 */
public final class SettingsHintHudModule extends HudModule {

    public SettingsHintHudModule() {
        super("settings", "module.xoldiummod.settings", false, 4f, 540f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        for (KeyBinding key : client.options.allKeys) {
            if ("key.xoldiummod.open_menu".equals(key.getTranslationKey())) {
                HudRenderUtil.drawLine(context, this, "Xoldium Menu: " + key.getBoundKeyLocalizedText().getString());
                return;
            }
        }
    }
}

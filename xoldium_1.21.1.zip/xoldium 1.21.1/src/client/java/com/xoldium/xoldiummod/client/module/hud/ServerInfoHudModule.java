package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.render.RenderTickCounter;

public final class ServerInfoHudModule extends HudModule {

    public ServerInfoHudModule() {
        super("server_info_hud", "module.xoldiummod.server_info_hud", false, 4f, 130f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ServerInfo info = client.getCurrentServerEntry();
        if (info == null) {
            HudRenderUtil.drawLine(context, this, "Singleplayer");
            return;
        }
        int online = client.getNetworkHandler() != null
                ? client.getNetworkHandler().getPlayerList().size()
                : 0;
        HudRenderUtil.drawLines(context, this, info.address, "Players: " + online);
    }
}

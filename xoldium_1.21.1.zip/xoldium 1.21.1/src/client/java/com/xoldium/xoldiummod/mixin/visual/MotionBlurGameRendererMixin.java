package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * SESI 10: motion blur diaktifkan kembali untuk 1.21.1 - lihat javadoc
 * {@link MotionBlurRenderer} untuk penjelasan lengkap kenapa tekniknya
 * berbeda dari versi 1.21.11 (ghosting berbasis {@code Framebuffer} lama,
 * bukan reprojection berbasis GPU baru).
 *
 * <p>Titik injeksi ini SENDIRI (method {@code render} pada
 * {@link GameRenderer}, tepat SETELAH {@code renderWorld} selesai) TIDAK
 * berubah antara 1.21.1 & 1.21.11 - {@code RenderTickCounter} sudah
 * menggantikan parameter {@code tickDelta} lama sejak Minecraft 1.21 di
 * KEDUA versi, dan {@code GameRenderer#renderWorld(RenderTickCounter)}
 * adalah salah satu titik render paling stabil/jarang dirombak di seluruh
 * codebase Minecraft - descriptor method di bawah SAMA PERSIS dengan versi
 * 1.21.11 proyek ini (yang sudah diverifikasi bekerja).
 */
@Mixin(GameRenderer.class)
public abstract class MotionBlurGameRendererMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(
            method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/GameRenderer;renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V",
                    shift = At.Shift.AFTER
            ),
            require = 0
    )
    private void xoldium$afterWorldRender(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        MotionBlurRenderer.onWorldRendered(this.client);
    }
}

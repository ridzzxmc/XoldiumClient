package com.xoldium.xoldiummod.client.social;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Deteksi pemain lain yang juga memakai Xoldium Client TANPA server/plugin
 * khusus.
 *
 * <p>Cara kerja: Minecraft mengirim "opsi klien" (bahasa, render distance,
 * dan {@code playerModelParts} = bitmask lapisan skin) ke server saat masuk
 * dunia, lalu server menyiarkan byte lapisan skin itu ke SEMUA pemain lain
 * lewat data tracker pemain. Vanilla hanya memakai bit 0-6; bit ke-7
 * ({@code 0x80}) tidak dipakai. Saat modul Xoldium Tag aktif,
 * {@code SyncedOptionsMarkerMixin} menyalakan bit itu di opsi klien kita
 * sendiri, dan di sisi pemain lain kita cukup membaca bit tersebut - bila
 * menyala, orang itu pasti memakai Xoldium Client. Berjalan di server
 * vanilla/Paper/dll yang meneruskan byte itu apa adanya; server yang
 * menyaring byte tsb otomatis membuat logo tidak muncul (aman, tidak ada
 * efek lain).
 *
 * <p>PERBAIKAN Sesi 8: (1) sejak Minecraft 1.21.9 field data tracker skin
 * pindah dari {@code PlayerEntity} ke superclass-nya (Avatar) - pemindaian
 * lama hanya membaca PlayerEntity sehingga log menulis "Tidak menemukan
 * TrackedData&lt;Byte&gt;" dan logo tidak pernah muncul; sekarang seluruh
 * hierarki sampai (tidak termasuk) LivingEntity dipindai. (2) Penanda
 * dipasang dengan mengganti objek opsi yang DIKEMBALIKAN
 * {@code GameOptions#getSyncedOptions} (refleksi record) - bukan lagi
 * memodifikasi konstruktor record (penyebab error "handler before this()
 * invocation must be static" & gagal masuk server).
 */
public final class XoldiumUsers {

    /** Bit penanda pada byte lapisan skin. */
    public static final int MARKER_BIT = 0x80;

    /** Karakter glyph logo pada font {@code xoldiummod:xoldium_icons}. */
    public static final String LOGO_GLYPH = "\uE000";

    public static final Identifier ICON_FONT = Identifier.of(XoldiumMod.MOD_ID, "xoldium_icons");

    private static final Style LOGO_STYLE = Style.EMPTY
            .withColor(TextColor.fromRgb(0xFFFFFF))
            .withFont(ICON_FONT);

    private static List<TrackedData<?>> byteData;
    private static boolean resolveFailed = false;
    private static boolean markLogged = false;
    private static boolean seenLogged = false;

    private XoldiumUsers() {
    }

    /** Teks logo + spasi kecil yang ditempel di depan nama. */
    public static MutableText logoPrefix() {
        return Text.literal(LOGO_GLYPH).setStyle(LOGO_STYLE).append(Text.literal(" ").setStyle(Style.EMPTY));
    }

    /** Apakah pemain ini memakai Xoldium Client (bit penanda menyala pada byte lapisan skin)? */
    public static boolean isXoldiumUser(PlayerEntity player) {
        if (player == null || resolveFailed) {
            return false;
        }
        try {
            List<TrackedData<?>> fields = fields();
            if (fields.isEmpty()) {
                return false;
            }
            for (TrackedData<?> data : fields) {
                Object value = player.getDataTracker().get(data);
                if (value instanceof Byte b && (b & MARKER_BIT) != 0) {
                    if (!seenLogged) {
                        seenLogged = true;
                        XoldiumMod.LOGGER.info("[Xoldium] Pemain pengguna Xoldium terdeteksi: {}", player.getName().getString());
                    }
                    return true;
                }
            }
        } catch (Throwable t) {
            resolveFailed = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Deteksi pengguna Xoldium dimatikan (data tracker tidak terbaca).", t);
        }
        return false;
    }

    /**
     * Semua field static {@code TrackedData<Byte>} pada hierarki PlayerEntity
     * sampai (tanpa) LivingEntity: lapisan skin (+ lengan utama di versi lama).
     * Nilai lengan utama hanya 0/1 sehingga tidak pernah punya bit 0x80 -
     * aman dicek bersama. LivingEntity/Entity sengaja dilewati (byte flag lain).
     */
    private static synchronized List<TrackedData<?>> fields() throws Exception {
        if (byteData != null) {
            return byteData;
        }
        List<TrackedData<?>> found = new ArrayList<>();
        Class<?> c = PlayerEntity.class;
        while (c != null && c != Object.class && c != LivingEntity.class) {
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) || f.getType() != TrackedData.class) {
                    continue;
                }
                Type generic = f.getGenericType();
                if (generic instanceof ParameterizedType pt && pt.getActualTypeArguments().length == 1
                        && pt.getActualTypeArguments()[0] == Byte.class) {
                    f.setAccessible(true);
                    Object v = f.get(null);
                    if (v instanceof TrackedData<?> td) {
                        found.add(td);
                    }
                }
            }
            c = c.getSuperclass();
        }
        byteData = found;
        if (found.isEmpty()) {
            XoldiumMod.LOGGER.warn("[Xoldium] Tidak menemukan TrackedData<Byte> pada hierarki PlayerEntity - logo nametag tidak aktif.");
        } else {
            XoldiumMod.LOGGER.info("[Xoldium] Xoldium Tag: {} field data tracker skin ditemukan.", found.size());
        }
        return byteData;
    }

    /**
     * Dipakai {@code SyncedOptionsMarkerMixin}: kembalikan salinan record opsi
     * klien dengan bit penanda menyala di {@code playerModelParts} (komponen
     * int ke-2 pada record: viewDistance, playerModelParts). Refleksi murni
     * pada objek yang dikembalikan game - tidak bergantung nama mapping.
     * Gagal -> objek asli dikembalikan apa adanya.
     */
    public static Object markOptions(Object options) {
        if (options == null) {
            return null;
        }
        try {
            Class<?> type = options.getClass();
            if (!type.isRecord()) {
                return options;
            }
            RecordComponent[] comps = type.getRecordComponents();
            Class<?>[] types = new Class<?>[comps.length];
            Object[] values = new Object[comps.length];
            int intIndex = -1;
            int intSeen = 0;
            for (int i = 0; i < comps.length; i++) {
                types[i] = comps[i].getType();
                Method accessor = comps[i].getAccessor();
                accessor.setAccessible(true);
                values[i] = accessor.invoke(options);
                if (types[i] == int.class) {
                    if (intSeen == 1) {
                        intIndex = i;
                    }
                    intSeen++;
                }
            }
            if (intIndex < 0) {
                return options;
            }
            int current = (Integer) values[intIndex];
            if ((current & MARKER_BIT) != 0) {
                return options;
            }
            values[intIndex] = current | MARKER_BIT;
            Constructor<?> ctor = type.getDeclaredConstructor(types);
            ctor.setAccessible(true);
            Object marked = ctor.newInstance(values);
            if (!markLogged) {
                markLogged = true;
                XoldiumMod.LOGGER.info("[Xoldium] Penanda Xoldium dipasang pada opsi klien yang dikirim ke server.");
            }
            return marked;
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal memasang penanda Xoldium pada opsi klien (dilewati, aman).", t);
            return options;
        }
    }

    /** Dipakai {@code PlayerDisplayNameMixin}: tempelkan logo di depan nama pemain pengguna Xoldium. */
    public static Text decorate(PlayerEntity player, Text original) {
        if (!XoldiumTagModule.showLogo()) {
            return original;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        boolean self = client != null && player == client.player;
        boolean marked = self ? XoldiumTagModule.showOwnTag() : isXoldiumUser(player);
        if (!marked) {
            return original;
        }
        if (original.getString().startsWith(LOGO_GLYPH)) {
            return original; // sudah didekorasi (hindari logo ganda)
        }
        return Text.empty().append(logoPrefix()).append(original);
    }
}

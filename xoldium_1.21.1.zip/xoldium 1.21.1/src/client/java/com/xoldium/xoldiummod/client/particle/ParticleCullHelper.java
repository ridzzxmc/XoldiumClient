package com.xoldium.xoldiummod.client.particle;

import com.xoldium.xoldiummod.client.core.FrustumContext;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Uji murni CPU-side apakah sebuah titik spawn partikel layak diproses
 * lebih lanjut. Dipanggil SEBELUM {@code Particle} apa pun dibuat, selalu
 * sinkron/inline (tanpa antrian/thread lain), sehingga hasilnya diketahui
 * pada tick yang sama persis seperti vanilla tanpa mod ini.
 */
public final class ParticleCullHelper {

    private ParticleCullHelper() {
    }

    public static boolean isEligible(double x, double y, double z) {
        XoldiumConfig cfg = XoldiumConfig.get();
        if (!cfg.enabled || !cfg.particleFrustumCulling) {
            return true;
        }

        Camera camera = FrustumContext.camera();
        if (camera == null) {
            return true; // fail-open sebelum frame pertama selesai render
        }

        Vec3d camPos = camera.getPos();
        double dx = x - camPos.x;
        double dy = y - camPos.y;
        double dz = z - camPos.z;
        double distanceSq = dx * dx + dy * dy + dz * dz;

        double safeRadius = cfg.particleCullSafeRadius;
        if (distanceSq <= safeRadius * safeRadius) {
            return true;
        }

        Box point = cfg.directParticleFastPath
                ? new Box(x - 0.5, y - 0.5, z - 0.5, x + 0.5, y + 0.5, z + 0.5)
                : new Box(x, y, z, x, y, z).expand(0.5);

        return FrustumContext.isPointVisible(point);
    }
}

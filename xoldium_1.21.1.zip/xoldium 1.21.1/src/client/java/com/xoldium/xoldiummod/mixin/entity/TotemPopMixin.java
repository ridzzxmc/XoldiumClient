package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.social.TotemPops;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook cadangan (status 35 lewat {@code LivingEntity#handleStatus}) - di Minecraft
 * modern status ini biasanya ditangani {@code ClientPlayNetworkHandler}
 * (lihat {@code TotemPacketMixin}); dedupe per-tick di {@link TotemPops}
 * mencegah hitungan ganda bila kedua hook terpanggil.
 */
@Mixin(LivingEntity.class)
public abstract class TotemPopMixin {

    @Inject(method = "handleStatus(B)V", at = @At("HEAD"), require = 0)
    private void xoldium$onStatus(byte status, CallbackInfo ci) {
        if (status == 35) {
            TotemPops.onPop((LivingEntity) (Object) this);
        }
    }
}

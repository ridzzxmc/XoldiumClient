package com.xoldium.xoldiummod.client.module;

import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Modul kategori HUD - elemen teks/ikon kecil yang digambar di layar setiap
 * frame lewat {@code HudRenderCallback} (didaftarkan terpusat oleh
 * {@link ModuleManager}, bukan oleh masing-masing modul, agar urutan
 * render & pembungkusan try/catch konsisten untuk semua elemen HUD).
 *
 * <p>Posisi ({@link #x}/{@link #y}) adalah koordinat piksel absolut dari
 * pojok kiri-atas layar, diatur lewat drag-and-drop di
 * {@code XoldiumHomeScreen} (HUD Editor). {@link #scale} mengalikan ukuran
 * render (dibatasi 0.3x - 4.0x).
 */
public abstract class HudModule extends Module {

    public static final float MIN_SCALE = 0.3f;
    public static final float MAX_SCALE = 4.0f;

    protected float x;
    protected float y;
    protected float scale = 1.0f;

    private float measuredWidth = 40f;
    private float measuredHeight = 10f;

    /**
     * Setting UNIVERSAL yang otomatis dimiliki SEMUA modul HUD (permintaan
     * pemakai: "semua Module ada Tempat untuk Setting nya sendiri sendiri",
     * dengan contoh eksplisit "setting FPS background nya jadi transparan").
     * Didaftarkan sekali di sini (bukan diulang manual di setiap modul HUD)
     * supaya konsisten & tidak ada yang lupa - nilai 0.0 = latar sepenuhnya
     * transparan, 1.0 = sepenuhnya pekat (default 0.56, dicocokkan dengan
     * alpha lama {@code 0x90} yang dulu tetap/tidak bisa diubah di
     * {@code HudRenderUtil}). Dibaca lewat {@link #backgroundOpacity()},
     * dipakai {@link com.xoldium.xoldiummod.client.util.HudRenderUtil}.
     */
    private final DoubleSetting backgroundOpacity = addSetting(
            new DoubleSetting("background_opacity", "setting.xoldiummod.hud.background_opacity", 0.56, 0.0, 1.0, 0.05));

    protected HudModule(String id, String nameKey, boolean defaultEnabled, float defaultX, float defaultY) {
        super(id, nameKey, ModuleCategory.HUD, defaultEnabled);
        this.x = defaultX;
        this.y = defaultY;
    }

    /** Opasitas latar kotak HUD ini, 0.0 (transparan penuh) - 1.0 (pekat penuh). */
    public final double backgroundOpacity() {
        return backgroundOpacity.get();
    }

    /**
     * Gambar elemen HUD ini. Dipanggil hanya bila {@link #isEnabled()} true.
     * Implementasi WAJIB memanggil {@link #setMeasuredSize(float, float)}
     * dengan ukuran mentah (sebelum dikali scale) supaya bounding box di
     * HUD Editor akurat untuk drag & scroll-to-scale.
     */
    public abstract void render(DrawContext context, RenderTickCounter tickCounter);

    /**
     * Render pratinjau statis untuk HUD Editor (dipanggil sebagai ganti
     * {@link #render} saat home screen dalam mode edit, supaya elemen yang
     * datanya butuh dunia/pemain tetap terlihat dengan data contoh walau
     * screen sedang terbuka). Default memanggil {@link #render} langsung -
     * override bila butuh tampilan placeholder yang berbeda.
     */
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        render(context, tickCounter);
    }

    public float x() {
        return x;
    }

    public float y() {
        return y;
    }

    public float scale() {
        return scale;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void setScale(float scale) {
        this.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
    }

    public float measuredWidth() {
        return measuredWidth * scale;
    }

    public float measuredHeight() {
        return measuredHeight * scale;
    }

    public void setMeasuredSize(float rawWidth, float rawHeight) {
        this.measuredWidth = Math.max(rawWidth, 4f);
        this.measuredHeight = Math.max(rawHeight, 4f);
    }
}

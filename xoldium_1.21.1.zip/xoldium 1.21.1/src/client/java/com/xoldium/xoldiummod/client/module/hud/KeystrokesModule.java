package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

/** Menampilkan status tombol WASD + tombol mouse kiri/kanan, mirip mod "Keystrokes" populer. */
public final class KeystrokesModule extends HudModule {

    private static final int BOX = 16;
    private static final int GAP = 2;
    private static final int COLOR_IDLE = 0x90202020;
    /** Dulu biru ({@code 0xB055C7F0}) - diganti putih terang (bukan biru) supaya tetap kontras jelas terhadap kotak idle yang gelap. */
    private static final int COLOR_ACTIVE = 0xE6FFFFFF;

    public KeystrokesModule() {
        super("keystrokes", "module.xoldiummod.keystrokes", false, 4f, 240f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        var options = client.options;
        TextRenderer tr = client.textRenderer;

        int gridWidth = BOX * 3 + GAP * 2;
        int gridHeight = BOX * 2 + GAP + BOX + GAP; // baris W/A/S/D + baris mouse
        setMeasuredSize(gridWidth, gridHeight);

        // CATATAN VERIFIKASI MAPPING (port 1.21.1): getMatrices() di 1.21.1
        // masih MatrixStack lama (push/pop, translate & scale 3-argumen) -
        // Matrix3x2fStack/pushMatrix() baru ada mulai 1.21.8, lihat HudRenderUtil.
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0);
        context.getMatrices().scale(scale, scale, 1);

        drawKey(context, tr, BOX + GAP, 0, options.forwardKey, "W");
        drawKey(context, tr, 0, BOX + GAP, options.leftKey, "A");
        drawKey(context, tr, BOX + GAP, BOX + GAP, options.backKey, "S");
        drawKey(context, tr, (BOX + GAP) * 2, BOX + GAP, options.rightKey, "D");

        int mouseRowY = (BOX + GAP) * 2;
        drawKey(context, tr, 0, mouseRowY, options.attackKey, "L");
        drawKey(context, tr, BOX + GAP, mouseRowY, options.jumpKey, "SP");
        drawKey(context, tr, (BOX + GAP) * 2, mouseRowY, options.useKey, "R");

        context.getMatrices().pop();
    }

    private void drawKey(DrawContext context, TextRenderer tr, int boxX, int boxY, KeyBinding binding, String label) {
        boolean pressed = binding.isPressed();
        context.fill(boxX, boxY, boxX + BOX, boxY + BOX, pressed ? COLOR_ACTIVE : COLOR_IDLE);
        int textWidth = tr.getWidth(label);
        // Teks hitam saat kotak putih terang (ditekan), putih saat kotak gelap (idle) - kontras tetap terjaga tanpa warna.
        int textColor = pressed ? 0xFF000000 : 0xFFFFFFFF;
        context.drawText(tr, label, boxX + (BOX - textWidth) / 2, boxY + (BOX - tr.fontHeight) / 2, textColor, !pressed);
    }
}

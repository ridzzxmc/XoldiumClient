package com.xoldium.xoldiummod.client.compat.vulkanmod;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Menambahkan grup "Xoldium" di bawah VulkanMod pada layar opsi VulkanMod
 * ({@code VOptionScreen}) lewat titik ekstensi publik resmi VulkanMod
 * ({@code net.vulkanmod.config.gui.ModSettingsRegistry}) - BUKAN Mixin ke
 * field internal {@code VOptionScreen} yang jauh lebih rapuh.
 *
 * <p>Reflection (bukan {@code modImplementation} langsung ke VulkanMod di
 * Gradle) dipakai supaya Xoldium tetap "zero compile-time dependency ke
 * VulkanMod": tetap bisa di-build dan berjalan normal di instalasi TANPA
 * VulkanMod. Bila VulkanMod tidak ter-install, atau versinya belum punya
 * {@code ModSettingsRegistry}, seluruh blok reflection gagal dengan aman
 * (ditangkap, dicatat sebagai info, TIDAK PERNAH men-crash client).
 *
 * <p>CATATAN VERIFIKASI (WAJIB sebelum rilis produksi): signature method
 * di bawah diambil dari pembacaan API publik VulkanMod yang tersedia saat
 * kode ini ditulis - kelas-kelas ini INTERNAL VulkanMod (bukan API yang
 * dijamin stabil seperti Fabric API), jadi verifikasi ulang lewat
 * decompile VulkanMod versi target sebelum rilis.
 */
public final class XoldiumVulkanModIntegration {

    private static final String VULKANMOD_MOD_ID = "vulkanmod";

    private XoldiumVulkanModIntegration() {
    }

    /** Dipanggil dari {@code XoldiumModClient#onInitializeClient()}. Tidak pernah melempar exception ke pemanggil. */
    public static void tryRegister() {
        if (!FabricLoader.getInstance().isModLoaded(VULKANMOD_MOD_ID)) {
            return;
        }

        try {
            registerUnsafe();
            XoldiumMod.LOGGER.info("[Xoldium] Berhasil mendaftarkan grup 'Xoldium' di menu VulkanMod.");
        } catch (Throwable t) {
            XoldiumMod.LOGGER.info(
                    "[Xoldium] Integrasi menu VulkanMod dilewati (API ModSettingsRegistry tidak ditemukan/cocok " +
                            "pada versi VulkanMod terinstall). Buka setting Xoldium lewat Right Shift atau Mod Menu.");
        }
    }

    private static void registerUnsafe() throws ReflectiveOperationException {
        ClassLoader cl = XoldiumVulkanModIntegration.class.getClassLoader();

        Class<?> registryClass = Class.forName("net.vulkanmod.config.gui.ModSettingsRegistry", true, cl);
        Class<?> entryClass = Class.forName("net.vulkanmod.config.gui.ModSettingsEntry", true, cl);
        Class<?> optionPageClass = Class.forName("net.vulkanmod.config.option.OptionPage", true, cl);
        Class<?> optionBlockClass = Class.forName("net.vulkanmod.config.gui.OptionBlock", true, cl);
        Class<?> optionBaseClass = Class.forName("net.vulkanmod.config.option.Option", true, cl);
        Class<?> switchOptionClass = Class.forName("net.vulkanmod.config.option.SwitchOption", true, cl);

        Object[] switchOptions = buildSwitchOptions(switchOptionClass);

        Object optionArray = Array.newInstance(optionBaseClass, switchOptions.length);
        for (int i = 0; i < switchOptions.length; i++) {
            Array.set(optionArray, i, switchOptions[i]);
        }

        Constructor<?> optionBlockCtor = optionBlockClass.getConstructor(String.class, optionArray.getClass());
        Object optionBlock = optionBlockCtor.newInstance("", optionArray);

        Object optionBlockArray = Array.newInstance(optionBlockClass, 1);
        Array.set(optionBlockArray, 0, optionBlock);

        Constructor<?> optionPageCtor = optionPageClass.getConstructor(String.class, optionBlockArray.getClass());
        Object optionPage = optionPageCtor.newInstance("Xoldium", optionBlockArray);

        List<Object> pages = new ArrayList<>();
        pages.add(optionPage);

        Supplier<List<Object>> pagesSupplier = () -> pages;
        Supplier<Identifier> iconSupplier = () -> Identifier.of("xoldiummod", "icon.png");
        Runnable onSave = XoldiumConfig::save;

        Constructor<?> entryCtor = entryClass.getConstructor(
                Text.class, Supplier.class, Supplier.class, Runnable.class);
        Object entry = entryCtor.newInstance(
                Text.literal("Xoldium"),
                iconSupplier,
                pagesSupplier,
                onSave
        );

        Object registryInstance = registryClass.getField("INSTANCE").get(null);
        Method addModEntry = registryClass.getMethod("addModEntry", entryClass);
        addModEntry.invoke(registryInstance, entry);
    }

    private static Object[] buildSwitchOptions(Class<?> switchOptionClass) throws ReflectiveOperationException {
        XoldiumConfig cfg = XoldiumConfig.get();

        List<ToggleBinding> bindings = List.of(
                new ToggleBinding("Entity Frustum Culling", () -> cfg.entityFrustumCulling, v -> cfg.entityFrustumCulling = v),
                new ToggleBinding("Player Culling", () -> cfg.playerCulling, v -> cfg.playerCulling = v),
                new ToggleBinding("Block Entity Culling", () -> cfg.blockEntityCulling, v -> cfg.blockEntityCulling = v),
                new ToggleBinding("Particle Frustum Culling", () -> cfg.particleFrustumCulling, v -> cfg.particleFrustumCulling = v),
                new ToggleBinding("Tile Entity Distance Culling", () -> cfg.tileEntityDistanceCulling, v -> cfg.tileEntityDistanceCulling = v),
                new ToggleBinding("Fast Entity Rendering", () -> cfg.fastEntityRendering, v -> cfg.fastEntityRendering = v),
                new ToggleBinding("Direct Particle Fast-Path", () -> cfg.directParticleFastPath, v -> cfg.directParticleFastPath = v),
                new ToggleBinding("Occlusion Culling Boost", () -> cfg.occlusionCullingBoost, v -> cfg.occlusionCullingBoost = v),
                new ToggleBinding("Mob AI Throttling", () -> cfg.mobAiThrottling, v -> cfg.mobAiThrottling = v)
        );

        Constructor<?> switchCtor = switchOptionClass.getConstructor(Text.class, Consumer.class, Supplier.class);

        Object[] result = new Object[bindings.size()];
        for (int i = 0; i < bindings.size(); i++) {
            ToggleBinding binding = bindings.get(i);
            Consumer<Boolean> setter = binding.setter;
            Supplier<Boolean> getter = () -> binding.getter.getAsBoolean();
            result[i] = switchCtor.newInstance(Text.literal(binding.label), setter, getter);
        }
        return result;
    }

    private record ToggleBinding(String label, BooleanSupplier getter, Consumer<Boolean> setter) {
    }
}

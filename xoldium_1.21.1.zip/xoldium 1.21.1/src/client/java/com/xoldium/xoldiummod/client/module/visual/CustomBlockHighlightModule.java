package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;

/**
 * Custom Block Highlight - MENGGANTIKAN modul Block Overlay & Blocks Modifier
 * (keduanya dihapus). Terinspirasi mod "Custom Block Highlight" (Tektonikal,
 * GPL-3.0): outline & isi block yang dibidik dengan warna/gradient/animasi
 * yang bisa diatur penuh di Module Setting.
 *
 * <p>Berbeda dari mod referensi (yang membangun pipeline GPU sendiri per versi
 * Minecraft), modul ini menggambar outline sebagai balok tipis dan isi sebagai
 * quad berwarna per-vertex lewat {@link WorldOverlay} (satu kelas tipis
 * yang menyentuh API render) - jauh lebih sedikit titik yang bisa pecah antar
 * versi. Outline vanilla hanya disembunyikan bila modul ON dan "Hide Vanilla
 * Outline" aktif; modul OFF = outline vanilla normal.
 */
public final class CustomBlockHighlightModule extends Module {

    // ---- Outline ----
    private final BooleanSetting outline = addSetting(
            new BooleanSetting("outline", "setting.xoldiummod.cbh.outline", true));
    private final ColorSetting outlineColor1 = addSetting(
            new ColorSetting("outline_color", "setting.xoldiummod.cbh.outline_color", 0xFFFFFFFF, true), outline::get);
    private final ColorSetting outlineColor2 = addSetting(
            new ColorSetting("outline_color_2", "setting.xoldiummod.cbh.outline_color_2", 0xFF5CB8FF, true),
            () -> outline.get() && this.gradientMode.index() != 0 && this.gradientMode.index() != 4);
    private final DoubleSetting thickness = addSetting(
            new DoubleSetting("thickness", "setting.xoldiummod.cbh.thickness", 0.012, 0.004, 0.08, 0.002), outline::get);

    // ---- Gradient ----
    private final ModeSetting gradientMode = addSetting(
            new ModeSetting("gradient", "setting.xoldiummod.cbh.gradient", 3,
                    "setting.xoldiummod.cbh.gradient.none",
                    "setting.xoldiummod.cbh.gradient.vertical",
                    "setting.xoldiummod.cbh.gradient.horizontal",
                    "setting.xoldiummod.cbh.gradient.diagonal",
                    "setting.xoldiummod.cbh.gradient.rainbow",
                    "setting.xoldiummod.cbh.gradient.pulse"));
    private final BooleanSetting animateGradient = addSetting(
            new BooleanSetting("animate_gradient", "setting.xoldiummod.cbh.animate_gradient", true),
            () -> gradientMode.index() >= 1 && gradientMode.index() <= 3);
    private final DoubleSetting animSpeed = addSetting(
            new DoubleSetting("anim_speed", "setting.xoldiummod.cbh.anim_speed", 0.8, 0.1, 4.0, 0.1),
            () -> gradientMode.index() >= 4 || (gradientMode.index() != 0 && animateGradient.get()));

    // ---- Fill ----
    private final BooleanSetting fill = addSetting(
            new BooleanSetting("fill", "setting.xoldiummod.cbh.fill", true));
    private final ColorSetting fillColor1 = addSetting(
            new ColorSetting("fill_color", "setting.xoldiummod.cbh.fill_color", 0x30FFFFFF, true), fill::get);
    private final ColorSetting fillColor2 = addSetting(
            new ColorSetting("fill_color_2", "setting.xoldiummod.cbh.fill_color_2", 0x305CB8FF, true),
            () -> fill.get() && gradientMode.index() != 0 && gradientMode.index() != 4);
    private final ModeSetting fillFaces = addSetting(
            new ModeSetting("fill_faces", "setting.xoldiummod.cbh.fill_faces", 0,
                    "setting.xoldiummod.cbh.fill_faces.all", "setting.xoldiummod.cbh.fill_faces.looked"), fill::get);

    // ---- Bentuk & gerak ----
    private final BooleanSetting exactShape = addSetting(
            new BooleanSetting("exact_shape", "setting.xoldiummod.cbh.exact_shape", true));
    private final DoubleSetting expand = addSetting(
            new DoubleSetting("expand", "setting.xoldiummod.cbh.expand", 0.002, 0.0, 0.15, 0.002));
    private final BooleanSetting smoothMove = addSetting(
            new BooleanSetting("smooth_move", "setting.xoldiummod.cbh.smooth_move", false));
    private final DoubleSetting moveSpeed = addSetting(
            new DoubleSetting("move_speed", "setting.xoldiummod.cbh.move_speed", 16.0, 2.0, 40.0, 1.0), smoothMove::get);
    private final BooleanSetting fade = addSetting(
            new BooleanSetting("fade", "setting.xoldiummod.cbh.fade", true));
    private final DoubleSetting fadeSpeed = addSetting(
            new DoubleSetting("fade_speed", "setting.xoldiummod.cbh.fade_speed", 14.0, 2.0, 40.0, 1.0), fade::get);
    private final BooleanSetting hideVanilla = addSetting(
            new BooleanSetting("hide_vanilla", "setting.xoldiummod.cbh.hide_vanilla", true));

    // ---- state ----
    private BlockPos lastPos;
    private VoxelShape lastShape;
    private Direction lastSide = Direction.UP;
    private float fadeValue = 0f;
    private long lastNanos = System.nanoTime();
    private final double[] smooth = new double[6];
    private boolean smoothInit = false;
    private boolean loggedRenderError = false;

    // batas normalisasi gradient (koordinat dunia) untuk frame ini
    private double bx0, by0, bz0, bx1, by1, bz1;

    public CustomBlockHighlightModule() {
        super("custom_block_highlight", "module.xoldiummod.custom_block_highlight", ModuleCategory.VISUAL, false);
        WorldRenderEvents.BLOCK_OUTLINE.register((context, outlineContext) -> !(isEnabled() && hideVanilla.get()));
        WorldRenderEvents.AFTER_ENTITIES.register(this::onAfterEntities);
    }

    @Override
    protected void onToggle(boolean enabled) {
        fadeValue = 0f;
        smoothInit = false;
        lastShape = null;
    }

    private void onAfterEntities(WorldRenderContext context) {
        if (!isEnabled()) {
            return;
        }
        try {
            draw(context);
        } catch (Throwable t) {
            if (!loggedRenderError) {
                loggedRenderError = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Custom Block Highlight gagal menggambar (dilewati, tidak crash).", t);
            }
        }
    }

    private void draw(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) {
            return;
        }
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;

        boolean has = false;
        HitResult hit = mc.crosshairTarget;
        if (hit instanceof BlockHitResult blockHit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = blockHit.getBlockPos();
            BlockState state = world.getBlockState(pos);
            VoxelShape shape = state.getOutlineShape(world, pos);
            if (!shape.isEmpty()) {
                if (lastPos == null || !lastPos.equals(pos)) {
                    lastPos = pos.toImmutable();
                }
                lastShape = shape;
                lastSide = blockHit.getSide();
                has = true;
            }
        }

        float target = has ? 1f : 0f;
        if (fade.get()) {
            fadeValue += (target - fadeValue) * Math.min(1f, fadeSpeed.get().floatValue() * dt);
            if (Math.abs(fadeValue - target) < 0.004f) {
                fadeValue = target;
            }
        } else {
            fadeValue = target;
        }
        if (lastShape == null || lastPos == null || fadeValue < 0.01f) {
            if (!has) {
                smoothInit = false;
            }
            return;
        }

        Box local = lastShape.getBoundingBox();
        double e = expand.get();
        double tx0 = lastPos.getX() + local.minX, ty0 = lastPos.getY() + local.minY, tz0 = lastPos.getZ() + local.minZ;
        double tx1 = lastPos.getX() + local.maxX, ty1 = lastPos.getY() + local.maxY, tz1 = lastPos.getZ() + local.maxZ;

        boolean useSmooth = smoothMove.get();
        if (useSmooth) {
            double[] tgt = {tx0, ty0, tz0, tx1, ty1, tz1};
            double far = 0;
            if (smoothInit) {
                for (int i = 0; i < 6; i++) far = Math.max(far, Math.abs(tgt[i] - smooth[i]));
            }
            if (!smoothInit || far > 24) {
                System.arraycopy(tgt, 0, smooth, 0, 6);
                smoothInit = true;
            } else {
                double k = Math.min(1.0, moveSpeed.get() * dt);
                for (int i = 0; i < 6; i++) smooth[i] += (tgt[i] - smooth[i]) * k;
            }
            tx0 = smooth[0]; ty0 = smooth[1]; tz0 = smooth[2];
            tx1 = smooth[3]; ty1 = smooth[4]; tz1 = smooth[5];
        }
        bx0 = tx0 - e; by0 = ty0 - e; bz0 = tz0 - e;
        bx1 = tx1 + e; by1 = ty1 + e; bz1 = tz1 + e;

        Vec3d cam = WorldOverlay.camera(context);
        MatrixStack matrices = WorldOverlay.matrices(context);
        if (matrices == null) {
            return;
        }
        Matrix4f m = WorldOverlay.positionMatrix(matrices);
        VertexConsumer vc = WorldOverlay.quadConsumer(context);
        if (vc == null) {
            return;
        }
        double time = now / 1_000_000_000.0;

        if (fill.get()) {
            drawFill(vc, m, cam, time, useSmooth);
        }
        if (outline.get()) {
            drawOutline(vc, m, cam, time, useSmooth, e);
        }
    }

    // ------------------------------------------------------------------
    // Fill
    // ------------------------------------------------------------------

    private void drawFill(VertexConsumer vc, Matrix4f m, Vec3d cam, double time, boolean boxOnly) {
        double e = expand.get() + 0.003;
        boolean lookedOnly = fillFaces.index() == 1;
        if (boxOnly || lookedOnly || !exactShape.get()) {
            drawBoxFaces(vc, m, cam, time, bx0 - 0.003, by0 - 0.003, bz0 - 0.003, bx1 + 0.003, by1 + 0.003, bz1 + 0.003,
                    lookedOnly ? lastSide : null);
            return;
        }
        for (Box b : lastShape.getBoundingBoxes()) {
            drawBoxFaces(vc, m, cam, time,
                    lastPos.getX() + b.minX - e, lastPos.getY() + b.minY - e, lastPos.getZ() + b.minZ - e,
                    lastPos.getX() + b.maxX + e, lastPos.getY() + b.maxY + e, lastPos.getZ() + b.maxZ + e, null);
        }
    }

    private void drawBoxFaces(VertexConsumer vc, Matrix4f m, Vec3d cam, double time,
                              double x0, double y0, double z0, double x1, double y1, double z1, Direction only) {
        double ax0 = x0 - cam.x, ay0 = y0 - cam.y, az0 = z0 - cam.z;
        double ax1 = x1 - cam.x, ay1 = y1 - cam.y, az1 = z1 - cam.z;
        for (Direction d : Direction.values()) {
            if (only != null && d != only) {
                continue;
            }
            switch (d) {
                case DOWN -> quad(vc, m, time, true,
                        x0, y0, z0, ax0, ay0, az0, x1, y0, z0, ax1, ay0, az0,
                        x1, y0, z1, ax1, ay0, az1, x0, y0, z1, ax0, ay0, az1);
                case UP -> quad(vc, m, time, true,
                        x0, y1, z0, ax0, ay1, az0, x1, y1, z0, ax1, ay1, az0,
                        x1, y1, z1, ax1, ay1, az1, x0, y1, z1, ax0, ay1, az1);
                case NORTH -> quad(vc, m, time, true,
                        x0, y0, z0, ax0, ay0, az0, x1, y0, z0, ax1, ay0, az0,
                        x1, y1, z0, ax1, ay1, az0, x0, y1, z0, ax0, ay1, az0);
                case SOUTH -> quad(vc, m, time, true,
                        x0, y0, z1, ax0, ay0, az1, x1, y0, z1, ax1, ay0, az1,
                        x1, y1, z1, ax1, ay1, az1, x0, y1, z1, ax0, ay1, az1);
                case WEST -> quad(vc, m, time, true,
                        x0, y0, z0, ax0, ay0, az0, x0, y1, z0, ax0, ay1, az0,
                        x0, y1, z1, ax0, ay1, az1, x0, y0, z1, ax0, ay0, az1);
                case EAST -> quad(vc, m, time, true,
                        x1, y0, z0, ax1, ay0, az0, x1, y1, z0, ax1, ay1, az0,
                        x1, y1, z1, ax1, ay1, az1, x1, y0, z1, ax1, ay0, az1);
            }
        }
    }

    /** Empat vertex; tiap vertex = (koordinat dunia utk warna, koordinat relatif-kamera utk posisi). */
    private void quad(VertexConsumer vc, Matrix4f m, double time, boolean isFill,
                      double w1x, double w1y, double w1z, double r1x, double r1y, double r1z,
                      double w2x, double w2y, double w2z, double r2x, double r2y, double r2z,
                      double w3x, double w3y, double w3z, double r3x, double r3y, double r3z,
                      double w4x, double w4y, double w4z, double r4x, double r4y, double r4z) {
        WorldOverlay.quad(vc, m,
                r1x, r1y, r1z, colorAt(w1x, w1y, w1z, isFill, time),
                r2x, r2y, r2z, colorAt(w2x, w2y, w2z, isFill, time),
                r3x, r3y, r3z, colorAt(w3x, w3y, w3z, isFill, time),
                r4x, r4y, r4z, colorAt(w4x, w4y, w4z, isFill, time));
    }

    // ------------------------------------------------------------------
    // Outline
    // ------------------------------------------------------------------

    private void drawOutline(VertexConsumer vc, Matrix4f m, Vec3d cam, double time, boolean boxOnly, double e) {
        double half = thickness.get() / 2.0;
        if (boxOnly || !exactShape.get()) {
            double x0 = bx0, y0 = by0, z0 = bz0, x1 = bx1, y1 = by1, z1 = bz1;
            double[][] c = {
                    {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1},
                    {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
            int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            for (int[] ed : edges) {
                beam(vc, m, cam, time, half, c[ed[0]], c[ed[1]]);
            }
            return;
        }
        Box lb = lastShape.getBoundingBox();
        final double ex = e;
        lastShape.forEachEdge((x1, y1, z1, x2, y2, z2) -> {
            double[] a = {
                    lastPos.getX() + expandV(x1, lb.minX, lb.maxX, ex),
                    lastPos.getY() + expandV(y1, lb.minY, lb.maxY, ex),
                    lastPos.getZ() + expandV(z1, lb.minZ, lb.maxZ, ex)};
            double[] b = {
                    lastPos.getX() + expandV(x2, lb.minX, lb.maxX, ex),
                    lastPos.getY() + expandV(y2, lb.minY, lb.maxY, ex),
                    lastPos.getZ() + expandV(z2, lb.minZ, lb.maxZ, ex)};
            beam(vc, m, cam, time, half, a, b);
        });
    }

    private static double expandV(double v, double min, double max, double e) {
        if (v <= min + 1.0e-6) return v - e;
        if (v >= max - 1.0e-6) return v + e;
        return v;
    }

    private void beam(VertexConsumer vc, Matrix4f m, Vec3d cam, double time, double half, double[] a, double[] b) {
        int ca = colorAt(a[0], a[1], a[2], false, time);
        int cb = colorAt(b[0], b[1], b[2], false, time);
        WorldOverlay.beam(vc, m,
                a[0] - cam.x, a[1] - cam.y, a[2] - cam.z, ca,
                b[0] - cam.x, b[1] - cam.y, b[2] - cam.z, cb, half);
    }

    // ------------------------------------------------------------------
    // Warna / gradient
    // ------------------------------------------------------------------

    private int colorAt(double wx, double wy, double wz, boolean isFill, double time) {
        int c1 = isFill ? fillColor1.argb() : outlineColor1.argb();
        int c2 = isFill ? fillColor2.argb() : outlineColor2.argb();
        int mode = gradientMode.index();
        double nx = norm(wx, bx0, bx1);
        double ny = norm(wy, by0, by1);
        double nz = norm(wz, bz0, bz1);
        double speed = animSpeed.get();
        int result;
        switch (mode) {
            case 1, 2, 3 -> {
                double t = mode == 1 ? ny : (mode == 2 ? (nx + nz) / 2.0 : (nx + ny + nz) / 3.0);
                if (animateGradient.get()) {
                    double phase = t + time * speed * 0.25;
                    phase -= Math.floor(phase);
                    t = 1.0 - Math.abs(2.0 * phase - 1.0);
                }
                result = Anim.lerpColor(c1, c2, (float) t);
            }
            case 4 -> {
                double hue = ((nx + ny + nz) / 3.0 + time * speed * 0.15);
                hue -= Math.floor(hue);
                int rgb = MathHelper.hsvToRgb((float) hue, 0.75f, 1.0f);
                result = (c1 & 0xFF000000) | (rgb & 0x00FFFFFF);
            }
            case 5 -> result = Anim.lerpColor(c1, c2, (float) (0.5 + 0.5 * Math.sin(time * speed * 2.0)));
            default -> result = c1;
        }
        return Anim.withAlpha(result, fadeValue);
    }

    private static double norm(double v, double min, double max) {
        double span = max - min;
        if (span < 1.0e-6) return 0.5;
        return Math.max(0.0, Math.min(1.0, (v - min) / span));
    }
}

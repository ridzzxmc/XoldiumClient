package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Daftar pemain lain yang berada dalam jangkauan render client (mirip
 * "ArrayList"/player list overlay pada banyak client PvP) - diurutkan dari
 * yang terdekat, dibatasi 8 entri agar tidak memenuhi layar.
 */
public final class ArrayListModule extends HudModule {

    private static final int MAX_ENTRIES = 8;

    public ArrayListModule() {
        super("array_list", "module.xoldiummod.array_list", false, 4f, 260f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        if (world == null || client.player == null) {
            return;
        }

        List<PlayerEntity> others = new ArrayList<>(world.getPlayers());
        others.remove(client.player);
        others.sort(Comparator.comparingDouble(p -> p.squaredDistanceTo(client.player)));

        if (others.isEmpty()) {
            return;
        }

        List<String> lines = new ArrayList<>();
        int count = Math.min(MAX_ENTRIES, others.size());
        for (int i = 0; i < count; i++) {
            PlayerEntity p = others.get(i);
            double distance = Math.sqrt(p.squaredDistanceTo(client.player));
            lines.add(p.getGameProfile().getName() + "  (" + Math.round(distance) + "m)");
        }
        HudRenderUtil.drawLines(context, this, lines.toArray(new String[0]));
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** UHC Overlay - rincian angka presisi HP/Absorption/Hunger/Saturation sekaligus dalam satu kotak, gaya overlay yang umum dipakai di server UHC. */
public final class UhcOverlayModule extends HudModule {

    public UhcOverlayModule() {
        super("uhc_overlay", "module.xoldiummod.uhc_overlay", false, 4f, 620f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        String hpLine = String.format("HP: %.1f/%.1f", client.player.getHealth(), client.player.getMaxHealth());
        String absorbLine = String.format("Absorption: %.1f", client.player.getAbsorptionAmount());
        String hungerLine = String.format("Hunger: %d  Sat: %.1f",
                client.player.getHungerManager().getFoodLevel(), client.player.getHungerManager().getSaturationLevel());
        HudRenderUtil.drawLines(context, this, hpLine, absorbLine, hungerLine);
    }
}

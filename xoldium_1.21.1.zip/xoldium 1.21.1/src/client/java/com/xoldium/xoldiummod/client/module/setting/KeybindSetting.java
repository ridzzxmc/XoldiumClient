package com.xoldium.xoldiummod.client.module.setting;

import net.minecraft.client.option.KeyBinding;

/**
 * Setting keybind untuk modul yang butuh tombol sendiri (Zoom, FreeLook,
 * dst) - MEMBUNGKUS {@link KeyBinding} vanilla ASLI yang didaftarkan lewat
 * {@code KeyBindingHelper} standar Fabric API (pola yang sama persis
 * dengan {@code openMenuKey} di {@code XoldiumModClient}), BUKAN sistem
 * keybind custom baru.
 *
 * <p>Konsekuensinya: persistensi tombol (disimpan/dimuat) SUDAH otomatis
 * ditangani Minecraft sendiri lewat {@code options.txt}, sama seperti
 * keybind vanilla lain - {@link com.xoldium.xoldiummod.client.module.ModuleManager}
 * TIDAK perlu (dan sengaja tidak) menyimpan nilai keybind ini ke
 * {@code xoldiumclient.json} sendiri (lihat {@code loadState}/
 * {@code saveState} - keduanya hanya menangani {@link BooleanSetting} &
 * {@link DoubleSetting}, {@link KeybindSetting} dilewati begitu saja,
 * TIDAK error, cuma tidak ada apa-apa yang perlu disimpan ulang di sana).
 *
 * <p>Keybind ini otomatis muncul & bisa diubah lewat menu Controls vanilla
 * seperti biasa - {@link com.xoldium.xoldiummod.client.gui.ModuleSettingsScreen}
 * HANYA menambahkan cara pintas kedua (tombol "Tekan tombol...") supaya
 * pemakai tidak perlu keluar-masuk menu Controls hanya untuk mengubah
 * satu keybind modul.
 */
public final class KeybindSetting extends ModuleSetting<KeyBinding> {

    public KeybindSetting(String id, String nameKey, KeyBinding binding) {
        super(id, nameKey, binding);
    }

    public KeyBinding binding() {
        return get();
    }
}

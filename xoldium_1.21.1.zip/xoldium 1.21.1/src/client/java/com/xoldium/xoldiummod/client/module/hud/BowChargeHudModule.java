package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;

/** Bow - menampilkan persentase tarikan busur (draw/pull progress) selagi ditahan, memakai rumus vanilla {@link BowItem#getPullProgress(int)}. */
public final class BowChargeHudModule extends HudModule {

    public BowChargeHudModule() {
        super("bow", "module.xoldiummod.bow", false, 4f, 420f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isUsingItem()) {
            return;
        }
        ItemStack active = player.getActiveItem();
        if (!(active.getItem() instanceof BowItem)) {
            return;
        }
        int useTicks = player.getItemUseTime();
        float pull = BowItem.getPullProgress(useTicks);
        HudRenderUtil.drawLine(context, this, "Bow: " + Math.round(pull * 100) + "%");
    }
}

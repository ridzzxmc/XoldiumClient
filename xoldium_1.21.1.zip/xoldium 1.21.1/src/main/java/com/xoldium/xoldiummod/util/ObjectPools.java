package com.xoldium.xoldiummod.util;

import net.minecraft.util.math.Box;

/**
 * Kumpulan scratch object thread-local untuk mengurangi alokasi objek
 * sementara di jalur yang dipanggil setiap tick / setiap frame per entity.
 * Thread-local dipakai sebagai kebiasaan aman default, walau seluruh jalur
 * cull Xoldium (entity, block entity, partikel) berjalan sinkron di render
 * thread client.
 */
public final class ObjectPools {

    private static final ThreadLocal<double[]> SCRATCH_AABB =
            ThreadLocal.withInitial(() -> new double[6]);

    private ObjectPools() {
    }

    /**
     * Mengambil array scratch [minX, minY, minZ, maxX, maxY, maxZ] milik
     * thread saat ini. Isi array akan ditimpa pemanggil berikutnya di
     * thread yang sama - JANGAN simpan referensi ini lintas frame/tick.
     */
    public static double[] scratchAabb() {
        return SCRATCH_AABB.get();
    }

    /** Mengisi ulang array scratch dari sebuah {@link Box} tanpa alokasi baru. */
    public static double[] fillFromBox(Box box) {
        double[] out = SCRATCH_AABB.get();
        out[0] = box.minX;
        out[1] = box.minY;
        out[2] = box.minZ;
        out[3] = box.maxX;
        out[4] = box.maxY;
        out[5] = box.maxZ;
        return out;
    }
}

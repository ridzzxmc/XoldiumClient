package com.xoldium.xoldiummod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Konfigurasi tunggal Xoldium Client: berisi (a) parameter internal
 * algoritma optimasi/culling milik Xoldium sendiri, dan (b) state generik
 * seluruh Module (HUD/Optimization/Movement/Visual) - enabled/disabled,
 * posisi & skala HUD, serta setting tambahan per modul (boolean/double).
 *
 * <p><b>PENTING:</b> Config ini TIDAK PERNAH menulis/membaca
 * {@code options.txt} (video settings vanilla, keybinding, dsb). Keybinding
 * Xoldium (termasuk tombol pembuka menu, default Right Shift) didaftarkan
 * lewat {@code KeyBindingHelper} standar Fabric API dan otomatis disimpan/
 * dimuat oleh Minecraft sendiri lewat menu Controls - Xoldium tidak perlu
 * (dan sengaja tidak) menyimpan ulang keybind secara manual di sini.
 */
public final class XoldiumConfig {

    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("xoldiumclient.json");

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static XoldiumConfig instance;

    // ========================================================================
    // Master switch
    // ========================================================================

    /** Master switch darurat: matikan seluruh optimasi Xoldium tanpa uninstall. */
    public boolean enabled = true;

    /**
     * Gaya latar menu Xoldium: 0 = Transparent (default, dunia game tetap
     * terlihat jelas), 1 = Glass, 2 = Solid (gaya lama, gelap pekat).
     */
    public int menuStyle = 0;

    /**
     * Versi skema config. v2 (Sesi 8): default Zoom & Hit Range berubah
     * (Hit Range mengikuti default mod referensi - merah, tampil di diri
     * sendiri). Config lama memuat nilai default lama (saveState menulis
     * SEMUA setting), jadi setting kedua modul itu di-reset SEKALI di sini.
     */
    public int configVersion = 0;

    // ========================================================================
    // Render Culling Settings (lihat FrustumContext / mixin culling)
    // ========================================================================

    public boolean entityFrustumCulling = true;
    public boolean playerCulling = false;
    public boolean blockEntityCulling = true;
    /** Margin pembesaran box block-entity sebelum uji visibilitas (dulu konstanta tetap {@code 1.0} di mixin) - setting "Cull Margin" milik modul Block Entity Culling. */
    public double blockEntityCullMargin = 1.0;
    public boolean particleFrustumCulling = true;
    public boolean tileEntityDistanceCulling = false;
    public double tileEntityCullDistance = 48.0;
    public double frustumCullMargin = 1.0;
    /** Jarak "aman" di bawahnya pemain lain TIDAK PERNAH di-cull walau Player Culling aktif (hindari pop-in pemain yang saling berdempetan). Setting milik modul Player Culling. */
    public double playerCullMinDistance = 0.0;

    // ========================================================================
    // Optimasi rendering tambahan
    // ========================================================================

    public boolean fastEntityRendering = true;
    public double fastEntityRenderDistance = 32.0;
    public boolean directParticleFastPath = true;
    public double particleCullSafeRadius = 4.0;
    public boolean occlusionCullingBoost = true;
    public boolean mobAiThrottling = true;
    public int mobAiThrottleDistance = 48;
    public int mobAiThrottleMaxInterval = 4;
    public double mobAiFreezeDistance = 96.0;

    // ========================================================================
    // Module framework - state generik untuk seluruh modul (HUD/Optimization/
    // Movement/Visual) yang didaftarkan lewat ModuleManager. Key = Module#id().
    // ========================================================================

    /** moduleId -> aktif/tidak. */
    public Map<String, Boolean> moduleEnabled = new LinkedHashMap<>();

    /** moduleId -> [x, y, scale] posisi & skala elemen HUD (hasil HUD Editor). */
    public Map<String, float[]> hudTransform = new LinkedHashMap<>();

    /** "moduleId.settingId" -> nilai boolean setting tambahan per modul. */
    public Map<String, Boolean> moduleBoolSettings = new LinkedHashMap<>();

    /** "moduleId.settingId" -> nilai double setting tambahan per modul (slider). */
    public Map<String, Double> moduleDoubleSettings = new LinkedHashMap<>();

    /** "moduleId.settingId" -> warna ARGB (ColorSetting). */
    public Map<String, Integer> moduleColorSettings = new LinkedHashMap<>();

    /** "moduleId.settingId" -> indeks opsi (ModeSetting). */
    public Map<String, Integer> moduleModeSettings = new LinkedHashMap<>();

    // ========================================================================
    // Load / Save
    // ========================================================================

    public static synchronized XoldiumConfig get() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static synchronized void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
                instance = GSON.fromJson(reader, XoldiumConfig.class);
            } catch (IOException | RuntimeException e) {
                com.xoldium.xoldiummod.XoldiumMod.LOGGER.warn(
                        "[Xoldium] Gagal membaca xoldiumclient.json, memakai default.", e);
                instance = new XoldiumConfig();
            }
        } else {
            instance = new XoldiumConfig();
        }
        if (instance == null) {
            instance = new XoldiumConfig();
        }
        // Jaga-jaga: field Map bisa null bila file config lama (versi
        // sebelumnya) tidak memilikinya sama sekali.
        if (instance.moduleEnabled == null) instance.moduleEnabled = new LinkedHashMap<>();
        if (instance.hudTransform == null) instance.hudTransform = new LinkedHashMap<>();
        if (instance.moduleBoolSettings == null) instance.moduleBoolSettings = new LinkedHashMap<>();
        if (instance.moduleDoubleSettings == null) instance.moduleDoubleSettings = new LinkedHashMap<>();
        if (instance.moduleColorSettings == null) instance.moduleColorSettings = new LinkedHashMap<>();
        if (instance.moduleModeSettings == null) instance.moduleModeSettings = new LinkedHashMap<>();
        if (instance.configVersion < 2) {
            instance.moduleBoolSettings.keySet().removeIf(k -> k.startsWith("hit_range.") || k.startsWith("zoom."));
            instance.moduleDoubleSettings.keySet().removeIf(k -> k.startsWith("hit_range.") || k.startsWith("zoom."));
            instance.moduleColorSettings.keySet().removeIf(k -> k.startsWith("hit_range.") || k.startsWith("zoom."));
            instance.moduleModeSettings.keySet().removeIf(k -> k.startsWith("hit_range.") || k.startsWith("zoom."));
            instance.configVersion = 2;
        }
        save();
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(instance, writer);
            }
        } catch (IOException e) {
            com.xoldium.xoldiummod.XoldiumMod.LOGGER.warn("[Xoldium] Gagal menyimpan xoldiumclient.json.", e);
        }
    }

    private XoldiumConfig() {
    }
}

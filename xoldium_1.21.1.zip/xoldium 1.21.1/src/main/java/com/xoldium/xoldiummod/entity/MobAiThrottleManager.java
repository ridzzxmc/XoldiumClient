package com.xoldium.xoldiummod.entity;

import com.xoldium.xoldiummod.config.XoldiumConfig;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import net.minecraft.entity.mob.AmbientEntity;
import net.minecraft.entity.mob.WaterCreatureEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

/**
 * "Mob AI Throttling": menurunkan frekuensi evaluasi ulang AI (goal
 * selector / target selector) untuk mob pasif/ambient yang jauh dari semua
 * pemain, TANPA menyentuh {@code Entity#tick()} dasar sama sekali -
 * sehingga gravitasi, gerakan yang sedang berjalan, tabrakan, dan posisi
 * yang dikirim ke client tetap berjalan normal setiap tick.
 *
 * <p>Di atas {@link XoldiumConfig#mobAiFreezeDistance}, evaluasi AI
 * dibekukan total (mobTick() selalu di-skip). Begitu pemain mendekat lagi
 * di bawah ambang freeze, evaluasi AI langsung kembali normal pada tick
 * berikutnya.
 *
 * <p>Hanya {@code MobEntity#mobTick()} yang di-skip (tempat goal/target
 * selector dievaluasi ulang) - TIDAK PERNAH menghentikan pathfinding yang
 * sedang berjalan. Keputusan berbasis jarak dari pemain (bukan frustum
 * kamera client manapun), sehingga identik hasilnya di server maupun
 * integrated server singleplayer - tidak ada risiko desync Server-Client.
 */
public final class MobAiThrottleManager {

    /** entityId -> jumlah tick berturut-turut sejak mobTick() terakhir benar-benar dijalankan. */
    private static final Long2IntOpenHashMap SKIP_COUNTERS = new Long2IntOpenHashMap();

    private static int cleanupCountdown = 20 * 60; // bersihkan cache tiap ~1 menit

    private MobAiThrottleManager() {
    }

    /**
     * Dipanggil dari {@code MobAiThrottleMixin} sebelum {@code mobTick()}
     * dijalankan. Mengembalikan {@code true} bila pemanggilan
     * {@code mobTick()} pada tick ini boleh di-skip.
     */
    public static boolean shouldSkipAiTick(MobEntity mob) {
        XoldiumConfig cfg = XoldiumConfig.get();
        if (!cfg.enabled || !cfg.mobAiThrottling) {
            return false;
        }

        // Hanya entitas pasif/ambient/makhluk air yang boleh di-throttle.
        // Mob hostile & netral SENGAJA tidak pernah disentuh agar combat,
        // farm mob, dan deteksi ancaman tetap responsif penuh.
        if (!(mob instanceof PassiveEntity) && !(mob instanceof AmbientEntity) && !(mob instanceof WaterCreatureEntity)) {
            return false;
        }

        World world = mob.getWorld();
        if (world.isClient()) {
            return false;
        }

        double searchRadius = Math.max(cfg.mobAiThrottleDistance, cfg.mobAiFreezeDistance) * 2.0;
        PlayerEntity nearest = world.getClosestPlayer(mob, searchRadius);
        double distance = nearest == null ? Double.MAX_VALUE : nearest.distanceTo(mob);

        if (distance < cfg.mobAiThrottleDistance) {
            SKIP_COUNTERS.remove(mob.getId());
            return false;
        }

        if (cfg.mobAiFreezeDistance > 0.0 && distance >= cfg.mobAiFreezeDistance) {
            SKIP_COUNTERS.put(mob.getId(), 0);
            return true;
        }

        int interval = computeInterval(cfg, distance);
        long id = mob.getId();
        int counter = SKIP_COUNTERS.get(id) + 1;

        if (counter >= interval) {
            SKIP_COUNTERS.put(id, 0);
            return false;
        }
        SKIP_COUNTERS.put(id, counter);
        return true;
    }

    private static int computeInterval(XoldiumConfig cfg, double distance) {
        double extra = distance - cfg.mobAiThrottleDistance;
        int interval = 2 + (int) (extra / 32.0);
        return Math.min(Math.max(interval, 2), Math.max(cfg.mobAiThrottleMaxInterval, 2));
    }

    /** Dipanggil dari {@link com.xoldium.xoldiummod.XoldiumMod} setiap akhir tick server. */
    public static void onServerTickEnd(MinecraftServer server) {
        if (--cleanupCountdown <= 0) {
            cleanupCountdown = 20 * 60;
            SKIP_COUNTERS.clear();
        }
    }
}

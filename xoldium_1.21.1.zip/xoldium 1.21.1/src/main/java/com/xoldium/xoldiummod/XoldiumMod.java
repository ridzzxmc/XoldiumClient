package com.xoldium.xoldiummod;

import com.xoldium.xoldiummod.config.XoldiumConfig;
import com.xoldium.xoldiummod.entity.MobAiThrottleManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry point umum Xoldium Client. Berjalan di kedua sisi (integrated
 * server, dedicated server, dan client) karena {@link MobAiThrottleManager}
 * adalah optimasi tick logic yang harus konsisten dengan simulasi server -
 * BUKAN sesuatu yang boleh hanya ditentukan secara lokal oleh client, agar
 * sinkronisasi Server-Client entitas tidak menyimpang.
 *
 * <p>Tidak ada satu pun kode di sini yang menyentuh rendering, GL, GUI,
 * atau modul HUD/Visual/Movement Xoldium - semuanya ada di
 * {@code src/client} (lihat {@link com.xoldium.xoldiummod.client.XoldiumModClient}),
 * supaya kelas-kelas yang berhubungan dengan tampilan tidak pernah ter-load
 * di dedicated server.
 */
public final class XoldiumMod implements ModInitializer {

    public static final String MOD_ID = "xoldiummod";
    public static final String MOD_NAME = "Xoldium Client";
    public static final String CREDIT = "Xoldium by ridzzxmc";
    public static final Logger LOGGER = LoggerFactory.getLogger("Xoldium");

    @Override
    public void onInitialize() {
        LOGGER.info("[Xoldium] Menginisialisasi optimasi backend (entity culling & Mob AI Throttling)...");

        XoldiumConfig.load();

        // Bersihkan cache penjadwalan tick setiap akhir tick server agar
        // tidak menumpuk entri untuk entitas yang sudah dihapus.
        ServerTickEvents.END_SERVER_TICK.register(MobAiThrottleManager::onServerTickEnd);

        LOGGER.info("[Xoldium] Siap. Mob AI Throttling radius = {} blok, freeze total di atas {} blok.",
                XoldiumConfig.get().mobAiThrottleDistance,
                XoldiumConfig.get().mobAiFreezeDistance);
    }
}

# Xoldium Client

Mod client & optimasi Fabric/Quilt untuk Minecraft **1.21.1**, penerus dari FulconMod - sekarang dengan Mod Menu bergaya modular (HUD / Optimization / Movement / Visual), HUD Editor drag-and-drop, dan seluruh optimasi rendering FulconMod yang sudah diperluas.

Tekan **Right Shift** (bisa diubah lewat menu *Controls* vanilla) untuk membuka Xoldium, atau klik tombol **XoldiumClient** di bawah Disconnect pada Game Menu / tombol **Mod Menu** di Title Screen.

---

## Fitur

### Layar Awal + HUD Editor (Right Shift)
Logo & wordmark Xoldium, tombol **Open Mod Menu** dan **Settings**, sekaligus jadi editor HUD: seret elemen HUD aktif untuk memindah posisi, scroll di atasnya untuk mengubah skala (0.5x - 3.0x). Dunia game tetap terlihat & berjalan normal di baliknya (bukan menu jeda buram).

### Mod Menu (kartu modul, tab, pencarian)
Tab **All / HUD / Optimization / Movement / Visual**, kotak pencarian, kartu per-modul dengan ikon, toggle ON/OFF, dan ikon gear untuk setting tambahan (bila modulnya punya setting).

- **HUD** (19 modul): FPS, Ping, CPS Counter, Coordinates, Clock, Day Counter, Direction, Biome, Armor, Potion, Saturation, Keystrokes, ArrayList, Combo Counter, Memory, Server Info, Pack Display, Chat Timestamps, dan Credit HUD permanen ("Xoldium by ridzzxmc").
- **Optimization**: 10 toggle (master switch + seluruh opsi culling/throttle di bawah) + tombol preset **Auto FPS Boost**.
- **Movement**: Auto Sprint.
- **Visual**: Custom Block Highlight (outline/isi/gradient/animasi, menggantikan Block Overlay & Blocks Modifier), Hit Range, Zoom, Fullbright, Free Look, Motion Blur, Damage Indicator, No Hurt Cam, Time Changer, Xoldium Tag (logo di nametag sesama pengguna Xoldium).
- **Semua modul** punya Module Setting sendiri (gear-icon: slider, pilihan, warna RGBA, keybind, Reset to Default) dan hanya aktif bila dinyalakan di Mod Menu.

Setiap modul dibungkus try/catch terpusat di `ModuleManager` - bila satu modul error, HANYA modul itu yang otomatis nonaktif ("Disabled (error)" di kartunya); modul lain & client tetap jalan normal.

### Optimasi Rendering & Logika (warisan FulconMod, diperluas)
Entity/Player/Block-Entity frustum culling, particle frustum culling + fast-path, fast entity rendering, occlusion culling boost, dan **Mob AI Throttling** (menurunkan frekuensi evaluasi AI mob pasif/ambient yang jauh dari pemain, freeze total di atas jarak tertentu) - semua lewat Fabric Rendering API (`WorldRenderEvents`, `HudRenderCallback`) dan Mixin bertarget sempit, TIDAK PERNAH menyentuh OpenGL/GlStateManager/RenderSystem langsung, sehingga kompatibel dengan Sodium maupun VulkanMod.

---

## Build

```bash
./gradlew build
```

Hasil jar ada di `build/libs/xoldiummod-<version>.jar`. Butuh JDK 21 dan koneksi internet (untuk resolve Minecraft/Yarn/Fabric API - tidak dilakukan di lingkungan pembuatan kode ini, lihat bagian "Status verifikasi" di bawah).

Untuk build ke versi Minecraft 1.21.x lain: ganti `minecraft_version`/`yarn_mappings`/`fabric_version`/`modmenu_version` di `gradle.properties` ke versi target (cek nomor terbaru di https://fabricmc.net/develop lebih dulu), lalu build ulang - sama seperti cara Lithium/Sodium/VulkanMod merilis jar terpisah per versi. **Hati-hati**: beberapa API rendering (lihat tabel di bagian "Status verifikasi" di bawah) berubah drastis mulai 1.21.6-1.21.8 - jar hasil build untuk 1.21.1 TIDAK bisa dipakai apa adanya di versi 1.21.8+ atau sebaliknya tanpa menyesuaikan kode itu lagi.

---

## Integrasi Mod Optimasi Pihak Ketiga (Lithium, BadOptimizations, ThreadTweak, MoreCulling, ScalableLux)

Source code kelima mod tersebut **tidak disalin/ditulis-ulang** ke dalam Mixin milik Xoldium. Ini keputusan teknis, bukan disingkat-singkat:

- Kelimanya punya puluhan-ratusan Mixin yang saling bergantung dan terikat erat ke mapping Yarn spesifik masing-masing. Menyalin mentah tanpa proses build/verifikasi ulang penuh (genSources, remap, test run sungguhan) sangat berisiko menghasilkan crash/bug baru - bertentangan langsung dengan syarat "stabil, tanpa error, tanpa crash".
- Pendekatan yang benar (dan yang dipakai modpack/mod "bundle optimasi" pada umumnya): pakai jar hasil build RESMI tiap mod apa adanya, lalu satukan ke satu file Xoldium.jar lewat **jar-in-jar** (`include` di Loom).

**Cara mengaktifkan** (manual, butuh internet - lihat `libs/README.txt`):
1. Build tiap project source yang dilampirkan dengan Gradle mereka sendiri.
2. Salin jar hasil build (bukan `-sources.jar`) ke folder `libs/`.
3. Buka `build.gradle`, aktifkan blok `include modImplementation(fileTree(...))` di bagian "INTEGRASI MOD OPTIMASI PIHAK KETIGA".
4. `./gradlew build`.

Sebelum langkah di atas dilakukan, Xoldium tetap 100% kompatibel berdampingan bila user meng-install kelima mod itu secara terpisah - kategori **Optimization** di Mod Menu Xoldium hanya berisi toggle untuk optimasi milik Xoldium sendiri (bukan toggle mod lain), sesuai prinsip satu sumber kebenaran per pengaturan.

---

## Status verifikasi & catatan mapping (WAJIB dibaca sebelum build produksi)

Proyek ini awalnya ditulis (tanpa akses compiler) menyasar Minecraft 1.21.11, lalu **diturunkan ke 1.21.1** lewat audit manual - dicek satu-satu bagian mana yang memakai API yang ternyata baru ada di versi Minecraft yang lebih baru dari 1.21.1, lalu diperbaiki atau (bila belum bisa diverifikasi tanpa compiler sungguhan) dinonaktifkan secara aman. Belum pernah benar-benar di-compile dengan `./gradlew build` (lingkungan pembuatan porting ini tidak ada akses internet untuk resolve Minecraft/Yarn/Fabric API) - **jalankan `./gradlew build` sungguhan dan cek error-nya** sebelum rilis produksi.

Yang sudah diperbaiki khusus untuk port 1.21.1:

| File | Masalah di versi sebelumnya (1.21.11) | Perbaikan |
|---|---|---|
| `assets/xoldiummod/textures/font/xoldium_icon.png` | Gambar 48x64 px (tidak persegi) - bitmap font provider Minecraft MEWAJIBKAN grid persegi, jadi glyph gagal render & tampil kotak "missing glyph" di depan nametag pengguna Xoldium lain. | Dipadding jadi 64x64 px (logo asli tidak diubah/di-crop). |
| `client/gui/IconRenderer.java` | Memakai `DrawContext#drawTexturedQuad`, baru ada mulai render pipeline rewrite 1.21.6+/1.21.7+ - tidak ada di 1.21.1, gagal compile. | Diganti ke overload `drawTexture(...)` klasik yang sudah ada sejak lama. |
| `client/util/HudRenderUtil.java`, `TotemCounterModule.java`, `KeystrokesModule.java` | Memakai `Matrix3x2fStack`/`pushMatrix()`/`translate(x,y)` 2-argumen - dikonfirmasi lewat dokumentasi Fabric API baru berlaku mulai **1.21.8**, bukan ~1.21.2 seperti dugaan awal. Dipakai HAMPIR SEMUA modul HUD, jadi ini titik gagal-compile paling kritis. | Dikembalikan ke `MatrixStack` klasik (`push()`/`pop()`/`translate(x,y,z)`/`scale(x,y,z)` 3-argumen) yang memang dipakai 1.21.1. |
| `client/render/motionblur/MotionBlurRenderer.java` + 2 Mixin-nya (`MotionBlurWorldRendererMixin`, `MotionBlurGameRendererMixin`) | Diimplementasikan langsung di atas `com.mojang.blaze3d.systems.GpuDevice`/`RenderPass`/`GpuBufferSlice` dst - abstraksi GPU yang juga bagian dari rewrite 1.21.6+, sama sekali tidak ada di 1.21.1. | Kedua Mixin **dihapus**, `MotionBlurRenderer` dijadikan no-op aman. Modul "Motion Blur" tetap tampil di Mod Menu (tidak crash), tapi **belum menghasilkan efek blur** di build 1.21.1 ini - perlu ditulis ulang di atas sistem shader post-process versi lama (`ShaderEffect`) sebagai pekerjaan terpisah. |

Titik yang SUDAH dicek dan dipastikan aman tanpa perlu perubahan (API-nya memang sudah ada & stabil sejak sebelum 1.21.1): `WorldRenderEvents`/`WorldRenderContext`/`HudRenderCallback` (paket `...rendering.v1` klasik, bukan paket `v1.world` yang baru ada 1.21.9+), `client/render/WorldOverlay.java` (VertexConsumer manual, tidak tersentuh rewrite), `DamageIndicatorModule.java` (MatrixStack DUNIA 3D, bukan MatrixStack GUI - tidak kena perubahan 1.21.8), `client/gui/XoldiumHomeScreen.java` (fallback teks, `drawTexture` sudah ikut diperbaiki di atas).

Titik yang punya `require = 0` sebagai jaring pengaman (sudah dipasang di SEMUA Mixin proyek ini) tapi descriptor-nya belum diverifikasi ulang khusus untuk 1.21.1 - kalau fitur terkait tidak aktif setelah build, ini yang perlu dicek pertama lewat `genSources`/IDE:

| File | Yang perlu dicek bila fitur tidak aktif |
|---|---|
| `mixin/particle/ParticleSpawnCullMixin.java` | Return type `addParticle(...)` (harus `@Nullable Particle`, bukan `void`) di Yarn 1.21.1. |
| `mixin/visual/LightmapTextureManagerMixin.java` (Fullbright) | Posisi ordinal pemanggilan `Double#floatValue()` di dalam `LightmapTextureManager#update(float)` bisa bergeser antar versi. |
| `mixin/visual/ZoomFovMixin.java` | Signature `GameRenderer#getFov(Camera, float, boolean)`. |
| `mixin/entity/*CullMixin.java`, `mixin/hud/*Mixin.java`, `mixin/network/SyncedOptionsMarkerMixin.java`, `mixin/entity/Totem*Mixin.java`, `mixin/entity/MobAiThrottleMixin.java` | Nama/descriptor method target - kemungkinan besar aman (method vanilla lama yang stabil), belum diverifikasi lewat compiler sungguhan. |
| `client/compat/vulkanmod/XoldiumVulkanModIntegration.java` | Seluruhnya via reflection & gagal-aman bila API VulkanMod tidak cocok - verifikasi lewat decompile VulkanMod versi target bila integrasi tidak jalan. |

Setiap titik di atas sudah diberi komentar Javadoc "CATATAN VERIFIKASI MAPPING" / "PORTING NOTE" langsung di kodenya.

---

## Struktur Proyek

```
src/main/java/com/xoldium/xoldiummod/          - kode umum (main+server aman): config, Mob AI Throttle, mixin server-safe
src/client/java/com/xoldium/xoldiummod/client/ - seluruh GUI, modul HUD/Optimization/Movement/Visual, rendering
src/client/java/com/xoldium/xoldiummod/mixin/  - mixin client-only (culling, chat timestamp)
src/main/resources/                            - fabric.mod.json, mixins.json, lang, logo.png
```

## Config

`config/xoldiumclient.json` - dibuat otomatis saat pertama kali dijalankan, berisi seluruh parameter optimasi + state ON/OFF, posisi, dan skala setiap modul.

---

Xoldium by **ridzzxmc**. Lisensi MIT.

---

## Kredit inspirasi modul (kode Xoldium ditulis ulang, bukan disalin)

Zoom (Zoomify 2.15.2 - isXander, LGPL-3.0-or-later: model tier/pembagi FOV, transisi, relative sensitivity - ditulis ulang, bukan disalin; tetap hormati LGPL bila mendistribusikan) & OkZoomer (Ok Zoomer team), Custom Block Highlight (Tektonikal), Fullbright (Greenman999),
Totem Counter & Hit Range (uku3lig; Hit Range berlisensi MPL-2.0 - default & fitur diikuti, kode digambar ulang untuk Fabric 1.21.1), Motion Blur (Jahleel / ItsPasi, LGPL-3.0 - lihat `MotionBlurRenderer`; **efek blur-nya untuk sementara non-aktif di build 1.21.1 ini**, lihat tabel status verifikasi di atas).

Paket src/client/java/ru/vidtu/ias adalah backend dari In-Game Account Switcher (IAS)
(https://github.com/The-Fireplace-Minecraft-Mods/In-Game-Account-Switcher), lisensi LGPL-3.0
(lihat LICENSE di folder ini). Perubahan: hanya menghapus anotasi org.jetbrains/errorprone
agar tidak butuh dependensi tambahan. Logika akun (offline, Microsoft device code, penyimpanan)
tidak diubah. Penghubung ke Minecraft ada di client/account/XoldiumAccounts.java.

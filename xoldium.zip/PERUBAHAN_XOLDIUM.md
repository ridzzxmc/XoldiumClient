# Ringkasan Perubahan

## Sesi 6 (terbaru) — Setiap Module punya Module Setting sendiri

Sesi 5 baru kasih setting nyata ke 4 modul (Motion Blur/Zoom/FreeLook/Time
Changer) - gear-icon TIDAK muncul di 39 modul lainnya. Sekarang **SEMUA**
modul (HUD, Optimization, Visual, Movement) punya minimal satu setting
NYATA (bukan hiasan/palsu):

- **Semua modul HUD** (32 modul): setting universal baru "Background
  Opacity" (0.0-1.0, default 0.56 = alpha lama) ditambahkan sekali di
  `HudModule` (kelas dasar) - otomatis diwarisi semua modul HUD tanpa
  perlu diulang manual. Ini yang langsung jawab contoh permintaan "setting
  FPS background jadi transparan" - set ke 0.0 = latar transparan penuh.
  `HudRenderUtil` diubah supaya benar-benar memakai nilai ini (dulu
  konstanta `BACKGROUND = 0x90000000` tetap, sekarang dihitung per-modul).
- **Semua modul Optimization** (10 modul): setting universal "Notify in
  Chat" (kirim pesan chat lokal saat di-toggle) ditambahkan di
  `OptimizationToggleModule`. 7 dari 10 modul JUGA dapat slider numerik
  nyata yang terhubung LANGSUNG ke field `XoldiumConfig` yang sama yang
  dibaca mixin culling (bukan penyimpanan terpisah): Frustum Margin, Cull
  Distance, Render Distance, Safe Radius, Freeze Distance (sudah ada
  sebelumnya di config), plus 3 field BARU yang ditambahkan sesi ini:
  `playerCullMinDistance` (Player Culling - jarak aman pemain lain tidak
  pernah di-cull), `blockEntityCullMargin` (Block Entity Culling, dulu
  konstanta tetap `1.0` di mixin), `FrustumContext.extraCullMargin`
  (Occlusion Boost - margin tambahan di atas radius otomatis).
- **Movement**: Auto Sprint dapat setting "Sprint While Sneaking".
- **Visual** (10 modul, semuanya sekarang ada settingnya): Fullbright
  ("Brightness" 1-15, dulu konstanta tetap 15), Damage Indicator
  ("Duration" 0.3-3.0 detik, dulu tetap 0.9 detik), No Hurt Cam
  ("Reduction" 0.0-1.0, dulu selalu hard 0), Block Overlay & Blocks
  Modifier (masing-masing "Hue" 0-360°, dikonversi HSV->RGB lewat
  `MathHelper.hsvToRgb` vanilla, dulu warna tetap), Scroll Settings
  ("Scale Step", dulu konstanta tetap `0.1f` di `XoldiumHomeScreen`).

Total: 4 (Sesi 5) + 39 (sesi ini) = SEMUA modul yang terdaftar di
`ModuleManager` sekarang menampilkan gear-icon dengan setting yang
sungguhan berefek.

## Sesi 5 — Bug title/HUD Editor + 20 module baru + animasi

### Bug title screen (logo jadi checkerboard hitam-magenta) — DIPERBAIKI
`mixin/titlescreen/TitleScreenMixin.java`: `title_logo.png` yang dipakai
sejak Sesi 2 TERNYATA TIDAK PERNAH ada di
`src/main/resources/assets/xoldiummod/` — Minecraft otomatis mengganti
tekstur yang gagal di-load dengan checkerboard hitam-magenta bawaan,
persis bentuk bug di screenshot. Wordmark "XOLDIUM CLIENT" yang tampil
benar itu sebenarnya dari override tekstur vanilla
`assets/minecraft/textures/gui/title/minecraft.png` (tidak berhubungan
dengan konstanta yang rusak itu). Drawable banner lebar yang rusak
dihapus total (bukan dicari file penggantinya - vanilla logo sudah cukup),
diganti badge kecil `logo.png` (yang benar-benar ada) di pojok kiri-bawah
dekat teks versi.

### Bug posisi logo HUD Editor ketabrak tombol — DIPERBAIKI
`client/gui/XoldiumHomeScreen.java#renderLogo`: posisi logo dulu dihitung
independen dari posisi tombol (`-24` tetap), sekarang dihitung MUNDUR dari
`buttonsY` dengan jarak aman tetap (14px) supaya tidak pernah tabrakan lagi.

### Setting keybind per-modul
`client/module/setting/KeybindSetting.java` (baru) membungkus `KeyBinding`
vanilla asli - persistensi otomatis lewat `options.txt` Minecraft sendiri.
`client/gui/ModuleSettingsScreen.java` ditambah tombol "tekan tombol..."
untuk mengubahnya langsung dari gear-icon modul (dipakai Zoom & FreeLook).

### Animasi smooth (bukan cuma ganti warna)
- `client/gui/IconRenderer.java`: toggle switch sekarang di-ease
  berdasarkan waktu nyata (knob geser + warna fade, ~150ms), progres
  animasi disimpan per-`module.id()` supaya tiap kartu independen.
- `client/gui/ModListScreen.java`: transisi buka/tutup Mod Menu pakai
  teknik "tirai" fade hitam (overlay alpha, BUKAN scale/translate
  transform) - aman karena tidak pernah mengubah posisi hit-test tombol
  vanilla selagi animasi jalan. ESC ikut memicu fade-tutup yang sama
  lewat override `close()`.

### 20 module baru (dari daftar id lengkap yang diminta)
13 sudah ada sebelumnya (fps/ping/cps/coords/armor/potions/keystrokes/
memory/pack/chat/fullbright/compass=direction_hud/outline=block_overlay)
- TIDAK ditambahkan ulang. 20 sisanya baru:

**4 dari source code yang dikirim:**
- `render/motionblur/MotionBlurRenderer.java` + `module/visual/MotionBlurModule.java`
  + 2 mixin baru (`MotionBlurGameRendererMixin`, `MotionBlurWorldRendererMixin`):
  PORTING HAMPIR LANGSUNG dari "Smooth Motion Blur" - `gradle.properties`
  mod referensi pakai `yarn_mappings=1.21.11+build.6`, SAMA PERSIS dengan
  proyek ini, jadi seluruh API GPU dipindah nyaris apa adanya. Setting
  "Strength" (0.05-5.0) & "Pause in GUIs" muncul di gear-icon. **Lisensi
  LGPL-3.0-only** (teknik asli oleh ItsPasi) - atribusi dipertahankan di
  javadoc `MotionBlurRenderer`, mohon pertahankan juga bila didistribusikan.
- `module/visual/ZoomModule.java` + `mixin/visual/ZoomFovMixin.java`:
  source Zoomify yang dikirim pakai mapping Mojang untuk versi berbeda,
  jadi DI-IMPLEMENTASI ULANG dari nol (bukan porting) - FOV di-ease halus
  (bukan loncat) selagi tombol ditahan, amount & smoothness diatur lewat
  setting.
- `module/visual/FreeLookModule.java` + `mixin/visual/FreeLookEntityMixin.java`
  + `mixin/visual/FreeLookCameraMixin.java`: source Freelook yang dikirim
  juga pakai mapping Mojang - konsepnya diporting (bukan kodenya) ke 2
  hook Yarn yang jauh lebih stabil (`Entity#changeLookDirection` +
  `Camera#update` TAIL) dibanding meniru method privat `alignWithEntity`
  mod referensi.
- `module/hud/TotemCounterModule.java` + `mixin/entity/TotemPopMixin.java`:
  source Totem Counter yang dikirim pakai mapping Mojang + arsitektur
  multi-loader berbeda - disederhanakan jadi hook tunggal
  `LivingEntity#handleStatus` (byte 35 = pakai totem), ditampilkan sebagai
  HUD sendiri (bukan di tab-list seperti mod referensi).

**16 module baru lainnya** (HUD kecuali disebutkan): Action Bar, Boss Bar
(baca lewat refleksi generik ke field `Map` internal `BossBarHud` - aman,
tidak pernah crash walau field-nya berubah nama), Bow (persentase tarikan),
Crosshair (info block/entity yang dibidik), Hotbar (slot terpilih), Item
Update (popup ganti item), Player (HP/absorption presisi), Scoreboard
(judul+jumlah entri sidebar lewat API publik `Scoreboard`), Settings
(pengingat keybind menu), Speed (block/detik), Time (waktu in-game, beda
dengan Clock HUD yang jam dunia nyata), TPS (perkiraan dari timing tick
client), UHC Overlay (rincian HP/Absorption/Hunger), Blocks Modifier
(**Visual** - outline magenta untuk barrier/light/structure_void yang
dibidik), Scroll Settings (**Visual** - toggle scroll-untuk-skala di HUD
Editor), Time Changer (**Visual** - kirim `/time set` berkala, hanya
berefek bila pemain berwenang).

Ikon: 20 file dari paket "Logo Module" kedua yang dikirim (semua module id
di daftar ternyata sudah punya ikon sendiri) disalin ke
`textures/gui/modules/` & dipetakan di `IconRenderer.MODULE_ICONS`.

## Sesi 4 — Perbaikan crash saat start
### Crash "Mixin transformation of net.minecraft.class_702 failed" — DIPERBAIKI
`mixin/particle/ParticleSpawnCullMixin.java` menargetkan
`ParticleManager#addParticle(...)` dengan descriptor return `V` (void).
Di Yarn 1.21.11, method ini sebenarnya mengembalikan `@Nullable Particle`,
bukan `void` — descriptor lama tidak pernah cocok dengan bytecode asli
(apalagi refmap mod ini tidak ter-load di lingkungan ini), sehingga Mixin
gagal menemukan target dan game crash total setiap kali `MinecraftClient`
membuat `ParticleManager` (persis di awal startup, sebelum menu utama
muncul). Diperbaiki dengan descriptor return yang benar
(`...)Lnet/minecraft/client/particle/Particle;`) dan callback
`CallbackInfoReturnable<Particle>` (`cir.setReturnValue(null)` untuk
membatalkan), bukan `CallbackInfo` biasa. Mixin lain (BlockEntityRenderCull,
EntityRenderCull, ChatHudTimestamp, LightmapTextureManager, TitleScreen,
MobAiThrottle) sudah dicek ulang dan targetnya masih valid di 1.21.11.

## Sesi 3
- **Renderer Optimization DIHAPUS TOTAL** (tidak berguna menurut kamu) -
  file `RendererOptimizationModule.java` dihapus, registrasinya di
  `ModuleManager.java` dan translation key-nya di `en_us.json`/`id_id.json`
  juga dihapus. Tidak ada sisa referensi di source manapun.
- **Damage Indicator dikembalikan ke MERAH** (`0xFF5050`) - permintaan
  "hitam-putih di luar Mod Menu" sebelumnya sudah kelewat jauh sampai
  ke sini, sekarang dibatalkan khusus untuk modul ini.

## Sesi 2
### Hitam-putih di luar Mod Menu
- `client/util/HudRenderUtil.java`: `ACCENT_COLOR` (dulu biru, dipakai
  Combo Counter & Credit HUD) -> abu sangat terang.
- `client/module/hud/KeystrokesModule.java`: kotak tombol ditekan (dulu
  biru) -> putih terang, teks otomatis jadi hitam di atasnya.
- Damage Indicator: lihat Sesi 3 di atas - DIBATALKAN, kembali merah.

### Logo title screen pakai gambar asli
`textures/gui/title_logo.png` (banner "XOLDIUM CLIENT" 1024x265) +
`mixin/titlescreen/TitleScreenMixin.java` digambar 220x57 di atas title
screen, menggantikan wordmark teks polos.

## Sesi 1
### Bug Fullbright — DIPERBAIKI
Mixin langsung ke perhitungan lightmap texture
(`mixin/visual/LightmapTextureManagerMixin.java`), TIDAK lagi lewat
`GameOptions#getGamma()` yang value-nya ditolak diam-diam oleh validator
slider vanilla di Minecraft 1.21.11.

### Mod Menu diperkecil & hitam-putih
`client/gui/ModListScreen.java` (panel ~460x300, kartu ~104x66) +
`client/gui/IconRenderer.java` (toggle & badge hitam-putih-abu netral).

### Ikon modul asli
21 dari 24 modul pakai ikon PNG dari `Logo Module.zip`, dipetakan di
`IconRenderer.MODULE_ICONS`; Biome HUD & No Hurt Cam tetap fallback
badge inisial huruf (tidak ada file ikon yang cocok).

### Logo asli di HUD Editor
`client/gui/XoldiumHomeScreen.java`: badge "X" diganti gambar
`logo.png` asli.

### UI khas title screen (ala Hyper Client)
Tombol "Mod Menu / HUD Editor / Settings" tambahan di kiri layar lewat
`Screen#addDrawable(...)` di `init()` (di 1.21.11 `TitleScreen` sudah
tidak meng-override `render(...)` sendiri lagi - Mixin ke render akan
crash saat start).

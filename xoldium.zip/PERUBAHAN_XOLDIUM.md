# Ringkasan Perubahan

## Sesi 15 - Show Me Your Skin diperbaiki, Inventory Scale, ikon hub (TIDAK DIKOMPILASI di lingkungan Claude)
- **Show Me Your Skin**: penyebab tidak berfungsi = hook lama menarget `render(...)` ArmorFeatureRenderer/ElytraFeatureRenderer
  dengan tipe antrian `OrderedRenderCommandQueue`, padahal di 1.21.11 parameternya `SubmitNodeCollector` (class_11659), sehingga
  hook tidak pernah terpasang (require=0, diam-diam). Sekarang: hook di `HumanoidMobRenderer#getEquipmentIfRenderable`
  (`method_65568`, sumber tunggal item armor/elytra state render) -> mengembalikan ItemStack.EMPTY bila disembunyikan.
  Ditambah dari mod asli: Show Armor In Combat (+durasi) dan Show Elytra While Flying.
  Tidak dibawa: transparansi/glint/trim per potongan, shield/hat, sinkronisasi server.
- **Inventory Scale** (modul baru, Visual): skala container 0.5-8x, skala tooltip 0.5-2x, sembunyikan avatar inventori.
  5 mixin di config "safe" (`InventoryScale*Mixin`). Tooltip diskalakan dengan titik tumpu di kursor (bukan persis mod asli).
- **Hub**: ikon kartu Module (kubus) & HUD Editor (pensil) memakai gambar kiriman, di `textures/gui/hub/`.
- Nama target mixin memakai nama intermediary hasil verifikasi dari file mapping 1.21.11 (folder InventoryScale).

## Sesi 14 (perbaikan besar - TIDAK DIKOMPILASI di lingkungan Claude, lihat catatan)
- **Crash `FireEntityTweakMixin`**: log menunjukkan `FireCommandRenderer#render` di 1.21.11 bertanda tangan
  `(BatchingRenderCommandQueue, VertexConsumerProvider.Immediate, AtlasManager)`, bukan 5 argumen seperti di source
  PvP Tweaks, sehingga Mixin melempar `Invalid descriptor` -> crash saat start. Mixin itu DIHAPUS. Skala api pada
  entitas tidak bisa dipasang aman tanpa menebak tipe internal, jadi "Fire Tweaks" sekarang = overlay api di layar
  (tetap) + **Fire Density** (kepadatan blok api & partikel nyala; port `FireRandomTickMixin` & `ParticleManagerMixin`).
- **Config mixin "aman"** `xoldiummod-safe.mixins.json` (`required: false`): semua mixin yang bergantung signature
  internal (cape, crystal, item physic, tweaks) dipindah ke sini - kalau satu gagal terpasang, hanya di-log, game TIDAK crash.
- **Cape**: hook lama `PlayerEntityRenderer#updateRenderState(AbstractClientPlayerEntity,...)` tidak pernah kena di 1.21.9+
  (renderer jadi generik `Avatar`). Sekarang cape diganti di sumber skin (`PlayerListEntrySkinMixin`), deteksi pengguna lain
  memindai seluruh hierarki `PlayerEntity` (byte skin pindah ke superclass), dan pembuatan aset cape tidak lagi mati
  untuk skin yang diunduh. Cape + chestplate tetap lewat `CapeChestMixin`.
- **HUD ganda**: HUD asli tidak digambar saat HUD Editor terbuka (preview editor sudah digambar sendiri).
- **Armor HUD**: gaya baru "Hotbar" (4 slot berbingkai + bar durabilitas + lencana "!!" berkedip), item di tangan di
  ATAS armor sebagai slot terpisah.
- **Potion HUD**: kartu baru (aksen warna efek, level Romawi, bar durasi, animasi masuk/keluar & kedip < 10 detik).
- **Title screen**: satu tombol "XoldiumClient" (di bawah Realms, di atas Mods) -> HUD Editor; teks "Beta" dihapus;
  panel pemain 3D dengan putar-masuk, ikut kursor halus, cahaya & bayangan; kotak di samping logo nametag hilang
  (spasi mewarisi font ikon); kartu akun pause menu dihitung ulang tiap frame & lebar mengikuti isi (tidak terpotong).
- **Hit Color**: pencarian alamat piksel lewat field + verifikasi, boleh mencoba ulang 5x (sebelumnya gagal permanen).
- **Auto GG**: server cookiesmp.my.id & minesive.com ditambahkan, deteksi umum aktif default.
- **Item Physic** (modul baru, konsep ItemPhysicLite), **Particle Tweaks** (modul baru, dari PvP Tweaks).
- **Animasi**: interpolasi `Anim.Smooth` tak bergantung FPS, easing quint/sine untuk buka-tutup layar.
- BELUM: Custom Crystal per-bagian warna/rainbow dari CC-main (butuh API render 26.x, tidak ada di 1.21.11).

## Sesi 10 (terbaru) - MSG, Hit Color, FreeLook, Custom Crystal/Crosshair, Tweaks, Hitboxes, UI Aurora

> **Status verifikasi jujur:** lingkungan pembuatan sesi ini tidak punya Minecraft/Gradle/internet, jadi mod
> BELUM di-compile penuh. Yang dicek: seluruh file Java lolos parser `javac` (tidak ada error sintaks) dan semua
> JSON valid. Nama API Yarn yang tidak pasti dibuat tahan banting (refleksi berbasis tipe / `require = 0`).
> **Jalankan `./gradlew build` dan uji di game sebelum rilis.** Kirim log error compile-nya bila ada, akan diperbaiki.

1. **Kategori MSG** (di samping Visual) + modul **Auto GG** - port AutoGG-Fabric: daftar server `servers.json`
   dibawa apa adanya (dibaca dari file bawaan, tanpa unduhan jaringan), jeda lewat tick client, pengaman anti-ganda 15 dtk.
2. **Damage Indicator -> Hit Color** - port konsep CookeyMod (timpa 8 baris `OverlayTexture`): warna + intensitas kilatan hit.
3. **FreeLook diperbaiki** - rotasi kamera kini ditimpa tepat saat `setRotation` di dalam `Camera#update` (sebelum
   kamera digeser mundur untuk third person), target dipilih lewat NAMA method (bukan descriptor yang beda tiap versi),
   plus perpindahan perspektif otomatis, mode Hold/Toggle, dan batas putaran kepala seperti source Freelook.
4. **Custom Crystal** (CC-main): Scale, Base (Default/Always/Never), Rotation Speed. Warna/rainbow/frame per-bagian
   BELUM (API render 26.x tidak ada di 1.21.11).
5. **Custom Crosshair** (menggantikan modul Crosshair lama): 32 preset + editor piksel 15x15, warna/skala/opacity.
6. **Tweaks** dari PvP Tweaks: Shield Tweak, Fire Overlay, Custom Size (per jenis item), Vision Tweaks (pumpkin blur).
   Fitur suara/partikel/CPS/durability PvP Tweaks tidak dibawa (sudah ada modul sendiri / di luar permintaan).
7. **Hitboxes** (Combat Hitboxes): kotak hitbox + warna target/hurt, garis mata, arah pandang.
8. **Home screen**: pemain 3D berputar dari skin akun + pil nama/Beta + tombol Wardrobe; **pause menu**: kartu akun
   (kepala, nama, server, ping, online) - gaya Aurora Client.
9. **Mod Menu**: scrollbar kanan yang bisa diseret (klik jalur untuk loncat).
11. **Xoldium Cape + Cape API**: cape logo X (dari Cape.png) untuk pengguna Xoldium; sesama pengguna saling melihat lewat server `xoldium-cape-server` (Node.js, tanpa dependency). Isi `apiUrl` di `config/xoldium_cape.json` atau `DEFAULT_API_URL` di `XoldiumCapeService`. Setting: Share My Cape, Show Others, Force Cape Visible.
12. **Cape (implementasi tanpa server, aktif)** - `XoldiumCapeModule` + `XoldiumUsers` + `CapeChestMixin` + `XoldiumStatusMixin`:
    - Cape tetap tampil saat memakai chestplate (slot chestplate di state render dikosongkan HANYA selama cape dirender, lalu dikembalikan; cape digeser 0.06 ke belakang).
    - Sesama pengguna Xoldium saling melihat cape tanpa server tambahan: client menyalakan bit 7 (0x80, tak dipakai vanilla) pada byte "Skin Customization" yang dikirim ke server; server menyiarkannya ke pemain lain; client Xoldium lain membacanya. Setting: Show Cape With Chestplate, Share Xoldium Status.
    - CATATAN: `client/cape/XoldiumCapeService.java` + `xoldium-cape-server.zip` (butir 11, desain API terpisah) TIDAK terhubung ke modul ini (tidak ada yang memanggilnya). Dibiarkan apa adanya; pilih salah satu pendekatan atau gabungkan.
13. **Perbaikan refleksi**: refleksi struktur Minecraft (SkinTextures, model 3D home screen, umur animasi Custom Crystal) kini memakai URUTAN/TIPE komponen, bukan nama - di game asli (1.21.11 masih ter-obfuscate) nama itu adalah nama intermediary.
10. **HUD Armor & Potion** bergaya foto referensi (Icons / Tiles); kotak label HUD lain kini membulat.

## Sesi 9 - FreeLook, HUD ikon, Tab List icon

> **Status verifikasi jujur:** lingkungan pembuatan sesi ini tidak punya Minecraft/Gradle/internet untuk
> `./gradlew build` sungguhan. Perbaikan diverifikasi lewat riset dokumentasi mapping Yarn manual, BUKAN lewat
> compiler sungguhan. **Jalankan `./gradlew build` sebelum rilis produksi.**

### 1. FreeLook - BUG UTAMA DITEMUKAN & DIPERBAIKI (ada di 1.21.11 MAUPUN 1.21.1)
`FreeLookCameraMixin.java` meng-inject `Camera#update(...)` dengan tipe parameter pertama ditulis sebagai `World`,
padahal descriptor bytecode asli method itu di Yarn memakai tipe `BlockView` (superinterface `World` - Mixin
mencocokkan descriptor APA ADANYA/nominal, bukan lewat subtype, jadi `World` != `BlockView` walau
`World implements BlockView`). Akibatnya mixin ini SELALU gagal ter-apply, dibungkam diam-diam oleh `require = 0`
(tidak crash, tapi juga tidak pernah aktif) -> `FreeLookModule.markCameraHookAlive()` tidak pernah terpanggil ->
`cameraHookAlive()` selalu `false` -> `FreeLookEntityMixin` tidak pernah membatalkan input mouse -> FreeLook
**tidak pernah benar-benar aktif** walau tombolnya ditekan. Diperbaiki: `World` -> `BlockView` di descriptor &
parameter method (satu-satunya perubahan, logika FreeLook lain sudah benar).

### 2. HUD Armor & Potion - sekarang pakai IKON, bukan cuma teks
Permintaan pemakai eksplisit: "jangan cuma tulisan, ada gambar armor nya" / "potion HUD ... ada gambar armor nya"
(maksudnya ikon efek). Kedua modul ditulis ulang:
- **Armor HUD**: tiap slot terisi digambar sebagai baris [ikon item 16x16 asli] + [nama & persen durabilitas],
  lewat `DrawContext#drawItem` - overload yang SAMA yang sudah dipakai `TotemCounterModule` (ikon Totem of
  Undying). Ikonnya diambil dari item aslinya (bukan daftar tekstur tetap), jadi otomatis berlaku untuk armor
  custom apa pun dari server/mod (mis. "Warden Armor", "Sculk Crown" di tangkapan layar pemakai).
- **Potion HUD**: tiap efek digambar [ikon 16x16] + [nama, level, sisa waktu]. Ikon diambil langsung dari
  `assets/<namespace-efek>/textures/mob_effect/<id-efek>.png` (konvensi path resmi Minecraft sejak ~1.19,
  dikonfirmasi lewat dokumentasi resmi docs.fabricmc.net) lewat overload `drawTexture(Identifier,...)` klasik -
  SENGAJA TIDAK memakai `StatusEffectSpriteManager`/`drawSprite` karena overload itu ikut berubah bentuk mengikuti
  perombakan render pipeline 1.21.6+/1.21.7+ (lihat catatan `IconRenderer` soal `drawTexturedQuad`). Efek custom
  tanpa tekstur di path itu otomatis jatuh ke tekstur "missing" bawaan Minecraft, bukan crash.

### 3. Tab List (daftar pemain saat menahan Tab) - ikon Xoldium ditambahkan (fitur baru)
Mixin baru `mixin/hud/PlayerListHudMixin.java` meng-inject `PlayerListHud#getPlayerName(PlayerListEntry)` (method
Yarn yang sudah stabil sejak snapshot 1.16 hingga rilis terbaru) dan menempelkan logo yang SAMA dengan nametag
lewat `XoldiumUsers.decorate` - otomatis kompatibel silang dengan port 1.21.1 karena keduanya membaca bit penanda
yang sama. Batasan wajar: hanya berlaku untuk pemain yang entitasnya sudah dimuat client (lewat
`World#getPlayerByUuid`) - sama seperti keterbatasan alami nametag itu sendiri untuk pemain yang belum ter-render.

### 4. Nametag & tombol title screen/pause menu - diaudit, TIDAK ada bug kode ditemukan
`PlayerDisplayNameMixin`, `OwnNametagMixin`, `SyncedOptionsMarkerMixin`, `XoldiumUsers`, `TitleScreenMixin`,
`GameMenuScreenMixin` sudah diperiksa - tidak ditemukan bug analog kasus FreeLook di atas. Sebagai langkah
pencegahan, `textures/font/xoldium_icon.png` (sebelumnya 48x64, tidak persegi) disamakan jadi 64x64 persegi seperti
port 1.21.1 (yang menurut catatan Sesi 9 port 1.21.1 sempat mengalami bug "kotak/missing glyph" karena grid font
non-persegi) - logo tidak diubah, hanya ditambah padding transparan, supaya kedua build konsisten.

## Sesi 8 - Zoom, Hit Range, Xoldium Tag, Mod Menu transparan, HUD Editor

> **Status verifikasi jujur:** lingkungan pembuatan kode ini tidak punya Minecraft/Gradle/internet, jadi mod BELUM
> di-compile penuh. Yang dicek: seluruh file Java lolos parser `javac` (tanpa error sintaks; error "package does not exist"
> = wajar karena tanpa jar Minecraft), JSON/lang valid. Titik yang bergantung nama API Minecraft dicantumkan di bawah.

### 1. Crash saat menekan keybind (Zoom/FreeLook/Totem) - DIPERBAIKI
Penyebab (dari crash report): `ModuleSettingsScreen#pollCapture` memanggil `GLFW.glfwGetKey` untuk kode 32..348; stub GLFW
Android (Zalith/Pojav) memakai buffer kecil -> `IndexOutOfBoundsException` di `DirectByteBuffer.get`. Sekarang hanya kode
keyboard yang nyata di-poll, tiap panggilan dibungkus try/catch dan kode yang gagal dibuang dari daftar (self-healing).

### 2. Zoom (mengacu Zoomify 2.15.2)
`ZoomModule` ditulis ulang: Initial Zoom + scroll bertingkat (pembagi = initial x stepMultiplier^tier), transisi halus
(waktu nyata), Relative Sensitivity (`1 / lerp(1, divisor, persen)`), Hold/Toggle, tombol **Zoom In / Zoom Out** terpisah
(HP tanpa scroll wheel), tangan tidak ikut zoom (hook `getFov` memakai argumen `changingFov`). Zoom "tidak bisa" karena
tombol tidak bisa diganti (crash #1) dan tombol bawaan `C` tidak terjangkau kontrol sentuh: di Zalith tambahkan tombol
kontrol yang dipetakan ke tombol Zoom. Log mencatat peringatan bila hook `getFov` tidak ter-apply.

### 3. Hit Range (mengacu mod Hit Range uku3lig)
Default kini sama dengan mod referensi: radius 3, Thick 0.15, merah `0x80FF0000`, hijau saat dalam jangkauan, 60 segmen,
jarak maks 100, **Show Around Myself = ON** (lingkaran merah di sekitar pemain sendiri seperti di gambar). Perbaikan:
tidak lagi berhenti diam-diam bila `MatrixStack` event `null`; quad di-flush pada matriks pass dunia; quad dua sisi.
Log mencatat "Hit Range menggambar N cincin" sekali. Setting Hit Range & Zoom lama di `xoldiumclient.json` di-reset SEKALI
(`configVersion` 2) karena config lama menyimpan default lama.

### 4. Xoldium Tag ala Feather (logo di samping nametag)
- Penyebab logo tak pernah muncul: sejak 1.21.9 data tracker skin pindah ke superclass `PlayerEntity`; pemindaian lama hanya
  membaca `PlayerEntity` ("Tidak menemukan TrackedData<Byte>"). Sekarang seluruh hierarki dipindai.
- **Error masuk server DIPERBAIKI:** `SyncedClientOptionsMixin` (konstruktor record, HEAD) dihapus -> diganti
  `SyncedOptionsMarkerMixin` (`GameOptions#getSyncedOptions` RETURN + refleksi record). Tidak ada lagi
  "handler before this() invocation must be static" / "Mixin transformation of class_8791 failed".
- `OwnNametagMixin`: nametag diri sendiri tampil di third-person (F5) lengkap dengan logo (setting "Show My Nametag").
- Keterbatasan: butuh server yang meneruskan byte lapisan skin apa adanya (Paper/Spigot/Velocity umumnya begitu).
- `defaultRequire` mixin diubah 1 -> 0: target mixin yang hilang di versi ini dilewati, bukan menjatuhkan game.

### 5. Mod Menu transparan
`ScreenChrome`: gaya menu **Transparent (default)** / Glass / Solid, dipilih di Home > Settings > Menu Style
(`menuStyle` di config). Redup layar penuh dan "tirai" hitam animasi dihapus; panel & kartu semi-transparan.

### 6. HUD Editor
Tombol **- / +** (0.3x-4.0x), **1x**, panah geser 1 piksel, **Prev/Next** pilih HUD; scroll wheel selalu aktif (tidak lagi
bergantung modul Scroll Settings yang default OFF). **Garis sejajar (snap)**: sisi kiri/tengah/kanan & atas/tengah/bawah
menempel ke HUD lain dan tepi/tengah layar (garis merah muda = X, biru = Y) + pembaca koordinat X/Y saat drag.
Drag memakai polling tombol kiri GLFW di `render` (tanpa override `mouseClicked/Dragged/Released` yang berubah di 1.21.9+).

### Titik yang perlu dicek saat compile
| File | Yang dicek |
|---|---|
| `mixin/visual/ZoomFovMixin` | descriptor `getFov(Camera;FZ)F` (require=0) |
| `mixin/network/SyncedOptionsMarkerMixin` | nama method `GameOptions#getSyncedOptions` (require=0) |
| `mixin/entity/OwnNametagMixin` | descriptor `LivingEntityRenderer#hasLabel(LivingEntity;D)Z` (require=0) |
| `client/render/WorldOverlay` | `WorldRenderContext#matrixStack()/consumers()/camera()`, `VertexConsumerProvider.Immediate#draw(RenderLayer)` |
| `client/social/XoldiumUsers` | `Style#withFont(Identifier)` |

## Sesi 7 — Title/Pause menu pro, animasi halus, modul diperbaiki, Custom Block Highlight, Hit Range, Xoldium Tag

> **Status verifikasi jujur:** lingkungan pembuatan kode ini tidak punya Minecraft/Gradle/internet, jadi
> mod BELUM di-compile penuh. Yang sudah dicek: seluruh 100+ file Java lolos parser `javac` (tanpa error sintaks),
> pemanggilan antar-kelas Xoldium konsisten, JSON/lang valid. Titik yang bergantung nama API Minecraft/Fabric
> tertentu dikumpulkan di bagian **"Titik yang perlu dicek saat compile"** di bawah, dan hampir semua mixin baru
> memakai `require = 0` (gagal-aman: fitur itu saja yang tidak jalan, game tidak crash).

### 1. Bug title Xoldium kepotong — DIPERBAIKI
Penyebab: `LogoDrawer` vanilla hanya menggambar bagian atas (256x44 dari kanvas 256x64) tekstur
`title/minecraft.png`, sedangkan logo Xoldium 1024x233 memenuhi seluruh tinggi kanvas - bagian bawah (blok 3D)
terpotong. Solusi murni aset (tanpa kode, tanpa mixin): logo diskala proporsional & diletakkan di area yang
benar-benar digambar (`minecraft.png` & `minceraft.png` jadi 1024x256, logo di 176px teratas). Splash kuning
sekarang juga tidak lagi menimpa huruf "M".

### 2. Tombol XoldiumClient di Game Menu (pause)
`mixin/titlescreen/GameMenuScreenMixin.java`: tombol **XoldiumClient** otomatis diletakkan tepat di bawah tombol
paling bawah (Disconnect / Save and Quit) dengan lebar sama, membuka Mod Menu. Ditambah lencana akun di kanan atas.

### 3. Tombol & widget vanilla bergaya profesional (semua menu)
Override sprite vanilla (`assets/minecraft/textures/gui/sprites/widget/`): `button`, `button_highlighted`,
`button_disabled`, `slider`, `slider_highlighted`, `slider_handle(_highlighted)`, `text_field(_highlighted)`
(+ `.mcmeta` nine-slice). Efeknya ke SEMUA tombol: Singleplayer, Multiplayer, Realms, Mods, Options, Quit,
Back to Game, Advancements, Statistics, dst. Hitam-abu bersudut membulat, hover = border putih. Tanpa kode -> aman lintas versi.

### 4. Animasi halus
`gui/anim/Anim.java` (easing + `Smooth` + `Timeline`), `gui/anim/ScreenChrome.java`, `gui/XoldiumScreen.java`
(basis semua layar Xoldium: fade + slide buka/tutup). Mod Menu: kartu masuk bertahap (stagger), hover ease,
garis tab meluncur, scroll halus, toggle geser, ikon membesar saat hover. HUD Editor & Settings ikut fade/slide.
Layar baru dibangun dari widget vanilla saja (area klik = `ButtonWidget` transparan) - TANPA override
`mouseClicked/keyPressed`, jadi tidak tergantung perubahan signature input Minecraft 1.21.9+.

### 5. Akun Minecraft di atas menu awal
`gui/AccountBadge.java`: username + kepala skin (skin sungguhan bila akun online; skin default bila offline),
tampil di Title Screen & Game Menu. Pencarian skin lewat refleksi berbasis tipe (bukan nama) + fallback avatar inisial.

### 6. Module Setting untuk SEMUA modul + tipe setting baru
`ColorSetting` (R/G/B/Opacity + pratinjau), `ModeSetting` (pilihan), `visibleWhen` (setting muncul sesuai kondisi),
tombol **Reset to Default**, layar setting scroll-able. Tersimpan di `xoldiumclient.json`
(`moduleColorSettings`, `moduleModeSettings`).

### 7. Modul
- **Zoom (ditulis ulang, mengacu OkZoomer):** penyebab lama = mixin `getFov` memakai descriptor return `D`
  (double) padahal 1.21.11 mengembalikan `float`. Sekarang dua injector (F & D, `require=0`), mode Hold/Toggle,
  scroll untuk ubah zoom, sensitivitas mouse dikurangi saat zoom, easing berbasis waktu.
- **Fullbright:** mixin gamma tetap (pola mod referensi greenman999) + mode **Night Vision** klien-saja sebagai
  cadangan; default "Gamma + Night Vision" supaya pasti terang walau salah satu jalur gagal.
- **Totem Counter (diperbaiki, mengacu uku3lig):** penyebab lama = status totem (35) TIDAK sampai ke
  `LivingEntity#handleStatus`, ditangani `ClientPlayNetworkHandler#onEntityStatus`. Sekarang hook di sana (+ hook lama
  dengan dedupe). Fitur: pop SEMUA pemain di nametag ("Nama | -3", warna bertingkat), HUD jumlah totem inventory / pop sendiri, keybind reset.
- **Custom Block Highlight** menggantikan Block Overlay & Blocks Modifier (dua-duanya dihapus): outline tebal
  (balok tipis), isi sisi, gradient (Vertical/Horizontal/Diagonal/Rainbow/Pulse) + animasi, dua warna outline & isi,
  ketebalan, expand, bentuk block tepat (tangga/slab/pagar), fade, gerak halus, sembunyikan outline vanilla.
- **Hit Range (baru, mengacu uku3lig):** cincin jangkauan di kaki pemain lain - radius, mode Line/Thick/Filled,
  warna & warna saat dalam jangkauan, nearest-only, show-self, jarak maksimum, segmen.
- **Xoldium Tag (baru):** logo Xoldium di nametag sesama pengguna Xoldium. Deteksi tanpa server khusus: bit ke-7
  (`0x80`) byte lapisan skin yang dikirim ke server dan disiarkan ke pemain lain (vanilla hanya memakai bit 0-6).
  `SyncedClientOptionsMixin` menyalakan bit itu, `XoldiumUsers` membacanya, `PlayerDisplayNameMixin` menempel
  glyph logo (font `xoldiummod:xoldium_icons`). Berjalan di server yang meneruskan byte itu apa adanya.
- **Semua modul hanya aktif bila dinyalakan di Mod Menu:** default FPS/Ping/Coordinates/Scroll Settings diubah
  jadi OFF; semua efek modul (mixin/event) dicek `isEnabled()`. (Pengecualian sengaja: Credit HUD dan Xoldium Tag default ON;
  keduanya tetap bisa dimatikan.)

### Titik yang perlu dicek saat compile (semuanya terisolasi)
| File | Yang dicek |
|---|---|
| `client/render/WorldOverlay.java` | 4 method tipis (`camera`, `matrices`, `quadConsumer`, `positionMatrix`) = satu-satunya kode yang menyentuh API render dunia untuk Custom Block Highlight & Hit Range. Di Fabric API baru event ada di `...rendering.v1.world` (`BEFORE_BLOCK_OUTLINE`, `AFTER_ENTITIES`/`END_MAIN`). |
| `CustomBlockHighlightModule` / `HitRangeModule` | Nama event `WorldRenderEvents.BLOCK_OUTLINE` / `AFTER_ENTITIES` sesuai versi Fabric API. |
| `XoldiumHomeScreen` | Override `mouseClicked/mouseDragged/mouseReleased` (HUD Editor drag) - bila memakai 1.21.9+ signature-nya berbasis `Click`. Layar lain sengaja bebas dari override ini. |
| `mixin/visual/ZoomFovMixin`, `LightmapTextureManagerMixin` | Descriptor `getFov(...)F/D` dan ordinal `Double#floatValue` (semua `require=0`). |
| `mixin/network/SyncedClientOptionsMixin` | Nama kelas `SyncedClientOptions` & konstruktor record (target string, `require=0`). |
| `gui/AccountBadge.java` | `MinecraftClient#getSession/getSkinProvider/getGameProfile`, `PlayerSkinDrawer` (refleksi + fallback). |
| `gradle.properties` | Versi ModMenu/Loom/Fabric API harus cocok dengan 1.21.11 - contoh referensi yang jalan di 1.21.11: Loom 1.14+, Loader 0.18+, Fabric API 0.139+, ModMenu 17.0.0-alpha.1. |

## Sesi 6 — Setiap Module punya Module Setting sendiri

Sesi 5 baru kasih setting nyata ke 4 modul (Motion Blur/Zoom/FreeLook/Time
Changer) - gear-icon TIDAK muncul di 39 modul lainnya. Sekarang **SEMUA**
modul (HUD, Optimization, Visual, Movement) punya minimal satu setting
NYATA (bukan hiasan/palsu):

- **Semua modul HUD** (32 modul): setting universal baru "Background
  Opacity" (0.0-1.0, default 0.56 = alpha lama) ditambahkan sekali di
  `HudModule` (kelas dasar) - otomatis diwarisi semua modul HUD tanpa
  perlu diulang manual. Ini yang langsung jawab contoh permintaan "setting
  FPS background jadi transparan" - set ke 0.0 = latar transparan penuh.
  `HudRenderUtil` diubah supaya benar-benar memakai nilai ini (dulu
  konstanta `BACKGROUND = 0x90000000` tetap, sekarang dihitung per-modul).
- **Semua modul Optimization** (10 modul): setting universal "Notify in
  Chat" (kirim pesan chat lokal saat di-toggle) ditambahkan di
  `OptimizationToggleModule`. 7 dari 10 modul JUGA dapat slider numerik
  nyata yang terhubung LANGSUNG ke field `XoldiumConfig` yang sama yang
  dibaca mixin culling (bukan penyimpanan terpisah): Frustum Margin, Cull
  Distance, Render Distance, Safe Radius, Freeze Distance (sudah ada
  sebelumnya di config), plus 3 field BARU yang ditambahkan sesi ini:
  `playerCullMinDistance` (Player Culling - jarak aman pemain lain tidak
  pernah di-cull), `blockEntityCullMargin` (Block Entity Culling, dulu
  konstanta tetap `1.0` di mixin), `FrustumContext.extraCullMargin`
  (Occlusion Boost - margin tambahan di atas radius otomatis).
- **Movement**: Auto Sprint dapat setting "Sprint While Sneaking".
- **Visual** (10 modul, semuanya sekarang ada settingnya): Fullbright
  ("Brightness" 1-15, dulu konstanta tetap 15), Damage Indicator
  ("Duration" 0.3-3.0 detik, dulu tetap 0.9 detik), No Hurt Cam
  ("Reduction" 0.0-1.0, dulu selalu hard 0), Block Overlay & Blocks
  Modifier (masing-masing "Hue" 0-360°, dikonversi HSV->RGB lewat
  `MathHelper.hsvToRgb` vanilla, dulu warna tetap), Scroll Settings
  ("Scale Step", dulu konstanta tetap `0.1f` di `XoldiumHomeScreen`).

Total: 4 (Sesi 5) + 39 (sesi ini) = SEMUA modul yang terdaftar di
`ModuleManager` sekarang menampilkan gear-icon dengan setting yang
sungguhan berefek.

## Sesi 5 — Bug title/HUD Editor + 20 module baru + animasi

### Bug title screen (logo jadi checkerboard hitam-magenta) — DIPERBAIKI
`mixin/titlescreen/TitleScreenMixin.java`: `title_logo.png` yang dipakai
sejak Sesi 2 TERNYATA TIDAK PERNAH ada di
`src/main/resources/assets/xoldiummod/` — Minecraft otomatis mengganti
tekstur yang gagal di-load dengan checkerboard hitam-magenta bawaan,
persis bentuk bug di screenshot. Wordmark "XOLDIUM CLIENT" yang tampil
benar itu sebenarnya dari override tekstur vanilla
`assets/minecraft/textures/gui/title/minecraft.png` (tidak berhubungan
dengan konstanta yang rusak itu). Drawable banner lebar yang rusak
dihapus total (bukan dicari file penggantinya - vanilla logo sudah cukup),
diganti badge kecil `logo.png` (yang benar-benar ada) di pojok kiri-bawah
dekat teks versi.

### Bug posisi logo HUD Editor ketabrak tombol — DIPERBAIKI
`client/gui/XoldiumHomeScreen.java#renderLogo`: posisi logo dulu dihitung
independen dari posisi tombol (`-24` tetap), sekarang dihitung MUNDUR dari
`buttonsY` dengan jarak aman tetap (14px) supaya tidak pernah tabrakan lagi.

### Setting keybind per-modul
`client/module/setting/KeybindSetting.java` (baru) membungkus `KeyBinding`
vanilla asli - persistensi otomatis lewat `options.txt` Minecraft sendiri.
`client/gui/ModuleSettingsScreen.java` ditambah tombol "tekan tombol..."
untuk mengubahnya langsung dari gear-icon modul (dipakai Zoom & FreeLook).

### Animasi smooth (bukan cuma ganti warna)
- `client/gui/IconRenderer.java`: toggle switch sekarang di-ease
  berdasarkan waktu nyata (knob geser + warna fade, ~150ms), progres
  animasi disimpan per-`module.id()` supaya tiap kartu independen.
- `client/gui/ModListScreen.java`: transisi buka/tutup Mod Menu pakai
  teknik "tirai" fade hitam (overlay alpha, BUKAN scale/translate
  transform) - aman karena tidak pernah mengubah posisi hit-test tombol
  vanilla selagi animasi jalan. ESC ikut memicu fade-tutup yang sama
  lewat override `close()`.

### 20 module baru (dari daftar id lengkap yang diminta)
13 sudah ada sebelumnya (fps/ping/cps/coords/armor/potions/keystrokes/
memory/pack/chat/fullbright/compass=direction_hud/outline=block_overlay)
- TIDAK ditambahkan ulang. 20 sisanya baru:

**4 dari source code yang dikirim:**
- `render/motionblur/MotionBlurRenderer.java` + `module/visual/MotionBlurModule.java`
  + 2 mixin baru (`MotionBlurGameRendererMixin`, `MotionBlurWorldRendererMixin`):
  PORTING HAMPIR LANGSUNG dari "Smooth Motion Blur" - `gradle.properties`
  mod referensi pakai `yarn_mappings=1.21.11+build.6`, SAMA PERSIS dengan
  proyek ini, jadi seluruh API GPU dipindah nyaris apa adanya. Setting
  "Strength" (0.05-5.0) & "Pause in GUIs" muncul di gear-icon. **Lisensi
  LGPL-3.0-only** (teknik asli oleh ItsPasi) - atribusi dipertahankan di
  javadoc `MotionBlurRenderer`, mohon pertahankan juga bila didistribusikan.
- `module/visual/ZoomModule.java` + `mixin/visual/ZoomFovMixin.java`:
  source Zoomify yang dikirim pakai mapping Mojang untuk versi berbeda,
  jadi DI-IMPLEMENTASI ULANG dari nol (bukan porting) - FOV di-ease halus
  (bukan loncat) selagi tombol ditahan, amount & smoothness diatur lewat
  setting.
- `module/visual/FreeLookModule.java` + `mixin/visual/FreeLookEntityMixin.java`
  + `mixin/visual/FreeLookCameraMixin.java`: source Freelook yang dikirim
  juga pakai mapping Mojang - konsepnya diporting (bukan kodenya) ke 2
  hook Yarn yang jauh lebih stabil (`Entity#changeLookDirection` +
  `Camera#update` TAIL) dibanding meniru method privat `alignWithEntity`
  mod referensi.
- `module/hud/TotemCounterModule.java` + `mixin/entity/TotemPopMixin.java`:
  source Totem Counter yang dikirim pakai mapping Mojang + arsitektur
  multi-loader berbeda - disederhanakan jadi hook tunggal
  `LivingEntity#handleStatus` (byte 35 = pakai totem), ditampilkan sebagai
  HUD sendiri (bukan di tab-list seperti mod referensi).

**16 module baru lainnya** (HUD kecuali disebutkan): Action Bar, Boss Bar
(baca lewat refleksi generik ke field `Map` internal `BossBarHud` - aman,
tidak pernah crash walau field-nya berubah nama), Bow (persentase tarikan),
Crosshair (info block/entity yang dibidik), Hotbar (slot terpilih), Item
Update (popup ganti item), Player (HP/absorption presisi), Scoreboard
(judul+jumlah entri sidebar lewat API publik `Scoreboard`), Settings
(pengingat keybind menu), Speed (block/detik), Time (waktu in-game, beda
dengan Clock HUD yang jam dunia nyata), TPS (perkiraan dari timing tick
client), UHC Overlay (rincian HP/Absorption/Hunger), Blocks Modifier
(**Visual** - outline magenta untuk barrier/light/structure_void yang
dibidik), Scroll Settings (**Visual** - toggle scroll-untuk-skala di HUD
Editor), Time Changer (**Visual** - kirim `/time set` berkala, hanya
berefek bila pemain berwenang).

Ikon: 20 file dari paket "Logo Module" kedua yang dikirim (semua module id
di daftar ternyata sudah punya ikon sendiri) disalin ke
`textures/gui/modules/` & dipetakan di `IconRenderer.MODULE_ICONS`.

## Sesi 4 — Perbaikan crash saat start
### Crash "Mixin transformation of net.minecraft.class_702 failed" — DIPERBAIKI
`mixin/particle/ParticleSpawnCullMixin.java` menargetkan
`ParticleManager#addParticle(...)` dengan descriptor return `V` (void).
Di Yarn 1.21.11, method ini sebenarnya mengembalikan `@Nullable Particle`,
bukan `void` — descriptor lama tidak pernah cocok dengan bytecode asli
(apalagi refmap mod ini tidak ter-load di lingkungan ini), sehingga Mixin
gagal menemukan target dan game crash total setiap kali `MinecraftClient`
membuat `ParticleManager` (persis di awal startup, sebelum menu utama
muncul). Diperbaiki dengan descriptor return yang benar
(`...)Lnet/minecraft/client/particle/Particle;`) dan callback
`CallbackInfoReturnable<Particle>` (`cir.setReturnValue(null)` untuk
membatalkan), bukan `CallbackInfo` biasa. Mixin lain (BlockEntityRenderCull,
EntityRenderCull, ChatHudTimestamp, LightmapTextureManager, TitleScreen,
MobAiThrottle) sudah dicek ulang dan targetnya masih valid di 1.21.11.

## Sesi 3
- **Renderer Optimization DIHAPUS TOTAL** (tidak berguna menurut kamu) -
  file `RendererOptimizationModule.java` dihapus, registrasinya di
  `ModuleManager.java` dan translation key-nya di `en_us.json`/`id_id.json`
  juga dihapus. Tidak ada sisa referensi di source manapun.
- **Damage Indicator dikembalikan ke MERAH** (`0xFF5050`) - permintaan
  "hitam-putih di luar Mod Menu" sebelumnya sudah kelewat jauh sampai
  ke sini, sekarang dibatalkan khusus untuk modul ini.

## Sesi 2
### Hitam-putih di luar Mod Menu
- `client/util/HudRenderUtil.java`: `ACCENT_COLOR` (dulu biru, dipakai
  Combo Counter & Credit HUD) -> abu sangat terang.
- `client/module/hud/KeystrokesModule.java`: kotak tombol ditekan (dulu
  biru) -> putih terang, teks otomatis jadi hitam di atasnya.
- Damage Indicator: lihat Sesi 3 di atas - DIBATALKAN, kembali merah.

### Logo title screen pakai gambar asli
`textures/gui/title_logo.png` (banner "XOLDIUM CLIENT" 1024x265) +
`mixin/titlescreen/TitleScreenMixin.java` digambar 220x57 di atas title
screen, menggantikan wordmark teks polos.

## Sesi 1
### Bug Fullbright — DIPERBAIKI
Mixin langsung ke perhitungan lightmap texture
(`mixin/visual/LightmapTextureManagerMixin.java`), TIDAK lagi lewat
`GameOptions#getGamma()` yang value-nya ditolak diam-diam oleh validator
slider vanilla di Minecraft 1.21.11.

### Mod Menu diperkecil & hitam-putih
`client/gui/ModListScreen.java` (panel ~460x300, kartu ~104x66) +
`client/gui/IconRenderer.java` (toggle & badge hitam-putih-abu netral).

### Ikon modul asli
21 dari 24 modul pakai ikon PNG dari `Logo Module.zip`, dipetakan di
`IconRenderer.MODULE_ICONS`; Biome HUD & No Hurt Cam tetap fallback
badge inisial huruf (tidak ada file ikon yang cocok).

### Logo asli di HUD Editor
`client/gui/XoldiumHomeScreen.java`: badge "X" diganti gambar
`logo.png` asli.

### UI khas title screen (ala Hyper Client)
Tombol "Mod Menu / HUD Editor / Settings" tambahan di kiri layar lewat
`Screen#addDrawable(...)` di `init()` (di 1.21.11 `TitleScreen` sudah
tidak meng-override `render(...)` sendiri lagi - Mixin ke render akan
crash saat start).

---

## Revisi terbaru (hub XoldiumClient, Cosmetic, HUD baru)

**Perbaikan bug**
- **HUD "tidak berfungsi"**: penyebabnya posisi default banyak modul di luar layar (y = 400-640) dan ikut tersimpan di config. Sekarang `ModuleManager.prepareHud` menempatkan otomatis modul yang belum pernah digeser (atau berada di luar layar) ke slot kosong tanpa menumpuk. Posisi yang pernah kamu geser sendiri tidak diubah.
- **Hit Color**: tekstur overlay tidak lagi "menyerah permanen" setelah gagal; alamat piksel di-cache dan diverifikasi longgar, dicoba ulang terus, di-refresh ~2 detik sekali, dan warna vanilla selalu dikembalikan saat modul OFF (tick global, tidak bergantung modul aktif).
- **AutoGG**: sekarang juga membalas GG saat KAMU membunuh pemain atau DIBUNUH pemain (deteksi pesan kematian, setting On Kill / On Death / Only Real Players), selain deteksi akhir game.
- **ItemPhysic**: yaw item sebelumnya dihitung dari posisi (berubah tiap frame -> item muter-muter saat dilempar). Sekarang yaw konstan per item (diturunkan dari argumen sin/rotation vanilla).
- **Fire Tweaks** dihapus (modul, 2 mixin, lang). Particle Tweaks tetap ada.

**HUD baru**: semua modul HUD memakai kartu berikon item + label + nilai + bar progres (`HudRenderUtil.drawCards`), Keystrokes beranimasi + CPS di tombol mouse, Potion HUD memakai ikon efek dari `textures/gui/sprites/mob_effect/` (path lama tidak ada lagi sejak 1.20.2).

**Fitur baru**
- Hub **XoldiumClient** (kotak besar Module + Cosmetic, tombol kecil HUD Editor di bawahnya).
- Layar **Cosmetic** (tombol "Wardrobe" diganti): daftar kategori, pratinjau 3D (tarik untuk memutar), kisi kartu cape. **Cape XoldiumClient dipindah ke sini** (hilang dari daftar modul).
- **Cart Counter** (port dari cartcounter-1.21.8), **Reach Display** (port dari ReachDisplay), **Show Me Your Skin** (port ringkas: sembunyikan helm/chestplate/legging/sepatu/elytra).

**Cosmetica**: Cosmetica memakai mapping Mojang + library online sendiri (cosmetica-core, kupe), jadi tidak bisa disalin ke proyek Yarn ini. Pasang jar `cosmetica` + `cosmetica-core` + `kupe` di folder `mods`; kategori "Cosmetica" di layar Cosmetic otomatis membuka layar aslinya (refleksi).

---

## Revisi: Cosmetic dihapus, hub 2 kotak, ikon pemain jauh

- Layar **Cosmetic dihapus**. Hub XoldiumClient sekarang hanya **Module** dan **HUD Editor** (dua kotak besar, animasi masuk beroverschoot, hover mengangkat + kilau menyapu, ikon melayang, efek tekan).
- Tombol di bawah pemain 3D (title screen) sekarang **Xoldium HUD Editor** dan langsung membuka HUD Editor.
- **Cape XoldiumClient dikembalikan ke daftar modul** (karena Cosmetic dihapus).
- **Ikon XoldiumClient untuk pemain jauh**: nametag vanilla berhenti di 64 blok, jadi logo ikut hilang. Sekarang ada overlay ikon (+ nama kecil & jarak) di atas kepala pemain Xoldium yang lebih jauh dari "Far Icon Starts At" (default 64 blok, setting di modul Xoldium Tag). Status pengguna juga di-cache per UUID sehingga ikon di tab tetap tampil walau entitas pemain tidak termuat.

# Xoldium Client

Mod client & optimasi Fabric/Quilt untuk Minecraft **1.21 - 1.21.11** (dikonfigurasi & diuji-rancang untuk **1.21.11**), penerus dari FulconMod - sekarang dengan Mod Menu bergaya modular (HUD / Optimization / Movement / Visual), HUD Editor drag-and-drop, dan seluruh optimasi rendering FulconMod yang sudah diperluas.

Tekan **Right Shift** (bisa diubah lewat menu *Controls* vanilla) untuk membuka Xoldium, atau klik tombol **XoldiumClient** di bawah Disconnect pada Game Menu / tombol **Mod Menu** di Title Screen.

---

## Fitur

### Layar Awal + HUD Editor (Right Shift)
Logo & wordmark Xoldium, tombol **Open Mod Menu** dan **Settings**, sekaligus jadi editor HUD: seret elemen HUD aktif untuk memindah posisi, scroll di atasnya untuk mengubah skala (0.5x - 3.0x). Dunia game tetap terlihat & berjalan normal di baliknya (bukan menu jeda buram).

### Mod Menu (kartu modul, tab, pencarian)
Tab **All / HUD / Optimization / Movement / Visual**, kotak pencarian, kartu per-modul dengan ikon, toggle ON/OFF, dan ikon gear untuk setting tambahan (bila modulnya punya setting).

- **HUD** (19 modul): FPS, Ping, CPS Counter, Coordinates, Clock, Day Counter, Direction, Biome, Armor, Potion, Saturation, Keystrokes, ArrayList, Combo Counter, Memory, Server Info, Pack Display, Chat Timestamps, dan Credit HUD permanen ("Xoldium by ridzzxmc").
- **Optimization**: 10 toggle (master switch + seluruh opsi culling/throttle di bawah) + tombol preset **Auto FPS Boost**.
- **Movement**: Auto Sprint.
- **Visual**: Custom Block Highlight (outline/isi/gradient/animasi, menggantikan Block Overlay & Blocks Modifier), Hit Range, Zoom, Fullbright, Free Look, Motion Blur, Damage Indicator, No Hurt Cam, Time Changer, Xoldium Tag (logo di nametag sesama pengguna Xoldium).
- **Semua modul** punya Module Setting sendiri (gear-icon: slider, pilihan, warna RGBA, keybind, Reset to Default) dan hanya aktif bila dinyalakan di Mod Menu.

Setiap modul dibungkus try/catch terpusat di `ModuleManager` - bila satu modul error, HANYA modul itu yang otomatis nonaktif ("Disabled (error)" di kartunya); modul lain & client tetap jalan normal.

### Optimasi Rendering & Logika (warisan FulconMod, diperluas)
Entity/Player/Block-Entity frustum culling, particle frustum culling + fast-path, fast entity rendering, occlusion culling boost, dan **Mob AI Throttling** (menurunkan frekuensi evaluasi AI mob pasif/ambient yang jauh dari pemain, freeze total di atas jarak tertentu) - semua lewat Fabric Rendering API (`WorldRenderEvents`, `HudRenderCallback`) dan Mixin bertarget sempit, TIDAK PERNAH menyentuh OpenGL/GlStateManager/RenderSystem langsung, sehingga kompatibel dengan Sodium maupun VulkanMod.

---

## Build

```bash
./gradlew build
```

Hasil jar ada di `build/libs/xoldiummod-<version>.jar`. Butuh JDK 21 dan koneksi internet (untuk resolve Minecraft/Yarn/Fabric API - tidak dilakukan di lingkungan pembuatan kode ini, lihat bagian "Status verifikasi" di bawah).

Untuk build ke versi Minecraft 1.21.x lain dalam rentang 1.21-1.21.11: duplikasi properti `minecraft_version`/`yarn_mappings`/`fabric_version` di `gradle.properties` per versi target, sama seperti cara Lithium/Sodium/VulkanMod merilis jar terpisah per versi.

---

## Integrasi Mod Optimasi Pihak Ketiga (Lithium, BadOptimizations, ThreadTweak, MoreCulling, ScalableLux)

Source code kelima mod tersebut **tidak disalin/ditulis-ulang** ke dalam Mixin milik Xoldium. Ini keputusan teknis, bukan disingkat-singkat:

- Kelimanya punya puluhan-ratusan Mixin yang saling bergantung dan terikat erat ke mapping Yarn spesifik masing-masing. Menyalin mentah tanpa proses build/verifikasi ulang penuh (genSources, remap, test run sungguhan) sangat berisiko menghasilkan crash/bug baru - bertentangan langsung dengan syarat "stabil, tanpa error, tanpa crash".
- Pendekatan yang benar (dan yang dipakai modpack/mod "bundle optimasi" pada umumnya): pakai jar hasil build RESMI tiap mod apa adanya, lalu satukan ke satu file Xoldium.jar lewat **jar-in-jar** (`include` di Loom).

**Cara mengaktifkan** (manual, butuh internet - lihat `libs/README.txt`):
1. Build tiap project source yang dilampirkan dengan Gradle mereka sendiri.
2. Salin jar hasil build (bukan `-sources.jar`) ke folder `libs/`.
3. Buka `build.gradle`, aktifkan blok `include modImplementation(fileTree(...))` di bagian "INTEGRASI MOD OPTIMASI PIHAK KETIGA".
4. `./gradlew build`.

Sebelum langkah di atas dilakukan, Xoldium tetap 100% kompatibel berdampingan bila user meng-install kelima mod itu secara terpisah - kategori **Optimization** di Mod Menu Xoldium hanya berisi toggle untuk optimasi milik Xoldium sendiri (bukan toggle mod lain), sesuai prinsip satu sumber kebenaran per pengaturan.

---

## Status verifikasi & catatan mapping (WAJIB dibaca sebelum build produksi)

Kode ini ditulis **tanpa akses internet/compiler** terhadap Minecraft 1.21.11 sungguhan, jadi belum pernah benar-benar di-compile. Seluruh arsitektur, logika, dan ~90% API yang dipakai sudah diverifikasi konsisten secara manual (nama field/method dicocokkan silang di seluruh project - lihat di bawah), tapi beberapa titik kecil bergantung pada signature API rendering yang **sering berubah antar rilis Minecraft** dan sebaiknya dicek sekali lewat `genSources`/IDE sebelum rilis produksi:

| File | Yang perlu dicek |
|---|---|
| `client/util/HudRenderUtil.java` | `DrawContext#getMatrices()` diasumsikan `Matrix3x2fStack` (API 2D pasca ~1.21.2): `pushMatrix()/popMatrix()/translate(x,y)/scale(x,y)`. |
| `client/render/WorldOverlay.java` + `CustomBlockHighlightModule` / `HitRangeModule` | Event `WorldRenderEvents.BLOCK_OUTLINE`/`AFTER_ENTITIES` (di Fabric API 1.21.9+ paket `...rendering.v1.world`), `WorldRenderContext#consumers/matrixStack/camera`, `RenderLayer#getDebugQuads`. Semua geometri lewat 4 method tipis di `WorldOverlay`. |
| `client/module/visual/DamageIndicatorModule.java` | Overload `TextRenderer#draw(..., Matrix4f, VertexConsumerProvider, ...)` untuk teks 3D billboard. |
| `client/gui/XoldiumHomeScreen.java` | `MinecraftClient#getRenderTickCounter()`. Logo digambar sebagai badge+wordmark teks (selalu kompilasi bersih) - lihat Javadoc method `renderLogo()` untuk cara mengaktifkan gambar `logo.png` asli setelah verifikasi overload `drawTexture`. |
| `client/compat/vulkanmod/XoldiumVulkanModIntegration.java` | Seluruhnya via reflection & gagal-aman bila API VulkanMod tidak cocok - verifikasi lewat decompile VulkanMod versi target. |

Setiap Mixin & titik di atas sudah diberi komentar Javadoc "CATATAN VERIFIKASI MAPPING" langsung di kodenya. Di luar titik-titik ini, seluruh nama kelas/method/field internal Xoldium sendiri (Module, HudModule, ModuleManager, XoldiumConfig, dst) sudah diverifikasi silang otomatis (import, pemanggilan method, nama field) sehingga konsisten satu sama lain.

---

## Struktur Proyek

```
src/main/java/com/xoldium/xoldiummod/          - kode umum (main+server aman): config, Mob AI Throttle, mixin server-safe
src/client/java/com/xoldium/xoldiummod/client/ - seluruh GUI, modul HUD/Optimization/Movement/Visual, rendering
src/client/java/com/xoldium/xoldiummod/mixin/  - mixin client-only (culling, chat timestamp)
src/main/resources/                            - fabric.mod.json, mixins.json, lang, logo.png
```

## Config

`config/xoldiumclient.json` - dibuat otomatis saat pertama kali dijalankan, berisi seluruh parameter optimasi + state ON/OFF, posisi, dan skala setiap modul.

---

Xoldium by **ridzzxmc**. Lisensi MIT.

---

## Kredit inspirasi modul (kode Xoldium ditulis ulang, bukan disalin)

Zoom (OkZoomer - Ok Zoomer team), Custom Block Highlight (Tektonikal), Fullbright (Greenman999),
Totem Counter & Hit Range (uku3lig), Motion Blur (Jahleel / ItsPasi, LGPL-3.0 - lihat `MotionBlurRenderer`).

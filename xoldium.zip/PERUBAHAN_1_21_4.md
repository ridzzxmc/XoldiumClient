# Xoldium Client - Port 1.21.11 -> 1.21.4 (Revisi 4)

Basis = source 1.21.11 terbaru (semua modul, GUI, XoldiumHub, Account, Cosmetic, Server Switcher, HUD, Tweaks, dst).
Hanya lapisan API yang disesuaikan ke Minecraft 1.21.4. Tampilan, tombol, dan fitur sama dengan 1.21.11.

## Build
`gradle.properties`: minecraft 1.21.4, yarn 1.21.4+build.8, fabric-api 0.119.4+1.21.4, modmenu 13.0.3. Jalankan `./gradlew build`
(pakai jar TANPA `-sources`).

## Perubahan API
- DrawContext: `pushMatrix/popMatrix/translate(x,y)/scale(x,y)` -> `push/pop/translate(x,y,0)/scale(x,y,1)`.
- Gambar tekstur: `drawTexturedQuad` -> `drawTexture(RenderLayer::getGuiTextured, ...)` (IconRenderer.drawTexture, PlayerModel3D).
- Input: `Click` -> `mouseClicked/mouseDragged/mouseReleased(double, double, int)` (ModListScreen, PixelGridWidget).
- Keybind category: objek `KeyBinding.Category` -> String translation key.
- `getTickProgress` -> `getTickDelta`; `getSelectedSlot()` -> field `selectedSlot`; `createNewRootLayer` -> translate z.
- Tombol Title Screen & Pause: bukan lagi mixin, tapi `XoldiumScreenHooks` (Fabric `ScreenEvents`) - tetap sama: XoldiumClient (di bawah Realms,
  di atas Mods), lencana akun, pemain 3D + Cosmetic/Ganti Akun, XoldiumHUB + Server Switcher + kartu akun di pause menu.
- Mixin render ditulis ulang ke signature 1.21.4: Custom Crystal, ItemPhysic, Cape+chestplate, Held Item Tweaks, Inventory Scale
  (mouse + tooltip). Show Me Your Skin: hook `ArmorFeatureRenderer#renderArmor` + pelacak entitas (`ShowSkinEntityMixin`).
- Cape: `SkinTextures` 1.21.4 (6 komponen, cape = komponen ke-3) didukung di `XoldiumCapeModule`.
- Motion Blur = BlurOnly (versi 1.21.4 dari revisi sebelumnya), Zoom = Ok Zoomer 10.0.0-beta.9 (revisi sebelumnya).
  Teks bahasa Zoom ditambahkan kembali ke en_us/id_id.
- Konfigurasi mixin: `src/main/resources/xoldiummod.mixins.json` (MobAiThrottle), `src/client/resources/xoldiummod.client.mixins.json`
  (inti, tanpa refmap manual) dan `xoldiummod.client.safe.mixins.json` (required=false: mixin render yang bila tidak cocok hanya
  menonaktifkan fiturnya, game tidak crash).

## Catatan jujur
Belum dikompilasi di lingkungan pembuatan (tanpa Minecraft/mapping/internet). Jika `./gradlew build` menampilkan error, kirim lognya.
Bagian yang paling mungkin perlu penyesuaian: Show Me Your Skin (nama method `renderArmor`), Inventory Scale (mouse/tooltip),
Held Item Tweaks. Cek `latest.log` untuk pesan "[Xoldium]" dan "Mixin apply failed".

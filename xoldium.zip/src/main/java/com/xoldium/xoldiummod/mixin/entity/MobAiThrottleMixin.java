package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.entity.MobAiThrottleManager;
import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin universal (dikompilasi di source set {@code main}, BUKAN
 * {@code client}) - berjalan baik di dedicated server maupun logical
 * server milik integrated server.
 *
 * <p>CATATAN VERIFIKASI MAPPING: nama method {@code mobTick} sudah stabil
 * di Yarn selama beberapa major version, tetapi selalu verifikasi ulang
 * lewat {@code genSources}/IDE saat pindah ke build Yarn baru.
 */
@Mixin(MobEntity.class)
public abstract class MobAiThrottleMixin {

    @Inject(method = "mobTick", at = @At("HEAD"), cancellable = true)
    private void xoldium$throttleAiTick(CallbackInfo ci) {
        MobEntity self = (MobEntity) (Object) this;
        if (MobAiThrottleManager.shouldSkipAiTick(self)) {
            ci.cancel();
        }
    }
}

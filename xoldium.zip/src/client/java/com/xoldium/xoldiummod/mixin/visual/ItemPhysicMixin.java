package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ItemPhysicModule;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Item Physic (port konsep ItemPhysicLite). Dipasang di config mixin "aman" (required=false): bila salah satu
 * target tidak cocok di versi ini, hanya dilewati + di-log - game tidak crash.
 *
 * <ul>
 *   <li>HEAD/RETURN: push matriks + turunkan item ke tanah (bobbing & spin vanilla dinetralkan di bawah).</li>
 *   <li>Redirect {@code MathHelper.sin(F)F}: nilai konstan -1 -> bobbing vanilla (sin*0.1+0.1) menjadi 0.</li>
 *   <li>Redirect {@code RotationAxis.rotation(F)}: spin sumbu-Y vanilla diganti rotasi tidur (X 90 derajat)
 *       + yaw tetap per item (sumbu Z setelah tidur = berputar di bidang tanah).</li>
 * </ul>
 */
@Mixin(ItemEntityRenderer.class)
public abstract class ItemPhysicMixin {

    @Unique
    private static final String RENDER =
            "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
                    + "Lnet/minecraft/client/render/state/CameraRenderState;)V";

    @Unique
    private float xoldium$yaw;
    @Unique
    private MatrixStack xoldium$pushed;

    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void xoldium$begin(ItemEntityRenderState state, MatrixStack matrices, OrderedRenderCommandQueue queue,
                               CameraRenderState camera, CallbackInfo ci) {
        xoldium$pushed = null;
        try {
            if (!ItemPhysicModule.active() || matrices == null) {
                return;
            }
            xoldium$yaw = ItemPhysicModule.yawFor(state);
            matrices.push();
            // item vanilla berpusat sekitar 0.25*skala di atas kaki entitas; turunkan supaya rata dengan tanah
            matrices.translate(0.0f, -0.085f + ItemPhysicModule.heightOffset(), 0.0f);
            xoldium$pushed = matrices;
        } catch (Throwable ignored) {
            xoldium$pushed = null;
        }
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void xoldium$end(ItemEntityRenderState state, MatrixStack matrices, OrderedRenderCommandQueue queue,
                             CameraRenderState camera, CallbackInfo ci) {
        try {
            if (xoldium$pushed != null) {
                xoldium$pushed.pop();
            }
        } catch (Throwable ignored) {
            // abaikan
        } finally {
            xoldium$pushed = null;
        }
    }

    @Redirect(method = RENDER, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;sin(F)F"), require = 0)
    private float xoldium$noBob(float value) {
        return xoldium$pushed != null ? -1.0f : MathHelper.sin(value);
    }

    @Redirect(method = RENDER, at = @At(value = "INVOKE",
            target = "Lnet/minecraft/util/math/RotationAxis;rotation(F)Lorg/joml/Quaternionf;"), require = 0)
    private Quaternionf xoldium$lieFlat(RotationAxis axis, float angle) {
        if (xoldium$pushed == null) {
            return axis.rotation(angle);
        }
        // tidur di tanah (X +90 derajat) lalu putar di bidang tanah dengan yaw tetap
        return new Quaternionf().rotateX((float) (Math.PI / 2.0)).rotateZ(xoldium$yaw);
    }
}

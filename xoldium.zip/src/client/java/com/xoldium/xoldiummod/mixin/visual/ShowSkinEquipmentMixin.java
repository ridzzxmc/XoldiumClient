package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ShowMeYourSkinModule;
import com.xoldium.xoldiummod.client.util.RenderEntityContext;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Show Me Your Skin (1.21.4): batalkan penggambaran satu potongan armor ({@code ArmorFeatureRenderer#renderArmor})
 * bila {@link ShowMeYourSkinModule#shouldHide} meminta potongan itu disembunyikan. Entitas yang sedang dirender
 * diketahui lewat ShowSkinEntityMixin (di 1.21.4 state render tidak memuat entitas).
 *
 * <p>Config mixin ini bertipe {@code required: false} dan {@code require = 0}: bila signature berbeda,
 * hook hanya dilewati dan armor tampil normal (tidak crash).
 */
@Mixin(ArmorFeatureRenderer.class)
public abstract class ShowSkinEquipmentMixin {

    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true, require = 0)
    private void xoldium$hideArmor(MatrixStack matrices, VertexConsumerProvider vertexConsumers, ItemStack stack,
                                   EquipmentSlot slot, int light, @Coerce Object model, CallbackInfo ci) {
        try {
            if (ShowMeYourSkinModule.shouldHide(RenderEntityContext.current(), slot, stack)) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
            // armor tampil normal
        }
    }
}

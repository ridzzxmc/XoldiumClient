package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ShowMeYourSkinModule;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Show Me Your Skin: timpa hasil {@code getEquipmentIfRenderable(LivingEntity, EquipmentSlot)} (satu-satunya
 * sumber item armor/elytra untuk state render humanoid & pemain di 1.21.11) dengan {@code ItemStack.EMPTY}
 * bila modul meminta potongan itu disembunyikan.
 *
 * <p>Nama target ditulis sebagai nama intermediary ({@code method_65568}, {@code remap = false}) karena
 * diverifikasi langsung dari file mapping 1.21.11 yang dikirim bersama source InventoryScale; di game asli
 * (ter-obfuscate) nama itulah yang dipakai. Handler {@code static} agar valid untuk target statis maupun
 * instance. Config mixin ini bertipe {@code required: false}: bila Mojang mengubah method di versi lain,
 * hook hanya dilewati dan armor tampil normal (tidak crash).
 */
@Mixin(BipedEntityRenderer.class)
public abstract class ShowSkinEquipmentMixin {

    @Inject(method = "method_65568", remap = false, at = @At("RETURN"), cancellable = true, require = 0)
    private static void xoldium$hideEquipment(LivingEntity entity, EquipmentSlot slot,
                                              CallbackInfoReturnable<ItemStack> cir) {
        try {
            ItemStack original = cir.getReturnValue();
            if (ShowMeYourSkinModule.shouldHide(entity, slot, original)) {
                cir.setReturnValue(ItemStack.EMPTY);
            }
        } catch (Throwable ignored) {
            // armor tampil normal
        }
    }
}

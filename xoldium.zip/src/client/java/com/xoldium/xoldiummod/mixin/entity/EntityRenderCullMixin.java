package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.core.FrustumContext;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mempertajam {@code Entity#shouldRender(double, double, double)} dengan uji
 * frustum berbasis bounding box 3D penuh, di atas pengecekan jarak bawaan
 * vanilla (hanya bisa mengubah hasil true -> false, tidak pernah sebaliknya).
 *
 * <p>Entity yang TIDAK PERNAH di-cull: pemain LOKAL dan entity apa pun yang
 * sedang membawa penumpang. Pemain LAIN hanya di-cull bila
 * {@link XoldiumConfig#playerCulling} diaktifkan (default OFF).
 */
@Mixin(Entity.class)
public abstract class EntityRenderCullMixin {

    @Inject(method = "shouldRender(DDD)Z", at = @At("RETURN"), cancellable = true)
    private void xoldium$tightenWithFrustum(double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) {
            return;
        }

        XoldiumConfig cfg = XoldiumConfig.get();
        if (!cfg.enabled || !cfg.entityFrustumCulling) {
            return;
        }

        Entity self = (Entity) (Object) this;

        if (self.hasPassengers()) {
            return;
        }

        if (self instanceof PlayerEntity player) {
            boolean isLocalPlayer = MinecraftClient.getInstance().player == player;
            if (isLocalPlayer || !cfg.playerCulling) {
                return;
            }
            if (cfg.playerCullMinDistance > 0.0) {
                double dx = x - self.getX();
                double dy = y - self.getY();
                double dz = z - self.getZ();
                if ((dx * dx + dy * dy + dz * dz) <= cfg.playerCullMinDistance * cfg.playerCullMinDistance) {
                    return; // masih di dalam jarak "aman" - jangan pernah di-cull
                }
            }
        }

        Box box = self.getBoundingBox();

        boolean useTightMargin = false;
        if (cfg.fastEntityRendering && FrustumContext.camera() != null) {
            var camPos = FrustumContext.camera().getPos();
            double dx = self.getX() - camPos.x;
            double dy = self.getY() - camPos.y;
            double dz = self.getZ() - camPos.z;
            double distSq = dx * dx + dy * dy + dz * dz;
            useTightMargin = distSq > cfg.fastEntityRenderDistance * cfg.fastEntityRenderDistance;
        }

        boolean visible = useTightMargin
                ? FrustumContext.isEntityVisible(self.getId(), box, 0.0)
                : FrustumContext.isEntityVisible(self.getId(), box);

        if (!visible) {
            cir.setReturnValue(false);
        }
    }
}

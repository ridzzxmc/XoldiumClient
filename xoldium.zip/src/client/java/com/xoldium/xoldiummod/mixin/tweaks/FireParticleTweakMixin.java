package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Particle Tweaks - kurangi/sembunyikan partikel ledakan, crystal, totem, hit.
 * Descriptor eksplisit sama dengan ParticleManagerMixin PvP Tweaks 1.21.11.
 */
@Mixin(ParticleManager.class)
public abstract class FireParticleTweakMixin {

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true, require = 0)
    private <T extends ParticleEffect> void xoldium$particleFilter(T params, double x, double y, double z,
                                                                 double vx, double vy, double vz,
                                                                 CallbackInfoReturnable<Particle> cir) {
        Identifier id = Registries.PARTICLE_TYPE.getId(params.getType());
        if (id == null) {
            return;
        }
        String p = id.getPath();

        // --- Particle Tweaks (PvP Tweaks): ledakan / crystal / totem / hit ---
        if (!TweaksModule.ParticleTweaks.active()) {
            return;
        }
        if (p.equals("explosion") || p.equals("explosion_emitter") || p.equals("poof") || p.equals("large_smoke")
                || p.equals("flash")) {
            xoldium$ratio(TweaksModule.ParticleTweaks.explosionRatio(), cir);
        } else if (p.equals("end_rod")) {
            xoldium$ratio(TweaksModule.ParticleTweaks.crystalRatio(), cir);
        } else if (p.equals("totem_of_undying")) {
            xoldium$ratio(TweaksModule.ParticleTweaks.totemRatio(), cir);
        } else if (p.equals("crit") || p.equals("enchanted_hit") || p.equals("damage_indicator")) {
            if (!TweaksModule.ParticleTweaks.showHit()) {
                cir.setReturnValue(null);
            }
        }
    }

    @Unique
    private static void xoldium$ratio(float ratio, CallbackInfoReturnable<Particle> cir) {
        if (ratio >= 1.0f) {
            return;
        }
        if (ratio <= 0.0f || Math.random() > ratio) {
            cir.setReturnValue(null);
        }
    }
}

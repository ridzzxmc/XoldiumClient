package com.xoldium.xoldiummod.mixin.network;

import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Menyalakan bit penanda Xoldium ({@link XoldiumUsers#MARKER_BIT}) pada
 * {@code playerModelParts} di opsi klien yang dikirim ke server - lihat
 * javadoc {@link XoldiumUsers} untuk penjelasan lengkap.
 *
 * <p>Target lewat string (bukan import) dan {@code require = 0}: bila nama
 * kelas/konstruktor berbeda di versi Minecraft lain, mixin ini diam-diam
 * tidak terpasang (logo tidak muncul di pemain lain) tanpa menyebabkan crash.
 * Hanya berlaku bila record dibuat di thread client (opsi milik SENDIRI) -
 * bukan saat server terintegrasi men-decode opsi milik pemain LAN.
 *
 * <p>{@code ordinal = 1}: argumen {@code int} ke-2 pada konstruktor record
 * (ke-1 = viewDistance, ke-2 = playerModelParts).
 */
@Mixin(targets = "net.minecraft.network.packet.c2s.common.SyncedClientOptions")
public abstract class SyncedClientOptionsMixin {

    @ModifyVariable(method = "<init>", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private int xoldium$markModelParts(int modelParts) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.isOnThread() && XoldiumTagModule.shouldBroadcast()) {
                return modelParts | XoldiumUsers.MARKER_BIT;
            }
        } catch (Throwable ignored) {
            // penanda kosmetik - jangan pernah mengganggu pembuatan opsi klien.
        }
        return modelParts;
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * CATATAN VERIFIKASI MAPPING (gaya sama seperti mixin lain di proyek ini -
 * lihat {@code LightmapTextureManagerMixin}): target
 * {@code GameRenderer#getFov(Camera, float, boolean)} adalah signature
 * Yarn yang SANGAT stabil & dipakai luas oleh hampir semua mod zoom
 * Fabric selama bertahun-tahun (jarang berubah antar versi karena FOV
 * effect scaling & item zoom vanilla sendiri bergantung padanya). Tetap
 * verifikasi ulang lewat {@code genSources}/IDE bila build Yarn proyek
 * berubah, sesuai kebiasaan proyek ini.
 */
@Mixin(GameRenderer.class)
public abstract class ZoomFovMixin {

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D", at = @At("RETURN"), cancellable = true)
    private void xoldium$applyZoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        cir.setReturnValue(ZoomModule.applyZoom(cir.getReturnValue()));
    }
}

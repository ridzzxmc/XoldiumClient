package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hook FOV Zoom. {@code GameRenderer#getFov(Camera, float, boolean)} mengembalikan
 * {@code float} di Minecraft 1.21.2+ (dikonfirmasi lewat OkZoomer 16.0.0-beta.2
 * untuk 1.21.11) dan {@code double} di versi lebih lama. Dua injector dengan
 * descriptor eksplisit + {@code require = 0}: yang cocok terpasang, yang tidak
 * cocok dilewati tanpa crash.
 */
@Mixin(GameRenderer.class)
public abstract class ZoomFovMixin {

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F", at = @At("RETURN"),
            cancellable = true, require = 0)
    private void xoldium$zoomFloat(Camera camera, float tickProgress, boolean changingFov,
                                   CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(ZoomModule.applyZoom(cir.getReturnValueF()));
    }

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D", at = @At("RETURN"),
            cancellable = true, require = 0)
    private void xoldium$zoomDouble(Camera camera, float tickProgress, boolean changingFov,
                                    CallbackInfoReturnable<Double> cir) {
        cir.setReturnValue(ZoomModule.applyZoom(cir.getReturnValueD()));
    }
}

package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Vision Tweaks: menyembunyikan overlay labu (pumpkin blur) - sama dengan PumpkinBlurMixin PvP Tweaks. */
@Mixin(InGameHud.class)
public abstract class PumpkinBlurTweakMixin {

    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void xoldium$noPumpkin(DrawContext context, Identifier texture, float opacity, CallbackInfo ci) {
        if (texture != null && TweaksModule.VisionTweaks.hidePumpkinBlur() && texture.getPath().contains("pumpkinblur")) {
            ci.cancel();
        }
    }
}

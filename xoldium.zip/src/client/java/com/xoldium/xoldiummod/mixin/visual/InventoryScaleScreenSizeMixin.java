package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Scale (2/5) - ukuran logis layar container dibagi skala, sehingga susunan slot/tombol dihitung
 * ulang untuk "layar" yang lebih kecil/besar (port {@code ScreenNewMixin}). Hook sesudah baris
 * {@code this.height = height} di {@code Screen#init(int,int)} (method_25423) dan {@code Screen#resize(int,int)}
 * (method_25410), field {@code height} = field_22790.
 */
@Mixin(Screen.class)
public abstract class InventoryScaleScreenSizeMixin {

    @Shadow
    public int width;
    @Shadow
    public int height;

    @Inject(method = "method_25423(II)V", remap = false,
            at = @At(value = "FIELD", target = "Lnet/minecraft/class_437;field_22790:I", shift = At.Shift.AFTER, remap = false),
            require = 0)
    private void xoldium$initSize(int width, int height, CallbackInfo ci) {
        xoldium$apply(width, height);
    }

    @Inject(method = "method_25410(II)V", remap = false,
            at = @At(value = "FIELD", target = "Lnet/minecraft/class_437;field_22790:I", shift = At.Shift.AFTER, remap = false),
            require = 0)
    private void xoldium$resizeSize(int width, int height, CallbackInfo ci) {
        xoldium$apply(width, height);
    }

    private void xoldium$apply(int newWidth, int newHeight) {
        try {
            float scale = InventoryScaleModule.containerScale();
            if (scale == 1.0f) {
                return;
            }
            this.width = (int) Math.ceil((double) newWidth / scale);
            this.height = (int) Math.ceil((double) newHeight / scale);
        } catch (Throwable ignored) {
            // ukuran bawaan tetap dipakai
        }
    }
}

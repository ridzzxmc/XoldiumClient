package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.FreeLookModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Hook kamera FreeLook (mengikuti source "Freelook": rotasi diganti TEPAT saat
 * {@code setRotation} dipanggil di dalam update kamera - SEBELUM kamera
 * digeser mundur untuk third person, sehingga kamera benar-benar mengorbit).
 *
 * <p>Tahan banting terhadap beda versi: target dipilih lewat NAMA method
 * ({@code update}), tanpa descriptor penuh - descriptor-nya berubah antar rilis
 * (BlockView vs World) dan itulah penyebab hook lama diam-diam tidak pernah
 * terpasang. Parameter dibaca dari {@code Args}/{@link MinecraftClient},
 * bukan dari signature. {@code require = 0}: bila target hilang, FreeLook
 * hanya tidak aktif - game tetap normal.
 */
@Mixin(Camera.class)
public abstract class FreeLookCameraMixin {

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Unique
    private boolean xoldium$applied;

    @Inject(method = "update", at = @At("HEAD"), require = 0)
    private void xoldium$resetApplied(CallbackInfo ci) {
        xoldium$applied = false;
    }

    /** Titik utama: ganti argumen setiap pemanggilan setRotation(yaw, pitch) di dalam update. */
    @ModifyArgs(method = "update", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"), require = 0)
    private void xoldium$overrideRotation(Args args) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!FreeLookModule.isActive() || client.player == null || client.getCameraEntity() != client.player) {
            return;
        }
        float yaw = FreeLookModule.getCameraYaw();
        float pitch = FreeLookModule.getCameraPitch();
        if (client.options.getPerspective().isFrontView()) {
            yaw += 180.0f;
            pitch = -pitch;
        }
        args.set(0, yaw);
        args.set(1, pitch);
        xoldium$applied = true;
    }

    /** Cadangan: bila pemanggilan setRotation berada di method lain, timpa rotasi di akhir update. */
    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void xoldium$fallbackRotation(CallbackInfo ci) {
        FreeLookModule.markCameraHookAlive();
        MinecraftClient client = MinecraftClient.getInstance();
        if (!xoldium$applied && FreeLookModule.isActive() && client.player != null
                && client.getCameraEntity() == client.player) {
            float yaw = FreeLookModule.getCameraYaw();
            float pitch = FreeLookModule.getCameraPitch();
            if (client.options.getPerspective().isFrontView()) {
                yaw += 180.0f;
                pitch = -pitch;
            }
            this.setRotation(yaw, pitch);
        }
    }
}

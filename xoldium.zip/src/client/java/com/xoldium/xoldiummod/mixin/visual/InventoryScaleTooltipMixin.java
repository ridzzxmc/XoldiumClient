package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Scale (4/5) - skala tooltip item di layar container. Dipasang di
 * {@code HandledScreen#drawMouseoverTooltip} (HEAD/RETURN): tooltip diskalakan dengan titik tumpu di posisi kursor,
 * sehingga tetap menempel di dekat kursor. {@code require = 0}: bila target tidak cocok, fitur ini tidak aktif.
 */
@Mixin(HandledScreen.class)
public abstract class InventoryScaleTooltipMixin {

    @Unique
    private boolean xoldium$tipScaled = false;

    @Inject(method = "drawMouseoverTooltip", at = @At("HEAD"), require = 0)
    private void xoldium$tipBegin(DrawContext context, int x, int y, CallbackInfo ci) {
        xoldium$tipScaled = false;
        try {
            float scale = InventoryScaleModule.tooltipScale();
            if (scale == 1.0f) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            Window window = client.getWindow();
            float container = InventoryScaleModule.containerScale();
            double guiX = client.mouse.getX() * window.getScaledWidth() / window.getWidth();
            double guiY = client.mouse.getY() * window.getScaledHeight() / window.getHeight();
            float pivotX = (float) (guiX / container);
            float pivotY = (float) (guiY / container);
            context.getMatrices().push();
            context.getMatrices().translate(pivotX, pivotY, 0f);
            context.getMatrices().scale(scale, scale, 1f);
            context.getMatrices().translate(-pivotX, -pivotY, 0f);
            xoldium$tipScaled = true;
        } catch (Throwable ignored) {
            xoldium$tipScaled = false;
        }
    }

    @Inject(method = "drawMouseoverTooltip", at = @At("RETURN"), require = 0)
    private void xoldium$tipEnd(DrawContext context, int x, int y, CallbackInfo ci) {
        if (xoldium$tipScaled) {
            xoldium$tipScaled = false;
            try {
                context.getMatrices().pop();
            } catch (Throwable ignored) {
                // abaikan
            }
        }
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Scale (4/5) - skala tooltip item di layar container. Dipasang di method penggambar tooltip
 * ({@code DrawContext#renderTooltip}, method_51435; di 1.21.11 tooltip digambar "tertunda" di dalam
 * {@code renderWithTooltipAndSubtitles}, jadi sudah berada dalam skala container).
 *
 * <p>Tooltip diskalakan dengan titik tumpu di posisi kursor, sehingga tetap menempel di dekat kursor. (Mod asli
 * menghitung ulang posisi lewat positioner tooltip; versi ini sengaja lebih sederhana agar tidak bergantung pada
 * tipe internal.)
 */
@Mixin(DrawContext.class)
public abstract class InventoryScaleTooltipMixin {

    @Unique
    private boolean xoldium$tipScaled = false;

    @Inject(method = "method_51435", remap = false, at = @At("HEAD"), require = 0)
    private void xoldium$tipBegin(CallbackInfo ci) {
        xoldium$tipScaled = false;
        try {
            float scale = InventoryScaleModule.tooltipScale();
            if (scale == 1.0f) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            Window window = client.getWindow();
            float container = InventoryScaleModule.containerScale();
            double guiX = client.mouse.getX() * window.getScaledWidth() / window.getWidth();
            double guiY = client.mouse.getY() * window.getScaledHeight() / window.getHeight();
            float pivotX = (float) (guiX / container);
            float pivotY = (float) (guiY / container);
            DrawContext self = (DrawContext) (Object) this;
            self.getMatrices().pushMatrix();
            self.getMatrices().translate(pivotX, pivotY);
            self.getMatrices().scale(scale, scale);
            self.getMatrices().translate(-pivotX, -pivotY);
            xoldium$tipScaled = true;
        } catch (Throwable ignored) {
            xoldium$tipScaled = false;
        }
    }

    @Inject(method = "method_51435", remap = false, at = @At("RETURN"), require = 0)
    private void xoldium$tipEnd(CallbackInfo ci) {
        if (xoldium$tipScaled) {
            xoldium$tipScaled = false;
            try {
                ((DrawContext) (Object) this).getMatrices().popMatrix();
            } catch (Throwable ignored) {
                // abaikan
            }
        }
    }
}

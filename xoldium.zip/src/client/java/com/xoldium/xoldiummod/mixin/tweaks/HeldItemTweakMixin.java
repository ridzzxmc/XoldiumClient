package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Custom Size + Shield Tweak untuk item di tangan. Signature
 * {@code renderItem(LivingEntity, ItemStack, ItemDisplayContext, MatrixStack,
 * OrderedRenderCommandQueue, int)} dan impor sama persis dengan
 * {@code HeldItemRendererMixin} di mod PvP Tweaks 1.7.7 (build 1.21.11).
 * Offset/rotasi shield diterapkan di sini juga (mod referensi memakai method
 * intermediary {@code method_3233} yang rapuh - lebih aman satu hook saja).
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemTweakMixin {

    @Inject(method = "renderItem", at = @At("HEAD"), require = 0)
    private void xoldium$tweakHeldItem(LivingEntity entity, ItemStack stack, ItemDisplayContext mode,
                                       MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                                       CallbackInfo ci) {
        if (matrices == null || stack == null || stack.isEmpty()) {
            return;
        }
        if (TweaksModule.ShieldTweak.active() && stack.getItem() == Items.SHIELD) {
            float[] o = TweaksModule.ShieldTweak.offset();
            if (o[0] != 0 || o[1] != 0 || o[2] != 0) {
                matrices.translate(o[0], o[1], o[2]);
            }
            float[] r = TweaksModule.ShieldTweak.rotation();
            if (r[0] != 0) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(r[0]));
            if (r[1] != 0) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(r[1]));
            if (r[2] != 0) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(r[2]));
        }
        if (TweaksModule.CustomSize.active()) {
            float scale = TweaksModule.CustomSize.scaleFor(stack);
            if (Float.compare(scale, 1.0f) != 0) {
                matrices.scale(scale, scale, scale);
            }
        }
    }
}

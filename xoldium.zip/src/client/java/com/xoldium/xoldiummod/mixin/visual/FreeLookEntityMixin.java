package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.FreeLookModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CATATAN VERIFIKASI MAPPING: {@code Entity#changeLookDirection(double,double)}
 * adalah method Yarn yang dipanggil {@code Mouse} vanilla tiap frame mouse
 * bergerak untuk memutar yaw/pitch entitas (lihat juga javadoc
 * {@link FreeLookModule}) - nama & signature ini sudah stabil bertahun-tahun.
 * Hanya dibatalkan untuk pemain lokal selagi {@link FreeLookModule#isActive()}
 * true, supaya badan pemain lain (dan badan sendiri saat FreeLook mati)
 * tidak pernah terpengaruh.
 */
@Mixin(Entity.class)
public abstract class FreeLookEntityMixin {

    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void xoldium$interceptFreeLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        Entity self = (Entity) (Object) this;
        if (FreeLookModule.isActive() && self == MinecraftClient.getInstance().player) {
            FreeLookModule.accumulate(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }
}

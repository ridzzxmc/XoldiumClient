package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ShowMeYourSkinModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Menandai state render milik pemain lokal (untuk setting "Diri sendiri" / "Pemain lain" Show Me Your Skin). */
@Mixin(LivingEntityRenderer.class)
public abstract class ShowSkinTagMixin {

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
            at = @At("TAIL"), require = 0)
    private void xoldium$tag(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        try {
            if (ShowMeYourSkinModule.active()) {
                ShowMeYourSkinModule.tag(state, entity == MinecraftClient.getInstance().player);
            }
        } catch (Throwable ignored) {
            // abaikan
        }
    }
}

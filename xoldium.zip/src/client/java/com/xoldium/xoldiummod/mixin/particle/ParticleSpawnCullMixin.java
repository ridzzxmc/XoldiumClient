package com.xoldium.xoldiummod.mixin.particle;

import com.xoldium.xoldiummod.client.particle.ParticleCullHelper;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mencegat {@code ParticleManager#addParticle(...)} SEBELUM objek
 * {@code Particle} dibuat - keputusan CPU-side murni, nol interaksi dengan
 * render backend (GL maupun Vulkan).
 *
 * <p>CATATAN VERIFIKASI MAPPING (perbaikan crash): di Yarn 1.21.11,
 * {@code addParticle(ParticleEffect, double, double, double, double,
 * double, double)} TIDAK ber-return {@code void}, melainkan
 * {@code @Nullable Particle} (dikonfirmasi lewat Yarn API docs). Descriptor
 * lama di mixin ini ("...)V") tidak pernah cocok dengan bytecode method
 * yang sebenarnya ("...)Lnet/minecraft/client/particle/Particle;"), jadi
 * Mixin gagal menemukan target dan game crash saat {@code MinecraftClient}
 * membuat {@code ParticleManager}. Karena target ber-return non-void,
 * callback WAJIB pakai {@link CallbackInfoReturnable} (bukan
 * {@code CallbackInfo}), dan pembatalan dilakukan dengan
 * {@code cir.setReturnValue(null)} (method aslinya sudah {@code @Nullable}).
 */
@Mixin(ParticleManager.class)
public abstract class ParticleSpawnCullMixin {

    @Inject(
            method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void xoldium$cullOffscreenParticle(
            ParticleEffect parameters, double x, double y, double z,
            double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<Particle> cir) {

        if (!ParticleCullHelper.isEligible(x, y, z)) {
            cir.setReturnValue(null);
        }
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.util.XoldiumUsers;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Menandai pengguna Xoldium: setiap paket keluar diperiksa; hanya paket opsi
 * client (dikenali dari sidik jari strukturnya, lihat {@link XoldiumUsers})
 * yang diganti salinan dengan bit 0x80 menyala. Paket lain lewat tanpa perubahan.
 * {@code require = 0}: bila method tidak ditemukan, fitur ini diam (tidak crash).
 */
@Mixin(ClientCommonNetworkHandler.class)
public abstract class XoldiumStatusMixin {

    @ModifyVariable(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"), argsOnly = true, require = 0)
    private Packet<?> xoldium$tagOptions(Packet<?> packet) {
        try {
            return XoldiumUsers.tagOutgoing(packet);
        } catch (Throwable t) {
            return packet;
        }
    }
}

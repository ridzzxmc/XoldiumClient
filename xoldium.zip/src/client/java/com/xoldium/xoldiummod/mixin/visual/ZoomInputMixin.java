package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scroll mouse saat zoom -> ubah kekuatan zoom (bukan ganti slot hotbar). Descriptor eksplisit + require=0. */
@Mixin(Mouse.class)
public abstract class ZoomInputMixin {

    @Inject(method = "onMouseScroll(JDD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void xoldium$scrollZoom(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (MinecraftClient.getInstance().currentScreen == null && ZoomModule.handleScroll(vertical)) {
            ci.cancel();
        }
    }
}

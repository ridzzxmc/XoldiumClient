package com.xoldium.xoldiummod.mixin.network;

import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Memanggil pengiriman opsi klien ke server ({@code GameOptions#sendClientSettings}). Dipakai
 * {@code CosmeticSync} untuk "denyut" penanda Xoldium saat membagikan cosmetic ke pengguna lain.
 */
@Mixin(GameOptions.class)
public interface GameOptionsInvoker {
    @Invoker("sendClientSettings")
    void xoldium$sendClientSettings();
}

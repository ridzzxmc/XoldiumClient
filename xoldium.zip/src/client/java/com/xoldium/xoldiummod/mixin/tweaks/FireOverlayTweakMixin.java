package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fire Overlay: mengecilkan / menyembunyikan api di layar saat terbakar.
 * Hook sama dengan {@code FireOverlayMixin} PvP Tweaks (HEAD: skala + push,
 * RETURN: pop). Dibuat berpasangan lewat flag supaya push/pop tidak pernah
 * tidak seimbang walau setting berubah di tengah frame.
 */
@Mixin(InGameOverlayRenderer.class)
public abstract class FireOverlayTweakMixin {

    private static boolean xoldium$pushed = false;

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void xoldium$fireHead(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                         Sprite sprite, CallbackInfo ci) {
        xoldium$pushed = false;
        if (!TweaksModule.FireOverlay.active()) {
            return;
        }
        float scale = TweaksModule.FireOverlay.overlayScale();
        if (scale <= 0.0f) {
            ci.cancel();
            return;
        }
        matrices.push();
        matrices.translate(0.0, (1.0f - scale) * -0.5f, 0.0);
        matrices.scale(scale, scale, 1.0f);
        xoldium$pushed = true;
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"), require = 0)
    private static void xoldium$fireTail(MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                         Sprite sprite, CallbackInfo ci) {
        if (xoldium$pushed) {
            xoldium$pushed = false;
            matrices.pop();
        }
    }
}

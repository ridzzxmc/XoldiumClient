package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fire Tweaks - partikel api di blok api. Sama dengan FireRandomTickMixin PvP Tweaks
 * (signature identik dengan source 1.21.11 yang dikirim pemakai).
 */
@Mixin(AbstractFireBlock.class)
public abstract class FireBlockTickTweakMixin {

    @Inject(method = "randomDisplayTick", at = @At("HEAD"), cancellable = true, require = 0)
    private void xoldium$fireDensity(BlockState state, World world, BlockPos pos, Random random, CallbackInfo ci) {
        if (!TweaksModule.FireOverlay.active()) {
            return;
        }
        float density = TweaksModule.FireOverlay.entityScale();
        if (density <= 0.0f || (density < 1.0f && random.nextFloat() > density)) {
            ci.cancel();
        }
    }
}

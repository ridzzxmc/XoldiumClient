package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Scale (5/5) - sembunyikan avatar pemain di layar inventori (bagian "NoInventoryAvatar" dari mod
 * asli). Mod asli me-redirect panggilan di {@code InventoryScreen#renderBg}; di sini method penggambar avatar
 * ({@code renderEntityInInventoryFollowsMouse}, method_2486) dibatalkan langsung, hanya saat layar yang terbuka
 * memang {@link InventoryScreen} dan opsi "Hide Player Avatar" aktif.
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScaleAvatarMixin {

    @Inject(method = "method_2486", remap = false, at = @At("HEAD"), cancellable = true, require = 0)
    private static void xoldium$hideAvatar(CallbackInfo ci) {
        try {
            if (InventoryScaleModule.hideAvatar()) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
            // avatar tampil normal
        }
    }
}

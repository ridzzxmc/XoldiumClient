package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Scale (1/5) - menskalakan seluruh gambar layar container.
 *
 * <p>Mod aslinya memasang push/pop matriks di {@code GameRenderer#render} tepat di sekeliling pemanggilan
 * {@code Screen#renderWithTooltipAndSubtitles}. Di sini hook dipasang langsung di method itu (HEAD/RETURN),
 * yang setara tetapi memberi akses {@link DrawContext} tanpa MixinExtras. Nama target = nama intermediary
 * hasil verifikasi dari file mapping 1.21.11 ({@code method_47413}).
 */
@Mixin(Screen.class)
public abstract class InventoryScaleRenderMixin {

    @Inject(method = "method_47413", remap = false, at = @At("HEAD"), require = 0)
    private void xoldium$scaleBegin(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        InventoryScaleModule.renderScaled = false;
        try {
            float scale = InventoryScaleModule.containerScale();
            if (scale != 1.0f) {
                context.getMatrices().pushMatrix();
                context.getMatrices().scale(scale, scale);
                InventoryScaleModule.renderScaled = true;
            }
        } catch (Throwable ignored) {
            InventoryScaleModule.renderScaled = false;
        }
    }

    @Inject(method = "method_47413", remap = false, at = @At("RETURN"), require = 0)
    private void xoldium$scaleEnd(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (InventoryScaleModule.renderScaled) {
            InventoryScaleModule.renderScaled = false;
            try {
                context.getMatrices().popMatrix();
            } catch (Throwable ignored) {
                // matriks sudah seimbang / tidak bisa di-pop: abaikan
            }
        }
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.Mouse;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Inventory Scale (3/5) - koordinat mouse (dalam satuan GUI) dibagi skala container, supaya klik/hover tetap
 * tepat di atas slot yang digambar membesar/mengecil (port {@code MouseHandlerMixin}). Target:
 * {@code Mouse#getScaledX/Y(Window,double)} (method_68880 / method_68884) yang memanggil
 * {@code Window#getScaledWidth/Height} (method_4486 / method_4502).
 */
@Mixin(Mouse.class)
public abstract class InventoryScaleMouseMixin {

    @Redirect(method = "method_68880", remap = false,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1041;method_4486()I", remap = false),
            require = 0)
    private static int xoldium$scaledWidth(Window window) {
        int original = window.getScaledWidth();
        try {
            float scale = InventoryScaleModule.containerScale();
            return scale == 1.0f ? original : (int) (original / scale);
        } catch (Throwable t) {
            return original;
        }
    }

    @Redirect(method = "method_68884", remap = false,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1041;method_4502()I", remap = false),
            require = 0)
    private static int xoldium$scaledHeight(Window window) {
        int original = window.getScaledHeight();
        try {
            float scale = InventoryScaleModule.containerScale();
            return scale == 1.0f ? original : (int) (original / scale);
        } catch (Throwable t) {
            return original;
        }
    }
}

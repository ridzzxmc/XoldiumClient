package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.Mouse;
import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Inventory Scale (3/5) - koordinat mouse (satuan GUI) dibagi skala container, supaya klik/hover tetap tepat di atas
 * slot yang digambar membesar/mengecil (port {@code MouseHandlerMixin}). Di 1.21.4 koordinat dihitung langsung di
 * {@code Mouse#onMouseButton}, {@code onCursorPos}, dan {@code onMouseScroll} lewat
 * {@code Window#getScaledWidth/getScaledHeight}; pemanggilan itulah yang dialihkan. {@code require = 0}: bila target
 * tidak cocok, fitur ini hanya tidak aktif.
 */
@Mixin(Mouse.class)
public abstract class InventoryScaleMouseMixin {

    @Redirect(method = {"onMouseButton", "onCursorPos", "onMouseScroll"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Window;getScaledWidth()I"),
            require = 0)
    private int xoldium$scaledWidth(Window window) {
        int original = window.getScaledWidth();
        try {
            float scale = InventoryScaleModule.containerScale();
            return scale == 1.0f ? original : (int) (original / scale);
        } catch (Throwable t) {
            return original;
        }
    }

    @Redirect(method = {"onMouseButton", "onCursorPos", "onMouseScroll"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Window;getScaledHeight()I"),
            require = 0)
    private int xoldium$scaledHeight(Window window) {
        int original = window.getScaledHeight();
        try {
            float scale = InventoryScaleModule.containerScale();
            return scale == 1.0f ? original : (int) (original / scale);
        } catch (Throwable t) {
            return original;
        }
    }
}

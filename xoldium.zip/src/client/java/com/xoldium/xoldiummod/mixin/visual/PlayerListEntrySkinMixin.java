package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.XoldiumCapeModule;
import net.minecraft.client.network.PlayerListEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Cape Xoldium - hook di SUMBER tekstur skin (PlayerListEntry#getSkinTextures), bukan di renderer.
 *
 * <p>Kenapa bukan di PlayerEntityRenderer#updateRenderState (cara lama): sejak 1.21.9 renderer pemain
 * generik ({@code AvatarRenderer<AvatarlikeEntity extends Avatar & ClientAvatarEntity>}), jadi descriptor
 * method-nya TIDAK lagi memuat {@code AbstractClientPlayerEntity} - hook lama dengan descriptor itu
 * diam-diam tidak pernah terpasang (require = 0) dan cape tidak pernah muncul. Method skin tidak punya
 * parameter, jadi descriptor-nya tidak bisa salah. Dipasang dua kali (nama Yarn + nama intermediary
 * method_52810) supaya tetap kena walau refmap tidak terbaca; keduanya idempoten.
 */
@Mixin(PlayerListEntry.class)
public abstract class PlayerListEntrySkinMixin {

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$capeYarn(CallbackInfoReturnable<Object> cir) {
        xoldium$apply(cir);
    }

    @Inject(method = "method_52810", remap = false, at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$capeIntermediary(CallbackInfoReturnable<Object> cir) {
        xoldium$apply(cir);
    }

    @Unique
    private void xoldium$apply(CallbackInfoReturnable<Object> cir) {
        try {
            Object original = cir.getReturnValue();
            if (original == null) {
                return;
            }
            PlayerListEntry self = (PlayerListEntry) (Object) this;
            if (self.getProfile() == null) {
                return;
            }
            Object changed = XoldiumCapeModule.transformSkin(original, self.getProfile().getId());
            if (changed != original) {
                cir.setReturnValue(changed);
            }
        } catch (Throwable ignored) {
            // jangan pernah melempar ke render loop
        }
    }
}

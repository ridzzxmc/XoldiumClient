package com.xoldium.xoldiummod.mixin.visual;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * PORTING LANGSUNG dari mixin {@code WorldRendererMixin} pada "Smooth
 * Motion Blur" (source dikirim pemakai) - daftar parameter method
 * {@code render} di bawah SAMA PERSIS dengan mod referensi (build Yarn
 * identik, {@code 1.21.11+build.6}), hanya nama kelas/paket & pemanggilan
 * {@link MotionBlurRenderer} yang disesuaikan.
 */
@Mixin(WorldRenderer.class)
public abstract class MotionBlurWorldRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void xoldium$captureFrame(
            ObjectAllocator allocator,
            RenderTickCounter tickCounter,
            boolean renderBlockOutline,
            Camera camera,
            Matrix4f positionMatrix,
            Matrix4f basicProjectionMatrix,
            Matrix4f projectionMatrix,
            GpuBufferSlice fogBuffer,
            Vector4f fogColor,
            boolean renderSky,
            CallbackInfo ci
    ) {
        MotionBlurRenderer.captureFrame(positionMatrix, basicProjectionMatrix, camera.getCameraPos());
    }
}

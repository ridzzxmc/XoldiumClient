package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.client.gui.AccountCard;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumFonts;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Game Menu (pause): tombol "XoldiumHUB" tepat di BAWAH tombol paling
 * bawah (Disconnect / Save and Quit) - klik membuka Mod Menu Xoldium; plus
 * lencana akun di pojok kanan-atas.
 *
 * <p>Posisi dihitung dari tombol paling bawah yang benar-benar ada (bukan
 * angka tetap) sehingga tetap pas walau layout tombol berubah / ditambah mod
 * lain (mis. Mod Menu menambah tombol "Mods"). {@code require = 0}: bila
 * target berubah, fitur ini hanya tidak muncul - game tetap normal.
 */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {

    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Unique
    private ButtonWidget xoldium$button;
    @Unique
    private ButtonWidget xoldium$switcher;

    @Inject(method = "init()V", at = @At("TAIL"), require = 0)
    private void xoldium$addXoldiumButton(CallbackInfo ci) {
        boolean hasButtons = false;
        for (Element child : this.children()) {
            if (child instanceof ButtonWidget button && button.visible) {
                hasButtons = true;
                break;
            }
        }
        if (!hasButtons) {
            return; // menu jeda tanpa tombol (mis. F3+Esc) - tidak ada yang perlu ditambah
        }
        xoldium$button = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("XoldiumHUB"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new com.xoldium.xoldiummod.client.gui.XoldiumHubScreen(this));
                    }
                })
                .dimensions(this.width / 2 - 102, this.height - 24, 204, 20)
                .build());
        // XoldiumServerSwitcher: buka daftar server dari menu jeda (konsep sama dengan mod ServerSwitcher).
        xoldium$switcher = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("Server Switcher"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen(this));
                    }
                })
                .dimensions(this.width / 2 - 102, this.height - 24, 204, 20)
                .build());
        xoldium$layout();

        // Posisi dihitung ULANG tiap frame dari tombol vanilla/mod lain (Mod Menu menambah tombol "Mods" sesudah
        // init kita). Perhitungan ini IDEMPOTEN: tombol milik kita sendiri TIDAK ikut dihitung, jadi hasilnya
        // selalu sama dan tombol tidak lagi "glitter" naik-turun (bug lama: Server Switcher ikut dianggap tombol
        // terbawah, sehingga tiap frame layout berganti antara tumpuk & satu baris).
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            int[] box = xoldium$layout();
            if (box == null) {
                return;
            }
            int cardY = Math.max(4, box[0] - AccountCard.HEIGHT - 8);
            AccountCard.render(context, this.textRenderer, box[1], box[2], cardY);
        });
    }

    /**
     * Susun tombol XoldiumHUB & Server Switcher tepat di bawah tombol vanilla terbawah.
     *
     * @return {topY, left, right} dari tombol vanilla, atau null bila tidak ada.
     */
    @Unique
    private int[] xoldium$layout() {
        ButtonWidget self = xoldium$button;
        ButtonWidget sw = xoldium$switcher;
        if (self == null || sw == null) {
            return null;
        }
        int topY = Integer.MAX_VALUE;
        int bottomY = 0;
        int left = Integer.MAX_VALUE;
        int right = 0;
        ButtonWidget lowest = null;
        for (Element child : this.children()) {
            if (child instanceof ButtonWidget button && button != self && button != sw
                    && button.visible && button.getWidth() >= 100) {
                topY = Math.min(topY, button.getY());
                left = Math.min(left, button.getX());
                right = Math.max(right, button.getX() + button.getWidth());
                if (button.getY() + button.getHeight() > bottomY) {
                    bottomY = button.getY() + button.getHeight();
                    lowest = button;
                }
            }
        }
        if (lowest == null) {
            return null;
        }
        int x = lowest.getX();
        int fullW = lowest.getWidth();
        int y = bottomY + 4;
        if (y + 20 + 4 + 20 <= this.height - 2) {
            // cukup ruang: tumpuk (XoldiumHUB lalu Server Switcher di bawahnya)
            xoldium$place(self, x, y, fullW);
            xoldium$place(sw, x, y + 24, fullW);
        } else {
            // layar pendek: satu baris berdampingan, dijaga tetap di dalam layar
            if (y + 20 > this.height - 2) {
                y = this.height - 22;
            }
            int half = (fullW - 4) / 2;
            xoldium$place(self, x, y, half);
            xoldium$place(sw, x + half + 4, y, fullW - half - 4);
        }
        return new int[]{topY, left, right};
    }

    @Unique
    private static void xoldium$place(ButtonWidget b, int x, int y, int w) {
        if (b.getX() != x) {
            b.setX(x);
        }
        if (b.getY() != y) {
            b.setY(y);
        }
        if (b.getWidth() != w) {
            b.setWidth(w);
        }
    }
}

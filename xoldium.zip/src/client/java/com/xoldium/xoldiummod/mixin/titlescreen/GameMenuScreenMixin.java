package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.client.gui.AccountCard;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumFonts;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Game Menu (pause): tombol "XoldiumClient" tepat di BAWAH tombol paling
 * bawah (Disconnect / Save and Quit) - klik membuka Mod Menu Xoldium; plus
 * lencana akun di pojok kanan-atas.
 *
 * <p>Posisi dihitung dari tombol paling bawah yang benar-benar ada (bukan
 * angka tetap) sehingga tetap pas walau layout tombol berubah / ditambah mod
 * lain (mis. Mod Menu menambah tombol "Mods"). {@code require = 0}: bila
 * target berubah, fitur ini hanya tidak muncul - game tetap normal.
 */
@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {

    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Unique
    private ButtonWidget xoldium$button;
    @Unique
    private ButtonWidget xoldium$switcher;

    @Inject(method = "init()V", at = @At("TAIL"), require = 0)
    private void xoldium$addXoldiumButton(CallbackInfo ci) {
        boolean hasButtons = false;
        for (Element child : this.children()) {
            if (child instanceof ButtonWidget button && button.visible) {
                hasButtons = true;
                break;
            }
        }
        if (!hasButtons) {
            return; // menu jeda tanpa tombol (mis. F3+Esc) - tidak ada yang perlu ditambah
        }
        xoldium$button = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("XoldiumClient"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new com.xoldium.xoldiummod.client.gui.XoldiumHubScreen(this));
                    }
                })
                .dimensions(this.width / 2 - 102, this.height - 24, 204, 20)
                .build());
        // XoldiumServerSwitcher: buka daftar server dari menu jeda (konsep sama dengan mod ServerSwitcher).
        xoldium$switcher = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("Server Switcher"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen(this));
                    }
                })
                .dimensions(this.width / 2 - 102, this.height - 24, 204, 20)
                .build());

        // Posisi tombol & kartu akun dihitung ULANG tiap frame dari tombol-tombol yang ada saat ini:
        // mod lain (mis. Mod Menu) menambah/menggeser tombol sesudah init() kita, sehingga posisi yang
        // dihitung sekali di awal membuat kartu menimpa tombol "Back to Game" & teksnya terpotong.
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            ButtonWidget self = xoldium$button;
            int topY = Integer.MAX_VALUE;
            int bottomY = 0;
            int left = Integer.MAX_VALUE;
            int right = 0;
            ButtonWidget lowest = null;
            for (Element child : this.children()) {
                if (child instanceof ButtonWidget button && button != self && button.visible && button.getWidth() >= 100) {
                    topY = Math.min(topY, button.getY());
                    left = Math.min(left, button.getX());
                    right = Math.max(right, button.getX() + button.getWidth());
                    if (button.getY() + button.getHeight() > bottomY) {
                        bottomY = button.getY() + button.getHeight();
                        lowest = button;
                    }
                }
            }
            if (lowest == null || self == null) {
                return;
            }
            int y = bottomY + 4;
            if (y + 20 > this.height - 2) {
                y = this.height - 22;
            }
            ButtonWidget sw = xoldium$switcher;
            int fullW = lowest.getWidth();
            if (sw != null && y + 24 + 20 <= this.height - 2) {
                // cukup ruang: Server Switcher tepat di bawah XoldiumClient
                self.setX(lowest.getX());
                self.setY(y);
                self.setWidth(fullW);
                sw.setX(lowest.getX());
                sw.setY(y + 24);
                sw.setWidth(fullW);
            } else if (sw != null) {
                // layar pendek: satu baris, XoldiumClient (60%) + Server Switcher (40%)
                int wLeft = Math.round(fullW * 0.6f) - 2;
                self.setX(lowest.getX());
                self.setY(y);
                self.setWidth(wLeft);
                sw.setX(lowest.getX() + wLeft + 4);
                sw.setY(y);
                sw.setWidth(fullW - wLeft - 4);
            } else {
                self.setX(lowest.getX());
                self.setY(y);
                self.setWidth(fullW);
            }
            int cardY = Math.max(4, topY - AccountCard.HEIGHT - 8);
            AccountCard.render(context, this.textRenderer, left, right, cardY);
        });
    }
}

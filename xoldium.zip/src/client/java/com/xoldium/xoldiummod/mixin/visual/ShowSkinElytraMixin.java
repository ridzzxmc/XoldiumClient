package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ShowMeYourSkinModule;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Show Me Your Skin (elytra): sama seperti armor, tetapi hanya slot dada saat elytra dirender. */
@Mixin(ElytraFeatureRenderer.class)
public abstract class ShowSkinElytraMixin {

    private static final String DESC =
            "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
                    + "ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V";

    @Unique
    private Object[] xoldium$saved;

    @Inject(method = DESC, at = @At("HEAD"), require = 0)
    private void xoldium$begin(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                               BipedEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        xoldium$saved = null;
        try {
            xoldium$saved = ShowMeYourSkinModule.hide(state, true);
        } catch (Throwable ignored) {
            // elytra tampil normal
        }
    }

    @Inject(method = DESC, at = @At("RETURN"), require = 0)
    private void xoldium$end(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                             BipedEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        try {
            ShowMeYourSkinModule.restore(state, xoldium$saved);
        } finally {
            xoldium$saved = null;
        }
    }
}

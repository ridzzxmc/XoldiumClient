package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.CustomCrosshairModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mengganti crosshair vanilla dengan Custom Crosshair (pola yang sama dengan
 * source UltCustomCrosshair: batalkan {@code renderCrosshair} lalu gambar
 * sendiri). Target dipilih lewat NAMA method; argumen tidak dipakai, jadi
 * tidak peka terhadap perubahan signature. {@code require = 0}: bila method
 * tidak ditemukan, crosshair vanilla tetap tampil (tidak crash).
 */
@Mixin(InGameHud.class)
public abstract class CrosshairHideMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void xoldium$replaceCrosshair(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter, CallbackInfo ci) {
        if (CustomCrosshairModule.shouldReplaceVanilla()) {
            ci.cancel();
            CustomCrosshairModule.renderReplacement(context);
        }
    }
}

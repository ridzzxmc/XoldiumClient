package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.util.RenderEntityContext;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Pelacak entitas untuk Show Me Your Skin di 1.21.4: {@code EntityRenderer#getAndUpdateRenderState(entity, tickDelta)}
 * dipanggil tepat sebelum entitas yang sama dirender (1.21.4 merender langsung, tanpa antrean), jadi entitas terakhir
 * yang tercatat = entitas yang sedang digambar oleh ShowSkinEquipmentMixin.
 */
@Mixin(EntityRenderer.class)
public abstract class ShowSkinEntityMixin {

    @Inject(method = "getAndUpdateRenderState", at = @At("HEAD"), require = 0)
    private void xoldium$track(Entity entity, float tickDelta, CallbackInfoReturnable<?> cir) {
        RenderEntityContext.set(entity instanceof LivingEntity living ? living : null);
    }
}

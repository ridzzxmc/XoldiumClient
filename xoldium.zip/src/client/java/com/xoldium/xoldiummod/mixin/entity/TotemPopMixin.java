package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.module.hud.TotemCounterModule;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CATATAN VERIFIKASI MAPPING: {@code LivingEntity#handleStatus(byte)}
 * adalah method Yarn stabil yang menerima "entity status" dari server
 * (dipakai untuk berbagai efek visual: partikel level-up, efek makan,
 * dst). Byte {@code 35} adalah status vanilla untuk "memakai Totem of
 * Undying" ({@code EntityStatuses.USE_TOTEM_OF_UNDYING} - dipakai literal
 * di sini, bukan lewat nama konstanta, supaya tidak bergantung pada satu
 * lagi nama field Yarn yang perlu dipastikan persis).
 *
 * <p>Ini SENGAJA lebih sederhana daripada source code "Totem Counter"
 * yang dikirim pemakai (yang memakai mapping Mojang & arsitektur
 * multi-loader berbeda - lihat javadoc {@link TotemCounterModule}) tapi
 * menangkap kejadian inti yang sama persis: totem pop pemain lain/diri
 * sendiri.
 */
@Mixin(LivingEntity.class)
public abstract class TotemPopMixin {

    private static final byte USE_TOTEM_OF_UNDYING_STATUS = 35;

    @Inject(method = "handleStatus", at = @At("HEAD"))
    private void xoldium$onStatus(byte status, CallbackInfo ci) {
        if (status == USE_TOTEM_OF_UNDYING_STATUS) {
            TotemCounterModule.onTotemPop((LivingEntity) (Object) this);
        }
    }
}

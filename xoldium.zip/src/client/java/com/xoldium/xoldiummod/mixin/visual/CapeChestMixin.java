package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.XoldiumCapeModule;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cape tetap tampil saat memakai chestplate. Selama {@code CapeFeatureRenderer#render}
 * slot chestplate di state dikosongkan (sehingga cek vanilla "ada chestplate ->
 * sembunyikan cape" lolos) lalu DIKEMBALIKAN di akhir method - armor tetap
 * dirender normal oleh feature lain. Cape digeser 0.06 blok ke belakang agar
 * tidak menembus armor. Descriptor penuh + {@code require = 0}: bila signature
 * berbeda di versi ini, hook tidak terpasang dan perilaku vanilla tetap berlaku.
 */
@Mixin(CapeFeatureRenderer.class)
public abstract class CapeChestMixin {

    private static final String DESC =
            "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
                    + "ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V";

    @Unique
    private Object[] xoldium$saved;
    @Unique
    private MatrixStack xoldium$pushed;

    @Inject(method = DESC, at = @At("HEAD"), require = 0)
    private void xoldium$begin(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                               PlayerEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        xoldium$saved = null;
        xoldium$pushed = null;
        try {
            xoldium$saved = XoldiumCapeModule.hideChest(state);
            if (xoldium$saved != null && matrices != null) {
                matrices.push();
                matrices.translate(0.0f, 0.0f, 0.06f);
                xoldium$pushed = matrices;
            }
        } catch (Throwable ignored) {
            // vanilla tetap berjalan
        }
    }

    @Inject(method = DESC, at = @At("RETURN"), require = 0)
    private void xoldium$end(MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                             PlayerEntityRenderState state, float limbAngle, float limbDistance, CallbackInfo ci) {
        try {
            if (xoldium$pushed != null) {
                xoldium$pushed.pop();
            }
        } catch (Throwable ignored) {
            // abaikan
        } finally {
            xoldium$pushed = null;
            try {
                XoldiumCapeModule.restoreChest(state, xoldium$saved);
            } finally {
                xoldium$saved = null;
            }
        }
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.CustomCrystalModule;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.state.EndCrystalEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook Custom Crystal. Signature 1.21.4: {@code render(EndCrystalEntityRenderState,
 * MatrixStack, VertexConsumerProvider, int)}. {@code require = 0}: bila gagal terpasang, crystal tampil normal.
 */
@Mixin(EndCrystalEntityRenderer.class)
public abstract class EndCrystalRenderMixin {

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/EndCrystalEntityRenderState;"
            + "Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), require = 0)
    private void xoldium$customCrystal(EndCrystalEntityRenderState state, MatrixStack matrices,
                                       VertexConsumerProvider vertexConsumers, int light,
                                       CallbackInfo ci) {
        if (!CustomCrystalModule.active()) {
            return;
        }
        CustomCrystalModule.applyToState(state);
        float s = CustomCrystalModule.scale();
        if (matrices != null && Float.compare(s, 1.0f) != 0) {
            matrices.scale(s, s, s);
        }
    }
}

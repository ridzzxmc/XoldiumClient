package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.CustomCrystalModule;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.state.EndCrystalEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook Custom Crystal. Signature {@code render(EndCrystalEntityRenderState,
 * MatrixStack, OrderedRenderCommandQueue, CameraRenderState)} sama dengan yang
 * dipakai mod referensi PvP Tweaks untuk 1.21.11 (sudah terbukti berjalan di
 * build itu). {@code require = 0}: bila gagal terpasang, crystal tampil normal.
 */
@Mixin(EndCrystalEntityRenderer.class)
public abstract class EndCrystalRenderMixin {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void xoldium$customCrystal(EndCrystalEntityRenderState state, MatrixStack matrices,
                                       OrderedRenderCommandQueue queue, CameraRenderState cameraState,
                                       CallbackInfo ci) {
        if (!CustomCrystalModule.active()) {
            return;
        }
        CustomCrystalModule.applyToState(state);
        float s = CustomCrystalModule.scale();
        if (matrices != null && Float.compare(s, 1.0f) != 0) {
            matrices.scale(s, s, s);
        }
    }
}

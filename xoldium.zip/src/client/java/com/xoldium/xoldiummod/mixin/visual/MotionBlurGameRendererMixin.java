package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * PORTING LANGSUNG dari mixin {@code GameRendererMixin} pada "Smooth Motion
 * Blur" (source dikirim pemakai) - target method & injection point SAMA
 * PERSIS (mod referensi memakai build Yarn yang identik dengan proyek ini,
 * {@code 1.21.11+build.6}), hanya nama kelas/paket & pemanggilan
 * {@link MotionBlurRenderer} yang disesuaikan ke porting Xoldium.
 */
@Mixin(GameRenderer.class)
public abstract class MotionBlurGameRendererMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(
            method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/GameRenderer;renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void xoldium$afterWorldRender(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        MotionBlurRenderer.onWorldRendered(this.client);
    }
}

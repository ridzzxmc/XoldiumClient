package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.AccountBadge;
import com.xoldium.xoldiummod.client.gui.PlayerModel3D;
import com.xoldium.xoldiummod.client.gui.IconRenderer;
import com.xoldium.xoldiummod.client.gui.XoldiumFonts;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumConfigScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * UI khas Xoldium Client di title screen - permintaan pemakai: "Buatkan
 * juga XoldiumClient ada UI nya sendiri seperti di foto Hyper Client yang
 * sudah aku kirim". Ditiru dari struktur foto referensi tsb: wordmark
 * brand + versi kecil di atas, dan kolom tombol kecil (Mod Menu/HUD
 * Editor/Settings - padanan "Language/Shots/Switch UI/Mod Menu" pada
 * referensi; tiga di sini sengaja hanya yang SUNGGUHAN fungsional di
 * Xoldium, bukan tombol dekorasi kosong) di sisi kiri layar - SEMUA murni
 * TAMBAHAN (additive) di atas title screen vanilla, sama seperti pada
 * foto referensi yang juga masih menampilkan tombol Singleplayer/
 * Multiplayer/Options/Quit Game bawaan Minecraft apa adanya di tengah,
 * tidak diganti/di-relayout sama sekali.
 *
 * <p>CATATAN VERIFIKASI PENTING: di Minecraft 1.21.11, {@code TitleScreen}
 * TERNYATA TIDAK LAGI meng-override {@code render(DrawContext,int,int,float)}
 * sendiri (dikonfirmasi lewat Yarn API docs {@code yarn-1.21.11+build.3} -
 * method itu sudah tidak ada di daftar method deklarasi {@code TitleScreen},
 * kemungkinan digantikan komponen {@code LogoDrawer} terpisah menyusul
 * perombakan render pipeline). Meng-Mixin {@code @Inject} ke {@code render}
 * pada {@code TitleScreen.class} langsung akan GAGAL dipasang (Mixin
 * apply error saat game start, karena method target harus benar-benar
 * DIDEKLARASIKAN di kelas yang di-{@code @Mixin}, bukan sekadar
 * ter-inherit). Solusinya: branding digambar lewat
 * {@code Screen#addDrawable(Drawable)} yang didaftarkan di dalam
 * {@code init()} (method yang TERKONFIRMASI ADA langsung di
 * {@code TitleScreen}) - {@code Drawable} adalah functional interface
 * ({@code render(DrawContext,int,int,float)}) sehingga bisa didaftarkan
 * sebagai lambda tanpa perlu Mixin kedua ke method render manapun sama
 * sekali.
 *
 * <p>Pola "mixin class extends Screen" di bawah ini standar untuk mixin
 * yang perlu memanggil method ter-inherit yang protected (di sini
 * {@code addDrawableChild}/{@code addDrawable}, dideklarasikan di
 * {@link Screen}, ter-inherit oleh {@link TitleScreen}) - constructor
 * tidak pernah benar-benar dipanggil saat runtime (Mixin transformer
 * menyuntikkan body method ke kelas target asli, {@code TitleScreen}),
 * murni supaya kelas ini kompilasi bersih.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    /**
     * BUG FIX (dilaporkan pemakai - screenshot menunjukkan kotak
     * hitam-magenta/checkerboard "missing texture" menimpa logo di title
     * screen): sebelumnya konstanta ini menunjuk ke
     * {@code textures/gui/title_logo.png}, sebuah file yang TIDAK PERNAH
     * ada di {@code src/main/resources/assets/xoldiummod/} (hanya
     * {@code logo.png} - badge "X" persegi, bukan banner lebar - yang
     * benar-benar ada). Minecraft otomatis mengganti tekstur yang gagal
     * di-load dengan pola checkerboard hitam-magenta bawaan - PERSIS
     * bentuk bug pada screenshot pemakai.
     *
     * <p>Banner "XOLDIUM CLIENT" itu sendiri SUDAH tampil benar tanpa
     * kode ini sama sekali - project ini juga meng-override tekstur
     * vanilla {@code assets/minecraft/textures/gui/title/minecraft.png}
     * (wordmark asli, 1024x265) yang digambar oleh {@code TitleScreen}
     * bawaan sendiri. Drawable kedua di sini dulu MENIMPA wordmark yang
     * sudah benar itu dengan file yang hilang - jadi solusinya bukan
     * mencari ganti file bannernya, tapi menghapus drawable kedua yang
     * duplikat & rusak ini sepenuhnya. Badge kecil {@code logo.png} (yang
     * BENAR-BENAR ada) dipakai sebagai gantinya, ukuran kecil di pojok
     * kiri-bawah dekat teks versi - bukan lagi banner lebar di tengah.
     */
    private static final Identifier BADGE_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int BADGE_SIZE = 14;

    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Unique
    private final Anim.Timeline xoldium$intro = new Anim.Timeline(520f);
    @Unique
    private final Anim.Smooth xoldium$follow = new Anim.Smooth(0f, 7f);
    @Unique
    private ButtonWidget xoldium$clientButton;
    @Unique
    private ButtonWidget xoldium$wardrobeButton;
    @Unique
    private boolean xoldium$placed;

    @Inject(method = "init()V", at = @At("TAIL"))
    private void xoldium$addBrandingButtons(CallbackInfo ci) {
        xoldium$placed = false;
        xoldium$wardrobeButton = null;

        // SATU tombol "XoldiumClient" (menggantikan Mod Menu / HUD Editor / Settings) -> membuka HUD Editor.
        // Posisinya dipasang di frame pertama render (setelah semua mod, termasuk Mod Menu, selesai menambah
        // tombolnya): di bawah Minecraft Realms dan di atas Mods; tombol di bawahnya turun satu baris.
        xoldium$clientButton = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.bold("XoldiumClient"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new com.xoldium.xoldiummod.client.gui.XoldiumHubScreen(this));
                    }
                })
                .dimensions(this.width / 2 - 100, this.height / 4 + 72, 200, 20)
                .build());
        xoldium$clientButton.setAlpha(0f);

        this.addDrawable((context, mouseX, mouseY, delta) -> {
            if (!xoldium$placed) {
                xoldium$place();
            }
            float t = Anim.easeOutCubic(Anim.clamp01((xoldium$intro.elapsedMs() - 160f) / 420f));
            xoldium$clientButton.setAlpha(xoldium$placed ? t : 0f);
        });

        // Lencana akun Minecraft (username + kepala skin) di atas menu awal.
        this.addDrawable((context, mouseX, mouseY, delta) ->
                AccountBadge.render(context, this.textRenderer, this.width, 8));

        // Panel pemain 3D + skin di kanan menu.
        int menuRight = this.width / 2 + 102;
        int spaceW = this.width - menuRight;
        if (spaceW >= 76 && this.height >= 200) {
            final int pcx = menuRight + spaceW / 2;
            final int modelBottom = this.height / 2 + 46;
            final float pixel = Math.max(1.5f, Math.min(4f, (this.height * 0.42f) / 32f));
            xoldium$wardrobeButton = this.addDrawableChild(ButtonWidget.builder(XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.wardrobe")), button -> {
                        if (this.client != null) {
                            this.client.setScreen(new com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen(this));
                        }
                    })
                    .dimensions(pcx - Math.min(112, spaceW - 4) / 2, modelBottom + 10, Math.min(112, spaceW - 4), 18)
                    .build());
            this.addDrawable((context, mouseX, mouseY, delta) -> {
                float intro = Anim.clamp01((xoldium$intro.elapsedMs() - 120f) / 900f);
                float a = Anim.easeOutCubic(Anim.clamp01(intro * 2.2f));
                xoldium$wardrobeButton.setAlpha(a);
                int modelH = Math.round(pixel * 32f);

                // --- latar: cahaya lembut di belakang model + bayangan oval di lantai (semua dianimasikan fade-in)
                int glowCy = modelBottom - modelH / 2;
                for (int i = 0; i < 6; i++) {
                    int rx = Math.round(modelH * (0.34f + i * 0.07f));
                    int ry = Math.round(modelH * (0.56f + i * 0.06f));
                    ScreenChrome.roundedFill(context, pcx - rx, glowCy - ry, pcx + rx, glowCy + ry,
                            Anim.withAlpha(0x0AA79BFF, a));
                }
                for (int i = 0; i < 5; i++) {
                    int w = Math.round(pixel * (12f - i * 1.6f));
                    context.fill(pcx - w, modelBottom + i, pcx + w, modelBottom + i + 1,
                            Anim.withAlpha(0x66000000, a * (0.9f - i * 0.15f)));
                }

                // --- pil nama (tanpa "Beta"): kepala skin + username
                String name = AccountBadge.username();
                var label = XoldiumFonts.medium(name);
                int headSize = 12;
                int pillW = Math.min(spaceW - 6, headSize + 6 + this.textRenderer.getWidth(label) + 12);
                int px1 = pcx - pillW / 2;
                int py1 = modelBottom - modelH - 26 + Math.round((1f - a) * 6f);
                ScreenChrome.roundedFill(context, px1, py1, px1 + pillW, py1 + 18, Anim.withAlpha(0xC8101012, a));
                ScreenChrome.roundedBorder(context, px1, py1, px1 + pillW, py1 + 18, Anim.withAlpha(0x70FFFFFF, a));
                if (!AccountBadge.drawHead(context, px1 + 4, py1 + 3, headSize)) {
                    context.fill(px1 + 4, py1 + 3, px1 + 4 + headSize, py1 + 3 + headSize, Anim.withAlpha(0xFF4A4A5A, a));
                }
                context.drawText(this.textRenderer, label, px1 + 4 + headSize + 5, py1 + 5, Anim.withAlpha(0xFFFFFFFF, a), false);

                // --- model: putar masuk (spin intro) lalu menghadap kursor dengan gerak halus + ayunan diam
                double t = (System.currentTimeMillis() % 100000L) / 1000.0;
                float target = (float) Math.max(-1.0, Math.min(1.0, (mouseX - pcx) * 0.012));
                float follow = xoldium$follow.update(target);
                float spin = (1f - Anim.easeOutCubic(intro)) * (float) (Math.PI * 2.0);
                float angle = follow + (float) (Math.sin(t * 0.9) * 0.16) + spin;
                int bob = Math.round((float) Math.sin(t * 1.7) * 0.8f);
                PlayerModel3D.draw(context, AccountBadge.skinObject(), pcx, modelBottom + bob - Math.round((1f - a) * 6f), pixel, angle);
            });
        }

        String version = FabricLoader.getInstance().getModContainer(XoldiumMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");

        // Drawable murni (bukan tombol) untuk badge kecil + teks versi.
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            int textY = this.height - 20;
            IconRenderer.drawTexture(context, BADGE_TEXTURE, 4, textY - 3, BADGE_SIZE, BADGE_SIZE);
            context.drawText(this.textRenderer, Text.literal("Xoldium v" + version),
                    4 + BADGE_SIZE + 4, textY, 0xFFAAAAAA, true);
        });
    }

    /**
     * Taruh tombol XoldiumClient tepat di bawah tombol "Minecraft Realms" dan geser tombol-tombol di
     * bawahnya (Mods, Options, Quit, ikon bahasa/aksesibilitas) turun satu baris.
     */
    @Unique
    private void xoldium$place() {
        xoldium$placed = true;
        try {
            ButtonWidget self = xoldium$clientButton;
            ButtonWidget realms = null;
            String realmsLabel = Text.translatable("menu.online").getString();
            List<ButtonWidget> wide = new ArrayList<>();
            for (Element child : this.children()) {
                if (child instanceof ButtonWidget b && b != self && b != xoldium$wardrobeButton && b.visible) {
                    if (b.getMessage().getString().equals(realmsLabel)) {
                        realms = b;
                    }
                    if (b.getWidth() >= 150) {
                        wide.add(b);
                    }
                }
            }
            if (realms == null && wide.size() >= 3) {
                wide.sort((a, b) -> Integer.compare(a.getY(), b.getY()));
                realms = wide.get(2); // Singleplayer, Multiplayer, Realms
            }
            if (realms == null) {
                return; // layout tak dikenali: biarkan tombol di posisi awal
            }
            int insertY = realms.getY() + realms.getHeight() + 4;
            int shift = self.getHeight() + 4;
            for (Element child : this.children()) {
                if (child instanceof ClickableWidget w && w != self && w != xoldium$wardrobeButton
                        && w.getY() >= insertY - 1 && w.getY() < this.height - 24) {
                    w.setY(w.getY() + shift);
                }
            }
            self.setX(realms.getX());
            self.setY(insertY);
            self.setWidth(realms.getWidth());
        } catch (Throwable ignored) {
            // posisi awal dipertahankan
        }
    }
}

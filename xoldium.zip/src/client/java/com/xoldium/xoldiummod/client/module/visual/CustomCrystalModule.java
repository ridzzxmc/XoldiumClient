package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Custom Crystal - mengatur tampilan End Crystal (ukuran, dasar/base,
 * kecepatan putar & pantul), terinspirasi mod "Crystal Chams" (CC-main) yang
 * dikirim pemakai.
 *
 * <p>BATASAN JUJUR: CC-main ditulis untuk Minecraft 26.1 (mapping Mojang) dan
 * merender ulang SELURUH crystal sendiri lewat API render 26.x
 * ({@code submitModelPart} dengan warna tint, daftar frame per-bagian, YACL).
 * API itu tidak sama dengan 1.21.11 (Yarn), jadi yang dipindahkan ke sini
 * hanya fitur yang bisa dicapai dengan aman tanpa menebak API: <b>Scale</b>,
 * <b>Base</b> (Default/Always/Never), <b>Rotation Speed</b> dan <b>Bounce
 * Speed</b> (keduanya lewat satu pengali umur animasi). Fitur CC yang BELUM
 * ada: warna/alfa/rainbow per bagian, daftar frame kustom, light level.
 * Hook-nya: {@code mixin.visual.EndCrystalRenderMixin}.
 */
public final class CustomCrystalModule extends Module {

    private static CustomCrystalModule instance;

    private final DoubleSetting scale = addSetting(
            new DoubleSetting("scale", "setting.xoldiummod.crystal.scale", 1.0, 0.1, 2.0, 0.05));
    private final ModeSetting base = addSetting(new ModeSetting("base", "setting.xoldiummod.crystal.base", 0,
            "setting.xoldiummod.crystal.base.default", "setting.xoldiummod.crystal.base.always",
            "setting.xoldiummod.crystal.base.never"));
    private final DoubleSetting spin = addSetting(
            new DoubleSetting("spin", "setting.xoldiummod.crystal.spin", 1.0, 0.0, 5.0, 0.1));

    private static Field ageField;
    private static Field baseField;
    private static boolean resolved = false;
    private static boolean broken = false;

    public CustomCrystalModule() {
        super("custom_crystal", "module.xoldiummod.custom_crystal", ModuleCategory.VISUAL, false);
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled() && !broken;
    }

    public static float scale() {
        return instance == null ? 1f : instance.scale.get().floatValue();
    }

    /** Terapkan base/spin ke state render crystal (dipanggil mixin tiap frame per crystal). */
    public static void applyToState(Object state) {
        if (!active()) {
            return;
        }
        try {
            resolve(state.getClass());
            if (ageField != null) {
                ageField.setFloat(state, ageField.getFloat(state) * instance.spin.get().floatValue());
            }
            if (baseField != null) {
                switch (instance.base.index()) {
                    case 1 -> baseField.setBoolean(state, true);
                    case 2 -> baseField.setBoolean(state, false);
                    default -> { }
                }
            }
        } catch (Throwable t) {
            broken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Custom Crystal: gagal mengubah state render (dinonaktifkan).", t);
        }
    }

    private static void resolve(Class<?> stateClass) {
        if (resolved) {
            return;
        }
        resolved = true;
        // boolean tunggal yang dideklarasikan langsung di kelas state crystal = "tampilkan base"
        Field onlyBoolean = null;
        int booleans = 0;
        for (Field f : stateClass.getDeclaredFields()) {
            if (f.getType() == boolean.class && !Modifier.isStatic(f.getModifiers())) {
                onlyBoolean = f;
                booleans++;
            }
        }
        if (booleans == 1) {
            onlyBoolean.setAccessible(true);
            baseField = onlyBoolean;
        }
        // float "age" (umur animasi) = field float PERTAMA di kelas dasar EntityRenderState (induk langsung Object).
        // Dicoba dulu lewat nama "age" (lingkungan dev), lalu urutan deklarasi (game asli memakai nama intermediary).
        for (Class<?> c = stateClass; c != null && c != Object.class; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField("age");
                if (f.getType() == float.class) {
                    f.setAccessible(true);
                    ageField = f;
                    return;
                }
            } catch (NoSuchFieldException ignored) {
                // naik ke kelas induk
            }
        }
        Class<?> root = stateClass;
        while (root.getSuperclass() != null && root.getSuperclass() != Object.class) {
            root = root.getSuperclass();
        }
        for (Field f : root.getDeclaredFields()) {
            if (f.getType() == float.class && !Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                ageField = f;
                return;
            }
        }
    }
}

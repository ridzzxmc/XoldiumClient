package com.xoldium.xoldiummod.client.crosshair;

public enum CrosshairPresets {
    DOT("Dot", generateDot()),
    SMALL_CROSS("Small Cross", generateSmallCross()),
    CROSS("Cross", generateCross()),
    LARGE_CROSS("Large Cross", generateLargeCross()),
    CIRCLE("Circle", generateCircle()),
    CIRCLE_DOT("Circle + Dot", generateCircleDot()),
    HOLLOW_CIRCLE("Hollow Circle", generateHollowCircle()),
    SQUARE("Square", generateSquare()),
    HOLLOW_SQUARE("Hollow Square", generateHollowSquare()),
    PLUS("Plus", generatePlus()),
    T_SHAPE("T-Shape", generateTShape()),
    ARROW("Arrow", generateArrow()),
    TRIANGLE("Triangle", generateTriangle()),
    DIAMOND("Diamond", generateDiamond()),
    X_CROSS("X Cross", generateXCross()),
    SNIPER("Sniper", generateSniper()),
    BRACKET("Bracket", generateBracket()),
    CORNERS("Corners", generateCorners()),
    SPLIT_CROSS("Split Cross", generateSplitCross()),
    STARFIELD("Star", generateStar()),
    CHEVRON("Chevron", generateChevron()),
    H_SHAPE("H-Shape", generateHShape()),
    GRID("Grid 3x3", generateGrid()),
    CROSSHAIR_GAP("Gap Cross", generateGapCross()),
    CIRCLE_CROSS("Circle Cross", generateCircleCross()),
    THICK_CROSS("Thick Cross", generateThickCross()),
    OUTLINE_CROSS("Outline Cross", generateOutlineCross()),
    MINIMAL("Minimal", generateMinimal()),
    COMPACT("Compact", generateCompact()),
    VALORANT("Valorant Style", generateValorant()),
    CSGO("CS:GO Style", generateCSGO()),
    OVERWATCH("Overwatch Style", generateOverwatch());

    private final String displayName;
    private final boolean[][] pattern;

    CrosshairPresets(String displayName, boolean[][] pattern) {
        this.displayName = displayName;
        this.pattern = pattern;
    }

    public String getDisplayName() { return displayName; }
    public boolean[][] getPattern() {
        boolean[][] copy = new boolean[15][15];
        for (int x = 0; x < 15; x++) {
            System.arraycopy(pattern[x], 0, copy[x], 0, 15);
        }
        return copy;
    }

    private static boolean[][] generateDot() {
        boolean[][] grid = new boolean[15][15];
        grid[7][7] = true;
        return grid;
    }

    private static boolean[][] generateSmallCross() {
        boolean[][] grid = new boolean[15][15];
        grid[7][6] = true;
        grid[7][7] = true;
        grid[7][8] = true;
        grid[6][7] = true;
        grid[8][7] = true;
        return grid;
    }

    private static boolean[][] generateCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 4; i <= 10; i++) {
            grid[7][i] = true;
            grid[i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateLargeCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 2; i <= 12; i++) {
            grid[7][i] = true;
            grid[i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateCircle() {
        boolean[][] grid = new boolean[15][15];
        int centerX = 7, centerY = 7;
        int radius = 3;

        for (int x = 0; x < 15; x++) {
            for (int y = 0; y < 15; y++) {
                int dx = x - centerX;
                int dy = y - centerY;
                if (dx * dx + dy * dy <= radius * radius) {
                    grid[x][y] = true;
                }
            }
        }
        return grid;
    }

    private static boolean[][] generateCircleDot() {
        boolean[][] grid = generateHollowCircle();
        grid[7][7] = true;
        return grid;
    }

    private static boolean[][] generateHollowCircle() {
        boolean[][] grid = new boolean[15][15];
        int centerX = 7, centerY = 7;
        int outerRadius = 4;
        int innerRadius = 3;

        for (int x = 0; x < 15; x++) {
            for (int y = 0; y < 15; y++) {
                int dx = x - centerX;
                int dy = y - centerY;
                int distSq = dx * dx + dy * dy;
                if (distSq <= outerRadius * outerRadius && distSq >= innerRadius * innerRadius) {
                    grid[x][y] = true;
                }
            }
        }
        return grid;
    }

    private static boolean[][] generateSquare() {
        boolean[][] grid = new boolean[15][15];
        for (int x = 5; x <= 9; x++) {
            for (int y = 5; y <= 9; y++) {
                grid[x][y] = true;
            }
        }
        return grid;
    }

    private static boolean[][] generateHollowSquare() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 5; i <= 9; i++) {
            grid[5][i] = true;
            grid[9][i] = true;
            grid[i][5] = true;
            grid[i][9] = true;
        }
        return grid;
    }

    private static boolean[][] generatePlus() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 5; i <= 9; i++) {
            grid[7][i] = true;
            grid[i][7] = true;
        }
        grid[7][7] = true;
        return grid;
    }

    private static boolean[][] generateTShape() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 4; i <= 10; i++) {
            grid[i][5] = true;
        }
        for (int i = 5; i <= 10; i++) {
            grid[7][i] = true;
        }
        return grid;
    }

    private static boolean[][] generateArrow() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 7; i <= 11; i++) {
            grid[7][i] = true;
        }
        grid[6][7] = true;
        grid[8][7] = true;
        grid[5][8] = true;
        grid[9][8] = true;
        return grid;
    }

    private static boolean[][] generateTriangle() {
        boolean[][] grid = new boolean[15][15];
        grid[7][4] = true;

        grid[6][5] = true;
        grid[7][5] = true;
        grid[8][5] = true;

        grid[5][6] = true;
        grid[6][6] = true;
        grid[7][6] = true;
        grid[8][6] = true;
        grid[9][6] = true;

        for (int i = 4; i <= 10; i++) {
            grid[i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateDiamond() {
        boolean[][] grid = new boolean[15][15];
        int center = 7;
        int size = 3;

        for (int i = -size; i <= size; i++) {
            int width = size - Math.abs(i);
            for (int j = -width; j <= width; j++) {
                grid[center + j][center + i] = true;
            }
        }
        return grid;
    }

    private static boolean[][] generateXCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 4; i <= 10; i++) {
            grid[i][i] = true;
            grid[i][14 - i] = true;
        }
        return grid;
    }

    private static boolean[][] generateSniper() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 0; i <= 5; i++) {
            grid[7][i] = true;
            grid[7][14 - i] = true;
            grid[i][7] = true;
            grid[14 - i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateBracket() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 0; i < 3; i++) {
            grid[4][4 + i] = true;
            grid[4 + i][4] = true;

            grid[10][4 + i] = true;
            grid[10 - i][4] = true;

            grid[4][10 - i] = true;
            grid[4 + i][10] = true;

            grid[10][10 - i] = true;
            grid[10 - i][10] = true;
        }
        return grid;
    }

    private static boolean[][] generateCorners() {
        boolean[][] grid = new boolean[15][15];
        grid[3][3] = grid[4][3] = grid[3][4] = true;
        grid[11][3] = grid[10][3] = grid[11][4] = true;
        grid[3][11] = grid[4][11] = grid[3][10] = true;
        grid[11][11] = grid[10][11] = grid[11][10] = true;
        return grid;
    }

    private static boolean[][] generateSplitCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 3; i <= 5; i++) {
            grid[7][i] = true;
            grid[7][14 - i] = true;
            grid[i][7] = true;
            grid[14 - i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateStar() {
        boolean[][] grid = new boolean[15][15];
        grid[7][7] = true;

        for (int i = 1; i <= 3; i++) {
            grid[7][7 - i] = true;
            grid[7][7 + i] = true;
            grid[7 - i][7] = true;
            grid[7 + i][7] = true;
        }

        for (int i = 1; i <= 2; i++) {
            grid[7 - i][7 - i] = true;
            grid[7 + i][7 - i] = true;
            grid[7 - i][7 + i] = true;
            grid[7 + i][7 + i] = true;
        }
        return grid;
    }

    private static boolean[][] generateChevron() {
        boolean[][] grid = new boolean[15][15];
        grid[7][9] = true;
        grid[6][8] = true;
        grid[8][8] = true;
        grid[5][7] = true;
        grid[9][7] = true;
        grid[4][6] = true;
        grid[10][6] = true;
        return grid;
    }

    private static boolean[][] generateHShape() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 4; i <= 10; i++) {
            grid[5][i] = true;
            grid[9][i] = true;
        }
        for (int i = 5; i <= 9; i++) {
            grid[i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateGrid() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 5; i <= 9; i += 2) {
            for (int j = 5; j <= 9; j += 2) {
                grid[i][j] = true;
            }
        }
        return grid;
    }

    private static boolean[][] generateGapCross() {
        boolean[][] grid = new boolean[15][15];
        grid[7][3] = true;
        grid[7][14 - 3] = true;
        grid[3][7] = true;
        grid[14 - 3][7] = true;
        grid[7][4] = true;
        grid[7][14 - 4] = true;
        grid[4][7] = true;
        grid[14 - 4][7] = true;
        grid[7][5] = true;
        grid[7][14 - 5] = true;
        grid[5][7] = true;
        grid[14 - 5][7] = true;
        grid[7][6] = true;
        grid[7][14 - 6] = true;
        grid[6][7] = true;
        grid[14 - 6][7] = true;
        return grid;
    }

    private static boolean[][] generateCircleCross() {
        boolean[][] grid = generateHollowCircle();
        grid[7][6] = grid[7][8] = true;
        grid[6][7] = grid[8][7] = true;
        return grid;
    }

    private static boolean[][] generateThickCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 4; i <= 10; i++) {
            grid[6][i] = grid[7][i] = grid[8][i] = true;
            grid[i][6] = grid[i][7] = grid[i][8] = true;
        }
        return grid;
    }

    private static boolean[][] generateOutlineCross() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 5; i <= 9; i++) {
            grid[7][i] = true;
            grid[i][7] = true;
        }
        grid[6][5] = grid[8][5] = true;
        grid[6][9] = grid[8][9] = true;
        grid[5][6] = grid[5][8] = true;
        grid[9][6] = grid[9][8] = true;
        return grid;
    }

    private static boolean[][] generateMinimal() {
        boolean[][] grid = new boolean[15][15];
        grid[7][7] = true;
        grid[7][6] = grid[7][8] = true;
        grid[6][7] = grid[8][7] = true;
        return grid;
    }

    private static boolean[][] generateCompact() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 6; i <= 8; i++) {
            grid[7][i] = true;
            grid[i][7] = true;
        }
        return grid;
    }

    private static boolean[][] generateValorant() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 5; i <= 6; i++) {
            grid[7][i] = true;
            grid[7][14 - i] = true;
            grid[i][7] = true;
            grid[14 - i][7] = true;
        }
        grid[7][3] = grid[7][11] = true;
        grid[3][7] = grid[11][7] = true;
        return grid;
    }

    private static boolean[][] generateCSGO() {
        boolean[][] grid = new boolean[15][15];
        for (int i = 3; i <= 5; i++) {
            grid[7][i] = true;
            grid[i][7] = grid[14 - i][7] = true;
        }
        for (int i = 9; i <= 11; i++) {
            grid[7][i] = true;
        }
        return grid;
    }

    private static boolean[][] generateOverwatch() {
        boolean[][] grid = new boolean[15][15];
        int centerX = 7, centerY = 7;
        int outerRadius = 4;
        int innerRadius = 2;

        for (int x = 0; x < 15; x++) {
            for (int y = 0; y < 15; y++) {
                int dx = x - centerX;
                int dy = y - centerY;
                int distSq = dx * dx + dy * dy;
                if (distSq <= outerRadius * outerRadius && distSq >= innerRadius * innerRadius) {
                    grid[x][y] = true;
                }
            }
        }

        grid[7][2] = true;
        grid[2][7] = true;
        grid[12][7] = true;
        grid[7][12] = true;

        return grid;
    }
}
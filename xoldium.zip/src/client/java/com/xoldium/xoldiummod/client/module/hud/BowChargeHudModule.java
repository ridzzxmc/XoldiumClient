package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;

/** Charge busur / crossbow dalam persen + bar. */
public final class BowChargeHudModule extends HudModule {

    public BowChargeHudModule() {
        super("bow", "module.xoldiummod.bow", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isUsingItem()) {
            return;
        }
        ItemStack active = player.getActiveItem();
        if (!(active.getItem() instanceof BowItem)) {
            return;
        }
        float pull = BowItem.getPullProgress(player.getItemUseTime());
        HudRenderUtil.drawCard(context, this, Items.BOW, pull >= 1f ? "BOW  \u2022  FULL" : "BOW",
                Math.round(pull * 100) + "%", pull);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        float pull = (System.currentTimeMillis() % 1500L) / 1500f;
        HudRenderUtil.drawCard(context, this, Items.BOW, "BOW", Math.round(pull * 100) + "%", pull);
    }
}

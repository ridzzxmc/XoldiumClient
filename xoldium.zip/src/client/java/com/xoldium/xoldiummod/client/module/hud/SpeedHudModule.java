package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.util.math.Vec3d;

/** Kecepatan horizontal dalam blok/detik + bar. */
public final class SpeedHudModule extends HudModule {

    private double shown = 0.0;

    public SpeedHudModule() {
        super("speed", "module.xoldiummod.speed", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        Vec3d v = client.player.getVelocity();
        double speed = Math.sqrt(v.x * v.x + v.z * v.z) * 20.0;
        shown += (speed - shown) * 0.25; // halus
        HudRenderUtil.drawCard(context, this, Items.FEATHER, "SPEED", String.format(Locale.ROOT, "%.2f b/s", shown),
                (float) Math.min(1.0, shown / 20.0));
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.FEATHER, "SPEED", "5.61 b/s", 0.28f);
            return;
        }
        render(context, tickCounter);
    }
}

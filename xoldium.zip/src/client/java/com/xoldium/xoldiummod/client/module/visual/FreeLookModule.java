package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * FreeLook - melihat sekeliling TANPA memutar badan pemain.
 *
 * <p>Ditulis ulang mengikuti source "Freelook" (v1.4.4) yang dikirim pemakai:
 * <ul>
 *   <li>Delta mouse dikumpulkan terpisah dari badan (faktor 0.15, pitch di-clamp
 *       -90..90) - {@code FreeLookEntityMixin} membatalkan
 *       {@code Entity#changeLookDirection} selagi aktif.</li>
 *   <li><b>Perbaikan utama:</b> rotasi kamera sekarang ditimpa DI DALAM
 *       {@code Camera#update}, pada panggilan {@code setRotation} bawaan
 *       (sebelum kamera digeser mundur untuk third person) - persis titik
 *       yang dipakai source referensi. Versi lama menimpa rotasi di akhir
 *       update, sehingga di third person posisi kamera tetap dihitung dari
 *       arah badan (kamera tidak mengorbit) dan di beberapa build hook-nya
 *       tidak pernah menyala.</li>
 *   <li>Seperti source referensi: dari first person, kamera otomatis pindah ke
 *       perspektif pilihan (default Third Person Back) selama FreeLook aktif
 *       dan dikembalikan saat selesai; mode Hold/Toggle; batas putaran
 *       horizontal (Max Head Yaw).</li>
 * </ul>
 */
public final class FreeLookModule extends Module {

    private static FreeLookModule instance;

    private final KeyBinding keyBinding;
    private final ModeSetting activation = addSetting(new ModeSetting("activation",
            "setting.xoldiummod.freelook.activation", 0,
            "setting.xoldiummod.freelook.activation.hold", "setting.xoldiummod.freelook.activation.toggle"));
    private final ModeSetting perspective = addSetting(new ModeSetting("perspective",
            "setting.xoldiummod.freelook.perspective", 0,
            "setting.xoldiummod.freelook.perspective.back",
            "setting.xoldiummod.freelook.perspective.front",
            "setting.xoldiummod.freelook.perspective.first"));
    private final ModeSetting maxYaw = addSetting(new ModeSetting("max_yaw",
            "setting.xoldiummod.freelook.max_yaw", 0,
            "setting.xoldiummod.freelook.max_yaw.free",
            "setting.xoldiummod.freelook.max_yaw.180",
            "setting.xoldiummod.freelook.max_yaw.90",
            "setting.xoldiummod.freelook.max_yaw.45"));
    private final BooleanSetting switchPerspective = addSetting(new BooleanSetting("switch_perspective",
            "setting.xoldiummod.freelook.switch_perspective", true));

    private float cameraYaw;
    private float cameraPitch;
    private float anchorYaw;
    private boolean anchored = false;

    private boolean active = false;          // keadaan FreeLook yang sedang berlaku
    private boolean toggled = false;         // untuk mode Toggle
    private boolean prevKeyDown = false;
    private Perspective savedPerspective = null;

    public FreeLookModule() {
        super("freelook", "module.xoldiummod.freelook", ModuleCategory.VISUAL, false);
        instance = this;
        keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.freelook.key", keyBinding));
    }

    @Override
    protected void onToggle(boolean enabled) {
        if (!enabled) {
            stop();
        }
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean down = keyBinding.isPressed();
        boolean want;
        if (activation.index() == 1) { // toggle
            if (down && !prevKeyDown) {
                toggled = !toggled;
            }
            want = toggled;
        } else {
            toggled = false;
            want = down;
        }
        prevKeyDown = down;

        if (client.player == null || client.currentScreen != null && activation.index() == 0 && !down) {
            want = want && client.player != null;
        }
        if (want && !active) {
            start(client);
        } else if (!want && active) {
            stop();
        }
    }

    private void start(MinecraftClient client) {
        active = true;
        anchored = false;
        savedPerspective = client.options.getPerspective();
        if (switchPerspective.get() && savedPerspective == Perspective.FIRST_PERSON) {
            client.options.setPerspective(switch (perspective.index()) {
                case 1 -> Perspective.THIRD_PERSON_FRONT;
                case 2 -> Perspective.FIRST_PERSON;
                default -> Perspective.THIRD_PERSON_BACK;
            });
        }
    }

    private void stop() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (active && savedPerspective != null && client.options != null) {
            client.options.setPerspective(savedPerspective);
        }
        active = false;
        anchored = false;
        toggled = false;
        savedPerspective = null;
    }

    /** Apakah FreeLook sedang aktif (modul ON + tombol/toggle menyala). */
    public static boolean isActive() {
        return instance != null && instance.active && instance.isEnabled();
    }

    private void ensureAnchor() {
        if (anchored) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            cameraYaw = client.player.getYaw();
            cameraPitch = client.player.getPitch();
            anchorYaw = cameraYaw;
            anchored = true;
        }
    }

    /** Dipanggil {@code FreeLookEntityMixin} tiap delta mouse selagi aktif - badan TIDAK ikut berputar, hanya kamera. */
    public static void accumulate(double cursorDeltaX, double cursorDeltaY) {
        if (instance == null) {
            return;
        }
        instance.ensureAnchor();
        double factor = 0.15;
        instance.cameraPitch = MathHelper.clamp(instance.cameraPitch + (float) (cursorDeltaY * factor), -90.0f, 90.0f);
        float limit = switch (instance.maxYaw.index()) {
            case 1 -> 180f;
            case 2 -> 90f;
            case 3 -> 45f;
            default -> -1f;
        };
        float yaw = instance.cameraYaw + (float) (cursorDeltaX * factor);
        instance.cameraYaw = limit < 0 ? yaw : MathHelper.clamp(yaw, instance.anchorYaw - limit, instance.anchorYaw + limit);
    }

    private static volatile boolean cameraHookAlive = false;

    public static void markCameraHookAlive() {
        cameraHookAlive = true;
    }

    public static boolean cameraHookAlive() {
        return cameraHookAlive;
    }

    public static float getCameraYaw() {
        if (instance == null) return 0f;
        instance.ensureAnchor();
        return instance.cameraYaw;
    }

    public static float getCameraPitch() {
        if (instance == null) return 0f;
        instance.ensureAnchor();
        return instance.cameraPitch;
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** PingDisplayModule - kartu HUD dengan ikon, label, nilai. */
public final class PingDisplayModule extends HudModule {

    public PingDisplayModule() {
        super("ping_display", "module.xoldiummod.ping_display", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        int ping = -1;
        if (client.getNetworkHandler() != null && client.player != null) {
            net.minecraft.client.network.PlayerListEntry entry =
                    client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) {
                ping = entry.getLatency();
            }
        }
        boolean ok = ping >= 0;
        HudRenderUtil.drawCard(context, this, Items.REPEATER, "PING", ok ? ping + " ms" : "-- ms",
                ok ? 1f - Math.min(300, ping) / 300f : 0f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) {
            HudRenderUtil.drawCard(context, this, Items.REPEATER, "PING", "32 ms", 0.9f);
            return;
        }
        render(context, tickCounter);
    }

}

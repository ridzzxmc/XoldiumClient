package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;

/** Ringkasan scoreboard sidebar (judul + jumlah baris). */
public final class ScoreboardHudModule extends HudModule {

    public ScoreboardHudModule() {
        super("scoreboard", "module.xoldiummod.scoreboard", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        ScoreboardObjective objective = client.world.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective == null) {
            return;
        }
        int count = client.world.getScoreboard().getScoreboardEntries(objective).size();
        HudRenderUtil.drawCard(context, this, Items.BOOK, "SCOREBOARD  \u2022  " + count + " lines",
                objective.getDisplayName().getString(), -1f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawCard(context, this, Items.BOOK, "SCOREBOARD  \u2022  8 lines", "Practice", -1f);
    }
}

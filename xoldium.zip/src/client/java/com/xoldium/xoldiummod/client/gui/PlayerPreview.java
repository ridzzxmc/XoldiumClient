package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.cosmetic.Cosmetics;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Pratinjau pemain 3D yang di-rasterisasi sendiri (software, z-buffer) ke tekstur kecil, lalu digambar sebagai SATU
 * quad. Dipakai title screen, XoldiumAccount, dan XoldiumCosmetic.
 *
 * <p>Kenapa tidak lagi memakai potongan-potongan quad GUI: setiap sisi tubuh dulu digambar terpisah dengan koordinat
 * dibulatkan ke integer, sehingga saat berputar muncul retakan, garis 1px yang "nembus", dan tekstur pecah (burik).
 * Di sini seluruh model (skin + lapisan luar + cosmetic) dihitung per-piksel dengan z-buffer, jadi bagian yang di
 * belakang tidak pernah tembus ke depan dan cosmetic tepat menempel di kepala/punggung seperti di dunia game
 * (memakai data quad yang SAMA dengan {@code CosmeticRenderer}).
 *
 * <p>Seluruh jalur ini dibungkus try/catch: bila ada yang gagal (skin tidak bisa dibaca dsb.) {@link #draw} mengembalikan
 * {@code false} dan pemanggil memakai renderer lama.
 */
public final class PlayerPreview {

    /** Jumlah sudut putar yang di-cache (5 derajat per langkah). */
    private static final int FRAMES = 72;
    /** Texel per piksel skin. */
    private static final int S = 3;
    /** Kanvas dalam piksel skin: x dari -32..32, y dari -16..40 (kepala = 0, kaki = 32). */
    private static final int CW = 64;
    private static final int CH = 56;
    private static final int X0 = -32;
    private static final int Y0 = -16;
    private static final int TW = CW * S;
    private static final int TH = CH * S;
    /** Pivot leher cosmetic (blok -> piksel model: kepala 8 piksel di atas pivot). */
    private static final float NECK_Y = 8f;
    /** Cosmetic punggung digeser ke belakang agar tidak menembus badan/armor (sama dengan renderer dunia). */
    public static final float BACK_PUSH = 0.07f;

    private static String curKey = "";
    private static int keyId = 0;
    private static int[] skinPx;
    private static long skinFailedAt = 0L;
    private static final Identifier[] FRAME_IDS = new Identifier[FRAMES];
    private static final List<Object[]> DYING = new ArrayList<>();
    private static boolean broken = false;
    private static int errors = 0;

    private PlayerPreview() {
    }

    /**
     * @return true bila berhasil digambar.
     */
    public static boolean draw(DrawContext ctx, Object skin, Cosmetics.Def head, Cosmetics.Def back,
                               int cx, int bottomY, float pixel, float angle) {
        if (broken) {
            return false;
        }
        try {
            Identifier tex = PlayerModel3D.textureOf(skin);
            boolean slim = PlayerModel3D.isSlim(skin);
            String key = tex + "|" + slim + "|" + (head == null ? "-" : head.id) + "|" + (back == null ? "-" : back.id);
            if (!key.equals(curKey)) {
                retire();
                curKey = key;
                keyId++;
                skinPx = null;
                skinFailedAt = 0L;
            }
            long now = System.currentTimeMillis();
            if (skinPx == null) {
                if (skinFailedAt != 0L && now - skinFailedAt < 1500L) {
                    return false;
                }
                skinPx = readSkin(tex);
                if (skinPx == null) {
                    skinFailedAt = now;
                    return false;
                }
            }
            reap(now);
            float step = (float) (Math.PI * 2.0 / FRAMES);
            int f = Math.floorMod(Math.round(angle / step), FRAMES);
            Identifier id = FRAME_IDS[f];
            if (id == null) {
                id = build(f, step, slim, head, back);
                FRAME_IDS[f] = id;
            }
            int x1 = Math.round(cx - (CW / 2f) * pixel);
            int x2 = Math.round(cx + (CW / 2f) * pixel);
            int y1 = Math.round(bottomY - (32 - Y0) * pixel);
            int y2 = Math.round(bottomY + (Y0 + CH - 32) * pixel);
            ctx.drawTexturedQuad(id, x1, y1, x2, y2, 0f, 1f, 0f, 1f);
            return true;
        } catch (Throwable t) {
            skinPx = null;
            skinFailedAt = System.currentTimeMillis();
            if (++errors >= 4) {
                broken = true;
            }
            XoldiumMod.LOGGER.warn("[Xoldium] Pratinjau pemain 3D gagal (pakai renderer cadangan).", t);
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Cache tekstur
    // ------------------------------------------------------------------

    private static void retire() {
        long now = System.currentTimeMillis();
        for (int i = 0; i < FRAMES; i++) {
            if (FRAME_IDS[i] != null) {
                DYING.add(new Object[]{FRAME_IDS[i], now});
                FRAME_IDS[i] = null;
            }
        }
    }

    /** Hapus tekstur lama baru setelah beberapa frame (GUI memakai antrian gambar tertunda). */
    private static void reap(long now) {
        if (DYING.isEmpty()) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        for (int i = DYING.size() - 1; i >= 0; i--) {
            Object[] e = DYING.get(i);
            if (now - (Long) e[1] > 600L) {
                try {
                    mc.getTextureManager().destroyTexture((Identifier) e[0]);
                } catch (Throwable ignored) {
                    // abaikan
                }
                DYING.remove(i);
            }
        }
    }

    // ------------------------------------------------------------------
    // Membaca skin
    // ------------------------------------------------------------------

    private static NativeImage imageOf(Object texture) {
        try {
            for (Method m : NativeImageBackedTexture.class.getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == NativeImage.class) {
                    m.setAccessible(true);
                    return (NativeImage) m.invoke(texture);
                }
            }
        } catch (Throwable ignored) {
            // lanjut ke resource
        }
        return null;
    }

    /** Skin 64x64 ARGB (skin lama 64x32 dikonversi seperti vanilla; skin HD diperkecil dengan sampling). */
    private static int[] readSkin(Identifier tex) {
        MinecraftClient mc = MinecraftClient.getInstance();
        NativeImage img = null;
        boolean owned = false;
        try {
            AbstractTexture t = mc.getTextureManager().getTexture(tex);
            if (t instanceof NativeImageBackedTexture) {
                img = imageOf(t);
            }
        } catch (Throwable ignored) {
            // coba resource
        }
        if (img == null) {
            try {
                Optional<Resource> r = mc.getResourceManager().getResource(tex);
                if (r.isPresent()) {
                    try (InputStream in = r.get().getInputStream()) {
                        img = NativeImage.read(in);
                        owned = true;
                    }
                }
            } catch (Throwable ignored) {
                // gagal
            }
        }
        if (img == null) {
            return null;
        }
        try {
            int w = img.getWidth();
            int h = img.getHeight();
            if (w < 64 || w % 64 != 0 || (h != w && h != w / 2)) {
                return null;
            }
            int sc = w / 64;
            boolean legacy = h == w / 2;
            int[] px = new int[64 * 64];
            int rows = legacy ? 32 : 64;
            for (int y = 0; y < rows; y++) {
                for (int x = 0; x < 64; x++) {
                    px[y * 64 + x] = img.getColorArgb(x * sc, y * sc);
                }
            }
            if (legacy) {
                int[][] rects = {
                        {4, 16, 16, 32, 4, 4}, {8, 16, 16, 32, 4, 4}, {0, 20, 24, 32, 4, 12}, {4, 20, 16, 32, 4, 12},
                        {8, 20, 8, 32, 4, 12}, {12, 20, 16, 32, 4, 12}, {44, 16, -8, 32, 4, 4}, {48, 16, -8, 32, 4, 4},
                        {40, 20, 0, 32, 4, 12}, {44, 20, -8, 32, 4, 12}, {48, 20, -16, 32, 4, 12}, {52, 20, -8, 32, 4, 12}};
                for (int[] r : rects) {
                    for (int i = 0; i < r[5]; i++) {
                        for (int j = 0; j < r[4]; j++) {
                            int k = r[4] - 1 - j;
                            px[(r[1] + r[3] + i) * 64 + (r[0] + r[2] + k)] = px[(r[1] + i) * 64 + (r[0] + j)];
                        }
                    }
                }
            }
            return px;
        } finally {
            if (owned) {
                img.close();
            }
        }
    }

    // ------------------------------------------------------------------
    // Rasterisasi satu frame
    // ------------------------------------------------------------------

    /** {x0,y0,z0, x1,y1,z1, u,v, grow, overlay(0/1)} dalam piksel skin. */
    private static float[][] boxes(boolean slim) {
        float aw = slim ? 3f : 4f;
        return new float[][]{
                {-4, 0, -4, 4, 8, 4, 0, 0, 0f, 0}, {-4, 0, -4, 4, 8, 4, 32, 0, 0.5f, 1},
                {-4, 8, -2, 4, 20, 2, 16, 16, 0f, 0}, {-4, 8, -2, 4, 20, 2, 16, 32, 0.25f, 1},
                {-4 - aw, 8, -2, -4, 20, 2, 40, 16, 0f, 0}, {-4 - aw, 8, -2, -4, 20, 2, 40, 32, 0.25f, 1},
                {4, 8, -2, 4 + aw, 20, 2, 32, 48, 0f, 0}, {4, 8, -2, 4 + aw, 20, 2, 48, 48, 0.25f, 1},
                {-4, 20, -2, 0, 32, 2, 0, 16, 0f, 0}, {-4, 20, -2, 0, 32, 2, 0, 32, 0.25f, 1},
                {0, 20, -2, 4, 32, 2, 16, 48, 0f, 0}, {0, 20, -2, 4, 32, 2, 0, 48, 0.25f, 1},
        };
    }

    private static Identifier build(int frame, float step, boolean slim, Cosmetics.Def head, Cosmetics.Def back) throws Throwable {
        float ang = frame * step;
        float cos = (float) Math.cos(ang);
        float sin = (float) Math.sin(ang);
        int[] out = new int[TW * TH];
        float[] zb = new float[TW * TH];
        Arrays.fill(zb, -1.0e9f);

        for (float[] b : boxes(slim)) {
            box(out, zb, b, cos, sin);
        }
        if (back != null) {
            cosmetic(out, zb, back, BACK_PUSH, cos, sin);
        }
        if (head != null) {
            cosmetic(out, zb, head, 0f, cos, sin);
        }

        NativeImage image = new NativeImage(TW, TH, true);
        for (int y = 0; y < TH; y++) {
            int row = y * TW;
            for (int x = 0; x < TW; x++) {
                image.setColorArgb(x, y, out[row + x]);
            }
        }
        Identifier id = Identifier.of(XoldiumMod.MOD_ID, "preview/p" + keyId + "_" + frame);
        Object tex = makeTexture(image, id.toString());
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, (AbstractTexture) tex);
        return id;
    }

    private static Object makeTexture(NativeImage img, String name) throws Throwable {
        Class<?> c = NativeImageBackedTexture.class;
        for (Constructor<?> k : c.getDeclaredConstructors()) {
            Class<?>[] p = k.getParameterTypes();
            if (p.length == 1 && p[0] == NativeImage.class) {
                k.setAccessible(true);
                return k.newInstance(img);
            }
            if (p.length == 2 && p[0] == Supplier.class && p[1] == NativeImage.class) {
                k.setAccessible(true);
                Supplier<String> sup = () -> name;
                return k.newInstance(sup, img);
            }
        }
        throw new IllegalStateException("konstruktor NativeImageBackedTexture tidak dikenali");
    }

    private static void box(int[] out, float[] zb, float[] b, float cos, float sin) {
        float gr = b[8];
        float x0 = b[0] - gr, y0 = b[1] - gr, z0 = b[2] - gr;
        float x1 = b[3] + gr, y1 = b[4] + gr, z1 = b[5] + gr;
        int w = Math.round(b[3] - b[0]);
        int h = Math.round(b[4] - b[1]);
        int d = Math.round(b[5] - b[2]);
        int u = (int) b[6];
        int v = (int) b[7];
        boolean ov = b[9] > 0.5f;
        float fw = x1 - x0, fh = y1 - y0, fd = z1 - z0;
        // depan (+z)
        face(out, zb, ov, x0, y0, z1, fw, 0, 0, 0, fh, 0, u + d, v + d, w, h, 0, 1, cos, sin);
        // belakang (-z)
        face(out, zb, ov, x1, y0, z0, -fw, 0, 0, 0, fh, 0, u + d + w + d, v + d, w, h, 0, -1, cos, sin);
        // sisi kanan karakter (x min)
        face(out, zb, ov, x0, y0, z0, 0, 0, fd, 0, fh, 0, u, v + d, d, h, -1, 0, cos, sin);
        // sisi kiri karakter (x max)
        face(out, zb, ov, x1, y0, z1, 0, 0, -fd, 0, fh, 0, u + d + w, v + d, d, h, 1, 0, cos, sin);
    }

    private static void face(int[] out, float[] zb, boolean overlay,
                             float px, float py, float pz,
                             float ax, float ay, float az,
                             float bx, float by, float bz,
                             int tu, int tv, int tw, int th,
                             float nx, float nz, float cos, float sin) {
        float nzr = -nx * sin + nz * cos;
        if (nzr < 0.0005f) {
            return; // membelakangi kamera
        }
        float pxr = px * cos + pz * sin, pzr = -px * sin + pz * cos;
        float axr = ax * cos + az * sin, azr = -ax * sin + az * cos;
        float bxr = bx * cos + bz * sin, bzr = -bx * sin + bz * cos;
        float psx = (pxr - X0) * S, psy = (py - Y0) * S;
        float asx = axr * S, asy = ay * S;
        float bsx = bxr * S, bsy = by * S;
        float det = asx * bsy - asy * bsx;
        if (Math.abs(det) < 1.0e-4f) {
            return;
        }
        float minX = Math.min(Math.min(psx, psx + asx), Math.min(psx + bsx, psx + asx + bsx));
        float maxX = Math.max(Math.max(psx, psx + asx), Math.max(psx + bsx, psx + asx + bsx));
        float minY = Math.min(Math.min(psy, psy + asy), Math.min(psy + bsy, psy + asy + bsy));
        float maxY = Math.max(Math.max(psy, psy + asy), Math.max(psy + bsy, psy + asy + bsy));
        int ix0 = Math.max(0, (int) Math.floor(minX));
        int ix1 = Math.min(TW - 1, (int) Math.ceil(maxX));
        int iy0 = Math.max(0, (int) Math.floor(minY));
        int iy1 = Math.min(TH - 1, (int) Math.ceil(maxY));
        float shade = 0.88f + 0.12f * nzr;
        final float eps = 0.003f;
        for (int y = iy0; y <= iy1; y++) {
            float dy = y + 0.5f - psy;
            for (int x = ix0; x <= ix1; x++) {
                float dx = x + 0.5f - psx;
                float s = (dx * bsy - dy * bsx) / det;
                float t = (asx * dy - asy * dx) / det;
                if (s < -eps || s >= 1f + eps || t < -eps || t >= 1f + eps) {
                    continue;
                }
                float sc = Math.min(0.9999f, Math.max(0f, s));
                float tc = Math.min(0.9999f, Math.max(0f, t));
                int texel = skinPx[(tv + (int) (tc * th)) * 64 + (tu + (int) (sc * tw))];
                int a = (texel >>> 24) & 255;
                if (overlay) {
                    if (a < 128) {
                        continue;
                    }
                } else {
                    texel |= 0xFF000000;
                }
                float z = pzr + s * azr + t * bzr;
                int idx = y * TW + x;
                if (z > zb[idx]) {
                    zb[idx] = z;
                    out[idx] = shadeColor(texel, shade);
                }
            }
        }
    }

    private static int shadeColor(int argb, float shade) {
        int r = Math.min(255, (int) (((argb >> 16) & 255) * shade));
        int g = Math.min(255, (int) (((argb >> 8) & 255) * shade));
        int b = Math.min(255, (int) ((argb & 255) * shade));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Quad berwarna cosmetic (kerangka data sama dengan CosmeticRenderer: x kanan karakter, y atas, z belakang). */
    private static void cosmetic(int[] out, float[] zb, Cosmetics.Def def, float push, float cos, float sin) {
        float[] q = def.quads();
        int[] c = def.colors();
        float[] sx = new float[4];
        float[] sy = new float[4];
        float[] zr = new float[4];
        float[] xr = new float[4];
        float[] yy = new float[4];
        for (int i = 0; i < c.length; i++) {
            int col = c[i];
            if (((col >>> 24) & 255) < 128) {
                continue;
            }
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                float qx = q[o + k * 3], qy = q[o + k * 3 + 1], qz = q[o + k * 3 + 2];
                float x = -qx * 16f;
                float y = NECK_Y - qy * 16f;
                float z = -(qz + push) * 16f;
                xr[k] = x * cos + z * sin;
                zr[k] = -x * sin + z * cos;
                yy[k] = y;
                sx[k] = (xr[k] - X0) * S;
                sy[k] = (y - Y0) * S;
            }
            // normal untuk sedikit shading
            float e1x = xr[1] - xr[0], e1y = yy[1] - yy[0], e1z = zr[1] - zr[0];
            float e2x = xr[3] - xr[0], e2y = yy[3] - yy[0], e2z = zr[3] - zr[0];
            float cxn = e1y * e2z - e1z * e2y, cyn = e1z * e2x - e1x * e2z, czn = e1x * e2y - e1y * e2x;
            float len = (float) Math.sqrt(cxn * cxn + cyn * cyn + czn * czn);
            float shade = len < 1.0e-6f ? 1f : 0.78f + 0.22f * Math.abs(czn / len);
            int argb = shadeColor(col, shade);
            tri(out, zb, sx, sy, zr, 0, 1, 2, argb);
            tri(out, zb, sx, sy, zr, 0, 2, 3, argb);
        }
    }

    private static void tri(int[] out, float[] zb, float[] sx, float[] sy, float[] zr, int i0, int i1, int i2, int argb) {
        float ax = sx[i0], ay = sy[i0], az = zr[i0];
        float bx = sx[i1], by = sy[i1], bz = zr[i1];
        float cx = sx[i2], cy = sy[i2], cz = zr[i2];
        float den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (Math.abs(den) < 1.0e-6f) {
            return;
        }
        int minX = Math.max(0, (int) Math.floor(Math.min(ax, Math.min(bx, cx))));
        int maxX = Math.min(TW - 1, (int) Math.ceil(Math.max(ax, Math.max(bx, cx))));
        int minY = Math.max(0, (int) Math.floor(Math.min(ay, Math.min(by, cy))));
        int maxY = Math.min(TH - 1, (int) Math.ceil(Math.max(ay, Math.max(by, cy))));
        final float e = -1.0e-4f;
        for (int y = minY; y <= maxY; y++) {
            float fy = y + 0.5f;
            for (int x = minX; x <= maxX; x++) {
                float fx = x + 0.5f;
                float l1 = ((by - cy) * (fx - cx) + (cx - bx) * (fy - cy)) / den;
                float l2 = ((cy - ay) * (fx - cx) + (ax - cx) * (fy - cy)) / den;
                float l3 = 1f - l1 - l2;
                if (l1 < e || l2 < e || l3 < e) {
                    continue;
                }
                float z = l1 * az + l2 * bz + l3 * cz;
                int idx = y * TW + x;
                if (z > zb[idx]) {
                    zb[idx] = z;
                    out[idx] = argb;
                }
            }
        }
    }
}

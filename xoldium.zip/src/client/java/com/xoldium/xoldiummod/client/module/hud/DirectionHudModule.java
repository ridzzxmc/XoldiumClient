package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** DirectionHudModule - kartu HUD dengan ikon, label, nilai. */
public final class DirectionHudModule extends HudModule {

    public DirectionHudModule() {
        super("direction_hud", "module.xoldiummod.direction_hud", false, 4f, 4f);
    }

    private static final String[] DIRECTIONS = {"SOUTH", "SOUTH-WEST", "WEST", "NORTH-WEST", "NORTH", "NORTH-EAST", "EAST", "SOUTH-EAST"};

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        float yaw = client.player.getYaw() % 360f;
        if (yaw < 0) yaw += 360f;
        int index = Math.round(yaw / 45f) & 7;
        HudRenderUtil.drawCard(context, this, Items.COMPASS, DIRECTIONS[index], Math.round(yaw) + "\u00B0", yaw / 360f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.COMPASS, "NORTH", "0\u00B0", 0f);
            return;
        }
        render(context, tickCounter);
    }

}

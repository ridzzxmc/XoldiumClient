package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** FpsModule - kartu HUD dengan ikon, label, nilai. */
public final class FpsModule extends HudModule {

    private int frameCounter = 0;
    private int displayedFps = 0;
    private long windowStartMs = System.currentTimeMillis();

    public FpsModule() {
        super("fps", "module.xoldiummod.fps", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        frameCounter++;
        long now = System.currentTimeMillis();
        long elapsed = now - windowStartMs;
        if (elapsed >= 500) {
            displayedFps = (int) Math.round(frameCounter * 1000.0 / elapsed);
            frameCounter = 0;
            windowStartMs = now;
        }
        HudRenderUtil.drawCard(context, this, Items.COMPARATOR, "FPS", String.valueOf(displayedFps),
                Math.min(1f, displayedFps / 240f));
    }

}

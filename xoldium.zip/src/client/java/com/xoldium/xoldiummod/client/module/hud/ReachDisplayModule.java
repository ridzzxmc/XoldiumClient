package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

/**
 * Reach Display - jarak serangan, port dari mod "Reach Display" (wolren) yang dikirim pemakai. Logika sama:
 * <ul>
 *   <li><b>Crosshair</b>: jarak mata -> titik kena (ray hit) ke entitas yang sedang dibidik, tampil di bawah
 *       crosshair (di-smooth), diwarnai gradien hijau -> merah menurut jarak (maks 3 blok / 5 di creative).</li>
 *   <li><b>Last hit</b>: jarak saat terakhir memukul (dihitung dari {@code AttackEntityCallback}, titik kena ray
 *       bila entitas yang dibidik = target, kalau tidak titik terdekat bounding box).</li>
 *   <li><b>Average</b>: rata-rata N pukulan terakhir.</li>
 * </ul>
 * Bedanya: tanpa MidnightLib (setting lewat Mod Menu Xoldium), hook serangan memakai API Fabric (bukan Mixin) dan
 * kartu Last/Average bisa digeser di HUD Editor.
 */
public final class ReachDisplayModule extends HudModule {

    private final BooleanSetting crosshair = addSetting(
            new BooleanSetting("crosshair", "setting.xoldiummod.reach.crosshair", true));
    private final BooleanSetting lastHit = addSetting(
            new BooleanSetting("last_hit", "setting.xoldiummod.reach.last_hit", true));
    private final BooleanSetting average = addSetting(
            new BooleanSetting("average", "setting.xoldiummod.reach.average", true));
    private final BooleanSetting gradient = addSetting(
            new BooleanSetting("gradient", "setting.xoldiummod.reach.gradient", true));
    private final BooleanSetting livingOnly = addSetting(
            new BooleanSetting("living_only", "setting.xoldiummod.reach.living_only", true));
    private final DoubleSetting decimals = addSetting(
            new DoubleSetting("decimals", "setting.xoldiummod.reach.decimals", 2, 0, 3, 1));
    private final DoubleSetting hits = addSetting(
            new DoubleSetting("average_hits", "setting.xoldiummod.reach.average_hits", 10, 2, 50, 1));
    private final DoubleSetting hideAfter = addSetting(
            new DoubleSetting("hide_after", "setting.xoldiummod.reach.hide_after", 6, 1, 30, 1));

    private static ReachDisplayModule instance;
    private static boolean hooked = false;

    private final Deque<Double> recent = new ArrayDeque<>();
    private double lastDistance = 0.0;
    private long lastHitAt = 0L;
    private double smoothed = 0.0;

    public ReachDisplayModule() {
        super("reach_display", "module.xoldiummod.reach_display", false, 4f, 4f);
        instance = this;
        if (!hooked) {
            hooked = true;
            AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
                try {
                    if (world.isClient() && instance != null && instance.isEnabled()) {
                        instance.onAttack(player, entity);
                    }
                } catch (Throwable ignored) {
                    // statistik reach tidak boleh mengganggu serangan
                }
                return ActionResult.PASS;
            });
        }
    }

    private void onAttack(PlayerEntity player, Entity target) {
        if (livingOnly.get() && !(target instanceof LivingEntity)) {
            return;
        }
        Vec3d eye = player.getEyePos();
        double distance;
        HitResult result = MinecraftClient.getInstance().crosshairTarget;
        if (result instanceof EntityHitResult hit && hit.getEntity() == target) {
            distance = eye.distanceTo(hit.getPos());
        } else {
            distance = eye.distanceTo(closest(target.getBoundingBox(), eye));
        }
        lastDistance = distance;
        lastHitAt = System.currentTimeMillis();
        recent.addLast(distance);
        while (recent.size() > Math.max(2, (int) Math.round(hits.get()))) {
            recent.pollFirst();
        }
    }

    private static Vec3d closest(Box box, Vec3d p) {
        return new Vec3d(Math.max(box.minX, Math.min(p.x, box.maxX)),
                Math.max(box.minY, Math.min(p.y, box.maxY)),
                Math.max(box.minZ, Math.min(p.z, box.maxZ)));
    }

    private double averageDistance() {
        if (recent.isEmpty()) {
            return 0.0;
        }
        double sum = 0.0;
        for (double d : recent) {
            sum += d;
        }
        return sum / recent.size();
    }

    private String fmt(double v) {
        int d = Math.max(0, Math.min(3, (int) Math.round(decimals.get())));
        return String.format(Locale.ROOT, "%." + d + "f", v);
    }

    private int colorFor(double dist, boolean creative) {
        if (!gradient.get()) {
            return 0xFFFFFFFF;
        }
        float t = (float) Math.max(0.0, Math.min(1.0, dist / (creative ? 5.0 : 3.0)));
        // hijau (dekat) -> kuning -> merah (jauh / di batas reach)
        int r = t < 0.5f ? Math.round(85 + (255 - 85) * (t * 2f)) : 255;
        int g = t < 0.5f ? 255 : Math.round(255 - (255 - 85) * ((t - 0.5f) * 2f));
        return 0xFF000000 | (r << 16) | (g << 8) | 85;
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        drawCrosshair(context, client);
        drawStats(context, false);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        drawStats(context, true);
    }

    private void drawCrosshair(DrawContext context, MinecraftClient client) {
        if (!crosshair.get() || client.crosshairTarget == null || client.player.isSpectator()) {
            return;
        }
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) {
            return;
        }
        Entity target = hit.getEntity();
        if (target.isInvisibleTo(client.player) || (livingOnly.get() && !(target instanceof LivingEntity))) {
            return;
        }
        double dist = client.player.getEyePos().distanceTo(hit.getPos());
        smoothed += (dist - smoothed) * 0.3;
        if (Math.abs(dist - smoothed) < 0.001) {
            smoothed = dist;
        }
        String text = fmt(smoothed);
        TextRenderer tr = client.textRenderer;
        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        int w = tr.getWidth(text);
        int x = sw / 2 - w / 2;
        int y = sh / 2 + 10;
        context.fill(x - 3, y - 2, x + w + 3, y + tr.fontHeight + 1, 0x70000000);
        context.drawText(tr, text, x, y, colorFor(smoothed, client.player.isCreative()), true);
    }

    private void drawStats(DrawContext context, boolean preview) {
        boolean show = preview || System.currentTimeMillis() - lastHitAt <= hideAfter.get() * 1000.0;
        if (!show || (!lastHit.get() && !average.get())) {
            if (preview) {
                setMeasuredSize(60f, 24f);
            }
            return;
        }
        boolean creative = MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().player.isCreative();
        java.util.List<HudRenderUtil.Card> cards = new java.util.ArrayList<>();
        double last = preview && lastHitAt == 0L ? 2.87 : lastDistance;
        double avg = preview && recent.isEmpty() ? 2.74 : averageDistance();
        float max = creative ? 5f : 3f;
        if (lastHit.get()) {
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.IRON_SWORD), "LAST HIT REACH", fmt(last) + " blocks",
                    (float) (last / max), colorFor(last, creative)));
        }
        if (average.get()) {
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.SPYGLASS), "AVERAGE  \u2022  " + Math.max(1, recent.size()) + " hits",
                    fmt(avg) + " blocks", (float) (avg / max), colorFor(avg, creative)));
        }
        HudRenderUtil.drawCards(context, this, cards);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Slot hotbar terpilih + ikon & nama item yang dipegang. */
public final class HotbarInfoModule extends HudModule {

    public HotbarInfoModule() {
        super("hotbar", "module.xoldiummod.hotbar", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        int slot = client.player.getInventory().getSelectedSlot() + 1;
        ItemStack stack = client.player.getInventory().getMainHandStack();
        String name = stack.isEmpty() ? "-" : stack.getName().getString();
        float dur = stack.isDamageable() ? 1f - stack.getDamage() / (float) Math.max(1, stack.getMaxDamage()) : -1f;
        HudRenderUtil.drawCard(context, this, stack.isEmpty() ? HudRenderUtil.icon(Items.BARRIER) : stack,
                "SLOT " + slot, name, dur);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.DIAMOND_SWORD, "SLOT 1", "Diamond Sword", 0.8f);
            return;
        }
        render(context, tickCounter);
    }
}

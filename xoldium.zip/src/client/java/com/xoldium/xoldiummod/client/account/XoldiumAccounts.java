package com.xoldium.xoldiummod.client.account;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.AccountBadge;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import ru.vidtu.ias.IAS;
import ru.vidtu.ias.account.Account;
import ru.vidtu.ias.account.MicrosoftAccount;
import ru.vidtu.ias.account.OfflineAccount;
import ru.vidtu.ias.auth.LoginData;
import ru.vidtu.ias.auth.handlers.CreateHandler;
import ru.vidtu.ias.auth.handlers.LoginHandler;
import ru.vidtu.ias.auth.microsoft.MSAuthClient;
import ru.vidtu.ias.auth.microsoft.fields.DeviceAuth;
import ru.vidtu.ias.config.IASStorage;
import ru.vidtu.ias.crypt.DummyCrypt;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Lapisan penghubung XoldiumAccount &lt;-&gt; backend In-Game Account Switcher (paket {@code ru.vidtu.ias}, LGPL-3.0,
 * disalin apa adanya dari source yang dikirim; lihat NOTICE_IAS).
 *
 * <p>Backend IAS (penyimpanan akun, login Microsoft lewat device code, akun offline) dipakai utuh. Yang ditulis
 * ulang hanya bagian yang menyentuh Minecraft: mengganti {@code Session} (akun aktif) pada {@link MinecraftClient}.
 * Karena IAS memakai mapping Mojang dan mod ini memakai Yarn, semua akses ke field internal dilakukan lewat
 * refleksi berbasis TIPE (bukan nama field), jadi tahan terhadap perbedaan nama. Bila ada langkah yang gagal,
 * pesan error ditampilkan di layar akun dan game tetap normal.
 */
public final class XoldiumAccounts {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
    private static boolean inited = false;

    private XoldiumAccounts() {
    }

    public static synchronized void init() {
        if (inited) {
            return;
        }
        inited = true;
        try {
            // tanpa cek "kill switch" jarak jauh ke GitHub (mod ini tidak boleh membuka koneksi sendiri saat start)
            System.setProperty("ias.skipDisableScanning", "true");
            IAS.init(FabricLoader.getInstance().getGameDir(), FabricLoader.getInstance().getConfigDir());
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Backend akun gagal dimulai (XoldiumAccount tidak aktif).", t);
        }
    }

    public static List<Account> accounts() {
        init();
        return new ArrayList<>(IASStorage.ACCOUNTS);
    }

    public static void save() {
        try {
            IAS.disclaimersStorage();
            IAS.saveStorage();
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal menyimpan daftar akun.", t);
        }
    }

    public static boolean validName(String name) {
        return name != null && NAME.matcher(name).matches();
    }

    /** Tambah akun offline; false bila nama tidak valid / sudah ada. */
    public static boolean addOffline(String name) {
        init();
        if (!validName(name)) {
            return false;
        }
        OfflineAccount account = new OfflineAccount(name, null);
        for (Account a : IASStorage.ACCOUNTS) {
            if (a.equals(account)) {
                return false;
            }
        }
        IASStorage.ACCOUNTS.add(account);
        save();
        return true;
    }

    public static void add(Account account) {
        init();
        for (Account a : IASStorage.ACCOUNTS) {
            if (a.equals(account) || (a.uuid().equals(account.uuid()) && a.type().equals(account.type()))) {
                IASStorage.ACCOUNTS.remove(a);
                break;
            }
        }
        IASStorage.ACCOUNTS.add(account);
        save();
    }

    public static void remove(Account account) {
        init();
        IASStorage.ACCOUNTS.remove(account);
        save();
    }

    public static boolean inWorld() {
        MinecraftClient c = MinecraftClient.getInstance();
        return c.world != null || c.player != null || c.getNetworkHandler() != null;
    }

    public static boolean isMicrosoft(Account a) {
        return a instanceof MicrosoftAccount;
    }

    // ------------------------------------------------------------------
    // Login
    // ------------------------------------------------------------------

    /** Hasil login yang dikirim ke UI (selalu di thread client). */
    public interface Result {
        void stage(String text);

        void done();

        void failed(String message);
    }

    public static void login(Account account, Result result) {
        init();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (inWorld()) {
            result.failed("Keluar dari dunia/server dulu sebelum ganti akun.");
            return;
        }
        if (account instanceof OfflineAccount offline) {
            LoginData data = new LoginData(offline.name(), OfflineAccount.uuid(offline.name()), "ias:offline", false);
            CompletableFuture.runAsync(() -> applyAsync(mc, data, result));
            return;
        }
        LoginHandler handler = new LoginHandler() {
            @Override
            public boolean cancelled() {
                return false;
            }

            @Override
            public void stage(String stage, Object... args) {
                mc.execute(() -> result.stage(friendlyStage(stage)));
            }

            @Override
            public CompletableFuture<String> password() {
                return CompletableFuture.failedFuture(new IllegalStateException("Akun berpassword tidak didukung."));
            }

            @Override
            public void success(LoginData data, boolean changed) {
                if (changed) {
                    save();
                }
                if (data == null) {
                    mc.execute(() -> result.failed("Login dibatalkan."));
                    return;
                }
                applyAsync(mc, data, result);
            }

            @Override
            public void error(Throwable error) {
                XoldiumMod.LOGGER.warn("[Xoldium] Login akun gagal.", error);
                mc.execute(() -> result.failed("Login gagal: " + root(error)));
            }
        };
        try {
            account.login(handler, null);
        } catch (Throwable t) {
            result.failed("Login gagal: " + root(t));
        }
    }

    private static void applyAsync(MinecraftClient mc, LoginData data, Result result) {
        try {
            ProfileResult profile = null;
            if (data.online()) {
                try {
                    profile = new YggdrasilAuthenticationService(java.net.Proxy.NO_PROXY)
                            .createMinecraftSessionService().fetchProfile(data.uuid(), true);
                } catch (Throwable t) {
                    XoldiumMod.LOGGER.warn("[Xoldium] Profil akun tidak bisa diambil (skin dimuat belakangan).", t);
                }
            }
            final ProfileResult fetched = profile;
            mc.execute(() -> {
                try {
                    applySession(mc, data, fetched);
                    AccountBadge.invalidate();
                    result.done();
                } catch (Throwable t) {
                    XoldiumMod.LOGGER.warn("[Xoldium] Ganti akun gagal.", t);
                    result.failed("Ganti akun gagal: " + root(t));
                }
            });
        } catch (Throwable t) {
            mc.execute(() -> result.failed("Ganti akun gagal: " + root(t)));
        }
    }

    private static void applySession(MinecraftClient mc, LoginData data, ProfileResult profile) throws Throwable {
        if (inWorld()) {
            throw new IllegalStateException("masih berada di dunia");
        }
        Object old = mc.getSession();
        Class<?> sessionClass = old.getClass();
        Object session = newSession(sessionClass, data);
        Field field = null;
        for (Field f : MinecraftClient.class.getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers()) && f.getType() == sessionClass) {
                field = f;
                break;
            }
        }
        if (field == null) {
            throw new IllegalStateException("field sesi tidak ditemukan");
        }
        field.setAccessible(true);
        field.set(mc, session);

        // profil game (nama/skin) - future<ProfileResult>; null = dibangun dari sesi
        for (Field f : MinecraftClient.class.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.getType() != CompletableFuture.class
                    || !(f.getGenericType() instanceof ParameterizedType pt)
                    || pt.getActualTypeArguments().length != 1
                    || !pt.getActualTypeArguments()[0].getTypeName().endsWith("ProfileResult")) {
                continue;
            }
            try {
                f.setAccessible(true);
                f.set(mc, CompletableFuture.completedFuture(profile));
            } catch (Throwable t) {
                XoldiumMod.LOGGER.warn("[Xoldium] Future profil game tidak bisa diganti (skin mungkin lama).", t);
            }
        }
        XoldiumMod.LOGGER.info("[Xoldium] Akun aktif diganti ke {} ({})", data.name(), data.online() ? "online" : "offline");
    }

    private static Object newSession(Class<?> sessionClass, LoginData data) throws Throwable {
        for (Constructor<?> c : sessionClass.getDeclaredConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            if (p.length < 3 || p[0] != String.class || p[1] != UUID.class || p[2] != String.class) {
                continue;
            }
            Object[] args = new Object[p.length];
            args[0] = data.name();
            args[1] = data.uuid();
            args[2] = data.token();
            boolean ok = true;
            for (int i = 3; i < p.length; i++) {
                if (p[i] == Optional.class) {
                    args[i] = Optional.empty();
                } else if (p[i].isEnum()) {
                    args[i] = pickEnum(p[i], data.online());
                } else {
                    ok = false;
                }
            }
            if (!ok) {
                continue;
            }
            c.setAccessible(true);
            return c.newInstance(args);
        }
        throw new IllegalStateException("konstruktor Session tidak dikenali");
    }

    private static Object pickEnum(Class<?> type, boolean online) {
        Object[] constants = type.getEnumConstants();
        String want = online ? "MSA" : "LEGACY";
        for (Object o : constants) {
            if (((Enum<?>) o).name().equalsIgnoreCase(want)) {
                return o;
            }
        }
        return constants[0];
    }

    // ------------------------------------------------------------------
    // Login Microsoft (device code)
    // ------------------------------------------------------------------

    /** Sesi login Microsoft yang sedang berjalan. */
    public static final class MicrosoftFlow implements CreateHandler {
        private volatile boolean cancelled = false;
        private volatile String stage = "Memulai...";
        private volatile DeviceAuth device;
        private volatile String error;
        private volatile MicrosoftAccount result;
        private MSAuthClient client;

        public boolean cancelled() {
            return cancelled;
        }

        public String stage() {
            return stage;
        }

        public DeviceAuth device() {
            return device;
        }

        public String error() {
            return error;
        }

        /** Akun hasil login (sekali ambil), atau null bila belum selesai. */
        public MicrosoftAccount takeResult() {
            MicrosoftAccount r = result;
            result = null;
            return r;
        }

        public void cancel() {
            cancelled = true;
            try {
                if (client != null) {
                    client.close();
                }
            } catch (Throwable ignored) {
                // abaikan
            }
        }

        @Override
        public void stage(String key, Object... args) {
            this.stage = friendlyStage(key);
        }

        @Override
        public void success(MicrosoftAccount account) {
            this.stage = "Selesai";
            this.result = account;
        }

        @Override
        public void error(Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Login Microsoft gagal.", t);
            this.error = "Login Microsoft gagal: " + root(t);
        }
    }

    public static MicrosoftFlow startMicrosoft() {
        init();
        MicrosoftFlow flow = new MicrosoftFlow();
        try {
            // DummyCrypt: stabil di semua perangkat (termasuk launcher Android). Token tersimpan di folder game.
            flow.client = new MSAuthClient(DummyCrypt.INSTANCE, flow);
            flow.client.start().thenAccept(auth -> flow.device = auth).exceptionally(t -> {
                flow.error = "Login Microsoft gagal: " + root(t);
                return null;
            });
        } catch (Throwable t) {
            flow.error = "Login Microsoft gagal: " + root(t);
        }
        return flow;
    }

    // ------------------------------------------------------------------

    private static String root(Throwable t) {
        Throwable c = t;
        for (int i = 0; i < 12 && c.getCause() != null && c.getCause() != c; i++) {
            c = c.getCause();
        }
        String m = c.getMessage();
        return m == null || m.isBlank() ? c.getClass().getSimpleName() : m;
    }

    static String friendlyStage(String key) {
        if (key == null) {
            return "Memproses...";
        }
        String k = key.toLowerCase(java.util.Locale.ROOT);
        if (k.contains("initializing")) return "Menyiapkan...";
        if (k.contains("decrypting")) return "Membuka data akun...";
        if (k.contains("encrypting")) return "Mengamankan data akun...";
        if (k.contains("processing")) return "Menunggu persetujuan...";
        if (k.contains("link")) return "Buka link & masukkan kode";
        if (k.contains("server")) return "Menyiapkan server login...";
        if (k.contains("msacto") || k.contains("msrto")) return "Menukar token Microsoft...";
        if (k.contains("msato")) return "Login Xbox Live...";
        if (k.contains("xbltoxsts")) return "Otorisasi Xbox...";
        if (k.contains("xststomca")) return "Login Minecraft...";
        if (k.contains("mcatomcp")) return "Mengambil profil...";
        if (k.contains("services")) return "Menyiapkan layanan...";
        if (k.contains("finalizing")) return "Menyelesaikan...";
        return "Memproses...";
    }
}

package com.xoldium.xoldiummod.client.crosshair;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.xoldium.xoldiummod.XoldiumMod;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Penyimpanan grid piksel crosshair buatan pemakai (preset "Custom").
 * Format grid sama dengan mod referensi UltCustomCrosshair: 15x15 boolean,
 * indeks [x][y], pusat di [7][7]. Warna/skala/opacity disimpan oleh sistem
 * setting modul Xoldium, bukan di sini.
 */
public final class CrosshairStore {

    public static final int GRID = 15;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("xoldium_crosshair.json");

    private static Data data;

    private CrosshairStore() {
    }

    private static final class Data {
        boolean[][] customGrid = CrosshairPresets.CROSS.getPattern();
    }

    private static Data data() {
        if (data == null) {
            try {
                if (Files.exists(FILE)) {
                    data = GSON.fromJson(Files.readString(FILE), Data.class);
                }
            } catch (Throwable t) {
                XoldiumMod.LOGGER.warn("[Xoldium] Gagal membaca crosshair custom, memakai bawaan.", t);
            }
            if (data == null || data.customGrid == null || data.customGrid.length != GRID) {
                data = new Data();
            }
            for (boolean[] column : data.customGrid) {
                if (column == null || column.length != GRID) {
                    data = new Data();
                    break;
                }
            }
        }
        return data;
    }

    /** Salinan grid custom (aman diubah pemanggil). */
    public static boolean[][] customGrid() {
        boolean[][] src = data().customGrid;
        boolean[][] copy = new boolean[GRID][GRID];
        for (int x = 0; x < GRID; x++) {
            System.arraycopy(src[x], 0, copy[x], 0, GRID);
        }
        return copy;
    }

    /** Referensi grid custom tanpa menyalin (untuk render tiap frame). */
    public static boolean[][] customGridRef() {
        return data().customGrid;
    }

    public static void setCustomGrid(boolean[][] grid) {
        boolean[][] copy = new boolean[GRID][GRID];
        for (int x = 0; x < GRID; x++) {
            System.arraycopy(grid[x], 0, copy[x], 0, GRID);
        }
        data().customGrid = copy;
        save();
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(data()));
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal menyimpan crosshair custom.", t);
        }
    }
}

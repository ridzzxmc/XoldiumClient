package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import java.util.ArrayDeque;
import java.util.Deque;

/** CPS - jumlah klik kiri / kanan per detik dalam kartu berikon pedang. */
public final class CpsCounterModule extends HudModule {

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public CpsCounterModule() {
        super("cps_counter", "module.xoldiummod.cps_counter", false, 4f, 4f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        boolean leftPressed = client.options.attackKey.isPressed();
        if (leftPressed && !wasLeftPressed) {
            leftClicks.addLast(now);
        }
        wasLeftPressed = leftPressed;
        boolean rightPressed = client.options.useKey.isPressed();
        if (rightPressed && !wasRightPressed) {
            rightClicks.addLast(now);
        }
        wasRightPressed = rightPressed;
        trim(leftClicks, now);
        trim(rightClicks, now);
    }

    private void trim(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawCard(context, this, Items.IRON_SWORD, "CPS  L | R",
                leftClicks.size() + "  |  " + rightClicks.size(), Math.min(1f, leftClicks.size() / 20f));
    }
}

package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.XoldiumMod;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Hub XoldiumClient (gaya Aurora Client): dua kotak besar - <b>Module</b> dan <b>HUD Editor</b>. Semua animasi (masuk bertahap, hover membesar) memakai
 * {@link Anim}; interaksi lewat widget transparan vanilla (tanpa override input).
 */
public final class XoldiumHubScreen extends XoldiumScreen {

    private static final int BIG_W = 100;
    private static final int BIG_H = 96;
    private static final int GAP = 10;
    private static final int SMALL_W = 96;
    private static final int SMALL_H = 30;

    /** Ikon kartu hub (putih transparan 128x128): kubus untuk Module, pensil untuk HUD Editor. */
    private static final Identifier ICON_MODULE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/hub/module.png");
    private static final Identifier ICON_COSMETIC = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/hub/cosmetic.png");
    private static final Identifier ICON_HUD_EDITOR = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/hub/hud_editor.png");
    private static final int ICON_SIZE = 40;

    private final ButtonWidget moduleHit = hitArea(this::openModules);
    private final ButtonWidget hudHit = hitArea(this::openHudEditor);
    private final ButtonWidget cosmeticHit = hitArea(this::openCosmetic);
    private final Anim.Smooth cosmeticHover = new Anim.Smooth(0f, 14f);
    private final Anim.Smooth cosmeticScale = new Anim.Smooth(1f, 12f);
    private final Anim.Smooth cosmeticLift = new Anim.Smooth(0f, 12f);
    private final Anim.Smooth moduleHover = new Anim.Smooth(0f, 14f);
    private final Anim.Smooth hudHover = new Anim.Smooth(0f, 14f);

    private final Anim.Smooth moduleScale = new Anim.Smooth(1f, 12f);
    private final Anim.Smooth hudScale = new Anim.Smooth(1f, 12f);
    private final Anim.Smooth moduleLift = new Anim.Smooth(0f, 12f);
    private final Anim.Smooth hudLift = new Anim.Smooth(0f, 12f);

    private int bigW;
    private int bigH;

    public XoldiumHubScreen(Screen parent) {
        super(Text.literal("XoldiumClient"), parent);
    }

    @Override
    protected void init() {
        this.addDrawableChild(moduleHit);
        this.addDrawableChild(hudHit);
        this.addDrawableChild(cosmeticHit);
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.back"), b -> this.close())
                .dimensions(6, this.height - 26, 56, 20).build());
    }

    private void openModules() {
        if (this.client != null) {
            this.client.setScreen(new ModListScreen(this));
        }
    }

    private void openCosmetic() {
        if (this.client != null) {
            this.client.setScreen(new XoldiumCosmeticScreen(this));
        }
    }

    private void openHudEditor() {
        if (this.client != null) {
            this.client.setScreen(new XoldiumHomeScreen(this));
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);
        float a = screenAlpha();
        float ms = openElapsedMs();

        // ukuran kotak menyesuaikan layar kecil (HP): skala turun bila ruang tidak cukup
        float fit = Math.min(1f, Math.min((this.width - 24f) / (BIG_W * 3 + GAP * 2), (this.height - 56f) / BIG_H));
        bigW = Math.round(BIG_W * fit);
        bigH = Math.round(BIG_H * fit);
        int gap = Math.round(GAP * fit);

        int rowW = bigW * 3 + gap * 2;
        int left = (this.width - rowW) / 2;
        int top = Math.max(34, (this.height - bigH) / 2 + 10);

        float titleIn = Anim.easeOutQuint(Anim.clamp01(ms / 650f));
        float titleA = a * titleIn;
        int titleY = top - 22 - Math.round((1f - titleIn) * -14f);
        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold("XOLDIUM CLIENT"),
                this.width / 2, titleY, Anim.withAlpha(0xFFFFFFFF, titleA));
        // garis bawah judul memanjang dari tengah
        int lineHalf = Math.round(Anim.easeOutCubic(Anim.clamp01((ms - 200f) / 600f)) * 34f);
        context.fill(this.width / 2 - lineHalf, titleY + 12, this.width / 2 + lineHalf, titleY + 13,
                Anim.withAlpha(0x88FFFFFF, titleA));

        // urutan: HUD Editor (kiri) - Module (tengah) - Cosmetic (kanan)
        drawBig(context, left, top, ICON_HUD_EDITOR, "HUD Editor", Text.translatable("gui.xoldiummod.hub.hud_hint").getString(),
                hudHover, hudScale, hudLift, hudHit, mouseX, mouseY, a, ms, 120f);
        drawBig(context, left + bigW + gap, top, ICON_MODULE, "Module", Text.translatable("gui.xoldiummod.hub.module_hint").getString(),
                moduleHover, moduleScale, moduleLift, moduleHit, mouseX, mouseY, a, ms, 220f);
        drawBig(context, left + (bigW + gap) * 2, top, ICON_COSMETIC, "Cosmetic", Text.translatable("gui.xoldiummod.hub.cosmetic_hint").getString(),
                cosmeticHover, cosmeticScale, cosmeticLift, cosmeticHit, mouseX, mouseY, a, ms, 320f);
        super.render(context, mouseX, mouseY, delta);
        endFrame();
    }

    private void drawBig(DrawContext context, int x, int y, Identifier icon, String title, String hint, Anim.Smooth hover,
                         Anim.Smooth scaleSmooth, Anim.Smooth liftSmooth, ButtonWidget hit, int mouseX, int mouseY,
                         float a, float ms, float delayMs) {
        // --- animasi masuk: geser dari bawah + membesar dengan sedikit overshoot + fade
        float t = Anim.clamp01((ms - delayMs) / 650f);
        float slide = Anim.easeOutQuint(t);
        float pop = Anim.easeOutBack(t);
        float alpha = a * Anim.easeOutCubic(Anim.clamp01(t * 1.6f));
        float enterScale = 0.82f + 0.18f * pop;
        int enterOffset = Math.round((1f - slide) * 22f);

        boolean over = mouseX >= x && mouseX < x + bigW && mouseY >= y && mouseY < y + bigH;
        boolean pressed = false;
        try {
            if (over && this.client != null) {
                pressed = org.lwjgl.glfw.GLFW.glfwGetMouseButton(this.client.getWindow().getHandle(),
                        org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            }
        } catch (Throwable ignored) {
            // abaikan
        }
        float h = hover.update(over ? 1f : 0f);
        float sc = scaleSmooth.update(pressed ? 0.955f : (over ? 1.045f : 1f));
        float lift = liftSmooth.update(over ? -3f : 0f);
        place(hit, x, y, bigW, bigH);

        float cx = x + bigW / 2f;
        float cy = y + bigH / 2f + enterOffset + lift;
        float total = sc * enterScale;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(cx, cy);
        context.getMatrices().scale(total, total);
        context.getMatrices().translate(-bigW / 2f, -bigH / 2f);

        // bayangan lembut di bawah kartu (menguat saat hover)
        for (int i = 0; i < 4; i++) {
            context.fill(3 + i, bigH + 2 + i, bigW - 3 - i, bigH + 3 + i,
                    Anim.withAlpha(0x30000000, alpha * (0.6f + 0.4f * h) * (1f - i * 0.22f)));
        }
        ScreenChrome.roundedFill(context, 0, 0, bigW, bigH, Anim.withAlpha(Anim.lerpColor(0xD0101012, 0xEA202026, h), alpha));
        ScreenChrome.roundedBorder(context, 0, 0, bigW, bigH, Anim.withAlpha(Anim.lerpColor(0x55FFFFFF, 0xFFFFFFFF, h), alpha));

        // kilau diagonal yang menyapu kartu saat hover (loop halus)
        if (h > 0.02f) {
            float sweep = (System.currentTimeMillis() % 1800L) / 1800f;
            int sx = Math.round(Anim.lerp(-24f, bigW + 8f, Anim.easeInOutSine(sweep)));
            for (int row = 3; row < bigH - 3; row += 2) {
                int off = sx + (bigH - row) / 3;
                int l = Math.max(3, off);
                int r = Math.min(bigW - 3, off + 12);
                if (r > l) {
                    context.fill(l, row, r, row + 2, Anim.withAlpha(0x14FFFFFF, alpha * h));
                }
            }
        }
        // glow tipis di tepi atas
        context.fill(3, 2, bigW - 3, 3 + Math.round(h * 12f), Anim.withAlpha(0x12FFFFFF, alpha));

        // ikon besar (gambar PNG): melayang pelan, sedikit membesar saat hover
        float bob = (float) Math.sin(System.currentTimeMillis() / 520.0 + x * 0.05) * (1.2f + 1.6f * h);
        float k = 1f + h * 0.12f;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(bigW / 2f, bigH / 2f - 26f + ICON_SIZE / 2f + bob - h * 2f);
        context.getMatrices().scale(k, k);
        IconRenderer.drawTexture(context, icon, -ICON_SIZE / 2, -ICON_SIZE / 2, ICON_SIZE, ICON_SIZE);
        context.getMatrices().popMatrix();
        // fade-in ikon: tekstur digambar tanpa alpha, jadi ditutup selubung warna kartu yang memudar
        if (alpha < 0.98f) {
            int veil = Anim.withAlpha(0xFF101012, Math.min(1f, (1f - alpha) * 1.1f));
            context.fill(bigW / 2 - ICON_SIZE / 2 - 4, bigH / 2 - 26 - 6, bigW / 2 + ICON_SIZE / 2 + 4,
                    bigH / 2 - 26 + ICON_SIZE + 8, veil);
        }

        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold(title), bigW / 2, bigH - 34,
                Anim.withAlpha(0xFFFFFFFF, alpha));
        int lw = Math.round(10f + h * 20f);
        context.fill(bigW / 2 - lw, bigH - 22, bigW / 2 + lw, bigH - 21, Anim.withAlpha(0xFFFFFFFF, alpha * (0.35f + 0.65f * h)));
        if (this.textRenderer.getWidth(hint) < bigW - 8) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(hint), bigW / 2, bigH - 16,
                    Anim.withAlpha(Anim.lerpColor(0xFF8A8A92, 0xFFC8C8D0, h), alpha));
        }
        context.getMatrices().popMatrix();
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Jam sistem (HH:mm:ss). */
public final class ClockHudModule extends HudModule {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ClockHudModule() {
        super("clock_hud", "module.xoldiummod.clock_hud", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        LocalTime now = LocalTime.now();
        HudRenderUtil.drawCard(context, this, Items.CLOCK, "CLOCK", now.format(FORMAT),
                (now.getHour() * 3600 + now.getMinute() * 60 + now.getSecond()) / 86400f);
    }
}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import org.lwjgl.system.MemoryUtil;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Hit Color (menggantikan Damage Indicator) - mengganti warna kilatan merah
 * saat entitas terkena hit/damage.
 *
 * <p>PORTING KONSEP dari source "CookeyMod" (rizecookey) yang dikirim pemakai:
 * di CookeyMod opsi {@code damageColor} bekerja dengan menimpa 8 baris piksel
 * pertama {@code OverlayTexture} (tekstur 16x16 "Entity Color Overlay" yang
 * dipakai shader entitas untuk kilatan merah saat terkena hit; baris 8-15
 * adalah kilatan PUTIH - creeper meledak dsb - dan sengaja tidak disentuh).
 * Alfa piksel di tekstur itu = seberapa banyak warna ASLI entitas dipertahankan
 * (vanilla: 178/255 = 70% asli + 30% merah), jadi "Intensity" di sini = persen
 * warna kilatan yang dicampurkan (default 30% = vanilla).
 *
 * <p>Cara menulisnya BERBEDA dari CookeyMod (mapping Mojang + Mixin ke
 * konstruktor {@code OverlayTexture}): di sini tekstur dicari lewat TIPE
 * (bukan nama field/method) lalu piksel ditulis langsung ke memori
 * {@code NativeImage} (RGBA 16x16) dan di-upload ulang, supaya tidak ada satu
 * pun nama method Yarn yang perlu ditebak. Penulisan ke memori native DIJAGA:
 * sebelum menulis, isi tekstur diverifikasi (baris merah vanilla & baris putih
 * harus persis seperti yang diharapkan) - bila tidak cocok, modul menyerah
 * dengan aman (log sekali), TIDAK menulis ke alamat yang tidak jelas.
 */
public final class HitColorModule extends Module {

    private static final int SIZE = 16;
    /** Piksel merah vanilla sebagai int little-endian RGBA-bytes: A=0xB2, B=0, G=0, R=0xFF. */
    private static final int VANILLA_RED_ABGR = 0xB20000FF;

    private final ColorSetting color = addSetting(
            new ColorSetting("color", "setting.xoldiummod.hit_color.color", 0xFFFF0000, false));
    private final DoubleSetting intensity = addSetting(
            new DoubleSetting("intensity", "setting.xoldiummod.hit_color.intensity", 30.0, 0.0, 100.0, 1.0));

    private int appliedKey = Integer.MIN_VALUE;
    private int lastWritten = VANILLA_RED_ABGR;
    private int retryCooldown = 0;
    private int failures = 0;
    private int refreshTicks = 0;
    /** Alamat piksel yang sudah terverifikasi (di-cache supaya perubahan berikutnya tidak bergantung isi piksel lama). */
    private long cachedPointer = 0L;
    private Object cachedTexture = null;
    /** true bila tekstur overlay sedang berisi warna kita dan harus dikembalikan ke vanilla saat modul mati. */
    private boolean dirty = false;

    public HitColorModule() {
        super("hit_color", "module.xoldiummod.hit_color", ModuleCategory.VISUAL, false);
        // Tick global (bukan hanya saat modul ON): supaya saat dimatikan, warna vanilla SELALU dikembalikan.
        net.fabricmc.fabric.api.event.client.ClientTickEvents.END_CLIENT_TICK.register(c -> globalTick());
    }

    private void globalTick() {
        try {
            if (retryCooldown > 0) {
                retryCooldown--;
                return;
            }
            if (isEnabled()) {
                int key = (color.argb() & 0x00FFFFFF) * 131 + (int) Math.round(intensity.get());
                refreshTicks++;
                // re-apply tiap ~2 dtk juga: tahan terhadap reload resource / tekstur dibuat ulang
                if (key != appliedKey || refreshTicks >= 40) {
                    refreshTicks = 0;
                    int keep = 255 - (int) Math.round(Math.max(0.0, Math.min(100.0, intensity.get())) * 2.55);
                    if (write(color.red(), color.green(), color.blue(), keep)) {
                        appliedKey = key;
                        dirty = true;
                        failures = 0;
                    } else {
                        backoff();
                    }
                }
            } else if (dirty) {
                if (write(255, 0, 0, 178)) { // merah vanilla
                    dirty = false;
                    appliedKey = Integer.MIN_VALUE;
                    failures = 0;
                } else {
                    backoff();
                }
            }
        } catch (Throwable t) {
            backoff();
        }
    }

    private void backoff() {
        failures++;
        retryCooldown = Math.min(100, 10 * failures); // coba lagi terus, tidak pernah menyerah permanen
    }

    @Override
    protected void onToggle(boolean enabled) {
        appliedKey = Integer.MIN_VALUE;
        refreshTicks = 40;
        retryCooldown = 0;
        failures = 0;
    }

    // ------------------------------------------------------------------

    private boolean write(int r, int g, int b, int keepAlpha) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            GameRenderer renderer = client.gameRenderer;
            if (renderer == null) {
                return false; // belum siap - coba lagi nanti
            }
            Object overlay = fieldOfType(renderer, OverlayTexture.class);
            if (overlay == null) {
                return fail("OverlayTexture tidak ditemukan di GameRenderer");
            }
            Object texture = fieldOfType(overlay, NativeImageBackedTexture.class);
            if (texture == null) {
                return fail("NativeImageBackedTexture tidak ditemukan di OverlayTexture");
            }
            NativeImage image = imageOf(texture);
            if (image == null) {
                return fail("NativeImage tidak ditemukan");
            }
            long pointer = cachedPointer;
            if (pointer == 0L || texture != cachedTexture || !stillValid(pointer)) {
                pointer = pixelPointer(image);
                cachedPointer = pointer;
                cachedTexture = texture;
            }
            if (pointer == 0L) {
                return fail("alamat piksel NativeImage 16x16 tidak ditemukan (isi tekstur bukan overlay vanilla?)");
            }
            int abgr = ((keepAlpha & 0xFF) << 24) | ((b & 0xFF) << 16) | ((g & 0xFF) << 8) | (r & 0xFF);
            lastWritten = abgr;
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < SIZE; col++) {
                    MemoryUtil.memPutInt(pointer + 4L * (row * SIZE + col), abgr);
                }
            }
            return upload(texture) || fail("method upload() tidak ditemukan");
        } catch (Throwable t) {
            cachedPointer = 0L;
            cachedTexture = null;
            if (failures < 3) {
                XoldiumMod.LOGGER.warn("[Xoldium] Hit Color: gagal menulis tekstur (akan dicoba lagi).", t);
            }
            return false;
        }
    }

    private boolean fail(String reason) {
        if (failures < 3) {
            XoldiumMod.LOGGER.warn("[Xoldium] Hit Color tidak bisa dipasang (akan dicoba lagi): {}", reason);
        }
        return false;
    }

    /** Baris 8 (kilatan putih) tidak pernah kita ubah -> harus tetap putih pekat; baris 0 harus punya alfa. */
    private static boolean stillValid(long p) {
        try {
            return MemoryUtil.memGetInt(p + 4L * (8 * SIZE)) == 0xFFFFFFFF;
        } catch (Throwable t) {
            return false;
        }
    }

    private static Object fieldOfType(Object owner, Class<?> type) throws IllegalAccessException {
        for (Class<?> c = owner.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (type.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    Object value = f.get(owner);
                    if (value != null) {
                        return value;
                    }
                }
            }
        }
        return null;
    }

    private static NativeImage imageOf(Object texture) throws Exception {
        for (Method m : texture.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == NativeImage.class) {
                m.setAccessible(true);
                return (NativeImage) m.invoke(texture);
            }
        }
        return null;
    }

    /**
     * Alamat memori piksel NativeImage. Dicari lewat FIELD long yang "mirip alamat" (> 64KB), ukuran harus 16x16,
     * dan DIVERIFIKASI lewat baris 8 (kilatan putih, tidak pernah kita ubah) = putih pekat serta baris 0 punya
     * alfa (merah vanilla ATAU warna buatan kita sebelumnya - tidak perlu sama persis, supaya ganti warna
     * berkali-kali tetap bisa).
     */
    private static long pixelPointer(NativeImage image) throws Exception {
        int sixteens = 0;
        List<Long> candidates = new ArrayList<>();
        for (Field f : NativeImage.class.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) {
                continue;
            }
            f.setAccessible(true);
            if (f.getType() == int.class && f.getInt(image) == SIZE) {
                sixteens++;
            } else if (f.getType() == long.class) {
                long v = f.getLong(image);
                if (v > 0x10000L) {
                    candidates.add(v);
                }
            }
        }
        if (sixteens < 2) {
            return 0L;
        }
        for (long p : candidates) {
            int row8 = MemoryUtil.memGetInt(p + 4L * (8 * SIZE));
            int row7 = MemoryUtil.memGetInt(p + 4L * (7 * SIZE));
            if (row8 == 0xFFFFFFFF && row7 != 0xFFFFFFFF) {
                return p;
            }
        }
        return 0L;
    }

    private static boolean upload(Object texture) throws Exception {
        Method found = null;
        for (Method m : texture.getClass().getDeclaredMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == void.class
                    && !Modifier.isStatic(m.getModifiers()) && !m.getName().equals("close")) {
                if (found != null) {
                    return false; // ambigu -> menyerah
                }
                found = m;
            }
        }
        if (found == null) {
            return false;
        }
        found.setAccessible(true);
        found.invoke(texture);
        return true;
    }
}

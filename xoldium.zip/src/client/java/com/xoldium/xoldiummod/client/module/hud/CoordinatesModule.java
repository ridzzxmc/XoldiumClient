package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** CoordinatesModule - kartu HUD dengan ikon, label, nilai. */
public final class CoordinatesModule extends HudModule {

    public CoordinatesModule() {
        super("coordinates", "module.xoldiummod.coordinates", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        int bx = client.player.getBlockPos().getX();
        int by = client.player.getBlockPos().getY();
        int bz = client.player.getBlockPos().getZ();
        HudRenderUtil.drawCard(context, this, Items.FILLED_MAP, "XYZ", bx + "  " + by + "  " + bz, -1f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.FILLED_MAP, "XYZ", "128  64  -256", -1f);
            return;
        }
        render(context, tickCounter);
    }

}

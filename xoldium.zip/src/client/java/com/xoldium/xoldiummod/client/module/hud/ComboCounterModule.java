package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.util.hit.EntityHitResult;

/** Combo - hitungan serangan beruntun (reset 3 detik tanpa serangan). */
public final class ComboCounterModule extends HudModule {

    private static final int TIMEOUT_TICKS = 60;

    private int combo = 0;
    private int ticksSinceHit = 0;
    private boolean wasAttackPressed = false;

    public ComboCounterModule() {
        super("combo_counter", "module.xoldiummod.combo_counter", false, 4f, 4f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean attackPressed = client.options.attackKey.isPressed();
        if (attackPressed && !wasAttackPressed && client.crosshairTarget instanceof EntityHitResult) {
            combo++;
            ticksSinceHit = 0;
        }
        wasAttackPressed = attackPressed;
        if (combo > 0) {
            ticksSinceHit++;
            if (ticksSinceHit > TIMEOUT_TICKS) {
                combo = 0;
            }
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (combo <= 0) {
            return;
        }
        HudRenderUtil.drawCard(context, this, Items.DIAMOND_SWORD, "COMBO", "x" + combo,
                1f - ticksSinceHit / (float) TIMEOUT_TICKS);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawCard(context, this, Items.DIAMOND_SWORD, "COMBO", "x" + Math.max(combo, 7), 0.7f);
    }
}

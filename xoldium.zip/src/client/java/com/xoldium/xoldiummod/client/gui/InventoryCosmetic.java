package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.cosmetic.Cosmetics;
import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

import java.lang.reflect.Field;

/**
 * Avatar pemain di layar inventory yang MENAMPILKAN cosmetic yang sedang dipakai.
 *
 * <p>Avatar vanilla (lengkap dengan skin dan ARMOR) dibiarkan. Cosmetic Xoldium digambar sebagai quad di dunia
 * ({@code CosmeticRenderer}) sehingga tidak ikut tampil di GUI, jadi di sini cosmetic digambar TERPISAH di atas
 * avatar lewat {@link PlayerPreview} (mode cosmetic-only), dengan posisi/skala/arah menoleh yang sama seperti
 * avatar vanilla (badan 20 derajat, kepala 40 derajat ke arah kursor).
 */
public final class InventoryCosmetic {

    private static Field fx;
    private static Field fy;
    private static boolean resolved = false;

    private InventoryCosmetic() {
    }

    public static void draw(DrawContext ctx, Screen screen, int mouseX, int mouseY) {
        if (!(screen instanceof InventoryScreen) || !PlayerPreview.available() || InventoryScaleModule.hideAvatar()) {
            return;
        }
        if (Cosmetics.myHead() == 0 && Cosmetics.myBack() == 0) {
            return;
        }
        int[] o = origin(screen);
        int i = o[0];
        int j = o[1];
        // kotak avatar vanilla: (i+26, j+8) - (i+75, j+78), ukuran model 30 px/blok, kaki sekitar j+72
        int cx = i + 50;
        int bottom = j + 72;
        float pixel = 30f * 0.9375f / 16f;
        double t = Math.atan((mouseX - (i + 50.5)) / 40.0);
        float body = (float) Math.toRadians(t * 20.0);
        float head = (float) Math.toRadians(t * 40.0);
        // 1.21.4: tidak ada layer GUI terpisah; geser z ke depan supaya digambar DI ATAS avatar vanilla
        ctx.getMatrices().push();
        ctx.getMatrices().translate(0f, 0f, 150f);
        ctx.enableScissor(i + 26, j + 8, i + 75, j + 78);
        try {
            PlayerPreview.draw(ctx, AccountBadge.skinObject(),
                    Cosmetics.head(Cosmetics.myHead()), Cosmetics.back(Cosmetics.myBack()),
                    cx, bottom, pixel, body, head, true);
        } finally {
            ctx.disableScissor();
            ctx.getMatrices().pop();
        }
    }

    /** Pojok kiri-atas panel inventory (ikut bergeser saat recipe book dibuka). */
    private static int[] origin(Screen s) {
        try {
            if (!resolved) {
                resolved = true;
                Class<?> hs = net.minecraft.client.gui.screen.ingame.HandledScreen.class;
                String[][] names = {{"field_2776", "field_2800"}, {"x", "y"}};
                for (String[] n : names) {
                    try {
                        Field a = hs.getDeclaredField(n[0]);
                        Field b = hs.getDeclaredField(n[1]);
                        if (a.getType() == int.class && b.getType() == int.class) {
                            a.setAccessible(true);
                            b.setAccessible(true);
                            fx = a;
                            fy = b;
                            break;
                        }
                    } catch (NoSuchFieldException ignored) {
                        // coba pasangan nama berikutnya
                    }
                }
            }
            if (fx != null && fy != null) {
                return new int[]{fx.getInt(s), fy.getInt(s)};
            }
        } catch (Throwable ignored) {
            // pakai posisi tengah
        }
        return new int[]{(s.width - 176) / 2, (s.height - 166) / 2};
    }
}

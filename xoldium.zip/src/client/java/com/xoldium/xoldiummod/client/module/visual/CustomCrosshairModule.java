package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.crosshair.CrosshairPresets;
import com.xoldium.xoldiummod.client.crosshair.CrosshairStore;
import com.xoldium.xoldiummod.client.gui.CrosshairEditorScreen;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.ActionSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Custom Crosshair (menggantikan modul "Crosshair" lama yang hanya menampilkan
 * nama block/entity). Port dari source "UltCustomCrosshair": crosshair digambar
 * dari grid piksel 15x15 (preset bawaan + editor piksel buatan sendiri), warna,
 * skala dan opacity. Crosshair vanilla disembunyikan oleh
 * {@code mixin.visual.CrosshairHideMixin} selama modul ini aktif.
 */
public final class CustomCrosshairModule extends Module {

    private static CustomCrosshairModule instance;

    private final ModeSetting preset;
    private final ColorSetting color = addSettingColor();
    private final DoubleSetting scale;
    private final DoubleSetting opacity;

    public CustomCrosshairModule() {
        super("crosshair", "module.xoldiummod.crosshair", ModuleCategory.VISUAL, false);
        instance = this;
        CrosshairPresets[] all = CrosshairPresets.values();
        String[] keys = new String[all.length + 1];
        keys[0] = "setting.xoldiummod.crosshair.preset.custom";
        for (int i = 0; i < all.length; i++) {
            keys[i + 1] = "setting.xoldiummod.crosshair.preset." + all[i].name().toLowerCase(java.util.Locale.ROOT);
        }
        // index default 3 = "Cross" (CROSS adalah elemen ke-3 enum, +1 karena "Custom" di depan)
        preset = addSetting(new ModeSetting("preset", "setting.xoldiummod.crosshair.preset", CrosshairPresets.CROSS.ordinal() + 1, keys));
        addSetting(color);
        scale = addSetting(new DoubleSetting("scale", "setting.xoldiummod.crosshair.scale", 1.0, 0.5, 3.0, 0.1));
        opacity = addSetting(new DoubleSetting("opacity", "setting.xoldiummod.crosshair.opacity", 1.0, 0.0, 1.0, 0.05));
        addSetting(new ActionSetting("editor", "setting.xoldiummod.crosshair.editor", () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> mc.setScreen(new CrosshairEditorScreen(mc.currentScreen)));
        }));
    }

    private static ColorSetting addSettingColor() {
        return new ColorSetting("color", "setting.xoldiummod.crosshair.color", 0xFFFFFFFF, false);
    }

    /** Jadikan "Custom" preset aktif (dipanggil editor setelah Save). */
    public static void selectCustom() {
        if (instance != null) {
            instance.preset.set(0);
        }
    }

    /** True bila crosshair vanilla harus disembunyikan dan crosshair ini yang digambar. */
    public static boolean shouldReplaceVanilla() {
        return instance != null && instance.isEnabled();
    }

    private boolean[][] activeGrid() {
        int index = preset.index();
        if (index <= 0) {
            return CrosshairStore.customGridRef();
        }
        return CrosshairPresets.values()[index - 1].getPattern();
    }

    /** Dipanggil mixin sebagai pengganti crosshair vanilla. */
    public static void renderReplacement(DrawContext context) {
        if (instance == null || !instance.isEnabled()) {
            return;
        }
        try {
            instance.draw(context);
        } catch (Throwable t) {
            instance.markCrashed(t);
        }
    }

    private void draw(DrawContext context) {
        boolean[][] grid = activeGrid();
        int alpha = (int) Math.round(Math.max(0.0, Math.min(1.0, opacity.get())) * 255.0);
        int argb = (alpha << 24) | (color.argb() & 0x00FFFFFF);
        float px = scale.get().floatValue();
        float total = CrosshairStore.GRID * px;
        float ox = context.getScaledWindowWidth() / 2f - total / 2f;
        float oy = context.getScaledWindowHeight() / 2f - total / 2f;
        for (int x = 0; x < CrosshairStore.GRID; x++) {
            for (int y = 0; y < CrosshairStore.GRID; y++) {
                if (grid[x][y]) {
                    int x1 = (int) (ox + x * px);
                    int y1 = (int) (oy + y * px);
                    int x2 = Math.max(x1 + 1, (int) (ox + (x + 1) * px));
                    int y2 = Math.max(y1 + 1, (int) (oy + (y + 1) * px));
                    context.fill(x1, y1, x2, y2, argb);
                }
            }
        }
    }
}

package com.xoldium.xoldiummod.client.module.tweaks;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;

/**
 * Tweaks - kumpulan penyesuaian PvP, port dari mod "PvP Tweaks" (1.7.7 untuk
 * 1.21.11) yang dikirim pemakai. Dibagi menjadi tiga modul tampilan terpisah
 * supaya tiap kartu punya setting sendiri (Shield Tweak, Fire Overlay, Custom
 * Size) plus satu kartu "Vision Tweaks" (Pumpkin Blur). Semua nilai default
 * identik dengan mod referensi (mis. skala pedang 70%, shield 70%, offset
 * shield -0.55/-0.01/0.10, skala api layar 20%).
 *
 * <p>Hook mixin ada di {@code mixin.tweaks.*} - semuanya {@code require = 0}.
 */
public final class TweaksModule {

    private TweaksModule() {
    }

    // ------------------------------------------------------------------
    // Shield Tweak
    // ------------------------------------------------------------------
    public static final class ShieldTweak extends Module {
        private static ShieldTweak instance;
        private final DoubleSetting offX = addSetting(new DoubleSetting("offset_x", "setting.xoldiummod.tweak.shield.offset_x", -55, -200, 200, 1));
        private final DoubleSetting offY = addSetting(new DoubleSetting("offset_y", "setting.xoldiummod.tweak.shield.offset_y", -1, -200, 200, 1));
        private final DoubleSetting offZ = addSetting(new DoubleSetting("offset_z", "setting.xoldiummod.tweak.shield.offset_z", 10, -200, 200, 1));
        private final DoubleSetting rotX = addSetting(new DoubleSetting("rot_x", "setting.xoldiummod.tweak.shield.rot_x", 0, -180, 180, 1));
        private final DoubleSetting rotY = addSetting(new DoubleSetting("rot_y", "setting.xoldiummod.tweak.shield.rot_y", 0, -180, 180, 1));
        private final DoubleSetting rotZ = addSetting(new DoubleSetting("rot_z", "setting.xoldiummod.tweak.shield.rot_z", 0, -180, 180, 1));

        public ShieldTweak() {
            super("shield_tweak", "module.xoldiummod.shield_tweak", ModuleCategory.VISUAL, false);
            instance = this;
        }

        public static boolean active() {
            return instance != null && instance.isEnabled();
        }

        /** [offsetX, offsetY, offsetZ] dalam blok (nilai setting / 100). */
        public static float[] offset() {
            return new float[]{instance.offX.get().floatValue() / 100f, instance.offY.get().floatValue() / 100f,
                    instance.offZ.get().floatValue() / 100f};
        }

        /** [rotX, rotY, rotZ] dalam derajat. */
        public static float[] rotation() {
            return new float[]{instance.rotX.get().floatValue(), instance.rotY.get().floatValue(),
                    instance.rotZ.get().floatValue()};
        }
    }

    // ------------------------------------------------------------------
    // Fire Overlay
    // ------------------------------------------------------------------
    public static final class FireOverlay extends Module {
        private static FireOverlay instance;
        private final DoubleSetting overlayScale = addSetting(new DoubleSetting("overlay_scale", "setting.xoldiummod.tweak.fire.overlay_scale", 20, 0, 100, 5));
        private final DoubleSetting entityScale = addSetting(new DoubleSetting("entity_scale", "setting.xoldiummod.tweak.fire.entity_scale", 100, 0, 100, 5));
        private final BooleanSetting hideOverlay = addSetting(new BooleanSetting("hide_overlay", "setting.xoldiummod.tweak.fire.hide_overlay", false));

        public FireOverlay() {
            super("fire_overlay", "module.xoldiummod.fire_overlay", ModuleCategory.VISUAL, false);
            instance = this;
        }

        public static boolean active() {
            return instance != null && instance.isEnabled();
        }

        /** Skala api di layar (0 = sembunyi). */
        public static float overlayScale() {
            return instance.hideOverlay.get() ? 0f : instance.overlayScale.get().floatValue() / 100f;
        }

        /** Skala api pada entitas yang terbakar (0 = sembunyi). */
        public static float entityScale() {
            return instance.entityScale.get().floatValue() / 100f;
        }
    }

    // ------------------------------------------------------------------
    // Particle Tweaks (port ParticleManagerMixin PvP Tweaks: ledakan, crystal, totem, partikel hit)
    // ------------------------------------------------------------------
    public static final class ParticleTweaks extends Module {
        private static ParticleTweaks instance;
        private final DoubleSetting explosion = addSetting(new DoubleSetting("explosion", "setting.xoldiummod.tweak.particles.explosion", 100, 0, 100, 5));
        private final DoubleSetting crystal = addSetting(new DoubleSetting("crystal", "setting.xoldiummod.tweak.particles.crystal", 100, 0, 100, 5));
        private final DoubleSetting totem = addSetting(new DoubleSetting("totem", "setting.xoldiummod.tweak.particles.totem", 100, 0, 100, 5));
        private final BooleanSetting hit = addSetting(new BooleanSetting("hit_particles", "setting.xoldiummod.tweak.particles.hit", true));

        public ParticleTweaks() {
            super("particle_tweaks", "module.xoldiummod.particle_tweaks", ModuleCategory.VISUAL, false);
            instance = this;
        }

        public static boolean active() {
            return instance != null && instance.isEnabled();
        }

        public static float explosionRatio() {
            return instance.explosion.get().floatValue() / 100f;
        }

        public static float crystalRatio() {
            return instance.crystal.get().floatValue() / 100f;
        }

        public static float totemRatio() {
            return instance.totem.get().floatValue() / 100f;
        }

        public static boolean showHit() {
            return instance.hit.get();
        }
    }

    // ------------------------------------------------------------------
    // Custom Size (ukuran item di tangan, per jenis item)
    // ------------------------------------------------------------------
    public static final class CustomSize extends Module {
        private static CustomSize instance;
        private final DoubleSetting sword = addSetting(new DoubleSetting("sword", "setting.xoldiummod.tweak.size.sword", 70, 10, 200, 5));
        private final DoubleSetting axe = addSetting(new DoubleSetting("axe", "setting.xoldiummod.tweak.size.axe", 100, 10, 200, 5));
        private final DoubleSetting shield = addSetting(new DoubleSetting("shield", "setting.xoldiummod.tweak.size.shield", 70, 10, 200, 5));
        private final DoubleSetting totem = addSetting(new DoubleSetting("totem", "setting.xoldiummod.tweak.size.totem", 100, 10, 200, 5));
        private final DoubleSetting gapple = addSetting(new DoubleSetting("golden_apple", "setting.xoldiummod.tweak.size.golden_apple", 100, 10, 200, 5));
        private final DoubleSetting bow = addSetting(new DoubleSetting("bow", "setting.xoldiummod.tweak.size.bow", 100, 10, 200, 5));
        private final DoubleSetting crossbow = addSetting(new DoubleSetting("crossbow", "setting.xoldiummod.tweak.size.crossbow", 100, 10, 200, 5));
        private final DoubleSetting trident = addSetting(new DoubleSetting("trident", "setting.xoldiummod.tweak.size.trident", 100, 10, 200, 5));
        private final DoubleSetting mace = addSetting(new DoubleSetting("mace", "setting.xoldiummod.tweak.size.mace", 100, 10, 200, 5));
        private final DoubleSetting armor = addSetting(new DoubleSetting("armor", "setting.xoldiummod.tweak.size.armor", 100, 10, 200, 5));
        private final DoubleSetting other = addSetting(new DoubleSetting("other", "setting.xoldiummod.tweak.size.other", 100, 10, 200, 5));

        public CustomSize() {
            super("custom_size", "module.xoldiummod.custom_size", ModuleCategory.VISUAL, false);
            instance = this;
        }

        public static boolean active() {
            return instance != null && instance.isEnabled();
        }

        /** Skala item di tangan (1.0 = normal). Logika pengelompokan item sama dengan PvpTweaksConfig#getItemScale. */
        public static float scaleFor(ItemStack stack) {
            CustomSize s = instance;
            if (stack == null || stack.isEmpty()) {
                return s.other.get().floatValue() / 100f;
            }
            Item item = stack.getItem();
            String path = Registries.ITEM.getId(item).getPath();
            if (path.endsWith("_sword")) return s.sword.get().floatValue() / 100f;
            if (path.endsWith("_axe")) return s.axe.get().floatValue() / 100f;
            if (item == Items.SHIELD) return s.shield.get().floatValue() / 100f;
            if (item == Items.TOTEM_OF_UNDYING) return s.totem.get().floatValue() / 100f;
            if (item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE) return s.gapple.get().floatValue() / 100f;
            if (item == Items.BOW) return s.bow.get().floatValue() / 100f;
            if (item == Items.CROSSBOW) return s.crossbow.get().floatValue() / 100f;
            if (item == Items.TRIDENT) return s.trident.get().floatValue() / 100f;
            if (item == Items.MACE) return s.mace.get().floatValue() / 100f;
            if (path.endsWith("_helmet") || path.endsWith("_chestplate") || path.endsWith("_leggings")
                    || path.endsWith("_boots") || item == Items.ELYTRA) {
                return s.armor.get().floatValue() / 100f;
            }
            return s.other.get().floatValue() / 100f;
        }
    }

    // ------------------------------------------------------------------
    // Vision Tweaks
    // ------------------------------------------------------------------
    public static final class VisionTweaks extends Module {
        private static VisionTweaks instance;
        private final BooleanSetting noPumpkinBlur = addSetting(new BooleanSetting("no_pumpkin_blur", "setting.xoldiummod.tweak.vision.no_pumpkin_blur", true));

        public VisionTweaks() {
            super("vision_tweaks", "module.xoldiummod.vision_tweaks", ModuleCategory.VISUAL, false);
            instance = this;
        }

        public static boolean hidePumpkinBlur() {
            return instance != null && instance.isEnabled() && instance.noPumpkinBlur.get();
        }
    }
}

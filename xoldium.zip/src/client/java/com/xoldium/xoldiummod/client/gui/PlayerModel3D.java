package com.xoldium.xoldiummod.client.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

import java.util.Arrays;

/**
 * Model pemain 3D berputar yang dibuat dari tekstur skin akun, untuk home
 * screen (meniru panel skin Aurora Client).
 *
 * <p>Dirender TANPA entitas/dunia (di home screen tidak ada {@code ClientWorld}
 * sehingga {@code InventoryScreen.drawEntity} tidak bisa dipakai): tiap bagian
 * tubuh (kepala, badan, lengan, kaki + lapisan luar/overlay) adalah balok yang
 * diputar pada sumbu Y dengan proyeksi ortografis. Karena rotasi hanya pada
 * sumbu Y, setiap sisi tegak tetap berupa persegi panjang di layar, jadi cukup
 * digambar dengan {@code DrawContext#drawTexturedQuad} (API yang sama dengan
 * yang sudah dipakai {@link IconRenderer}) memakai potongan UV skin 64x64 asli.
 * Hasilnya: model menghadap kursor dan bisa terlihat dari samping/belakang.
 */
public final class PlayerModel3D {

    private static final Identifier FALLBACK = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
    private static final float TEX = 64f;

    private PlayerModel3D() {
    }

    // bagian: {xMin, yMin, w, h, d, u0, v0}  (satuan = piksel skin, titik asal = tengah badan, y ke bawah)
    private static float[][] parts(boolean slim) {
        int aw = slim ? 3 : 4;
        return new float[][]{
                // dasar lalu overlay untuk tiap bagian
                {-4, 0, 8, 8, 8, 0, 0},        // 0 kepala
                {-4, 8, 8, 12, 4, 16, 16},     // 1 badan
                {-4 - aw, 8, aw, 12, 4, 40, 16}, // 2 lengan kanan (sisi kiri layar)
                {4, 8, aw, 12, 4, 32, 48},     // 3 lengan kiri
                {-4, 20, 4, 12, 4, 0, 16},     // 4 kaki kanan
                {0, 20, 4, 12, 4, 16, 48},     // 5 kaki kiri
        };
    }

    private static final float[][] OVERLAY_UV = {
            {32, 0}, {16, 32}, {40, 32}, {48, 48}, {0, 32}, {0, 48}
    };

    /**
     * Tekstur skin dari objek SkinTextures. Dicari berdasarkan URUTAN komponen record (komponen
     * pertama = aset tekstur badan, yang komponen Identifier terakhirnya adalah path tekstur) -
     * BUKAN nama method, karena di game asli nama itu adalah nama intermediary.
     */
    public static Identifier textureOf(Object skin) {
        if (skin == null || !skin.getClass().isRecord()) {
            return FALLBACK;
        }
        try {
            Object body = com.xoldium.xoldiummod.client.util.RecordUtil.get(skin, 0);
            if (body instanceof Identifier id) {
                return id;
            }
            if (body != null && body.getClass().isRecord()) {
                int n = body.getClass().getRecordComponents().length;
                if (com.xoldium.xoldiummod.client.util.RecordUtil.get(body, n - 1) instanceof Identifier id) {
                    return id;
                }
            }
        } catch (Throwable ignored) {
            // jatuh ke Steve
        }
        return FALLBACK;
    }

    /**
     * Model slim = komponen bertipe enum 2 nilai (SLIM, WIDE). Dulu dianggap slim bila ordinal == 1, padahal di
     * Minecraft SLIM adalah konstanta PERTAMA (ordinal 0) - akibatnya skin slim (Alex) digambar sebagai wide dan
     * muncul garis hitam di lengan. Sekarang dicek lewat nama konstanta; ordinal hanya cadangan.
     */
    public static boolean isSlim(Object skin) {
        if (skin == null || !skin.getClass().isRecord()) {
            return false;
        }
        try {
            java.lang.reflect.RecordComponent[] comps = skin.getClass().getRecordComponents();
            for (int i = 0; i < comps.length; i++) {
                Class<?> t = comps[i].getType();
                if (t.isEnum() && t.getEnumConstants().length == 2) {
                    Object v = com.xoldium.xoldiummod.client.util.RecordUtil.get(skin, i);
                    if (v instanceof Enum<?> e) {
                        String n = e.name();
                        if (n.equalsIgnoreCase("SLIM")) {
                            return true;
                        }
                        if (n.equalsIgnoreCase("WIDE") || n.equalsIgnoreCase("DEFAULT")) {
                            return false;
                        }
                        return e.ordinal() == 0;
                    }
                    return false;
                }
            }
        } catch (Throwable ignored) {
            // anggap wide
        }
        return false;
    }

    /**
     * Deteksi lengan slim dari piksel skin 64x64 (ARGB): kolom ke-4 lengan (kanan x=47,y=20..31 dan kiri
     * x=39,y=52..63) transparan penuh pada skin slim. Dipakai sebagai penentu utama; {@code fallback} dipakai
     * hanya bila piksel tidak tersedia.
     */
    public static boolean detectSlim(int[] px, boolean fallback) {
        if (px == null || px.length < 64 * 64) {
            return fallback;
        }
        for (int y = 20; y < 32; y++) {
            if (((px[y * 64 + 47] >>> 24) & 255) > 0) {
                return false;
            }
        }
        for (int y = 52; y < 64; y++) {
            if (((px[y * 64 + 39] >>> 24) & 255) > 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Gambar model. (cx, bottomY) = titik tengah-bawah kaki; {@code pixel} = ukuran satu piksel skin dalam
     * piksel layar GUI; {@code angle} = sudut putar Y (radian, 0 = menghadap layar).
     */
    public static void draw(DrawContext context, Object skin, int cx, int bottomY, float pixel, float angle) {
        // Jalur utama: render software ber-z-buffer (+ cosmetic yang sedang dipakai). Renderer lama = cadangan.
        if (PlayerPreview.draw(context, skin,
                com.xoldium.xoldiummod.client.cosmetic.Cosmetics.head(com.xoldium.xoldiummod.client.cosmetic.Cosmetics.myHead()),
                com.xoldium.xoldiummod.client.cosmetic.Cosmetics.back(com.xoldium.xoldiummod.client.cosmetic.Cosmetics.myBack()),
                cx, bottomY, pixel, angle)) {
            return;
        }
        Identifier tex = textureOf(skin);
        boolean slim = isSlim(skin);
        float[][] base = parts(slim);
        float cos = (float) Math.cos(angle);
        float sin = (float) Math.sin(angle);
        float top = bottomY - 32f * pixel;

        // urut dari yang terjauh (z' terkecil) ke terdekat
        Integer[] order = {0, 1, 2, 3, 4, 5};
        final float[] depth = new float[6];
        for (int i = 0; i < 6; i++) {
            float xc = base[i][0] + base[i][2] / 2f;
            depth[i] = -xc * sin;
        }
        Arrays.sort(order, (a, b) -> Float.compare(depth[a], depth[b]));

        for (int idx : order) {
            float[] p = base[idx];
            drawBox(context, tex, cx, top, pixel, cos, sin, p, p[5], p[6], 0f);
            float[] ov = OVERLAY_UV[idx];
            drawBox(context, tex, cx, top, pixel, cos, sin, p, ov[0], ov[1], 0.5f);
        }
    }

    private static void drawBox(DrawContext ctx, Identifier tex, int cx, float top, float pixel,
                                float cos, float sin, float[] p, float u0, float v0, float grow) {
        float w = p[2] + grow * 2, h = p[3] + grow * 2, d = p[4] + grow * 2;
        float xc = p[0] + p[2] / 2f;               // pusat bagian (sebelum rotasi)
        float y1 = top + (p[1] - grow) * pixel;
        float y2 = y1 + h * pixel;
        float hw = w / 2f, hd = d / 2f;
        float uw = p[2], uh = p[3], ud = p[4];     // ukuran UV selalu ukuran asli

        // sisi belakang / depan (hanya satu yang terlihat)
        boolean front = cos > 0f;
        float zf = front ? hd : -hd;
        float xa = (-hw) * cos + zf * sin;
        float xb = (hw) * cos + zf * sin;
        // tengah bagian ikut berputar: x' = xc*cos + ...
        float shift = xc * cos;
        if (front) {
            quad(ctx, tex, cx + (shift + Math.min(xa, xb)) * pixel, y1, cx + (shift + Math.max(xa, xb)) * pixel, y2,
                    (u0 + ud) , v0 + ud, uw, uh);
        } else {
            quad(ctx, tex, cx + (shift + Math.min(xa, xb)) * pixel, y1, cx + (shift + Math.max(xa, xb)) * pixel, y2,
                    (u0 + ud + uw + ud), v0 + ud, uw, uh);
        }
        // sisi samping: sin > 0 -> sisi kanan karakter (x = -hw) terlihat; sin < 0 -> sisi kiri (x = +hw)
        if (Math.abs(sin) > 0.01f) {
            boolean rightSide = sin > 0f;
            float sx = rightSide ? -hw : hw;
            float s1 = sx * cos + (-hd) * sin;
            float s2 = sx * cos + (hd) * sin;
            float uSide = rightSide ? u0 : (u0 + ud + uw);
            quad(ctx, tex, cx + (shift + Math.min(s1, s2)) * pixel, y1, cx + (shift + Math.max(s1, s2)) * pixel, y2,
                    uSide, v0 + ud, ud, uh);
        }
    }

    private static void quad(DrawContext ctx, Identifier tex, float x1, float y1, float x2, float y2,
                             float u, float v, float uw, float vh) {
        int ix1 = Math.round(x1), ix2 = Math.round(x2);
        if (ix2 <= ix1) {
            ix2 = ix1 + 1;
        }
        int iy1 = Math.round(y1), iy2 = Math.round(y2);
        // 1.21.4: drawTexture dengan koordinat piksel u/v + ukuran region pada tekstur skin 64x64
        ctx.drawTexture(RenderLayer::getGuiTextured, tex, ix1, iy1, u, v, ix2 - ix1, Math.max(1, iy2 - iy1),
                Math.round(uw), Math.round(vh), (int) TEX, (int) TEX);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** ServerInfoHudModule - kartu HUD dengan ikon, label, nilai. */
public final class ServerInfoHudModule extends HudModule {

    public ServerInfoHudModule() {
        super("server_info_hud", "module.xoldiummod.server_info_hud", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        net.minecraft.client.network.ServerInfo info = client.getCurrentServerEntry();
        if (info == null) {
            HudRenderUtil.drawCard(context, this, Items.ENDER_EYE, "SERVER", "Singleplayer", -1f);
            return;
        }
        int online = client.getNetworkHandler() != null ? client.getNetworkHandler().getPlayerList().size() : 0;
        String address = info.address == null ? "?" : info.address;
        HudRenderUtil.drawCard(context, this, Items.ENDER_EYE, address.toUpperCase(Locale.ROOT),
                online + " online", -1f);
    }

}

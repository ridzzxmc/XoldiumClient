package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Block Overlay: menggambar ulang outline block yang sedang dibidik dengan
 * warna aksen Xoldium (menggantikan outline hitam vanilla), lewat event
 * resmi Fabric Rendering {@code WorldRenderEvents#BLOCK_OUTLINE} - BUKAN
 * Mixin ke {@code WorldRenderer} internal.
 *
 * <p>Warna outline sekarang bisa diatur lewat gear-icon (setting "Hue",
 * 0-360 derajat) - dikonversi HSV->RGB lewat {@code MathHelper.hsvToRgb}
 * (utilitas vanilla yang sama dipakai warna kulit domba/kembang api,
 * stabil lama), default 197° dicocokkan dengan warna cyan-biru lama
 * ({@code 0.33, 0.78, 0.94}) supaya tidak berubah kalau tidak disentuh.
 *
 * <p>CATATAN VERIFIKASI MAPPING: nama nested type persis
 * ({@code WorldRenderEvents.BlockOutlineContext}) dan method
 * {@code WorldRenderer.drawBox(...)} sudah stabil selama beberapa rilis,
 * tapi tetap verifikasi ulang lewat {@code genSources}/IDE saat pindah ke
 * build Yarn/Fabric API baru.
 */
public final class BlockOverlayModule extends Module {

    private final DoubleSetting hue = addSetting(
            new DoubleSetting("hue", "setting.xoldiummod.block_overlay.hue", 197.0, 0.0, 360.0, 1.0));

    public BlockOverlayModule() {
        super("block_overlay", "module.xoldiummod.block_overlay", ModuleCategory.VISUAL, false);
        WorldRenderEvents.BLOCK_OUTLINE.register(this::onBlockOutline);
    }

    private boolean onBlockOutline(WorldRenderContext context, WorldRenderEvents.BlockOutlineContext blockContext) {
        if (!isEnabled()) {
            return true; // biarkan vanilla menggambar outline normal
        }
        try {
            Vec3d camPos = context.camera().getPos();
            Box box = new Box(blockContext.blockPos())
                    .offset(-camPos.x, -camPos.y, -camPos.z)
                    .expand(0.002);

            int packedRgb = MathHelper.hsvToRgb((float) (hue.get() / 360.0), 0.65f, 0.94f);
            float r = ((packedRgb >> 16) & 0xFF) / 255f;
            float g = ((packedRgb >> 8) & 0xFF) / 255f;
            float b = (packedRgb & 0xFF) / 255f;
            VertexConsumer consumer = context.consumers().getBuffer(RenderLayer.getLines());
            WorldRenderer.drawBox(context.matrixStack(), consumer, box, r, g, b, 1.0f);
        } catch (Throwable t) {
            markCrashed(t);
            return true;
        }
        return false; // sudah digambar sendiri, cegah outline vanilla dobel
    }
}

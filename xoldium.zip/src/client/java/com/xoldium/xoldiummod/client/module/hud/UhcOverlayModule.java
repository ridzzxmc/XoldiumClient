package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ringkasan survival: HP (bar), absorption, lapar, saturation. */
public final class UhcOverlayModule extends HudModule {

    public UhcOverlayModule() {
        super("uhc_overlay", "module.xoldiummod.uhc_overlay", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        float hp = client.player.getHealth();
        float max = Math.max(1f, client.player.getMaxHealth());
        float abs = client.player.getAbsorptionAmount();
        int food = client.player.getHungerManager().getFoodLevel();
        float sat = client.player.getHungerManager().getSaturationLevel();
        List<HudRenderUtil.Card> cards = new ArrayList<>();
        cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.GOLDEN_APPLE), "HEALTH",
                String.format(Locale.ROOT, "%.1f / %.1f", hp, max) + (abs > 0f ? String.format(Locale.ROOT, "  +%.1f", abs) : ""),
                hp / max));
        cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.COOKED_BEEF), "HUNGER  /  SATURATION",
                food + "  /  " + String.format(Locale.ROOT, "%.1f", sat), food / 20f));
        HudRenderUtil.drawCards(context, this, cards);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            List<HudRenderUtil.Card> cards = new ArrayList<>();
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.GOLDEN_APPLE), "HEALTH", "20.0 / 20.0  +4.0", 1f));
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.COOKED_BEEF), "HUNGER  /  SATURATION", "18  /  4.2", 0.9f));
            HudRenderUtil.drawCards(context, this, cards);
            return;
        }
        render(context, tickCounter);
    }
}

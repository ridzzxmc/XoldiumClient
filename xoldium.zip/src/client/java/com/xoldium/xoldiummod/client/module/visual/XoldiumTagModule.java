package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;

/**
 * Xoldium Tag - logo Xoldium di nametag pemain yang juga memakai Xoldium
 * Client (terlihat oleh sesama pengguna Xoldium). Mekanisme deteksi: lihat
 * {@link com.xoldium.xoldiummod.client.social.XoldiumUsers}.
 *
 * <p>Default ON karena fitur ini memang bersifat "branding otomatis" (semua
 * pengguna Xoldium saling terlihat); tetap bisa dimatikan penuh di Mod Menu.
 * Perubahan "Broadcast" berlaku saat masuk server berikutnya (opsi klien
 * dikirim ke server ketika bergabung / saat opsi skin diubah).
 */
public final class XoldiumTagModule extends Module {

    private static volatile XoldiumTagModule instance;

    private final BooleanSetting showLogo = addSetting(
            new BooleanSetting("show_logo", "setting.xoldiummod.xoldium_tag.show_logo", true));
    private final BooleanSetting broadcast = addSetting(
            new BooleanSetting("broadcast", "setting.xoldiummod.xoldium_tag.broadcast", true));

    public XoldiumTagModule() {
        super("xoldium_tag", "module.xoldiummod.xoldium_tag", ModuleCategory.VISUAL, true);
        instance = this;
    }

    public static boolean isActive() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled();
    }

    /** Tampilkan logo di nametag pengguna Xoldium lain. */
    public static boolean showLogo() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.showLogo.get();
    }

    /** Beri tahu pengguna Xoldium lain bahwa kita juga memakai Xoldium (bit penanda di opsi klien). */
    public static boolean shouldBroadcast() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.broadcast.get();
    }
}

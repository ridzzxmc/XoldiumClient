package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;

/**
 * Xoldium Tag (gaya Feather Client) - logo Xoldium di samping nametag
 * pemain yang juga memakai Xoldium Client (terlihat oleh sesama pengguna
 * Xoldium), dan nametag DIRI SENDIRI ikut tampil saat kamera third-person
 * (F5) lengkap dengan logonya. Mekanisme deteksi: lihat
 * {@link com.xoldium.xoldiummod.client.social.XoldiumUsers}.
 *
 * <p>Default ON karena fitur ini memang bersifat "branding otomatis" (semua
 * pengguna Xoldium saling terlihat); tetap bisa dimatikan penuh di Mod Menu.
 * Perubahan "Broadcast" berlaku saat masuk server berikutnya (opsi klien
 * dikirim ke server ketika bergabung / saat opsi skin diubah).
 */
public final class XoldiumTagModule extends Module {

    private static volatile XoldiumTagModule instance;

    private final BooleanSetting showLogo = addSetting(
            new BooleanSetting("show_logo", "setting.xoldiummod.xoldium_tag.show_logo", true));
    private final BooleanSetting showOwn = addSetting(
            new BooleanSetting("show_own", "setting.xoldiummod.xoldium_tag.show_own", true));
    private final BooleanSetting broadcast = addSetting(
            new BooleanSetting("broadcast", "setting.xoldiummod.xoldium_tag.broadcast", true));

    private final BooleanSetting farIcons = addSetting(
            new BooleanSetting("far_icons", "setting.xoldiummod.xoldium_tag.far_icons", true));
    private final com.xoldium.xoldiummod.client.module.setting.DoubleSetting farDistance = addSetting(
            new com.xoldium.xoldiummod.client.module.setting.DoubleSetting("far_distance",
                    "setting.xoldiummod.xoldium_tag.far_distance", 64, 16, 256, 4));

    public XoldiumTagModule() {
        super("xoldium_tag", "module.xoldiummod.xoldium_tag", ModuleCategory.VISUAL, true);
        instance = this;
        com.xoldium.xoldiummod.client.social.XoldiumFarIcons.register();
    }

    /** Gambar ikon overlay untuk pemain Xoldium yang jauh (di luar jarak nametag). */
    public static boolean showFarIcons() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.showLogo.get() && i.farIcons.get();
    }

    /** Jarak minimum (blok) ikon overlay mulai digambar. */
    public static double farDistance() {
        XoldiumTagModule i = instance;
        return i == null ? 64.0 : i.farDistance.get();
    }

    public static boolean isActive() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled();
    }

    /** Tampilkan logo di nametag pengguna Xoldium lain. */
    public static boolean showLogo() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.showLogo.get();
    }

    /** Tampilkan nametag (dengan logo) milik diri sendiri di third-person. */
    public static boolean showOwnTag() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.showOwn.get();
    }

    /** Beri tahu pengguna Xoldium lain bahwa kita juga memakai Xoldium (bit penanda di opsi klien). */
    public static boolean shouldBroadcast() {
        XoldiumTagModule i = instance;
        return i != null && i.isEnabled() && i.broadcast.get();
    }
}

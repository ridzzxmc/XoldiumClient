package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Totem Counter - menghitung berapa kali Totem of Undying "pop" (dipicu),
 * dikonsep dari source code "Totem Counter" yang dikirim pemakai - lihat
 * {@code mixin.entity.TotemPopMixin} untuk catatan kenapa hook-nya
 * disederhanakan (mapping mod referensi tidak cocok dengan proyek ini).
 *
 * <p>Menghitung untuk SEMUA pemain yang terlihat (map {@link #pops} per
 * UUID, sama seperti mod referensi), tapi HUD ini sendiri hanya
 * menampilkan hitungan milik pemain lokal - lebih konsisten dengan gaya
 * modul HUD lain di Xoldium (satu baris info ringkas, lihat
 * {@link HudRenderUtil}) dibanding menambahkannya ke tab-list/nametag
 * pemain lain seperti mod referensi.
 */
public final class TotemCounterModule extends HudModule {

    private static final Map<UUID, Integer> POPS = new HashMap<>();

    public TotemCounterModule() {
        super("totem_counter", "module.xoldiummod.totem_counter", false, 4f, 240f);
    }

    /** Dipanggil {@code TotemPopMixin} tiap kali sebuah LivingEntity memicu status "pakai totem". */
    public static void onTotemPop(LivingEntity entity) {
        if (entity instanceof PlayerEntity player) {
            POPS.merge(player.getUuid(), 1, Integer::sum);
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        int count = POPS.getOrDefault(client.player.getUuid(), 0);
        HudRenderUtil.drawLine(context, this, "Totem Pops: " + count);
    }
}

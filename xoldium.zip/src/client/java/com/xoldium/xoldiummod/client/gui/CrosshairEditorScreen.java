package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.crosshair.CrosshairPresets;
import com.xoldium.xoldiummod.client.crosshair.CrosshairStore;
import com.xoldium.xoldiummod.client.module.visual.CustomCrosshairModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Editor piksel Custom Crosshair (grid 15x15, klik sel untuk menyala/mati;
 * kotak merah = pusat crosshair). Port ringkas dari CrosshairEditorScreen
 * milik mod referensi UltCustomCrosshair: grid yang sama + pemilih preset
 * (tombol sebelumnya/berikutnya memuat pola preset ke grid untuk diedit lebih
 * lanjut). Warna, skala & opacity diatur dari setting modul Custom Crosshair.
 */
public final class CrosshairEditorScreen extends Screen {

    private final Screen parent;
    private PixelGridWidget grid;
    private int presetIndex = -1;
    private ButtonWidget presetLabel;

    public CrosshairEditorScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.crosshair_editor.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        grid = new PixelGridWidget(cx - 90, cy - 100, CrosshairStore.customGrid());
        this.addDrawableChild(grid);

        int y = cy + 90;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> stepPreset(-1))
                .dimensions(cx - 110, y, 20, 20).build());
        presetLabel = this.addDrawableChild(ButtonWidget.builder(presetText(), b -> { })
                .dimensions(cx - 88, y, 176, 20).build());
        presetLabel.active = false;
        this.addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> stepPreset(1))
                .dimensions(cx + 90, y, 20, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.crosshair_editor.clear"), b -> grid.clearGrid())
                .dimensions(cx - 110, y, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.crosshair_editor.save"), b -> save())
                .dimensions(cx - 35, y, 70, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.cancel"), b -> close())
                .dimensions(cx + 40, y, 70, 20).build());
    }

    private Text presetText() {
        if (presetIndex < 0) {
            return Text.translatable("gui.xoldiummod.crosshair_editor.current");
        }
        return Text.literal(CrosshairPresets.values()[presetIndex].getDisplayName());
    }

    private void stepPreset(int dir) {
        CrosshairPresets[] all = CrosshairPresets.values();
        presetIndex = Math.floorMod(presetIndex + dir, all.length);
        grid.setGrid(all[presetIndex].getPattern());
        presetLabel.setMessage(presetText());
    }

    private void save() {
        CrosshairStore.setCustomGrid(grid.getGrid());
        CustomCrosshairModule.selectCustom();
        close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xC0101010);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("gui.xoldiummod.crosshair_editor.hint"), this.width / 2, 24, 0xFFFFFF55);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // latar digambar manual di render() (hindari blur ganda per frame)
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}

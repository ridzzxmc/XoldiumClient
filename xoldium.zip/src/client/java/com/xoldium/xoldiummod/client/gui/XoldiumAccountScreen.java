package com.xoldium.xoldiummod.client.gui;

import com.mojang.authlib.GameProfile;
import com.xoldium.xoldiummod.client.account.XoldiumAccounts;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import ru.vidtu.ias.account.Account;
import ru.vidtu.ias.account.MicrosoftAccount;
import ru.vidtu.ias.auth.microsoft.fields.DeviceAuth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * XoldiumAccount - ganti akun langsung dari game (backend In-Game Account Switcher).
 *
 * <p>Kiri: nama & skin akun aktif dalam ukuran BESAR. Kanan: daftar akun + tombol Ganti Akun / Tambah Offline /
 * Tambah Microsoft / Hapus. Semua interaksi lewat widget vanilla (tombol transparan) agar tidak bergantung pada
 * signature event input yang berubah antar versi Minecraft.
 */
public final class XoldiumAccountScreen extends XoldiumScreen {

    private static final int ROW_H = 26;

    private final List<ButtonWidget> rowHits = new ArrayList<>();
    private final ButtonWidget switchHit = hitArea(this::doSwitch);
    private final ButtonWidget offlineHit = hitArea(this::beginOffline);
    private final ButtonWidget msHit = hitArea(this::beginMicrosoft);
    private final ButtonWidget deleteHit = hitArea(this::doDelete);
    private final ButtonWidget upHit = hitArea(() -> scroll(-1));
    private final ButtonWidget downHit = hitArea(() -> scroll(1));
    private final ButtonWidget backHit = hitArea(this::close);
    private final ButtonWidget okHit = hitArea(this::confirmOffline);
    private final ButtonWidget cancelHit = hitArea(this::cancelMode);
    private final ButtonWidget openLinkHit = hitArea(this::openLink);
    private final ButtonWidget copyCodeHit = hitArea(this::copyCode);

    private TextFieldWidget nameField;
    private List<Account> accounts = new ArrayList<>();
    private final Map<Account, Object> skins = new HashMap<>();
    private int selected = -1;
    private int scrollTop = 0;
    private int visibleRows = 5;
    private String status = "";
    private int statusColor = 0xFF9A9AA0;
    private boolean busy = false;
    private int mode = 0; // 0 normal, 1 offline, 2 microsoft
    private XoldiumAccounts.MicrosoftFlow flow;

    private int px, py, pw, ph;

    public XoldiumAccountScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.account.title"), parent);
    }

    @Override
    protected void init() {
        accounts = XoldiumAccounts.accounts();
        pw = Math.min(this.width - 16, 520);
        ph = Math.min(this.height - 16, 300);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        visibleRows = Math.max(2, (ph - 100) / ROW_H);
        rowHits.clear();
        for (int i = 0; i < visibleRows; i++) {
            final int slot = i;
            ButtonWidget b = hitArea(() -> select(scrollTop + slot));
            rowHits.add(b);
            this.addDrawableChild(b);
        }
        for (ButtonWidget b : new ButtonWidget[]{switchHit, offlineHit, msHit, deleteHit, upHit, downHit, backHit,
                okHit, cancelHit, openLinkHit, copyCodeHit}) {
            this.addDrawableChild(b);
        }
        nameField = new TextFieldWidget(this.textRenderer, 0, 0, 120, 16, Text.translatable("gui.xoldiummod.account.name"));
        nameField.setMaxLength(16);
        nameField.setVisible(false);
        this.addDrawableChild(nameField);
        layoutHits();
    }

    private int listX() {
        return px + 196;
    }

    private int listW() {
        return pw - 196 - 12;
    }

    private void layoutHits() {
        int lx = listX();
        int ly = py + 36;
        for (int i = 0; i < rowHits.size(); i++) {
            ButtonWidget b = rowHits.get(i);
            boolean on = mode == 0 && scrollTop + i < accounts.size();
            b.visible = on;
            b.active = on;
            place(b, lx, ly + i * ROW_H, listW() - 14, ROW_H - 2);
        }
        int by = py + ph - 34;
        int bw = (listW() - 12) / 4;
        place(switchHit, lx, by, bw, 22);
        place(offlineHit, lx + (bw + 4), by, bw, 22);
        place(msHit, lx + (bw + 4) * 2, by, bw, 22);
        place(deleteHit, lx + (bw + 4) * 3, by, bw, 22);
        place(upHit, lx + listW() - 12, py + 36, 12, 22);
        place(downHit, lx + listW() - 12, py + 36 + visibleRows * ROW_H - 24, 12, 22);
        place(backHit, px + 12, py + ph - 34, 80, 22);
        boolean normal = mode == 0;
        for (ButtonWidget b : new ButtonWidget[]{switchHit, offlineHit, msHit, deleteHit, upHit, downHit}) {
            b.visible = normal;
            b.active = normal;
        }
        int cy = py + 70 + 40;
        place(okHit, lx, cy + 30, 90, 22);
        place(cancelHit, lx + 98, cy + 30, 90, 22);
        okHit.visible = okHit.active = mode == 1;
        cancelHit.visible = cancelHit.active = mode != 0;
        place(openLinkHit, lx, py + 150, 110, 22);
        place(copyCodeHit, lx + 118, py + 150, 110, 22);
        openLinkHit.visible = openLinkHit.active = mode == 2;
        copyCodeHit.visible = copyCodeHit.active = mode == 2;
        if (nameField != null) {
            nameField.setX(lx);
            nameField.setY(cy);
            nameField.setWidth(188);
            nameField.setVisible(mode == 1);
            nameField.active = mode == 1;
        }
    }

    private void scroll(int dir) {
        int max = Math.max(0, accounts.size() - visibleRows);
        scrollTop = Math.max(0, Math.min(max, scrollTop + dir));
        layoutHits();
    }

    private void select(int index) {
        if (index >= 0 && index < accounts.size()) {
            selected = index;
        }
    }

    private void say(String text, boolean error) {
        status = text;
        statusColor = error ? 0xFFFF6B6B : 0xFFB8B8C0;
    }

    private void doSwitch() {
        if (busy) {
            return;
        }
        if (selected < 0 || selected >= accounts.size()) {
            say("Pilih akun dulu.", true);
            return;
        }
        busy = true;
        say("Memproses...", false);
        XoldiumAccounts.login(accounts.get(selected), new XoldiumAccounts.Result() {
            @Override
            public void stage(String text) {
                say(text, false);
            }

            @Override
            public void done() {
                busy = false;
                say("Akun diganti!", false);
            }

            @Override
            public void failed(String message) {
                busy = false;
                say(message, true);
            }
        });
    }

    private void doDelete() {
        if (busy || selected < 0 || selected >= accounts.size()) {
            return;
        }
        XoldiumAccounts.remove(accounts.get(selected));
        accounts = XoldiumAccounts.accounts();
        selected = -1;
        scroll(0);
        say("Akun dihapus dari daftar.", false);
    }

    private void beginOffline() {
        mode = 1;
        nameField.setText("");
        layoutHits();
        this.setFocused(nameField);
        say("Masukkan nama (3-16 huruf/angka/_).", false);
    }

    private void confirmOffline() {
        String name = nameField.getText().trim();
        if (!XoldiumAccounts.validName(name)) {
            say("Nama tidak valid (3-16 huruf/angka/_).", true);
            return;
        }
        if (!XoldiumAccounts.addOffline(name)) {
            say("Akun itu sudah ada.", true);
            return;
        }
        accounts = XoldiumAccounts.accounts();
        selected = accounts.size() - 1;
        mode = 0;
        scroll(accounts.size());
        say("Akun offline ditambahkan.", false);
    }

    private void beginMicrosoft() {
        if (busy) {
            return;
        }
        mode = 2;
        flow = XoldiumAccounts.startMicrosoft();
        layoutHits();
        say("Menyiapkan login Microsoft...", false);
    }

    private void cancelMode() {
        if (flow != null) {
            flow.cancel();
            flow = null;
        }
        mode = 0;
        layoutHits();
        say("", false);
    }

    private void openLink() {
        DeviceAuth d = flow != null ? flow.device() : null;
        if (d == null) {
            return;
        }
        try {
            net.minecraft.util.Util.getOperatingSystem().open(d.uri());
        } catch (Throwable t) {
            copyCode();
            say("Tidak bisa membuka browser. Buka " + d.uri() + " manual (kode disalin).", true);
        }
    }

    private void copyCode() {
        DeviceAuth d = flow != null ? flow.device() : null;
        if (d != null && this.client != null) {
            this.client.keyboard.setClipboard(d.user());
            say("Kode disalin.", false);
        }
    }

    @Override
    protected void onClosing() {
        if (flow != null) {
            flow.cancel();
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);
        float a = screenAlpha();
        int dy = slideOffset(14);

        if (mode == 2 && flow != null) {
            MicrosoftAccount done = flow.takeResult();
            if (done != null) {
                XoldiumAccounts.add(done);
                accounts = XoldiumAccounts.accounts();
                selected = accounts.size() - 1;
                mode = 0;
                flow = null;
                layoutHits();
                say("Akun Microsoft ditambahkan: " + done.name(), false);
            } else if (flow.error() != null) {
                say(flow.error(), true);
                flow = null;
                mode = 0;
                layoutHits();
            }
        }

        ScreenChrome.roundedFill(context, px, py + dy, px + pw, py + ph + dy, Anim.withAlpha(ScreenChrome.panelBg(), a));
        ScreenChrome.roundedBorder(context, px, py + dy, px + pw, py + ph + dy, Anim.withAlpha(ScreenChrome.PANEL_BORDER, a));
        drawText(context, Text.translatable("gui.xoldiummod.account.title").getString(), px + 14, py + 12 + dy, 0xFFFFFFFF, a, true);

        // ---- kiri: akun aktif BESAR ----
        int cx1 = px + 12, cx2 = px + 184;
        int cy1 = py + 32 + dy, cy2 = py + ph - 42 + dy;
        ScreenChrome.roundedFill(context, cx1, cy1, cx2, cy2, Anim.withAlpha(ScreenChrome.cardBg(), a));
        ScreenChrome.roundedBorder(context, cx1, cy1, cx2, cy2, Anim.withAlpha(ScreenChrome.CARD_BORDER, a));
        String name = AccountBadge.username();
        int nameW = this.textRenderer.getWidth(name) + 26;
        int nx = (cx1 + cx2) / 2 - nameW / 2;
        ScreenChrome.roundedFill(context, nx, cy1 + 8, nx + nameW, cy1 + 26, Anim.withAlpha(0xCC101012, a));
        AccountBadge.drawHead(context, nx + 3, cy1 + 10, 14);
        drawText(context, name, nx + 22, cy1 + 13, 0xFFFFFFFF, a, true);
        float pixel = Math.max(2f, (cy2 - cy1 - 52) / 32f);
        float angle = (float) Math.sin(Anim.nowMs() / 1400.0) * 0.35f;
        PlayerModel3D.draw(context, AccountBadge.skinObject(), (cx1 + cx2) / 2, Math.round(cy2 - 10 + dy * 0f), pixel, angle);

        // ---- kanan ----
        int lx = listX();
        if (mode == 0) {
            drawText(context, Text.translatable("gui.xoldiummod.account.list").getString(), lx, py + 24 + dy, 0xFF9A9AA0, a, false);
            for (int i = 0; i < visibleRows; i++) {
                int idx = scrollTop + i;
                if (idx >= accounts.size()) {
                    break;
                }
                Account acc = accounts.get(idx);
                int ry = py + 36 + i * ROW_H + dy;
                boolean sel = idx == selected;
                boolean active = acc.name().equalsIgnoreCase(name);
                ScreenChrome.roundedFill(context, lx, ry, lx + listW() - 14, ry + ROW_H - 2,
                        Anim.withAlpha(sel ? 0xFF3A3A44 : ScreenChrome.cardBg(), a));
                ScreenChrome.roundedBorder(context, lx, ry, lx + listW() - 14, ry + ROW_H - 2,
                        Anim.withAlpha(sel ? 0xAAFFFFFF : ScreenChrome.CARD_BORDER, a));
                Object skin = skins.computeIfAbsent(acc, k -> AccountBadge.skinOf(new GameProfile(k.uuid(), k.name())));
                if (skin == null) {
                    skins.remove(acc);
                } else {
                    AccountBadge.drawHeadOf(context, skin, lx + 4, ry + 4, 16);
                }
                drawText(context, acc.name(), lx + 26, ry + 4, 0xFFFFFFFF, a, true);
                String kind = XoldiumAccounts.isMicrosoft(acc) ? "Microsoft" : "Offline";
                drawText(context, kind + (active ? "  \u2022 aktif" : ""), lx + 26, ry + 14, active ? 0xFF7CFF9B : 0xFF9A9AA0, a, false);
            }
            if (accounts.isEmpty()) {
                drawText(context, Text.translatable("gui.xoldiummod.account.empty").getString(), lx + 4, py + 48 + dy, 0xFF9A9AA0, a, false);
            }
            button(context, switchHit, "gui.xoldiummod.account.switch", a, dy, mouseX, mouseY, true);
            button(context, offlineHit, "gui.xoldiummod.account.add_offline", a, dy, mouseX, mouseY, false);
            button(context, msHit, "gui.xoldiummod.account.add_ms", a, dy, mouseX, mouseY, false);
            button(context, deleteHit, "gui.xoldiummod.account.delete", a, dy, mouseX, mouseY, false);
            drawText(context, "\u25B2", lx + listW() - 10, py + 42 + dy, 0xFF9A9AA0, a, false);
            drawText(context, "\u25BC", lx + listW() - 10, py + 36 + visibleRows * ROW_H - 18 + dy, 0xFF9A9AA0, a, false);
        } else if (mode == 1) {
            drawText(context, Text.translatable("gui.xoldiummod.account.add_offline").getString(), lx, py + 40 + dy, 0xFFFFFFFF, a, true);
            button(context, okHit, "gui.xoldiummod.account.ok", a, dy, mouseX, mouseY, true);
            button(context, cancelHit, "gui.xoldiummod.account.cancel", a, dy, mouseX, mouseY, false);
        } else {
            drawText(context, Text.translatable("gui.xoldiummod.account.add_ms").getString(), lx, py + 40 + dy, 0xFFFFFFFF, a, true);
            DeviceAuth d = flow != null ? flow.device() : null;
            if (d == null) {
                drawText(context, flow != null ? flow.stage() : "...", lx, py + 70 + dy, 0xFFB8B8C0, a, false);
            } else {
                drawText(context, Text.translatable("gui.xoldiummod.account.ms_step").getString(), lx, py + 64 + dy, 0xFF9A9AA0, a, false);
                drawText(context, d.uri().toString(), lx, py + 78 + dy, 0xFF8FC7FF, a, false);
                drawText(context, Text.translatable("gui.xoldiummod.account.ms_code").getString(), lx, py + 100 + dy, 0xFF9A9AA0, a, false);
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(lx, py + 114 + dy);
                context.getMatrices().scale(2f, 2f);
                context.drawText(this.textRenderer, d.user(), 0, 0, Anim.withAlpha(0xFFFFFFFF, a), true);
                context.getMatrices().popMatrix();
                button(context, openLinkHit, "gui.xoldiummod.account.open_link", a, dy, mouseX, mouseY, true);
                button(context, copyCodeHit, "gui.xoldiummod.account.copy_code", a, dy, mouseX, mouseY, false);
            }
            button(context, cancelHit, "gui.xoldiummod.account.cancel", a, dy, mouseX, mouseY, false);
            cancelHit.setY(py + 190);
        }

        button(context, backHit, "gui.xoldiummod.account.back", a, dy, mouseX, mouseY, false);
        if (!status.isEmpty()) {
            drawText(context, status, px + 100, py + ph - 28 + dy, statusColor, a, false);
        }
        super.render(context, mouseX, mouseY, delta);
        endFrame();
    }

    private void drawText(DrawContext ctx, String text, int x, int y, int color, float a, boolean shadow) {
        ctx.drawText(this.textRenderer, text, x, y, Anim.withAlpha(color, a), shadow);
    }

    private void button(DrawContext ctx, ButtonWidget hit, String key, float a, int dy, int mx, int my, boolean primary) {
        if (!hit.visible) {
            return;
        }
        int x = hit.getX(), y = hit.getY() + dy, w = hit.getWidth(), h = hit.getHeight();
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        int bg = primary ? (hover ? 0xFFFFFFFF : 0xFFE6E6E6) : (hover ? ScreenChrome.cardBgHover() : ScreenChrome.cardBg());
        ScreenChrome.roundedFill(ctx, x, y, x + w, y + h, Anim.withAlpha(bg, a));
        ScreenChrome.roundedBorder(ctx, x, y, x + w, y + h, Anim.withAlpha(ScreenChrome.CARD_BORDER, a));
        String label = Text.translatable(key).getString();
        int tw = this.textRenderer.getWidth(label);
        ctx.drawText(this.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2,
                Anim.withAlpha(primary ? 0xFF000000 : 0xFFFFFFFF, a), false);
    }
}

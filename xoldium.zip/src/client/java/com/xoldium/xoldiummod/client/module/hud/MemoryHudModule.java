package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** MemoryHudModule - kartu HUD dengan ikon, label, nilai. */
public final class MemoryHudModule extends HudModule {

    public MemoryHudModule() {
        super("memory_hud", "module.xoldiummod.memory_hud", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L);
        long maxMb = rt.maxMemory() / (1024L * 1024L);
        HudRenderUtil.drawCard(context, this, Items.REDSTONE, "MEMORY", usedMb + " / " + maxMb + " MB",
                maxMb <= 0 ? 0f : usedMb / (float) maxMb);
    }

}

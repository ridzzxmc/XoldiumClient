package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.item.Item;

/** Pop-up singkat nama item saat berganti item di tangan. */
public final class ItemChangeHudModule extends HudModule {

    private static final long DISPLAY_DURATION_MS = 2000;

    private Item lastItem = Items.AIR;
    private String cachedLabel = "";
    private ItemStack cachedStack = ItemStack.EMPTY;
    private long changedAtMs = 0L;

    public ItemChangeHudModule() {
        super("itemupdate", "module.xoldiummod.itemupdate", false, 4f, 4f);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        ItemStack current = client.player.getMainHandStack();
        Item currentItem = current.getItem();
        if (currentItem != lastItem) {
            lastItem = currentItem;
            cachedLabel = current.isEmpty() ? "Empty hand" : current.getName().getString();
            cachedStack = current.copy();
            changedAtMs = System.currentTimeMillis();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        long age = System.currentTimeMillis() - changedAtMs;
        if (cachedLabel.isEmpty() || age > DISPLAY_DURATION_MS) {
            return;
        }
        HudRenderUtil.drawCard(context, this, cachedStack.isEmpty() ? HudRenderUtil.icon(Items.BARRIER) : cachedStack,
                "HELD ITEM", cachedLabel, 1f - age / (float) DISPLAY_DURATION_MS);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawCard(context, this, cachedStack.isEmpty() ? HudRenderUtil.icon(Items.DIAMOND_SWORD) : cachedStack,
                "HELD ITEM", cachedLabel.isEmpty() ? "Item Update" : cachedLabel, 0.6f);
    }
}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;

/**
 * Inventory Scale - skala inventori & container (chest, furnace, crafting, dll) TERPISAH dari GUI Scale game.
 * Port dari mod "Inventory Scale Fix" (dwmirlol; berbasis InventoryScale & NoInventoryAvatar oleh microcontrollers;
 * kode skala aslinya dari DulkirMod-Fabric, MPL-2.0): skala container 0.5x - 8x, skala tooltip item, dan opsi
 * menyembunyikan avatar pemain di layar inventori.
 *
 * <p>Modul ini hanya menyimpan setting & menjawab "skala berapa sekarang". Pemasangan ke game dilakukan mixin
 * {@code InventoryScale*Mixin} (config mixin "safe": bila satu hook gagal terpasang, hanya di-log, game tetap normal).
 * Skala HANYA berlaku saat layar yang terbuka adalah container ({@link HandledScreen}); modul OFF = skala 1.0.
 */
public final class InventoryScaleModule extends Module {

    private static InventoryScaleModule instance;

    /** true selama push matriks skala aktif di {@code Screen#renderWithTooltipAndSubtitles} (agar pop berpasangan). */
    public static boolean renderScaled = false;

    private final DoubleSetting containerScale = addSetting(
            new DoubleSetting("container_scale", "setting.xoldiummod.inventory_scale.container", 1.0, 0.5, 8.0, 0.1));
    private final DoubleSetting tooltipScale = addSetting(
            new DoubleSetting("tooltip_scale", "setting.xoldiummod.inventory_scale.tooltip", 1.0, 0.5, 2.0, 0.1));
    private final BooleanSetting hideAvatar = addSetting(
            new BooleanSetting("hide_avatar", "setting.xoldiummod.inventory_scale.hide_avatar", true));

    public InventoryScaleModule() {
        super("inventory_scale", "module.xoldiummod.inventory_scale", ModuleCategory.VISUAL, false);
        instance = this;
    }

    private static boolean onContainerScreen() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return false;
        }
        Screen screen = client.currentScreen;
        return screen instanceof HandledScreen<?>;
    }

    private static float normalize(double value) {
        float f = (float) value;
        if (!(f > 0.01f) || Float.isNaN(f) || Float.isInfinite(f)) {
            return 1.0f;
        }
        return Math.abs(f - 1.0f) < 0.001f ? 1.0f : f;
    }

    /** Skala container saat ini; 1.0 bila modul OFF atau layar yang terbuka bukan container. */
    public static float containerScale() {
        try {
            if (instance == null || !instance.isEnabled() || !onContainerScreen()) {
                return 1.0f;
            }
            return normalize(instance.containerScale.get());
        } catch (Throwable t) {
            return 1.0f;
        }
    }

    /** Skala tooltip saat ini; 1.0 bila modul OFF atau layar yang terbuka bukan container. */
    public static float tooltipScale() {
        try {
            if (instance == null || !instance.isEnabled() || !onContainerScreen()) {
                return 1.0f;
            }
            return normalize(instance.tooltipScale.get());
        } catch (Throwable t) {
            return 1.0f;
        }
    }

    /** true bila avatar pemain di layar inventori (survival) harus disembunyikan. */
    public static boolean hideAvatar() {
        try {
            if (instance == null || !instance.isEnabled() || !instance.hideAvatar.get()) {
                return false;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            return client != null && client.currentScreen instanceof InventoryScreen;
        } catch (Throwable t) {
            return false;
        }
    }
}

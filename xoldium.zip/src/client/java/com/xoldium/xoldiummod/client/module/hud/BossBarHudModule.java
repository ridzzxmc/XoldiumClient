package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.entity.boss.BossBar;

import java.lang.reflect.Field;
import java.util.Map;

/** Boss bar aktif sebagai kartu (nama + bar persen). Dibaca lewat refleksi berbasis tipe (aman antar versi). */
public final class BossBarHudModule extends HudModule {

    public BossBarHudModule() {
        super("bossbar", "module.xoldiummod.bossbar", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.inGameHud == null) {
            return;
        }
        List<HudRenderUtil.Card> cards = readActiveBossBars(client.inGameHud.getBossBarHud());
        if (cards.isEmpty()) {
            return;
        }
        HudRenderUtil.drawCards(context, this, cards);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        List<HudRenderUtil.Card> cards = new ArrayList<>();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.inGameHud != null) {
            cards = readActiveBossBars(client.inGameHud.getBossBarHud());
        }
        if (cards.isEmpty()) {
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.WITHER_SKELETON_SKULL), "BOSS", "Wither  72%", 0.72f));
        }
        HudRenderUtil.drawCards(context, this, cards);
    }

    private static List<HudRenderUtil.Card> readActiveBossBars(BossBarHud bossBarHud) {
        List<HudRenderUtil.Card> cards = new ArrayList<>();
        try {
            for (Field field : bossBarHud.getClass().getDeclaredFields()) {
                if (!Map.class.isAssignableFrom(field.getType())) {
                    continue;
                }
                field.setAccessible(true);
                Object raw = field.get(bossBarHud);
                if (!(raw instanceof Map<?, ?> map)) {
                    continue;
                }
                for (Object value : map.values()) {
                    if (value instanceof BossBar bar) {
                        int pct = Math.round(bar.getPercent() * 100);
                        cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.WITHER_SKELETON_SKULL), "BOSS",
                                bar.getName().getString() + "  " + pct + "%", bar.getPercent()));
                    }
                }
                break;
            }
        } catch (Throwable ignored) {
            // field internal berubah - tampilkan kosong saja
        }
        return cards;
    }
}

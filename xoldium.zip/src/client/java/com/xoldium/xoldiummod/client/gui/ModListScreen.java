package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mod Menu Xoldium: panel gelap membulat, tab kategori dengan garis bawah
 * yang MELUNCUR, kartu modul dengan hover-fade, toggle yang berganti halus,
 * scroll yang di-ease, dan animasi buka (slide-up + fade) / tutup (fade).
 *
 * <p>Semua area klik adalah {@link ButtonWidget} transparan (lihat
 * {@link XoldiumScreen#hitArea}) - visual digambar manual di {@link #render},
 * jadi tidak ada override input yang bergantung versi Minecraft.
 */
public final class ModListScreen extends XoldiumScreen {

    private static final int PANEL_WIDTH = 460;
    private static final int PANEL_HEIGHT = 320;
    private static final int CARD_WIDTH = 104;
    private static final int CARD_HEIGHT = 66;
    private static final int CARD_GAP = 8;
    private static final int PAD = 10;
    private static final int GRID_TOP_OFFSET = 52;

    private TextFieldWidget searchField;
    private ButtonWidget autoFpsBoostButton;
    private ModuleCategory currentCategory = ModuleCategory.ALL;
    private List<Module> visibleModules = new ArrayList<>();

    private final List<CardView> cards = new ArrayList<>();
    private final List<TabView> tabs = new ArrayList<>();

    private final Anim.Smooth scroll = new Anim.Smooth(0f, 14f);
    private float scrollTarget = 0f;
    private final Anim.Smooth underlineX = new Anim.Smooth(-1f, 16f);
    private final Anim.Smooth underlineW = new Anim.Smooth(0f, 16f);
    private final Map<String, Anim.Smooth> hover = new HashMap<>();
    private final Map<String, Anim.Smooth> gearHover = new HashMap<>();
    private final Map<String, Anim.Smooth> onState = new HashMap<>();

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    public ModListScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.mod_menu.title"), parent);
    }

    @Override
    protected void init() {
        panelW = Math.min(PANEL_WIDTH, this.width - 16);
        panelH = Math.min(PANEL_HEIGHT, this.height - 16);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        int searchWidth = 120;
        searchField = new TextFieldWidget(this.textRenderer, 0, 0, searchWidth, 16,
                Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setPlaceholder(Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setChangedListener(query -> {
            scrollTarget = 0f;
            refreshVisibleModules();
        });
        this.addDrawableChild(searchField);

        autoFpsBoostButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.mod_menu.auto_fps_boost"),
                        button -> ModuleManager.applyAutoFpsBoostPreset())
                .dimensions(0, 0, 90, 16)
                .build();
        autoFpsBoostButton.visible = currentCategory == ModuleCategory.OPTIMIZATION;
        this.addDrawableChild(autoFpsBoostButton);

        tabs.clear();
        for (ModuleCategory category : ModuleCategory.values()) {
            ButtonWidget hit = hitArea(() -> selectCategory(category));
            this.addDrawableChild(hit);
            tabs.add(new TabView(category, hit));
        }

        cards.clear();
        refreshVisibleModules();
    }

    private void selectCategory(ModuleCategory category) {
        if (isClosing()) {
            return;
        }
        currentCategory = category;
        scrollTarget = 0f;
        autoFpsBoostButton.visible = category == ModuleCategory.OPTIMIZATION;
        refreshVisibleModules();
    }

    private void refreshVisibleModules() {
        String query = searchField != null ? searchField.getText() : "";
        visibleModules = ModuleManager.search(currentCategory, query);

        for (CardView old : cards) {
            this.remove(old.card);
            if (old.gear != null) {
                this.remove(old.gear);
            }
        }
        cards.clear();

        for (Module module : visibleModules) {
            ButtonWidget gear = null;
            if (module.hasSettings()) {
                gear = hitArea(() -> {
                    if (!isClosing() && this.client != null) {
                        this.client.setScreen(new ModuleSettingsScreen(this, module));
                    }
                });
                this.addDrawableChild(gear); // ditambahkan lebih dulu = prioritas klik di atas kartu
            }
            ButtonWidget card = hitArea(() -> {
                if (!isClosing()) {
                    module.setEnabled(!module.isToggledOn());
                }
            });
            this.addDrawableChild(card);
            cards.add(new CardView(module, card, gear));
        }
    }

    // ------------------------------------------------------------------
    // Layout (dipanggil tiap frame - posisi widget = posisi gambar)
    // ------------------------------------------------------------------

    private int columns() {
        int available = panelW - PAD * 2;
        return Math.max(1, (available + CARD_GAP) / (CARD_WIDTH + CARD_GAP));
    }

    private int gridTop() {
        return panelY + GRID_TOP_OFFSET;
    }

    private int gridBottom() {
        return panelY + panelH - PAD;
    }

    private float maxScroll() {
        int rows = (visibleModules.size() + columns() - 1) / columns();
        float content = rows * (CARD_HEIGHT + CARD_GAP) - CARD_GAP;
        return Math.max(0f, content - (gridBottom() - gridTop()));
    }

    private void layout(int oy) {
        // baris atas: judul kiri, search + boost kanan
        int right = panelX + panelW - PAD;
        searchField.setX(right - searchField.getWidth());
        searchField.setY(panelY + 8 + oy);
        autoFpsBoostButton.setX(searchField.getX() - 6 - autoFpsBoostButton.getWidth());
        autoFpsBoostButton.setY(panelY + 8 + oy);

        // tab
        int x = panelX + PAD;
        int y = panelY + 28 + oy;
        for (TabView tab : tabs) {
            String label = Text.translatable(tab.category.translationKey()).getString();
            tab.x = x;
            tab.y = y;
            tab.w = this.textRenderer.getWidth(label) + 16;
            tab.h = 16;
            place(tab.hit, tab.x, tab.y, tab.w, tab.h);
            x += tab.w + 2;
        }

        // kartu
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        float scrolled = scroll.update(scrollTarget);
        int cols = columns();
        int gridLeft = panelX + PAD;
        int top = gridTop() + oy;
        int bottom = gridBottom() + oy;
        for (int i = 0; i < cards.size(); i++) {
            CardView view = cards.get(i);
            int col = i % cols;
            int row = i / cols;
            float stagger = 1f - Anim.easeOutCubic(Anim.clamp01((openElapsedMs() - Math.min(i, 12) * 18f) / 240f));
            view.x = gridLeft + col * (CARD_WIDTH + CARD_GAP);
            view.y = Math.round(top + row * (CARD_HEIGHT + CARD_GAP) - scrolled + stagger * 12f);

            int visTop = Math.max(view.y, top);
            int visBottom = Math.min(view.y + CARD_HEIGHT, bottom);
            boolean visible = visBottom - visTop > 2;
            view.card.visible = visible;
            if (view.gear != null) {
                view.gear.visible = visible;
            }
            if (visible) {
                place(view.card, view.x, visTop, CARD_WIDTH, visBottom - visTop);
                if (view.gear != null) {
                    int gy = view.y + CARD_HEIGHT - 17;
                    int gTop = Math.max(gy, top);
                    int gBottom = Math.min(gy + 14, bottom);
                    if (gBottom - gTop > 2) {
                        place(view.gear, view.x + 3, gTop, 14, gBottom - gTop);
                    } else {
                        view.gear.visible = false;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);

        int oy = slideOffset(18);
        layout(oy);
        float alpha = screenAlpha();

        int px1 = panelX;
        int py1 = panelY + oy;
        int px2 = panelX + panelW;
        int py2 = panelY + panelH + oy;

        // panel
        ScreenChrome.roundedFill(context, px1, py1, px2, py2, Anim.withAlpha(ScreenChrome.PANEL_BG, alpha));
        ScreenChrome.roundedBorder(context, px1, py1, px2, py2, Anim.withAlpha(ScreenChrome.PANEL_BORDER, alpha));
        ScreenChrome.verticalGradient(context, px1 + 1, py1 + 1, px2 - 1, py1 + 26,
                Anim.withAlpha(0x22FFFFFF, alpha), Anim.withAlpha(0x00FFFFFF, alpha));

        // judul
        context.drawText(this.textRenderer, XoldiumFonts.bold("XOLDIUM"), px1 + PAD, py1 + 12,
                Anim.withAlpha(0xFFFFFFFF, alpha), false);

        renderTabs(context, mouseX, mouseY, alpha, oy);

        // pemisah
        context.fill(px1 + 8, py1 + 47, px2 - 8, py1 + 48, Anim.withAlpha(0x30FFFFFF, alpha));

        renderGrid(context, mouseX, mouseY, alpha, oy);

        super.render(context, mouseX, mouseY, delta);

        // tirai fade untuk transisi buka/tutup
        float curtain = 1f - alpha;
        if (curtain > 0.01f) {
            context.fill(0, 0, this.width, this.height, Anim.withAlpha(0xFF000000, curtain * 0.55f));
        }
        endFrame();
    }

    private void renderTabs(DrawContext context, int mouseX, int mouseY, float alpha, int oy) {
        TabView selected = null;
        for (TabView tab : tabs) {
            boolean isSel = tab.category == currentCategory;
            boolean hovered = mouseX >= tab.x && mouseX <= tab.x + tab.w && mouseY >= tab.y && mouseY <= tab.y + tab.h;
            float h = tab.hover.update(hovered || isSel ? 1f : 0f);
            if (isSel) {
                selected = tab;
            }
            if (h > 0.01f && !isSel) {
                ScreenChrome.roundedFill(context, tab.x, tab.y, tab.x + tab.w, tab.y + tab.h,
                        Anim.withAlpha(0x22FFFFFF, h * alpha));
            }
            String label = Text.translatable(tab.category.translationKey()).getString();
            int textColor = Anim.lerpColor(ScreenChrome.TEXT_DIM, 0xFFFFFFFF, h);
            context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.medium(label),
                    tab.x + tab.w / 2, tab.y + 4, Anim.withAlpha(textColor, alpha));
        }
        if (selected != null) {
            if (underlineX.get() < 0f) {
                underlineX.snap(selected.x);
                underlineW.snap(selected.w);
            }
            float ux = underlineX.update(selected.x);
            float uw = underlineW.update(selected.w);
            context.fill(Math.round(ux), selected.y + selected.h, Math.round(ux + uw), selected.y + selected.h + 1,
                    Anim.withAlpha(0xFFFFFFFF, alpha));
        }
    }

    private void renderGrid(DrawContext context, int mouseX, int mouseY, float alpha, int oy) {
        int left = panelX + PAD - 1;
        int right = panelX + panelW - PAD + 1;
        int top = gridTop() + oy;
        int bottom = gridBottom() + oy;

        context.enableScissor(left, top, right, bottom);
        for (CardView view : cards) {
            if (view.y + CARD_HEIGHT < top || view.y > bottom) {
                continue;
            }
            renderCard(context, view, mouseX, mouseY, alpha, top, bottom);
        }
        context.disableScissor();

        if (visibleModules.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.translatable("gui.xoldiummod.mod_menu.empty"),
                    (left + right) / 2, top + 24, Anim.withAlpha(ScreenChrome.TEXT_DIM, alpha));
        }

        // scrollbar tipis
        float max = maxScroll();
        if (max > 0f) {
            int trackH = bottom - top;
            int barH = Math.max(14, Math.round(trackH * (trackH / (trackH + max))));
            int barY = top + Math.round((trackH - barH) * (scroll.get() / max));
            context.fill(right, barY, right + 2, barY + barH, Anim.withAlpha(0x66FFFFFF, alpha));
        }
    }

    private void renderCard(DrawContext context, CardView view, int mouseX, int mouseY, float alpha, int top, int bottom) {
        Module module = view.module;
        int x = view.x;
        int y = view.y;
        boolean inViewport = mouseY >= top && mouseY <= bottom;
        boolean hovered = inViewport && mouseX >= x && mouseX <= x + CARD_WIDTH && mouseY >= y && mouseY <= y + CARD_HEIGHT;
        boolean gearHovered = inViewport && module.hasSettings()
                && mouseX >= x + 3 && mouseX <= x + 17 && mouseY >= y + CARD_HEIGHT - 17 && mouseY <= y + CARD_HEIGHT - 3;

        float h = hover.computeIfAbsent(module.id(), k -> new Anim.Smooth(0f, 14f)).update(hovered ? 1f : 0f);
        float on = onState.computeIfAbsent(module.id(), k -> new Anim.Smooth(module.isEnabled() ? 1f : 0f, 12f))
                .update(module.isEnabled() ? 1f : 0f);
        float g = gearHover.computeIfAbsent(module.id(), k -> new Anim.Smooth(0f, 16f)).update(gearHovered ? 1f : 0f);

        int bg = Anim.lerpColor(ScreenChrome.CARD_BG, ScreenChrome.CARD_BG_HOVER, h);
        int border = Anim.lerpColor(ScreenChrome.CARD_BORDER, 0xE0FFFFFF, Math.max(h, on * 0.55f));
        ScreenChrome.roundedFill(context, x, y, x + CARD_WIDTH, y + CARD_HEIGHT, Anim.withAlpha(bg, alpha));
        ScreenChrome.roundedBorder(context, x, y, x + CARD_WIDTH, y + CARD_HEIGHT, Anim.withAlpha(border, alpha));

        // aksen atas saat aktif (memudar masuk/keluar)
        if (on > 0.01f) {
            context.fill(x + 6, y + 1, x + CARD_WIDTH - 6, y + 2, Anim.withAlpha(0xFFFFFFFF, on * alpha));
        }

        // judul
        String title = module.displayName().getString();
        int maxTitleWidth = CARD_WIDTH - 10;
        if (this.textRenderer.getWidth(title) > maxTitleWidth) {
            title = this.textRenderer.trimToWidth(title, maxTitleWidth - this.textRenderer.getWidth("..")) + "..";
        }
        context.drawText(this.textRenderer, XoldiumFonts.medium(title), x + 5, y + 6, Anim.withAlpha(0xFFFFFFFF, alpha), false);
        if (module.isCrashed()) {
            context.drawText(this.textRenderer, Text.translatable("gui.xoldiummod.mod_menu.crashed"),
                    x + 5, y + 16, Anim.withAlpha(0xFFFF6666, alpha), false);
        }

        // ikon (sedikit membesar saat hover)
        int iconSize = 24 + Math.round(4 * h);
        IconRenderer.drawModuleIcon(context, this.textRenderer, module,
                x + CARD_WIDTH / 2, y + CARD_HEIGHT / 2 + 1, iconSize, module.isEnabled());

        // baris bawah: gear kiri + toggle kanan
        int bottomY = y + CARD_HEIGHT - 14;
        if (module.hasSettings()) {
            if (g > 0.01f) {
                ScreenChrome.roundedFill(context, x + 3, y + CARD_HEIGHT - 17, x + 17, y + CARD_HEIGHT - 3,
                        Anim.withAlpha(0x33FFFFFF, g * alpha));
            }
            IconRenderer.drawGearIcon(context, x + 5, bottomY - 1, 10, 0xFFCCCCCC);
        }
        IconRenderer.drawToggleSwitch(context, x + CARD_WIDTH - 26, bottomY, 22, 11, module.id(), module.isToggledOn());
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isClosing()) {
            return true;
        }
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget - (float) (verticalAmount * 34)));
        return true;
    }

    // ------------------------------------------------------------------

    private static final class CardView {
        final Module module;
        final ButtonWidget card;
        final ButtonWidget gear;
        int x;
        int y;

        CardView(Module module, ButtonWidget card, ButtonWidget gear) {
            this.module = module;
            this.card = card;
            this.gear = gear;
        }
    }

    private static final class TabView {
        final ModuleCategory category;
        final ButtonWidget hit;
        final Anim.Smooth hover = new Anim.Smooth(0f, 16f);
        int x;
        int y;
        int w;
        int h;

        TabView(ModuleCategory category, ButtonWidget hit) {
            this.category = category;
            this.hit = hit;
        }
    }
}

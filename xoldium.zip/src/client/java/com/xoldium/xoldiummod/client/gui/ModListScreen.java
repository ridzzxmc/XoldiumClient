package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Layar daftar modul Xoldium ("Mod Menu").
 *
 * <p>REVISI TAMPILAN (permintaan pemakai): panel & kartu modul diperkecil
 * banyak - meniru rasio ukuran pada foto referensi kecil yang dilampirkan
 * (panel ~460x300, kartu ~104x66) - BUKAN lagi memenuhi hampir seluruh
 * layar seperti sebelumnya. Skema warna diganti HITAM-PUTIH murni: seluruh
 * elemen aksen biru ({@code 0xFF55C7F0}) dihapus (garis bawah tab terpilih,
 * badge ikon, toggle switch) - lihat {@link IconRenderer} untuk toggle/ikon,
 * di sini hanya garis bawah tab & border kartu yang disentuh langsung.
 * Ikon kartu sekarang file PNG asli dari paket ikon pemakai (via
 * {@link IconRenderer#drawModuleIcon}), bukan lagi badge inisial huruf.
 *
 * <p>ANIMASI BUKA/TUTUP (permintaan pemakai): dipakai teknik "tirai
 * hitam" (curtain fade) - SELURUH konten layar (panel, kartu, tombol
 * vanilla) digambar & di-hit-test PERSIS seperti biasa tanpa transform
 * apa pun (jadi posisi klik tombol/kartu tidak pernah meleset walau
 * animasi sedang jalan), lalu satu overlay hitam semi-transparan digambar
 * DI ATAS semuanya dengan alpha yang mengecil dari penuh -> 0 saat
 * membuka ({@link #openedAtMs}), atau membesar dari 0 -> penuh saat
 * menutup ({@link #closing}/{@link #closingAtMs}) sebelum layar
 * benar-benar diganti ke {@link #parent}. Ini jauh lebih aman daripada
 * scale/translate transform sungguhan (yang butuh menyamakan ulang
 * seluruh koordinat mouse-hit-test widget vanilla selama animasi).
 */
public final class ModListScreen extends Screen {

    private static final int PANEL_WIDTH = 460;
    private static final int PANEL_HEIGHT = 300;
    private static final int CARD_WIDTH = 104;
    private static final int CARD_HEIGHT = 66;
    private static final int CARD_GAP = 8;
    private static final int MARGIN = 10;
    private static final int PANEL_BG = 0xF0060606;
    private static final int CARD_BG = 0xF0121212;
    private static final int CARD_BG_HOVER = 0xF01D1D1D;
    private static final int CARD_BORDER = 0x28FFFFFF;
    private static final int CARD_BORDER_HOVER = 0xFFFFFFFF;

    /** Durasi animasi buka/tutup Mod Menu (fade "tirai" - lihat javadoc kelas). */
    private static final int OPEN_ANIM_MS = 160;
    private static final int CLOSE_ANIM_MS = 120;

    private final Screen parent;
    private TextFieldWidget searchField;
    private ButtonWidget autoFpsBoostButton;
    private ModuleCategory currentCategory = ModuleCategory.ALL;
    private int scrollOffset = 0;
    private List<Module> visibleModules;

    private int panelX;
    private int panelY;

    private final long openedAtMs = System.currentTimeMillis();
    private boolean closing = false;
    private long closingAtMs = 0L;

    // Bounding box tiap kartu yang sedang dirender frame ini, dipakai untuk hit-test klik.
    private final List<CardBounds> cardBoundsThisFrame = new java.util.ArrayList<>();
    private final List<TabBounds> tabBoundsThisFrame = new java.util.ArrayList<>();

    public ModListScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.mod_menu.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelX = (this.width - PANEL_WIDTH) / 2;
        panelY = (this.height - PANEL_HEIGHT) / 2;

        int searchWidth = 110;
        int searchX = panelX + PANEL_WIDTH - MARGIN - searchWidth;
        int searchY = panelY + 8;
        searchField = new TextFieldWidget(this.textRenderer, searchX, searchY, searchWidth, 16,
                Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setPlaceholder(Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setChangedListener(query -> {
            scrollOffset = 0;
            refreshVisibleModules();
        });
        this.addDrawableChild(searchField);

        int boostWidth = 82;
        autoFpsBoostButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.mod_menu.auto_fps_boost"),
                        button -> ModuleManager.applyAutoFpsBoostPreset())
                .dimensions(searchX - 6 - boostWidth, searchY - 2, boostWidth, 20)
                .build();
        autoFpsBoostButton.visible = currentCategory == ModuleCategory.OPTIMIZATION;
        this.addDrawableChild(autoFpsBoostButton);

        refreshVisibleModules();
    }

    private void refreshVisibleModules() {
        String query = searchField != null ? searchField.getText() : "";
        visibleModules = ModuleManager.search(currentCategory, query);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + PANEL_WIDTH, panelY + PANEL_HEIGHT, PANEL_BG);
        context.drawBorder(panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, 0x40FFFFFF);

        renderTabs(context, mouseX, mouseY);

        int gridTop = panelY + 30;
        context.fill(panelX + 8, gridTop - 6, panelX + PANEL_WIDTH - 8, gridTop - 5, 0x30FFFFFF);

        renderGrid(context, mouseX, mouseY, gridTop);

        super.render(context, mouseX, mouseY, delta);

        renderTransitionCurtain(context);

        if (closing && System.currentTimeMillis() - closingAtMs >= CLOSE_ANIM_MS && this.client != null) {
            this.client.setScreen(parent);
        }
    }

    /** Overlay "tirai" fade hitam untuk animasi buka/tutup - lihat javadoc kelas. */
    private void renderTransitionCurtain(DrawContext context) {
        long now = System.currentTimeMillis();
        float alpha;
        if (closing) {
            float t = Math.min(1f, (now - closingAtMs) / (float) CLOSE_ANIM_MS);
            alpha = t;
        } else {
            float t = Math.min(1f, (now - openedAtMs) / (float) OPEN_ANIM_MS);
            alpha = 1f - t;
        }
        if (alpha > 0.001f) {
            context.fill(0, 0, this.width, this.height, IconRenderer.withAlphaFactor(0xFF000000, alpha));
        }
    }

    private void renderTabs(DrawContext context, int mouseX, int mouseY) {
        tabBoundsThisFrame.clear();
        int x = panelX + 8;
        int y = panelY + 6;
        int height = 16;
        for (ModuleCategory category : ModuleCategory.values()) {
            String label = Text.translatable(category.translationKey()).getString();
            int width = this.textRenderer.getWidth(label) + 12;
            boolean selected = category == currentCategory;
            boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;

            int bg = selected ? 0xFF1E1E1E : (hovered ? 0x501E1E1E : 0x00000000);
            context.fill(x, y, x + width, y + height, bg);
            if (selected) {
                context.fill(x, y + height - 1, x + width, y + height, 0xFFFFFFFF);
            }
            int textColor = selected ? 0xFFFFFFFF : 0xFF999999;
            context.drawCenteredTextWithShadow(this.textRenderer, label, x + width / 2, y + 4, textColor);

            tabBoundsThisFrame.add(new TabBounds(category, x, y, width, height));
            x += width + 3;
        }
    }

    private void renderGrid(DrawContext context, int mouseX, int mouseY, int gridTop) {
        cardBoundsThisFrame.clear();

        int contentLeft = panelX + 8;
        int contentRight = panelX + PANEL_WIDTH - 8;
        int contentBottom = panelY + PANEL_HEIGHT - 8;
        int availableWidth = contentRight - contentLeft;
        int columns = Math.max(1, (availableWidth + CARD_GAP) / (CARD_WIDTH + CARD_GAP));

        context.enableScissor(contentLeft, gridTop, contentRight, contentBottom);

        int col = 0;
        int row = 0;
        for (Module module : visibleModules) {
            int cardX = contentLeft + col * (CARD_WIDTH + CARD_GAP);
            int cardY = gridTop - scrollOffset + row * (CARD_HEIGHT + CARD_GAP);

            if (cardY + CARD_HEIGHT >= gridTop && cardY <= contentBottom) {
                renderCard(context, module, cardX, cardY, mouseX, mouseY);
            }
            cardBoundsThisFrame.add(new CardBounds(module, cardX, cardY));

            col++;
            if (col >= columns) {
                col = 0;
                row++;
            }
        }

        context.disableScissor();

        if (visibleModules.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.translatable("gui.xoldiummod.mod_menu.empty"),
                    (contentLeft + contentRight) / 2, gridTop + 20, 0xFF999999);
        }
    }

    private void renderCard(DrawContext context, Module module, int x, int y, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + CARD_WIDTH && mouseY >= y && mouseY <= y + CARD_HEIGHT;

        context.fill(x, y, x + CARD_WIDTH, y + CARD_HEIGHT, hovered ? CARD_BG_HOVER : CARD_BG);
        int borderColor = hovered ? CARD_BORDER_HOVER : CARD_BORDER;
        context.drawBorder(x, y, CARD_WIDTH, CARD_HEIGHT, borderColor);

        // Judul (dipotong biar tidak tabrakan dengan kartu sebelah pada lebar kecil)
        String title = module.displayName().getString();
        int maxTitleWidth = CARD_WIDTH - 8;
        if (this.textRenderer.getWidth(title) > maxTitleWidth) {
            title = this.textRenderer.trimToWidth(title, maxTitleWidth - this.textRenderer.getWidth("..")) + "..";
        }
        context.drawText(this.textRenderer, title, x + 5, y + 4, 0xFFFFFFFF, false);
        if (module.isCrashed()) {
            context.drawText(this.textRenderer,
                    Text.translatable("gui.xoldiummod.mod_menu.crashed"), x + 5, y + 13, 0xFFFF6666, false);
        }

        // Ikon (PNG asli atau badge fallback) di tengah kartu
        IconRenderer.drawModuleIcon(context, this.textRenderer, module,
                x + CARD_WIDTH / 2, y + CARD_HEIGHT / 2 + 3, 26, module.isEnabled());

        // Baris bawah: gear (kiri) + toggle (kanan)
        int bottomY = y + CARD_HEIGHT - 14;
        if (module.hasSettings()) {
            IconRenderer.drawGearIcon(context, x + 4, bottomY - 1, 10, 0xFFCCCCCC);
        }
        IconRenderer.drawToggleSwitch(context, x + CARD_WIDTH - 26, bottomY, 22, 11, module.id(), module.isToggledOn());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (closing) {
            return true; // abaikan klik selagi animasi tutup jalan, cegah interaksi ganda
        }
        if (button == 0) {
            for (TabBounds tab : tabBoundsThisFrame) {
                if (tab.contains(mouseX, mouseY)) {
                    currentCategory = tab.category();
                    scrollOffset = 0;
                    autoFpsBoostButton.visible = currentCategory == ModuleCategory.OPTIMIZATION;
                    refreshVisibleModules();
                    return true;
                }
            }

            for (CardBounds card : cardBoundsThisFrame) {
                int bottomY = card.y() + CARD_HEIGHT - 14;
                int gearX = card.x() + 4;
                int gearY = bottomY - 1;
                int toggleX = card.x() + CARD_WIDTH - 26;
                int toggleY = bottomY;

                if (card.module().hasSettings() && contains(mouseX, mouseY, gearX, gearY, 10, 10)) {
                    if (this.client != null) {
                        this.client.setScreen(new ModuleSettingsScreen(this, card.module()));
                    }
                    return true;
                }
                if (contains(mouseX, mouseY, toggleX, toggleY, 22, 11)) {
                    card.module().setEnabled(!card.module().isToggledOn());
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (closing) {
            return true;
        }
        scrollOffset = Math.max(0, scrollOffset - (int) (verticalAmount * 18));
        return true;
    }

    /**
     * Memicu animasi fade-tutup alih-alih langsung mengganti layar (lihat
     * {@link #renderTransitionCurtain} - pergantian layar sungguhan
     * ditunda sampai animasi selesai, ditangani di {@link #render}).
     * Dipanggil otomatis oleh {@code Screen} bawaan saat ESC ditekan
     * ({@code shouldCloseOnEsc()} default true), jadi ESC ikut memicu
     * fade yang sama tanpa kode tambahan.
     */
    @Override
    public void close() {
        if (!closing) {
            closing = true;
            closingAtMs = System.currentTimeMillis();
        }
    }

    private static boolean contains(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private record CardBounds(Module module, int x, int y) {
    }

    private record TabBounds(ModuleCategory category, int x, int y, int width, int height) {
        boolean contains(double mx, double my) {
            return mx >= x && mx <= x + width && my >= y && my <= y + height;
        }
    }
}

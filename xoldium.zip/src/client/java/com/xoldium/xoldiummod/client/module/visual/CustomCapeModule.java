package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.ActionSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Custom Cape: pakai gambar cape sendiri (PNG) yang tampil di punggung kamu. Konsepnya mengikuti mod
 * Custom Capes (ep-custom-capes): gambar cape diambil dari folder, dipilih lewat daftar, lalu diterapkan ke
 * tekstur cape pemain. Letakkan PNG format cape Minecraft (64x32 atau kelipatannya, 22x17 juga boleh) di folder
 * {@code <folder game>/xoldium/capes}, lalu pilih "Cape 1..8" (urut abjad) di pengaturan modul. Tombol
 * "Buka folder cape" membuka folder tersebut. Cape kustom hanya terlihat di sisi kamu.
 */
public final class CustomCapeModule extends Module {

    private static final int SLOTS = 8;
    private static final Path DIR = FabricLoader.getInstance().getGameDir().resolve("xoldium").resolve("capes");

    private final ModeSetting slot;
    private List<Path> files = new ArrayList<>();
    private Identifier registered;
    private int appliedSlot = -1;
    private boolean applied = false;
    private int tickCounter = 0;

    public CustomCapeModule() {
        super("custom_cape", "module.xoldiummod.custom_cape", ModuleCategory.VISUAL, false);
        String[] keys = new String[SLOTS + 1];
        keys[0] = "option.xoldiummod.custom_cape.none";
        for (int i = 1; i <= SLOTS; i++) {
            keys[i] = "option.xoldiummod.custom_cape.slot" + i;
        }
        slot = addSetting(new ModeSetting("cape", "setting.xoldiummod.custom_cape.cape", 1, keys));
        addSetting(new ActionSetting("open_folder", "setting.xoldiummod.custom_cape.open_folder", CustomCapeModule::openFolder));
        addSetting(new ActionSetting("reload", "setting.xoldiummod.custom_cape.reload", () -> appliedSlot = -2));
    }

    private static void openFolder() {
        try {
            Files.createDirectories(DIR);
            net.minecraft.util.Util.getOperatingSystem().open(DIR.toFile());
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Folder cape tidak bisa dibuka: {}", DIR, t);
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        appliedSlot = -2;
        if (!enabled) {
            release();
        } else {
            prepareFolder();
        }
    }

    private void prepareFolder() {
        try {
            Files.createDirectories(DIR);
            boolean empty;
            try (Stream<Path> s = Files.list(DIR)) {
                empty = s.noneMatch(p -> p.toString().toLowerCase().endsWith(".png"));
            }
            if (empty) { // contoh awal: cape Xoldium
                try (InputStream in = CustomCapeModule.class.getResourceAsStream("/assets/xoldiummod/textures/cape/xoldium_cape.png")) {
                    if (in != null) {
                        Files.copy(in, DIR.resolve("Xoldium.png"));
                    }
                }
            }
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Folder cape tidak bisa disiapkan.", t);
        }
    }

    @Override
    public void onClientTick() {
        if (++tickCounter % 10 != 0) {
            return;
        }
        int want = slot.get();
        if (want == appliedSlot) {
            return;
        }
        appliedSlot = want;
        apply(want);
    }

    private void apply(int want) {
        release();
        if (want <= 0) {
            return;
        }
        try {
            files = new ArrayList<>();
            if (Files.isDirectory(DIR)) {
                try (Stream<Path> s = Files.list(DIR)) {
                    s.filter(p -> p.toString().toLowerCase().endsWith(".png")).sorted().forEach(files::add);
                }
            }
            if (want > files.size()) {
                return;
            }
            Path file = files.get(want - 1);
            NativeImage img;
            try (InputStream in = Files.newInputStream(file)) {
                img = NativeImage.read(in);
            }
            NativeImage fixed = normalize(img);
            Identifier id = Identifier.of(XoldiumMod.MOD_ID, "custom_cape/c" + System.nanoTime());
            Object tex = makeTexture(fixed, id.toString());
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.getTextureManager().registerTexture(id, (net.minecraft.client.texture.AbstractTexture) tex);
            registered = id;
            XoldiumCapeModule.setOverride(id);
            applied = true;
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Cape kustom gagal dimuat (pakai cape standar).", t);
        }
    }

    /** Pastikan rasio 2:1 (64x32 / kelipatan); format 22x17 diperluas ke 64x32. */
    private static NativeImage normalize(NativeImage src) {
        int w = src.getWidth();
        int h = src.getHeight();
        if (w == 22 && h == 17) {
            NativeImage out = new NativeImage(64, 32, true);
            for (int y = 0; y < 17; y++) {
                for (int x = 0; x < 22; x++) {
                    out.setColorArgb(x, y, src.getColorArgb(x, y));
                }
            }
            src.close();
            return out;
        }
        if (w == h * 2 && w >= 64) {
            return src;
        }
        // rasio lain: tempel ke kanvas 2:1 terkecil yang muat
        int cw = Math.max(64, w);
        int ch = cw / 2;
        while (ch < h) {
            cw *= 2;
            ch = cw / 2;
        }
        NativeImage out = new NativeImage(cw, ch, true);
        for (int y = 0; y < Math.min(h, ch); y++) {
            for (int x = 0; x < Math.min(w, cw); x++) {
                out.setColorArgb(x, y, src.getColorArgb(x, y));
            }
        }
        src.close();
        return out;
    }

    private static Object makeTexture(NativeImage img, String name) throws Throwable {
        Class<?> c = net.minecraft.client.texture.NativeImageBackedTexture.class;
        for (Constructor<?> k : c.getDeclaredConstructors()) {
            Class<?>[] p = k.getParameterTypes();
            if (p.length == 1 && p[0] == NativeImage.class) {
                k.setAccessible(true);
                return k.newInstance(img);
            }
            if (p.length == 2 && p[0] == Supplier.class && p[1] == NativeImage.class) {
                k.setAccessible(true);
                Supplier<String> sup = () -> name;
                return k.newInstance(sup, img);
            }
        }
        throw new IllegalStateException("konstruktor NativeImageBackedTexture tidak dikenali");
    }

    private void release() {
        XoldiumCapeModule.setOverride(null);
        if (registered != null) {
            try {
                MinecraftClient.getInstance().getTextureManager().destroyTexture(registered);
            } catch (Throwable ignored) {
                // abaikan
            }
            registered = null;
        }
        applied = false;
    }
}

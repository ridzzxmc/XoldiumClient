package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.cosmetic.Cosmetics;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * XoldiumCosmetic: skin 3D pemain di tengah, daftar cosmetic kepala (kiri) dan punggung/badan (kanan).
 * Cosmetic yang dipilih langsung tampil di pemain 3D dan dikirim ke pengguna XoldiumClient lain.
 */
public final class XoldiumCosmeticScreen extends XoldiumScreen {

    private static final int CELL = 30;
    private static final int GAP = 4;
    private static final int FRAMES = 12;
    private static final float SPRITE_PX = 3f; // piksel sprite per piksel model

    private final List<ButtonWidget> headHits = new ArrayList<>();
    private final List<ButtonWidget> backHits = new ArrayList<>();
    private final ButtonWidget backHit = hitArea(this::close);
    private final ButtonWidget othersHit = hitArea(() -> Cosmetics.setShowOthers(!Cosmetics.showOthers()));

    private int leftX, rightX, gridTop, headCols, backCols;

    public XoldiumCosmeticScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.cosmetic.title"), parent);
    }

    @Override
    protected void init() {
        headHits.clear();
        backHits.clear();
        headCols = this.width < 330 ? 3 : 4;
        backCols = 2;
        int headW = headCols * (CELL + GAP) - GAP;
        int backW = backCols * (CELL + GAP) - GAP;
        leftX = Math.max(8, this.width / 2 - 70 - headW - 8);
        rightX = Math.min(this.width - 8 - backW, this.width / 2 + 70 + 8);
        gridTop = 46;
        for (int i = 0; i <= Cosmetics.HEAD.size(); i++) {
            final int idx = i;
            ButtonWidget b = hitArea(() -> Cosmetics.select(true, idx));
            headHits.add(b);
            this.addDrawableChild(b);
        }
        for (int i = 0; i <= Cosmetics.BACK.size(); i++) {
            final int idx = i;
            ButtonWidget b = hitArea(() -> Cosmetics.select(false, idx));
            backHits.add(b);
            this.addDrawableChild(b);
        }
        this.addDrawableChild(backHit);
        this.addDrawableChild(othersHit);
        place(backHit, 6, this.height - 26, 56, 20);
        place(othersHit, this.width - 6 - 150, this.height - 26, 150, 20);
        for (int i = 0; i < headHits.size(); i++) {
            place(headHits.get(i), leftX + (i % headCols) * (CELL + GAP), gridTop + (i / headCols) * (CELL + GAP), CELL, CELL);
        }
        for (int i = 0; i < backHits.size(); i++) {
            place(backHits.get(i), rightX + (i % backCols) * (CELL + GAP), gridTop + (i / backCols) * (CELL + GAP), CELL, CELL);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);
        float a = screenAlpha();
        int dy = slideOffset(12);

        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold("XOLDIUM COSMETIC"),
                this.width / 2, 14 + dy, Anim.withAlpha(0xFFFFFFFF, a));
        context.fill(this.width / 2 - 34, 26 + dy, this.width / 2 + 34, 27 + dy, Anim.withAlpha(0x88FFFFFF, a));

        // ---- pemain 3D di tengah ----
        float pixel = Math.max(2f, Math.min(5f, (this.height - 110f) / 32f));
        int cx = this.width / 2;
        int bottom = Math.round(this.height - 44 + dy);
        float angle = (float) ((Anim.nowMs() % 9000L) / 9000.0 * Math.PI * 2.0);
        int frame = Math.floorMod(Math.round(angle / (float) (Math.PI * 2.0 / FRAMES)), FRAMES);
        float neckY = bottom - 32f * pixel + 8f * pixel;
        Cosmetics.Def head = Cosmetics.head(Cosmetics.myHead());
        Cosmetics.Def back = Cosmetics.back(Cosmetics.myBack());
        boolean facingFront = Math.cos(angle) > 0;
        if (back != null && facingFront) {
            sprite(context, back, frame, cx, neckY, pixel, 40f, a);
        }
        PlayerModel3D.draw(context, AccountBadge.skinObject(), cx, bottom, pixel, angle);
        if (back != null && !facingFront) {
            sprite(context, back, frame, cx, neckY, pixel, 40f, a);
        }
        if (head != null) {
            sprite(context, head, frame, cx, neckY, pixel, 100f, a);
        }
        // nama
        String name = AccountBadge.username();
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(name), cx, bottom + 6, Anim.withAlpha(0xFFFFFFFF, a));

        // ---- kolom kiri: kepala ----
        context.drawTextWithShadow(this.textRenderer, Text.translatable("gui.xoldiummod.cosmetic.head"), leftX, gridTop - 12 + dy,
                Anim.withAlpha(0xFF9A9AA0, a));
        for (int i = 0; i < headHits.size(); i++) {
            Cosmetics.Def d = i == 0 ? null : Cosmetics.HEAD.get(i - 1);
            drawCell(context, headHits.get(i), d, Cosmetics.myHead() == i, mouseX, mouseY, a, dy);
        }
        // ---- kolom kanan: punggung/badan ----
        context.drawTextWithShadow(this.textRenderer, Text.translatable("gui.xoldiummod.cosmetic.back"), rightX, gridTop - 12 + dy,
                Anim.withAlpha(0xFF9A9AA0, a));
        for (int i = 0; i < backHits.size(); i++) {
            Cosmetics.Def d = i == 0 ? null : Cosmetics.BACK.get(i - 1);
            drawCell(context, backHits.get(i), d, Cosmetics.myBack() == i, mouseX, mouseY, a, dy);
        }

        // nama cosmetic yang sedang disorot / dipakai
        String hover = hoverName(mouseX, mouseY);
        if (hover != null) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(hover), cx, 32 + dy, Anim.withAlpha(0xFFFFFFFF, a));
        }

        // tombol bawah
        smallButton(context, backHit, Text.translatable("gui.back").getString(), a, dy, mouseX, mouseY);
        String others = Text.translatable("gui.xoldiummod.cosmetic.others").getString() + ": "
                + (Cosmetics.showOthers() ? "ON" : "OFF");
        smallButton(context, othersHit, others, a, dy, mouseX, mouseY);
        super.render(context, mouseX, mouseY, delta);
        endFrame();
    }

    private String hoverName(int mx, int my) {
        for (int i = 0; i < headHits.size(); i++) {
            if (inside(headHits.get(i), mx, my)) {
                return i == 0 ? Text.translatable("gui.xoldiummod.cosmetic.none").getString() : Cosmetics.HEAD.get(i - 1).name;
            }
        }
        for (int i = 0; i < backHits.size(); i++) {
            if (inside(backHits.get(i), mx, my)) {
                return i == 0 ? Text.translatable("gui.xoldiummod.cosmetic.none").getString() : Cosmetics.BACK.get(i - 1).name;
            }
        }
        return null;
    }

    private static boolean inside(ButtonWidget b, int mx, int my) {
        return mx >= b.getX() && mx < b.getX() + b.getWidth() && my >= b.getY() && my < b.getY() + b.getHeight();
    }

    private void sprite(DrawContext ctx, Cosmetics.Def def, int frame, int cx, float neckY, float pixel, float anchorY, float a) {
        float size = 128f * pixel / SPRITE_PX;
        float x = cx - 64f * pixel / SPRITE_PX;
        float y = neckY - anchorY * pixel / SPRITE_PX;
        float u0 = frame / (float) FRAMES;
        float u1 = (frame + 1) / (float) FRAMES;
        ctx.drawTexturedQuad(def.sprite, Math.round(x), Math.round(y), Math.round(x + size), Math.round(y + size), u0, u1, 0f, 1f);
    }

    private void drawCell(DrawContext ctx, ButtonWidget hit, Cosmetics.Def def, boolean equipped, int mx, int my, float a, int dy) {
        int x = hit.getX(), y = hit.getY() + dy;
        boolean hover = inside(hit, mx, my);
        int bg = equipped ? 0xFF3A3A44 : (hover ? ScreenChrome.cardBgHover() : ScreenChrome.cardBg());
        ScreenChrome.roundedFill(ctx, x, y, x + CELL, y + CELL, Anim.withAlpha(bg, a));
        ScreenChrome.roundedBorder(ctx, x, y, x + CELL, y + CELL,
                Anim.withAlpha(equipped ? 0xFFFFFFFF : (hover ? 0x88FFFFFF : ScreenChrome.CARD_BORDER), a));
        if (def == null) {
            String x0 = "\u2715";
            ctx.drawText(this.textRenderer, x0, x + (CELL - this.textRenderer.getWidth(x0)) / 2, y + (CELL - 8) / 2,
                    Anim.withAlpha(0xFF9A9AA0, a), false);
        } else {
            ctx.drawTexturedQuad(def.icon, x + 3, y + 3, x + CELL - 3, y + CELL - 3, 0f, 1f, 0f, 1f);
        }
    }

    private void smallButton(DrawContext ctx, ButtonWidget hit, String label, float a, int dy, int mx, int my) {
        int x = hit.getX(), y = hit.getY() + dy, w = hit.getWidth(), h = hit.getHeight();
        boolean hover = inside(hit, mx, my);
        ScreenChrome.roundedFill(ctx, x, y, x + w, y + h, Anim.withAlpha(hover ? ScreenChrome.cardBgHover() : ScreenChrome.cardBg(), a));
        ScreenChrome.roundedBorder(ctx, x, y, x + w, y + h, Anim.withAlpha(ScreenChrome.CARD_BORDER, a));
        ctx.drawText(this.textRenderer, label, x + (w - this.textRenderer.getWidth(label)) / 2, y + (h - 8) / 2,
                Anim.withAlpha(0xFFFFFFFF, a), false);
    }
}

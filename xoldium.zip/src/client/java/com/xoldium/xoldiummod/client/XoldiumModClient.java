package com.xoldium.xoldiummod.client;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.compat.vulkanmod.XoldiumVulkanModIntegration;
import com.xoldium.xoldiummod.client.core.FrustumContext;
import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumScreenHooks;
import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.client.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Entry point client-only Xoldium Client.
 *
 * <ul>
 *   <li>Mendaftarkan {@link WorldRenderEvents#START} untuk {@link FrustumContext}
 *       (dipakai seluruh mixin culling).</li>
 *   <li>Mendaftarkan keybind pembuka menu Xoldium (default Right Shift, bisa
 *       diubah lewat Controls seperti keybind vanilla lainnya) yang membuka
 *       {@link XoldiumHomeScreen}.</li>
 *   <li>Menginisialisasi {@link ModuleManager} (seluruh modul HUD/
 *       Optimization/Movement/Visual).</li>
 *   <li>Mencoba integrasi opsional ke menu VulkanMod - gagal dengan aman
 *       bila VulkanMod tidak ter-install.</li>
 * </ul>
 *
 * <p>TIDAK ada mixin yang didaftarkan manual di sini (lewat
 * {@code xoldiummod.mixins.json}), dan TIDAK ada pemanggilan API OpenGL/
 * GlStateManager/RenderSystem langsung di seluruh mod ini.
 */
public final class XoldiumModClient implements ClientModInitializer {

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.START.register(FrustumContext::beginFrame);
        WorldRenderEvents.AFTER_SETUP.register(FrustumContext::updateFrustum);
        // Cadangan motion blur: hanya aktif bila mixin GameRenderer#renderWorld tidak ter-apply.
        WorldRenderEvents.END.register(context -> MotionBlurRenderer.applyFallback());
        // Tombol Title Screen / menu Pause lewat Fabric API (tanpa mixin).
        XoldiumScreenHooks.register();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                XoldiumKeyCategory.MAIN
        ));

        ModuleManager.init();
        com.xoldium.xoldiummod.client.cosmetic.CosmeticRenderer.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            com.xoldium.xoldiummod.client.cosmetic.CosmeticSync.tick(client);
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new com.xoldium.xoldiummod.client.gui.XoldiumHubScreen(null));
                }
            }
        });

        // Ingatan pengguna Xoldium (ikon tab/nametag) dibersihkan tiap ganti server.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> XoldiumUsers.clearKnown());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> XoldiumUsers.clearKnown());

        XoldiumVulkanModIntegration.tryRegister();
        XoldiumMod.LOGGER.info("[Xoldium] Modul client (GUI, HUD, culling, optimasi) aktif. Tekan Right Shift untuk membuka menu.");
    }
}

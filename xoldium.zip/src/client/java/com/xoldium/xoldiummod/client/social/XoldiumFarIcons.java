package com.xoldium.xoldiummod.client.social;

import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * Ikon XoldiumClient untuk pemain yang JAUH. Nametag vanilla (dan logo di dalamnya) hanya digambar sampai
 * 64 blok, jadi ikon hilang walau pemainnya masih termuat - padahal di tab ikonnya masih terlihat. Di sini ikon
 * digambar sebagai overlay HUD di atas kepala pemain (proyeksi dunia -> layar) untuk pemain Xoldium yang lebih
 * jauh dari jarak nametag, lengkap dengan nama kecil + jarak.
 *
 * <p>Batas jujur: pemain yang entitasnya sudah tidak dimuat client (di luar jarak tracking server) tidak punya
 * posisi sama sekali, jadi untuk mereka ikon hanya bisa tampil di tab list (status terakhir di-cache per UUID).
 */
public final class XoldiumFarIcons {

    private static boolean registered = false;
    private static int scanCooldown = 0;

    private XoldiumFarIcons() {
    }

    public static void register() {
        if (registered) {
            return;
        }
        registered = true;
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> XoldiumUsers.clearKnown());
        // Scan berkala: isi cache status walau pemain tidak sedang terlihat/di-nametag.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null || !XoldiumTagModule.showLogo() || --scanCooldown > 0) {
                return;
            }
            scanCooldown = 20;
            try {
                for (PlayerEntity p : client.world.getPlayers()) {
                    if (p != client.player) {
                        XoldiumUsers.isXoldiumUser(p);
                    }
                }
            } catch (Throwable ignored) {
                // murni kosmetik
            }
        });
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            try {
                render(context);
            } catch (Throwable ignored) {
                // overlay kosmetik - jangan pernah mengganggu HUD
            }
        });
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || client.options.hudHidden
                || !XoldiumTagModule.showFarIcons()) {
            return;
        }
        Camera camera = client.gameRenderer.getCamera();
        Vec3d cam = camera.getPos();
        double yaw = Math.toRadians(camera.getYaw());
        double pitch = Math.toRadians(camera.getPitch());
        // basis kamera: forward / right / up
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(client.options.getFov().getValue()) / 2.0);
        double aspect = sw / (double) sh;
        double minDist = XoldiumTagModule.farDistance();
        TextRenderer tr = client.textRenderer;
        Text icon = Text.literal(XoldiumUsers.LOGO_GLYPH).setStyle(net.minecraft.text.Style.EMPTY
                .withColor(net.minecraft.text.TextColor.fromRgb(0xFFFFFF)).withFont(XoldiumUsers.ICON_FONT));

        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || p.isInvisible()) {
                continue;
            }
            double dist = Math.sqrt(p.squaredDistanceTo(client.player));
            if (dist < minDist || !XoldiumUsers.isXoldiumUser(p)) {
                continue;
            }
            Vec3d rel = new Vec3d(p.getX(), p.getY() + p.getHeight() + 0.7, p.getZ()).subtract(cam);
            double depth = rel.dotProduct(fwd);
            if (depth < 0.5) {
                continue;
            }
            double ndcX = rel.dotProduct(right) / (depth * tanHalf * aspect);
            double ndcY = rel.dotProduct(up) / (depth * tanHalf);
            if (Math.abs(ndcX) > 1.05 || Math.abs(ndcY) > 1.05) {
                continue;
            }
            int px = (int) Math.round(sw / 2.0 + ndcX * sw / 2.0);
            int py = (int) Math.round(sh / 2.0 - ndcY * sh / 2.0);

            // makin jauh makin kecil (min 0.7x), tetap terbaca
            float scale = (float) Math.max(0.7, Math.min(1.5, 24.0 / Math.max(8.0, dist) + 0.55));
            String label = p.getName().getString() + "  " + Math.round(dist) + "m";
            float labelScale = 0.6f * scale;
            int lw = Math.round(tr.getWidth(label) * labelScale);

            context.getMatrices().pushMatrix();
            context.getMatrices().translate(px, py);
            // pil latar
            int pillW = Math.max(lw + 8, 18);
            int pillH = Math.round(10 * scale + 9 * labelScale + 3);
            context.fill(-pillW / 2, -pillH, pillW / 2, 0, 0x88000000);
            // ikon
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(-tr.getWidth(icon) * scale / 2f, -pillH + 1);
            context.getMatrices().scale(scale, scale);
            context.drawText(tr, icon, 0, 0, 0xFFFFFFFF, true);
            context.getMatrices().popMatrix();
            // nama + jarak
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(-lw / 2f, -pillH + 10 * scale + 1);
            context.getMatrices().scale(labelScale, labelScale);
            context.drawText(tr, label, 0, 0, 0xFFE6E6EA, false);
            context.getMatrices().popMatrix();
            context.getMatrices().popMatrix();
        }
    }
}

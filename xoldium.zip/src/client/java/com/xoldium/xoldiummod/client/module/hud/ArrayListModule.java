package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Comparator;

/** Pemain terdekat (maks 5): nama + jarak, dengan bar kedekatan. */
public final class ArrayListModule extends HudModule {

    private static final int MAX_ENTRIES = 5;
    private static final double RANGE = 64.0;

    public ArrayListModule() {
        super("array_list", "module.xoldiummod.array_list", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        if (world == null || client.player == null) {
            return;
        }
        List<PlayerEntity> others = new ArrayList<>(world.getPlayers());
        others.remove(client.player);
        others.sort(Comparator.comparingDouble(p -> p.squaredDistanceTo(client.player)));
        if (others.isEmpty()) {
            return;
        }
        List<HudRenderUtil.Card> cards = new ArrayList<>();
        int count = Math.min(MAX_ENTRIES, others.size());
        for (int i = 0; i < count; i++) {
            PlayerEntity p = others.get(i);
            double distance = Math.sqrt(p.squaredDistanceTo(client.player));
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.PLAYER_HEAD), "NEARBY  \u2022  " + Math.round(distance) + " m",
                    p.getName().getString(), (float) Math.max(0.0, 1.0 - distance / RANGE)));
        }
        HudRenderUtil.drawCards(context, this, cards);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().world == null) {
            List<HudRenderUtil.Card> cards = new ArrayList<>();
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.PLAYER_HEAD), "NEARBY  \u2022  6 m", "Steve", 0.9f));
            cards.add(new HudRenderUtil.Card(HudRenderUtil.icon(Items.PLAYER_HEAD), "NEARBY  \u2022  21 m", "Alex", 0.67f));
            HudRenderUtil.drawCards(context, this, cards);
            return;
        }
        render(context, tickCounter);
    }
}

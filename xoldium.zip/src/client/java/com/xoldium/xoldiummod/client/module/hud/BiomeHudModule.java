package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** BiomeHudModule - kartu HUD dengan ikon, label, nilai. */
public final class BiomeHudModule extends HudModule {

    public BiomeHudModule() {
        super("biome_hud", "module.xoldiummod.biome_hud", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }
        String name = client.world.getBiome(client.player.getBlockPos()).getKey()
                .map(key -> key.getValue().getPath()).orElse("unknown");
        HudRenderUtil.drawCard(context, this, Items.OAK_SAPLING, "BIOME", pretty(name), -1f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().world == null) {
            HudRenderUtil.drawCard(context, this, Items.OAK_SAPLING, "BIOME", "Plains", -1f);
            return;
        }
        render(context, tickCounter);
    }

    static String pretty(String path) {
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

}

package com.xoldium.xoldiummod.client.module;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.hud.*;
import com.xoldium.xoldiummod.client.module.movement.SprintModule;
import com.xoldium.xoldiummod.client.module.optimization.OptimizationToggleModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.CustomBlockHighlightModule;
import com.xoldium.xoldiummod.client.module.visual.HitRangeModule;
import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import com.xoldium.xoldiummod.client.module.msg.AutoGgModule;
import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import com.xoldium.xoldiummod.client.module.visual.CustomCrosshairModule;
import com.xoldium.xoldiummod.client.module.visual.CustomCrystalModule;
import com.xoldium.xoldiummod.client.module.visual.HitColorModule;
import com.xoldium.xoldiummod.client.module.visual.ItemPhysicModule;
import com.xoldium.xoldiummod.client.module.visual.HitboxesModule;
import com.xoldium.xoldiummod.client.module.visual.InventoryScaleModule;
import com.xoldium.xoldiummod.client.module.visual.ShowMeYourSkinModule;
import com.xoldium.xoldiummod.client.module.visual.XoldiumCapeModule;
import com.xoldium.xoldiummod.client.module.visual.FreeLookModule;
import com.xoldium.xoldiummod.client.module.visual.FullbrightModule;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import com.xoldium.xoldiummod.client.module.visual.NoHurtCamModule;
import com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule;
import com.xoldium.xoldiummod.client.module.visual.TimeChangerModule;
import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.client.ClientTickEvents;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Registry & dispatcher terpusat untuk seluruh {@link Module} Xoldium.
 *
 * <p>Setiap panggilan ke modul individual (tick, render) dibungkus
 * try/catch supaya satu modul yang error tidak pernah men-crash client -
 * lihat {@link Module#markCrashed}. Ini satu-satunya tempat
 * {@code HudRenderCallback} & {@code ClientTickEvents} Xoldium didaftarkan.
 */
public final class ModuleManager {

    private static final Map<String, Module> BY_ID = new LinkedHashMap<>();

    /**
     * Posisi default LAMA (versi sebelumnya). Banyak yang berada di luar layar (y = 400 - 640) dan ikut tersimpan
     * di config, sehingga modul HUD "tidak berfungsi" (sebenarnya tergambar di luar layar). Transform tersimpan
     * yang sama persis dengan default lama dianggap "belum pernah digeser pemakai" -> ditempatkan otomatis.
     */
    private static final Map<String, float[]> LEGACY_DEFAULTS = new java.util.HashMap<>();

    static {
        LEGACY_DEFAULTS.put("memory_hud", new float[]{4f, 102f});
        LEGACY_DEFAULTS.put("pack_display", new float[]{4f, 148f});
        LEGACY_DEFAULTS.put("direction_hud", new float[]{4f, 74f});
        LEGACY_DEFAULTS.put("bow", new float[]{4f, 420f});
        LEGACY_DEFAULTS.put("fps", new float[]{4f, 4f});
        LEGACY_DEFAULTS.put("cps_counter", new float[]{90f, 4f});
        LEGACY_DEFAULTS.put("combo_counter", new float[]{90f, 18f});
        LEGACY_DEFAULTS.put("tps", new float[]{4f, 600f});
        LEGACY_DEFAULTS.put("totem_counter", new float[]{4f, 240f});
        LEGACY_DEFAULTS.put("bossbar", new float[]{4f, 640f});
        LEGACY_DEFAULTS.put("scoreboard", new float[]{4f, 520f});
        LEGACY_DEFAULTS.put("armor_hud", new float[]{4f, 164f});
        LEGACY_DEFAULTS.put("hotbar", new float[]{4f, 460f});
        LEGACY_DEFAULTS.put("saturation_hud", new float[]{4f, 116f});
        LEGACY_DEFAULTS.put("speed", new float[]{4f, 560f});
        LEGACY_DEFAULTS.put("time", new float[]{4f, 580f});
        LEGACY_DEFAULTS.put("itemupdate", new float[]{4f, 480f});
        LEGACY_DEFAULTS.put("server_info_hud", new float[]{4f, 130f});
        LEGACY_DEFAULTS.put("coordinates", new float[]{4f, 32f});
        LEGACY_DEFAULTS.put("actionbar", new float[]{4f, 400f});
        LEGACY_DEFAULTS.put("day_counter", new float[]{4f, 60f});
        LEGACY_DEFAULTS.put("credit_hud", new float[]{4f, -1f});
        LEGACY_DEFAULTS.put("ping_display", new float[]{4f, 18f});
        LEGACY_DEFAULTS.put("clock_hud", new float[]{4f, 46f});
        LEGACY_DEFAULTS.put("array_list", new float[]{4f, 260f});
        LEGACY_DEFAULTS.put("keystrokes", new float[]{4f, 240f});
        LEGACY_DEFAULTS.put("uhc_overlay", new float[]{4f, 620f});
        LEGACY_DEFAULTS.put("player", new float[]{4f, 500f});
        LEGACY_DEFAULTS.put("settings", new float[]{4f, 540f});
        LEGACY_DEFAULTS.put("potion_hud", new float[]{4f, 200f});
        LEGACY_DEFAULTS.put("biome_hud", new float[]{4f, 88f});
    }
    private static final List<Module> ALL = new ArrayList<>();
    private static boolean initialized = false;

    private ModuleManager() {
    }

    /** Dipanggil sekali dari {@code XoldiumModClient#onInitializeClient()}. */
    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;

        registerHudModules();
        registerOptimizationModules();
        registerMovementModules();
        registerVisualModules();
        registerMsgModules();

        loadState();

        HudRenderCallback.EVENT.register(ModuleManager::onHudRender);
        ClientTickEvents.END_CLIENT_TICK.register(client -> onClientTick());

        XoldiumMod.LOGGER.info("[Xoldium] {} modul terdaftar (HUD/Optimization/Movement/Visual/MSG).", ALL.size());
    }

    private static void registerHudModules() {
        register(new CreditHudModule());
        register(new FpsModule());
        register(new PingDisplayModule());
        register(new CpsCounterModule());
        register(new CoordinatesModule());
        register(new ClockHudModule());
        register(new DayCounterModule());
        register(new DirectionHudModule());
        register(new BiomeHudModule());
        register(new ArmorHudModule());
        register(new PotionHudModule());
        register(new SaturationHudModule());
        register(new KeystrokesModule());
        register(new ArrayListModule());
        register(new ComboCounterModule());
        register(new MemoryHudModule());
        register(new ServerInfoHudModule());
        register(new PackDisplayModule());
        register(new ChatTimestampsModule());

        // --- Modul baru (permintaan pemakai - daftar module id lengkap) ---
        register(new ActionBarHudModule());
        register(new BossBarHudModule());
        register(new BowChargeHudModule());
        register(new HotbarInfoModule());
        register(new ItemChangeHudModule());
        register(new PlayerInfoHudModule());
        register(new ScoreboardHudModule());
        register(new SettingsHintHudModule());
        register(new SpeedHudModule());
        register(new TimeHudModule());
        register(new TpsHudModule());
        register(new TotemCounterModule());
        register(new CartCounterModule());
        register(new ReachDisplayModule());
        register(new UhcOverlayModule());
    }

    private static void registerOptimizationModules() {
        XoldiumConfig cfg = XoldiumConfig.get();

        register(new OptimizationToggleModule("opt_master", "module.xoldiummod.opt_master",
                () -> cfg.enabled, v -> cfg.enabled = v, true));
        register(new OptimizationToggleModule("opt_entity_frustum", "module.xoldiummod.opt_entity_frustum",
                () -> cfg.entityFrustumCulling, v -> cfg.entityFrustumCulling = v, true)
                .withDoubleSetting("frustum_margin", "setting.xoldiummod.opt.frustum_margin",
                        cfg.frustumCullMargin, 0.0, 4.0, 0.25, v -> cfg.frustumCullMargin = v));
        register(new OptimizationToggleModule("opt_player_culling", "module.xoldiummod.opt_player_culling",
                () -> cfg.playerCulling, v -> cfg.playerCulling = v, false)
                .withDoubleSetting("min_distance", "setting.xoldiummod.opt.min_distance",
                        cfg.playerCullMinDistance, 0.0, 32.0, 2.0, v -> cfg.playerCullMinDistance = v));
        register(new OptimizationToggleModule("opt_block_entity_culling", "module.xoldiummod.opt_block_entity_culling",
                () -> cfg.blockEntityCulling, v -> cfg.blockEntityCulling = v, true)
                .withDoubleSetting("cull_margin", "setting.xoldiummod.opt.cull_margin",
                        cfg.blockEntityCullMargin, 0.0, 4.0, 0.25, v -> cfg.blockEntityCullMargin = v));
        register(new OptimizationToggleModule("opt_particle_frustum", "module.xoldiummod.opt_particle_frustum",
                () -> cfg.particleFrustumCulling, v -> cfg.particleFrustumCulling = v, true));
        register(new OptimizationToggleModule("opt_tile_entity_distance", "module.xoldiummod.opt_tile_entity_distance",
                () -> cfg.tileEntityDistanceCulling, v -> cfg.tileEntityDistanceCulling = v, false)
                .withDoubleSetting("cull_distance", "setting.xoldiummod.opt.cull_distance",
                        cfg.tileEntityCullDistance, 8.0, 128.0, 4.0, v -> cfg.tileEntityCullDistance = v));
        register(new OptimizationToggleModule("opt_fast_entity_rendering", "module.xoldiummod.opt_fast_entity_rendering",
                () -> cfg.fastEntityRendering, v -> cfg.fastEntityRendering = v, true)
                .withDoubleSetting("render_distance", "setting.xoldiummod.opt.render_distance",
                        cfg.fastEntityRenderDistance, 8.0, 96.0, 4.0, v -> cfg.fastEntityRenderDistance = v));
        register(new OptimizationToggleModule("opt_direct_particle_fastpath", "module.xoldiummod.opt_direct_particle_fastpath",
                () -> cfg.directParticleFastPath, v -> cfg.directParticleFastPath = v, true)
                .withDoubleSetting("safe_radius", "setting.xoldiummod.opt.safe_radius",
                        cfg.particleCullSafeRadius, 1.0, 16.0, 0.5, v -> cfg.particleCullSafeRadius = v));
        register(new OptimizationToggleModule("opt_occlusion_boost", "module.xoldiummod.opt_occlusion_boost",
                () -> cfg.occlusionCullingBoost, v -> cfg.occlusionCullingBoost = v, true)
                .withDoubleSetting("extra_margin", "setting.xoldiummod.opt.extra_margin",
                        com.xoldium.xoldiummod.client.core.FrustumContext.extraCullMargin, 0.0, 128.0, 8.0,
                        v -> com.xoldium.xoldiummod.client.core.FrustumContext.extraCullMargin = v));
        register(new OptimizationToggleModule("opt_mob_ai_throttle", "module.xoldiummod.opt_mob_ai_throttle",
                () -> cfg.mobAiThrottling, v -> cfg.mobAiThrottling = v, true)
                .withDoubleSetting("freeze_distance", "setting.xoldiummod.opt.freeze_distance",
                        cfg.mobAiFreezeDistance, 32.0, 256.0, 8.0, v -> cfg.mobAiFreezeDistance = v));
    }

    private static void registerMovementModules() {
        register(new SprintModule());
    }

    private static void registerVisualModules() {
        // Custom Block Highlight menggantikan Block Overlay & Blocks Modifier (dihapus).
        register(new CustomBlockHighlightModule());
        register(new HitRangeModule());
        register(new XoldiumTagModule());
        register(new HitColorModule());
        register(new FullbrightModule());
        register(new NoHurtCamModule());

        // --- Modul baru ---
        register(new FreeLookModule());
        register(new MotionBlurModule());
        register(new ScrollSettingsModule());
        register(new TimeChangerModule());
        register(new ZoomModule());

        // --- Modul baru (permintaan: Custom Crosshair, Custom Crystal, Hitboxes, Tweaks) ---
        register(new CustomCrosshairModule());
        register(new CustomCrystalModule());
        register(new HitboxesModule());
        register(new XoldiumCapeModule());
        register(new ShowMeYourSkinModule());
        register(new InventoryScaleModule());
        register(new TweaksModule.ShieldTweak());
        register(new TweaksModule.ParticleTweaks());
        register(new ItemPhysicModule());
        register(new TweaksModule.CustomSize());
        register(new TweaksModule.VisionTweaks());
    }

    private static void registerMsgModules() {
        register(new AutoGgModule());
    }

    private static void register(Module module) {
        BY_ID.put(module.id(), module);
        ALL.add(module);
    }

    public static Module get(String id) {
        return BY_ID.get(id);
    }

    public static List<Module> all() {
        return ALL;
    }

    public static List<Module> byCategory(ModuleCategory category) {
        return ALL.stream()
                .filter(m -> !m.hiddenFromMenu() && (category == ModuleCategory.ALL || m.category() == category))
                .collect(Collectors.toList());
    }

    public static List<Module> search(ModuleCategory category, String query) {
        List<Module> base = byCategory(category);
        if (query == null || query.isBlank()) {
            return base;
        }
        String needle = query.toLowerCase(Locale.ROOT);
        return base.stream()
                .filter(m -> m.displayName().getString().toLowerCase(Locale.ROOT).contains(needle))
                .collect(Collectors.toList());
    }

    public static List<HudModule> hudModules() {
        List<HudModule> out = new ArrayList<>();
        for (Module m : ALL) {
            if (m instanceof HudModule hud) {
                out.add(hud);
            }
        }
        return out;
    }

    // ------------------------------------------------------------------
    // Auto FPS Boost preset (tombol di tab Optimization)
    // ------------------------------------------------------------------

    /** Menyalakan seluruh toggle Optimization dengan nilai agresif yang direkomendasikan. */
    public static void applyAutoFpsBoostPreset() {
        for (Module m : byCategory(ModuleCategory.OPTIMIZATION)) {
            m.setEnabled(true);
        }
        XoldiumConfig cfg = XoldiumConfig.get();
        cfg.mobAiThrottleDistance = 32;
        cfg.mobAiFreezeDistance = 64.0;
        cfg.fastEntityRenderDistance = 24.0;
        cfg.tileEntityCullDistance = 32.0;
        cfg.frustumCullMargin = 0.5;
        saveState();
        XoldiumMod.LOGGER.info("[Xoldium] Preset 'Auto FPS Boost' diterapkan.");
    }

    // ------------------------------------------------------------------
    // Dispatch per-frame / per-tick (dibungkus try/catch per modul)
    // ------------------------------------------------------------------

    private static void onHudRender(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        // HUD Editor menggambar preview setiap HUD sendiri; kalau HUD asli ikut digambar di belakangnya
        // hasilnya "double" (armor/potion/dll tampil dua kali dengan isi berbeda).
        if (net.minecraft.client.MinecraftClient.getInstance().currentScreen
                instanceof com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen) {
            return;
        }
        int sw = net.minecraft.client.MinecraftClient.getInstance().getWindow().getScaledWidth();
        int sh = net.minecraft.client.MinecraftClient.getInstance().getWindow().getScaledHeight();
        for (HudModule hud : hudModules()) {
            if (!hud.isEnabled()) {
                continue;
            }
            try {
                prepareHud(hud, sw, sh);
                hud.render(context, tickCounter);
            } catch (Throwable t) {
                hud.markCrashed(t);
            }
        }
    }

    // ------------------------------------------------------------------
    // Penempatan otomatis HUD (anti menumpuk / anti di luar layar)
    // ------------------------------------------------------------------

    /**
     * Dipanggil sebelum {@code render}/{@code renderPreview}. Modul yang belum ditempatkan diparkir di luar layar
     * satu frame (supaya ukuran aslinya terukur), lalu dipindah ke slot kosong pertama. Modul yang posisinya
     * ternyata berada di luar layar (mis. ganti GUI scale) juga ditempatkan ulang.
     */
    public static void prepareHud(HudModule hud, int sw, int sh) {
        if (!hud.wantsAutoPlace() || sw <= 0 || sh <= 0) {
            return;
        }
        int stage = hud.placeStage();
        if (stage == 2) {
            float w = hud.measuredWidth();
            float h = hud.measuredHeight();
            boolean off = hud.x() + w < 6f || hud.x() > sw - 6f || hud.y() + h < 4f || hud.y() > sh - 4f;
            if (!off) {
                return;
            }
            hud.setPlaceStage(0);
            stage = 0;
        }
        if (stage == 0) {
            hud.setPositionRaw(-2000f, -2000f); // ukur dulu di luar layar
            hud.setPlaceStage(1);
            return;
        }
        // stage 1: ukuran sudah diketahui
        float w = hud.measuredWidth();
        float h = hud.measuredHeight();
        float[] slot = findFreeSlot(hud, w, h, sw, sh);
        hud.setPositionRaw(slot[0], slot[1]);
        hud.setPlaceStage(2);
        saveState();
    }

    private static float[] findFreeSlot(HudModule self, float w, float h, int sw, int sh) {
        float stepX = 6f;
        for (float cx = 4f; cx + w <= sw - 4f; cx += stepX) {
            for (float cy = 4f; cy + h <= sh - 4f; cy += 4f) {
                if (!collides(self, cx, cy, w, h)) {
                    return new float[]{cx, cy};
                }
            }
        }
        return new float[]{4f, 4f}; // layar penuh: tumpuk di pojok
    }

    private static boolean collides(HudModule self, float x, float y, float w, float h) {
        for (HudModule other : hudModules()) {
            if (other == self || !other.isEnabled() || other.placeStage() != 2) {
                continue;
            }
            float ox = other.x();
            float oy = other.y();
            float ow = other.measuredWidth();
            float oh = other.measuredHeight();
            if (x < ox + ow + 3f && x + w + 3f > ox && y < oy + oh + 3f && y + h + 3f > oy) {
                return true;
            }
        }
        return false;
    }

    private static void onClientTick() {
        for (Module m : ALL) {
            if (!m.isEnabled()) {
                continue;
            }
            try {
                m.onClientTick();
            } catch (Throwable t) {
                m.markCrashed(t);
            }
        }
    }

    // ------------------------------------------------------------------
    // Persistence
    // ------------------------------------------------------------------

    private static void loadState() {
        XoldiumConfig cfg = XoldiumConfig.get();
        for (Module m : ALL) {
            Boolean en = cfg.moduleEnabled.get(m.id());
            if (en != null) {
                m.setEnabledFromConfig(en);
            }

            if (m instanceof HudModule hud) {
                float[] t = cfg.hudTransform.get(m.id());
                if (t != null && t.length == 3) {
                    float[] old = LEGACY_DEFAULTS.get(m.id());
                    boolean untouched = old != null && Math.abs(old[0] - t[0]) < 0.5f && Math.abs(old[1] - t[1]) < 0.5f;
                    hud.setScale(t[2]);
                    if (!untouched && hud.wantsAutoPlace()) {
                        hud.setPosition(t[0], t[1]);
                    } else if (!hud.wantsAutoPlace()) {
                        hud.setPosition(t[0], t[1]);
                    }
                    // untouched -> placeStage tetap 0 -> ditempatkan otomatis saat pertama dirender
                }
            }

            for (ModuleSetting<?> setting : m.settings()) {
                String key = m.id() + "." + setting.id();
                if (setting instanceof BooleanSetting bs) {
                    Boolean v = cfg.moduleBoolSettings.get(key);
                    if (v != null) bs.setFromConfig(v);
                } else if (setting instanceof DoubleSetting ds) {
                    Double v = cfg.moduleDoubleSettings.get(key);
                    if (v != null) ds.setFromConfig(v);
                } else if (setting instanceof ColorSetting cs) {
                    Integer v = cfg.moduleColorSettings.get(key);
                    if (v != null) cs.setFromConfig(v);
                } else if (setting instanceof ModeSetting ms) {
                    Integer v = cfg.moduleModeSettings.get(key);
                    if (v != null) ms.setFromConfig(v);
                }
            }
        }
    }

    /** Menyimpan state seluruh modul (enabled, posisi HUD, setting) ke {@link XoldiumConfig} dan menulis file. */
    public static void saveState() {
        if (!initialized) {
            return; // hindari menulis config parsial saat modul masih didaftarkan
        }
        XoldiumConfig cfg = XoldiumConfig.get();
        for (Module m : ALL) {
            cfg.moduleEnabled.put(m.id(), m.isToggledOn());

            if (m instanceof HudModule hud) {
                cfg.hudTransform.put(m.id(), new float[]{hud.x(), hud.y(), hud.scale()});
            }

            for (ModuleSetting<?> setting : m.settings()) {
                String key = m.id() + "." + setting.id();
                if (setting instanceof BooleanSetting bs) {
                    cfg.moduleBoolSettings.put(key, bs.get());
                } else if (setting instanceof DoubleSetting ds) {
                    cfg.moduleDoubleSettings.put(key, ds.get());
                } else if (setting instanceof ColorSetting cs) {
                    cfg.moduleColorSettings.put(key, cs.get());
                } else if (setting instanceof ModeSetting ms) {
                    cfg.moduleModeSettings.put(key, ms.get());
                }
            }
        }
        XoldiumConfig.save();
    }
}

package com.xoldium.xoldiummod.client.cosmetic;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.mixin.network.GameOptionsInvoker;
import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import com.xoldium.xoldiummod.client.social.XoldiumUsers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Sinkron cosmetic antar pengguna XoldiumClient TANPA server tambahan.
 *
 * <p>Server vanilla hanya meneruskan satu hal dari klien ke pemain lain: byte "bagian skin" (jaket, topi, dll).
 * Bit 0x80 byte itu sudah dipakai Xoldium sebagai penanda "pengguna Xoldium" (idle = bit menyala). Di atas
 * kanal 1-bit itu, cosmetic dikirim sebagai <b>denyut</b> (bit dimatikan sebentar lalu dinyalakan lagi) yang
 * dikodekan lewat PANJANG denyut:
 * <pre>
 *   header : low 18 tick
 *   tiap bit: high 4 tick, lalu low 4 tick (=0) atau 9 tick (=1)
 *   payload: 11 bit = head(5) back(3) check(3)
 * </pre>
 * Penerima membaca bit tersebut tiap tick dan mengukur panjang run-nya (toleran +-2 tick akibat jitter
 * jaringan). Satu frame +- 5 detik, dikirim ulang tiap ~25 detik (dan saat pilihan berubah / ada pemain baru),
 * sehingga pemain yang baru mendekat ikut menerima. Penerima menganggap pemain tetap "pengguna Xoldium" selama
 * bit menyala terlihat dalam 45 detik terakhir, sehingga ikon nametag tidak berkedip saat denyut.
 */
public final class CosmeticSync {

    private static final int PAYLOAD_BITS = 11;
    private static final int HEADER = 18;
    private static final int GAP = 4;
    private static final int LOW0 = 4;
    private static final int LOW1 = 9;
    private static final int PERIOD = 500; // tick (25 dtk)

    // ---------------- pengirim ----------------
    private static volatile boolean pulseLow = false;
    private static int[] plan;
    private static int planIdx;
    private static int planLeft;
    private static int sinceFrame = 1000;
    private static boolean dirty = true;
    private static int lastPlayers = 0;
    private static boolean sendBroken = false;

    // ---------------- penerima ----------------
    private static final class Rx {
        int low;          // panjang run low berjalan
        int high;         // panjang run high berjalan
        boolean collecting;
        int bits;
        int count;
    }

    private static final Map<UUID, Rx> RX = new HashMap<>();
    private static final Map<UUID, int[]> LOADOUTS = new HashMap<>();

    private CosmeticSync() {
    }

    /** Dibaca mixin opsi klien: true = jangan pasang penanda (sedang "low"). */
    public static boolean isPulseLow() {
        return pulseLow;
    }

    public static void markDirty() {
        dirty = true;
    }

    /** {head, back} milik pemain lain (hasil sinkron), atau null. */
    public static int[] of(UUID id) {
        return LOADOUTS.get(id);
    }

    private static int check(int head, int back) {
        return (head * 3 + back * 5 + 1) & 7;
    }

    public static void clear() {
        RX.clear();
        LOADOUTS.clear();
        plan = null;
        pulseLow = false;
        sinceFrame = 1000;
        dirty = true;
        lastPlayers = 0;
    }

    public static void tick(MinecraftClient mc) {
        try {
            if (mc.world == null || mc.player == null) {
                if (!RX.isEmpty() || !LOADOUTS.isEmpty() || plan != null) {
                    clear();
                }
                return;
            }
            receive(mc);
            send(mc);
        } catch (Throwable t) {
            pulseLow = false;
            plan = null;
            if (!sendBroken) {
                sendBroken = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Sinkron cosmetic dimatikan karena error (client tetap normal).", t);
            }
        }
    }

    // ------------------------------------------------------------------
    // Kirim
    // ------------------------------------------------------------------

    private static void send(MinecraftClient mc) {
        boolean can = !sendBroken && mc.getNetworkHandler() != null && !mc.isInSingleplayer()
                && XoldiumTagModule.shouldBroadcast();
        if (!can) {
            if (plan != null) {
                plan = null;
                pulseLow = false;
            }
            return;
        }
        int head = Cosmetics.myHead();
        int back = Cosmetics.myBack();
        int players = mc.world.getPlayers().size();
        if (plan == null) {
            sinceFrame++;
            boolean any = head != 0 || back != 0;
            boolean newcomers = players > lastPlayers && any && sinceFrame > 100;
            lastPlayers = players;
            if ((dirty && sinceFrame > 40) || (any && sinceFrame > PERIOD) || newcomers) {
                dirty = false;
                sinceFrame = 0;
                buildPlan(head, back);
                planIdx = 0;
                planLeft = plan[0];
                pulseLow = true;
                push(mc);
            }
            return;
        }
        if (--planLeft > 0) {
            return;
        }
        planIdx++;
        if (planIdx >= plan.length) {
            plan = null;
            pulseLow = false;
            sinceFrame = 0;
            push(mc);
            return;
        }
        pulseLow = planIdx % 2 == 0;
        planLeft = plan[planIdx];
        push(mc);
    }

    private static void buildPlan(int head, int back) {
        int value = ((head & 31) << 6) | ((back & 7) << 3) | check(head, back);
        int[] p = new int[1 + PAYLOAD_BITS * 2];
        p[0] = HEADER;
        for (int i = 0; i < PAYLOAD_BITS; i++) {
            boolean one = ((value >> (PAYLOAD_BITS - 1 - i)) & 1) != 0;
            p[1 + i * 2] = GAP;            // high
            p[2 + i * 2] = one ? LOW1 : LOW0; // low
        }
        // p: [low header, high, low, high, low, ...]; indeks genap = low
        plan = new int[p.length];
        plan[0] = p[0];
        for (int i = 1; i < p.length; i++) {
            plan[i] = p[i];
        }
    }

    private static void push(MinecraftClient mc) {
        try {
            ((GameOptionsInvoker) mc.options).xoldium$sendClientSettings();
        } catch (Throwable t) {
            sendBroken = true;
            plan = null;
            pulseLow = false;
            XoldiumMod.LOGGER.warn("[Xoldium] Tidak bisa mengirim opsi klien - sinkron cosmetic dimatikan.", t);
        }
    }

    // ------------------------------------------------------------------
    // Terima
    // ------------------------------------------------------------------

    private static void receive(MinecraftClient mc) {
        Set<UUID> present = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            UUID id = p.getUuid();
            present.add(id);
            if (p == mc.player) {
                continue;
            }
            boolean bit = XoldiumUsers.rawMarker(p);
            XoldiumUsers.noteMarker(id, bit);
            if (!XoldiumUsers.recentlyMarked(id)) {
                continue;
            }
            Rx rx = RX.computeIfAbsent(id, k -> new Rx());
            if (!bit) {
                rx.low++;
                rx.high = 0;
                if (rx.low > 40) {
                    rx.collecting = false;
                }
            } else {
                if (rx.low > 0) {
                    lowEnded(id, rx, rx.low);
                    rx.low = 0;
                }
                rx.high++;
                if (rx.collecting && rx.high > 25) {
                    rx.collecting = false;
                }
            }
        }
        if (RX.size() > present.size()) {
            RX.keySet().removeIf(id -> !present.contains(id));
        }
    }

    private static void lowEnded(UUID id, Rx rx, int n) {
        if (n >= 13 && n <= 30) {
            rx.collecting = true;
            rx.bits = 0;
            rx.count = 0;
            return;
        }
        if (!rx.collecting) {
            return;
        }
        if (n >= 2 && n <= 6) {
            rx.bits = rx.bits << 1;
        } else if (n >= 7 && n <= 12) {
            rx.bits = (rx.bits << 1) | 1;
        } else {
            rx.collecting = false;
            return;
        }
        if (++rx.count == PAYLOAD_BITS) {
            rx.collecting = false;
            int v = rx.bits & 0x7FF;
            int head = (v >> 6) & 31;
            int back = (v >> 3) & 7;
            if ((v & 7) == check(head, back)) {
                LOADOUTS.put(id, new int[]{
                        head <= Cosmetics.HEAD.size() ? head : 0,
                        back <= Cosmetics.BACK.size() ? back : 0});
            }
        }
    }
}

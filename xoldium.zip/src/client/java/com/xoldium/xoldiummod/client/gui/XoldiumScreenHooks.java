package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * UI Xoldium di Title Screen dan menu Pause (port 1.21.4 dari TitleScreenMixin + GameMenuScreenMixin 1.21.11).
 *
 * <p>Dipasang lewat Fabric API {@code ScreenEvents.AFTER_INIT} - BUKAN mixin ke {@code TitleScreen} /
 * {@code GameMenuScreen}. AFTER_INIT dijalankan setelah SEMUA mod lain (termasuk Mod Menu) selesai menambah
 * tombolnya, jadi posisi tombol akurat dan fitur ini tidak bergantung pada refmap/mapping mixin sama sekali.
 * Tampilan, tombol, dan perilakunya sama dengan versi 1.21.11:
 *
 * <ul>
 *   <li>Title Screen: tombol "XoldiumClient" (di bawah Minecraft Realms, di atas Mods) -> XoldiumHub;
 *       lencana akun kanan-atas -> XoldiumAccount; pemain 3D + skin di kanan menu dengan tombol
 *       Cosmetic & ganti akun; badge kecil + teks versi di kiri-bawah.</li>
 *   <li>Menu Pause: tombol "XoldiumHUB" + "Server Switcher" tepat di bawah tombol paling bawah, plus kartu akun.</li>
 * </ul>
 */
public final class XoldiumScreenHooks {

    private static final Identifier BADGE_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int BADGE_SIZE = 14;

    /** Status animasi per instance layar (bertahan walau layar di-init ulang saat resize). */
    private static final Map<Screen, TitleState> TITLE_STATE = new WeakHashMap<>();

    private static final class TitleState {
        final Anim.Timeline intro = new Anim.Timeline(520f);
        final Anim.Smooth follow = new Anim.Smooth(0f, 7f);
    }

    private XoldiumScreenHooks() {
    }

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            try {
                if (screen instanceof TitleScreen) {
                    decorateTitle(client, screen, scaledWidth, scaledHeight);
                } else if (screen instanceof GameMenuScreen) {
                    decoratePause(client, screen, scaledWidth, scaledHeight);
                }
            } catch (Throwable t) {
                XoldiumMod.LOGGER.warn("[Xoldium] Gagal menambah tombol Xoldium di {}", screen.getClass().getName(), t);
            }
        });
    }

    // ------------------------------------------------------------------
    // Title Screen
    // ------------------------------------------------------------------

    private static void decorateTitle(MinecraftClient client, Screen screen, int width, int height) {
        final TextRenderer tr = client.textRenderer;
        final List<ClickableWidget> buttons = Screens.getButtons(screen);
        final TitleState state = TITLE_STATE.computeIfAbsent(screen, s -> new TitleState());

        // SATU tombol "XoldiumClient" -> XoldiumHub. Posisi dipasang di frame pertama render.
        final ButtonWidget clientButton = ButtonWidget.builder(XoldiumFonts.bold("XoldiumClient"),
                        button -> client.setScreen(new XoldiumHubScreen(screen)))
                .dimensions(width / 2 - 100, height / 4 + 72, 200, 20)
                .build();
        clientButton.setAlpha(0f);
        buttons.add(clientButton);

        // Lencana akun (username + kepala skin) di kanan-atas; klik -> XoldiumAccount.
        final ButtonWidget badgeHit = ButtonWidget.builder(Text.empty(),
                        button -> client.setScreen(new XoldiumAccountScreen(screen)))
                .dimensions(width - 120, 8, 112, 26)
                .build();
        badgeHit.setAlpha(0f);
        buttons.add(badgeHit);

        // Panel pemain 3D + skin di kanan menu.
        final int menuRight = width / 2 + 102;
        final int spaceW = width - menuRight;
        ButtonWidget wardrobe = null;
        ButtonWidget account = null;
        final boolean showPanel = spaceW >= 76 && height >= 200;
        final int pcx = menuRight + spaceW / 2;
        final int modelBottom = height / 2 + 46;
        final float pixel = Math.max(1.5f, Math.min(4f, (height * 0.42f) / 32f));
        if (showPanel) {
            final int bw = Math.min(112, spaceW - 4);
            wardrobe = ButtonWidget.builder(
                            XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.wardrobe")),
                            button -> client.setScreen(new XoldiumCosmeticScreen(screen)))
                    .dimensions(pcx - bw / 2, modelBottom + 10, bw, 18)
                    .build();
            account = ButtonWidget.builder(
                            XoldiumFonts.medium(Text.translatable("gui.xoldiummod.account.switch_short")),
                            button -> client.setScreen(new XoldiumAccountScreen(screen)))
                    .dimensions(pcx - bw / 2, modelBottom + 32, bw, 18)
                    .build();
            wardrobe.setAlpha(0f);
            account.setAlpha(0f);
            buttons.add(wardrobe);
            buttons.add(account);
        }
        final ButtonWidget wardrobeButton = wardrobe;
        final ButtonWidget accountButton = account;

        final String version = FabricLoader.getInstance().getModContainer(XoldiumMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");

        final boolean[] placed = {false};

        // Sebelum render: posisi & alpha tombol (supaya tombol tidak sempat tampil di posisi awal).
        ScreenEvents.beforeRender(screen).register((s, context, mouseX, mouseY, delta) -> {
            if (!placed[0]) {
                placed[0] = true;
                placeClientButton(s, clientButton, wardrobeButton, accountButton, badgeHit);
            }
            float t = Anim.easeOutCubic(Anim.clamp01((state.intro.elapsedMs() - 160f) / 420f));
            clientButton.setAlpha(placed[0] ? t : 0f);
            if (wardrobeButton != null && accountButton != null) {
                float intro = Anim.clamp01((state.intro.elapsedMs() - 120f) / 900f);
                float a = Anim.easeOutCubic(Anim.clamp01(intro * 2.2f));
                accountButton.setAlpha(a);
                wardrobeButton.setAlpha(a);
            }
            // Area klik lencana akun mengikuti lebar teks.
            int w = 6 + 16 + 6 + tr.getWidth(XoldiumFonts.medium(AccountBadge.username())) + 10;
            badgeHit.setX(s.width - 8 - w);
            badgeHit.setY(8);
            badgeHit.setWidth(w);
            badgeHit.setHeight(26);
        });

        // Setelah render: lencana akun, panel pemain 3D, badge kecil + versi.
        ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, delta) -> {
            AccountBadge.render(context, tr, s.width, 8);

            if (showPanel) {
                float intro = Anim.clamp01((state.intro.elapsedMs() - 120f) / 900f);
                float a = Anim.easeOutCubic(Anim.clamp01(intro * 2.2f));
                int modelH = Math.round(pixel * 32f);

                // latar: cahaya lembut di belakang model + bayangan oval di lantai (fade-in)
                int glowCy = modelBottom - modelH / 2;
                for (int i = 0; i < 6; i++) {
                    int rx = Math.round(modelH * (0.34f + i * 0.07f));
                    int ry = Math.round(modelH * (0.56f + i * 0.06f));
                    ScreenChrome.roundedFill(context, pcx - rx, glowCy - ry, pcx + rx, glowCy + ry,
                            Anim.withAlpha(0x0AA79BFF, a));
                }
                for (int i = 0; i < 5; i++) {
                    int w = Math.round(pixel * (12f - i * 1.6f));
                    context.fill(pcx - w, modelBottom + i, pcx + w, modelBottom + i + 1,
                            Anim.withAlpha(0x66000000, a * (0.9f - i * 0.15f)));
                }

                // pil nama: kepala skin + username
                String name = AccountBadge.username();
                var label = XoldiumFonts.medium(name);
                int headSize = 12;
                int pillW = Math.min(spaceW - 6, headSize + 6 + tr.getWidth(label) + 12);
                int px1 = pcx - pillW / 2;
                int py1 = modelBottom - modelH - 26 + Math.round((1f - a) * 6f);
                ScreenChrome.roundedFill(context, px1, py1, px1 + pillW, py1 + 18, Anim.withAlpha(0xC8101012, a));
                ScreenChrome.roundedBorder(context, px1, py1, px1 + pillW, py1 + 18, Anim.withAlpha(0x70FFFFFF, a));
                if (!AccountBadge.drawHead(context, px1 + 4, py1 + 3, headSize)) {
                    context.fill(px1 + 4, py1 + 3, px1 + 4 + headSize, py1 + 3 + headSize, Anim.withAlpha(0xFF4A4A5A, a));
                }
                context.drawText(tr, label, px1 + 4 + headSize + 5, py1 + 5, Anim.withAlpha(0xFFFFFFFF, a), false);

                // model: putar masuk lalu menghadap kursor dengan gerak halus + ayunan diam
                double t = (System.currentTimeMillis() % 100000L) / 1000.0;
                float target = (float) Math.max(-1.0, Math.min(1.0, (mouseX - pcx) * 0.012));
                float follow = state.follow.update(target);
                float spin = (1f - Anim.easeOutCubic(intro)) * (float) (Math.PI * 2.0);
                float angle = follow + (float) (Math.sin(t * 0.9) * 0.16) + spin;
                int bob = Math.round((float) Math.sin(t * 1.7) * 0.8f);
                PlayerModel3D.draw(context, AccountBadge.skinObject(), pcx,
                        modelBottom + bob - Math.round((1f - a) * 6f), pixel, angle);
            }

            // badge kecil + teks versi di kiri-bawah
            int textY = s.height - 20;
            IconRenderer.drawTexture(context, BADGE_TEXTURE, 4, textY - 3, BADGE_SIZE, BADGE_SIZE);
            context.drawText(tr, Text.literal("Xoldium v" + version), 4 + BADGE_SIZE + 4, textY, 0xFFAAAAAA, true);
        });
    }

    /**
     * Taruh tombol XoldiumClient tepat di bawah tombol "Minecraft Realms" dan geser tombol-tombol di
     * bawahnya (Mods, Options, Quit, ikon bahasa/aksesibilitas) turun satu baris.
     */
    private static void placeClientButton(Screen screen, ButtonWidget self, ButtonWidget wardrobe,
                                          ButtonWidget account, ButtonWidget badgeHit) {
        try {
            ButtonWidget realms = null;
            String realmsLabel = Text.translatable("menu.online").getString();
            List<ButtonWidget> wide = new ArrayList<>();
            for (Element child : screen.children()) {
                if (child instanceof ButtonWidget b && b != self && b != wardrobe && b != account
                        && b != badgeHit && b.visible) {
                    if (b.getMessage().getString().equals(realmsLabel)) {
                        realms = b;
                    }
                    if (b.getWidth() >= 150) {
                        wide.add(b);
                    }
                }
            }
            if (realms == null && wide.size() >= 3) {
                wide.sort((a, b) -> Integer.compare(a.getY(), b.getY()));
                realms = wide.get(2); // Singleplayer, Multiplayer, Realms
            }
            if (realms == null) {
                return; // layout tak dikenali: biarkan tombol di posisi awal
            }
            int insertY = realms.getY() + realms.getHeight() + 4;
            int shift = self.getHeight() + 4;
            for (Element child : screen.children()) {
                if (child instanceof ClickableWidget w && w != self && w != wardrobe && w != account && w != badgeHit
                        && w.getY() >= insertY - 1 && w.getY() < screen.height - 24) {
                    w.setY(w.getY() + shift);
                }
            }
            self.setX(realms.getX());
            self.setY(insertY);
            self.setWidth(realms.getWidth());
        } catch (Throwable ignored) {
            // posisi awal dipertahankan
        }
    }

    // ------------------------------------------------------------------
    // Menu Pause
    // ------------------------------------------------------------------

    private static void decoratePause(MinecraftClient client, Screen screen, int width, int height) {
        boolean hasButtons = false;
        for (Element child : screen.children()) {
            if (child instanceof ButtonWidget button && button.visible) {
                hasButtons = true;
                break;
            }
        }
        if (!hasButtons) {
            return; // menu jeda tanpa tombol (mis. F3+Esc) - tidak ada yang perlu ditambah
        }
        final TextRenderer tr = client.textRenderer;
        final List<ClickableWidget> buttons = Screens.getButtons(screen);

        final ButtonWidget hub = ButtonWidget.builder(XoldiumFonts.bold("XoldiumHUB"),
                        button -> client.setScreen(new XoldiumHubScreen(screen)))
                .dimensions(width / 2 - 102, height - 24, 204, 20)
                .build();
        // XoldiumServerSwitcher: buka daftar server dari menu jeda.
        final ButtonWidget switcher = ButtonWidget.builder(XoldiumFonts.bold("Server Switcher"),
                        button -> client.setScreen(new MultiplayerScreen(screen)))
                .dimensions(width / 2 - 102, height - 24, 204, 20)
                .build();
        buttons.add(hub);
        buttons.add(switcher);
        pauseLayout(screen, hub, switcher);

        // Posisi dihitung ULANG tiap frame (Mod Menu dkk menambah tombol sesudah init kita). Idempotent:
        // tombol milik kita sendiri tidak ikut dihitung, jadi tidak ada "glitter" naik-turun.
        ScreenEvents.beforeRender(screen).register((s, context, mouseX, mouseY, delta) -> pauseLayout(s, hub, switcher));
        ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, delta) -> {
            int[] box = pauseLayout(s, hub, switcher);
            if (box == null) {
                return;
            }
            int cardY = Math.max(4, box[0] - AccountCard.HEIGHT - 8);
            AccountCard.render(context, tr, box[1], box[2], cardY);
        });
    }

    /**
     * Susun tombol XoldiumHUB & Server Switcher tepat di bawah tombol vanilla terbawah.
     *
     * @return {topY, left, right} dari tombol vanilla, atau null bila tidak ada.
     */
    private static int[] pauseLayout(Screen screen, ButtonWidget self, ButtonWidget sw) {
        int topY = Integer.MAX_VALUE;
        int bottomY = 0;
        int left = Integer.MAX_VALUE;
        int right = 0;
        ButtonWidget lowest = null;
        for (Element child : screen.children()) {
            if (child instanceof ButtonWidget button && button != self && button != sw
                    && button.visible && button.getWidth() >= 100) {
                topY = Math.min(topY, button.getY());
                left = Math.min(left, button.getX());
                right = Math.max(right, button.getX() + button.getWidth());
                if (button.getY() + button.getHeight() > bottomY) {
                    bottomY = button.getY() + button.getHeight();
                    lowest = button;
                }
            }
        }
        if (lowest == null) {
            return null;
        }
        int x = lowest.getX();
        int fullW = lowest.getWidth();
        int y = bottomY + 4;
        if (y + 20 + 4 + 20 <= screen.height - 2) {
            // cukup ruang: tumpuk (XoldiumHUB lalu Server Switcher di bawahnya)
            place(self, x, y, fullW);
            place(sw, x, y + 24, fullW);
        } else {
            // layar pendek: satu baris berdampingan, dijaga tetap di dalam layar
            if (y + 20 > screen.height - 2) {
                y = screen.height - 22;
            }
            int half = (fullW - 4) / 2;
            place(self, x, y, half);
            place(sw, x + half + 4, y, fullW - half - 4);
        }
        return new int[]{topY, left, right};
    }

    private static void place(ButtonWidget b, int x, int y, int w) {
        if (b.getX() != x) {
            b.setX(x);
        }
        if (b.getY() != y) {
            b.setY(y);
        }
        if (b.getWidth() != w) {
            b.setWidth(w);
        }
    }
}

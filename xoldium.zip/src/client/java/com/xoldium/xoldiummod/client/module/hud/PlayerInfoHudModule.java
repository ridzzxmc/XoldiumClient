package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** HP + absorption + bar. */
public final class PlayerInfoHudModule extends HudModule {

    public PlayerInfoHudModule() {
        super("player", "module.xoldiummod.player", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        float hp = client.player.getHealth();
        float max = Math.max(1f, client.player.getMaxHealth());
        float abs = client.player.getAbsorptionAmount();
        String value = String.format(Locale.ROOT, "%.1f / %.1f", hp, max)
                + (abs > 0f ? String.format(Locale.ROOT, "  +%.1f", abs) : "");
        HudRenderUtil.drawCard(context, this, abs > 0f ? Items.GOLDEN_APPLE : Items.APPLE, "HEALTH", value, hp / max);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.GOLDEN_APPLE, "HEALTH", "20.0 / 20.0  +4.0", 1f);
            return;
        }
        render(context, tickCounter);
    }
}

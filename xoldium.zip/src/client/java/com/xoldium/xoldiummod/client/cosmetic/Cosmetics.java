package com.xoldium.xoldiummod.client.cosmetic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xoldium.xoldiummod.XoldiumMod;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Katalog cosmetic Xoldium + pilihan pemain sendiri.
 *
 * <p>Model 3D dari file yang dikirim (glTF: Hats Mini-Pack & Black Wings, bbmodel: Cosmetic Set 1 & 2) sudah
 * DIKONVERSI saat build menjadi daftar quad berwarna (tekstur dipanggang ke warna) di
 * {@code assets/xoldiummod/cosmetics/<id>.json}, supaya bisa digambar di dunia tanpa bergantung pada API
 * renderer model Minecraft yang berubah-ubah. Urutan {@link #HEAD}/{@link #BACK} adalah ID jaringan: jangan diurutkan ulang
 * (urutan yang sama dipakai semua pengguna XoldiumClient agar saling terlihat).
 */
public final class Cosmetics {

    /** Satu cosmetic. {@code index} = ID jaringan (mulai 1; 0 = kosong). */
    public static final class Def {
        public final String id;
        public final String name;
        public final boolean head;
        public final int index;
        public final Identifier sprite;
        public final Identifier icon;
        private float[] quads;
        private int[] colors;
        private boolean loaded;

        Def(String id, String name, boolean head, int index) {
            this.id = id;
            this.name = name;
            this.head = head;
            this.index = index;
            this.sprite = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/cosmetic/sprite_" + id + ".png");
            this.icon = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/cosmetic/icon_" + id + ".png");
        }

        private synchronized void load() {
            if (loaded) {
                return;
            }
            loaded = true;
            try (InputStream in = Cosmetics.class.getResourceAsStream("/assets/xoldiummod/cosmetics/" + id + ".json")) {
                if (in == null) {
                    throw new IllegalStateException("resource tidak ada");
                }
                JsonObject o = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
                JsonArray q = o.getAsJsonArray("q");
                JsonArray c = o.getAsJsonArray("c");
                quads = new float[q.size()];
                for (int i = 0; i < quads.length; i++) {
                    quads[i] = q.get(i).getAsFloat();
                }
                colors = new int[c.size()];
                for (int i = 0; i < colors.length; i++) {
                    colors[i] = (int) c.get(i).getAsLong();
                }
            } catch (Throwable t) {
                XoldiumMod.LOGGER.warn("[Xoldium] Cosmetic '{}' gagal dimuat (dilewati).", id, t);
                quads = new float[0];
                colors = new int[0];
            }
        }

        /** 12 float per quad (4 titik xyz, blok, relatif pivot leher). */
        public float[] quads() {
            load();
            return quads;
        }

        /** Satu warna ARGB per quad. */
        public int[] colors() {
            load();
            return colors;
        }
    }

    public static final List<Def> HEAD = List.of(
            new Def("top_hat", "Top Hat", true, 1),
            new Def("xmas_hat", "Santa Hat", true, 2),
            new Def("straw_hat", "Straw Hat", true, 3),
            new Def("chef_hat", "Chef Hat", true, 4),
            new Def("crown", "Crown", true, 5),
            new Def("paper_bag", "Paper Bag", true, 6),
            new Def("mistletoe_crown", "Mistletoe Crown", true, 7),
            new Def("pumpkin_mask", "Pumpkin Mask", true, 8),
            new Def("witch_hat", "Witch Hat", true, 9),
            new Def("gingerbread_mask", "Gingerbread Mask", true, 10),
            new Def("skull_mask", "Skull Mask", true, 11),
            new Def("cowboy_hat", "Cowboy Hat", true, 12),
            new Def("straw_hat_v2", "Straw Hat V2", true, 13),
            new Def("snowman", "Snowman", true, 14),
            new Def("grave", "Grave", true, 15));

    public static final List<Def> BACK = List.of(
            new Def("black_wings", "Black Wings", false, 1),
            new Def("life_buoy", "Life Buoy", false, 2),
            new Def("hay_bale", "Hay Bale", false, 3));

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("xoldium_cosmetics.json");

    private static int myHead = 0;
    private static int myBack = 0;
    private static boolean showOthers = true;
    private static boolean loaded = false;

    private Cosmetics() {
    }

    public static Def head(int index) {
        return index >= 1 && index <= HEAD.size() ? HEAD.get(index - 1) : null;
    }

    public static Def back(int index) {
        return index >= 1 && index <= BACK.size() ? BACK.get(index - 1) : null;
    }

    private static synchronized void ensureLoaded() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            if (Files.exists(CONFIG)) {
                JsonObject o = JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject();
                myHead = clamp(o.has("head") ? o.get("head").getAsInt() : 0, HEAD.size());
                myBack = clamp(o.has("back") ? o.get("back").getAsInt() : 0, BACK.size());
                showOthers = !o.has("showOthers") || o.get("showOthers").getAsBoolean();
            }
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Config cosmetic rusak (diabaikan).", t);
        }
    }

    private static int clamp(int v, int max) {
        return Math.max(0, Math.min(max, v));
    }

    private static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("head", myHead);
            o.addProperty("back", myBack);
            o.addProperty("showOthers", showOthers);
            Files.createDirectories(CONFIG.getParent());
            Files.writeString(CONFIG, GSON.toJson(o));
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal menyimpan pilihan cosmetic.", t);
        }
    }

    public static int myHead() {
        ensureLoaded();
        return myHead;
    }

    public static int myBack() {
        ensureLoaded();
        return myBack;
    }

    public static boolean showOthers() {
        ensureLoaded();
        return showOthers;
    }

    public static void setShowOthers(boolean value) {
        ensureLoaded();
        showOthers = value;
        save();
    }

    /** Pilih cosmetic (index 0 = lepas). Memicu pengiriman ulang ke pengguna Xoldium lain. */
    public static void select(boolean head, int index) {
        ensureLoaded();
        if (head) {
            myHead = clamp(index, HEAD.size());
        } else {
            myBack = clamp(index, BACK.size());
        }
        save();
        CosmeticSync.markDirty();
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Estimasi TPS dari jarak antar tick client (tanpa paket server). */
public final class TpsHudModule extends HudModule {

    private long lastTickMs = System.currentTimeMillis();
    private double smoothedMspt = 50.0;

    public TpsHudModule() {
        super("tps", "module.xoldiummod.tps", false, 4f, 4f);
    }

    @Override
    public void onClientTick() {
        long now = System.currentTimeMillis();
        double delta = now - lastTickMs;
        lastTickMs = now;
        if (delta > 0 && delta < 2000) {
            smoothedMspt = smoothedMspt * 0.9 + delta * 0.1;
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        double tps = Math.min(20.0, 1000.0 / Math.max(1.0, smoothedMspt));
        HudRenderUtil.drawCard(context, this, Items.REPEATER, "TPS", String.format(Locale.ROOT, "%.1f", tps),
                (float) (tps / 20.0));
    }
}

package com.xoldium.xoldiummod.client.util;

import net.minecraft.entity.LivingEntity;

/**
 * Menyimpan entitas hidup yang sedang dirender (diisi mixin {@code ShowSkinEntityMixin}). Kelas biasa (bukan mixin)
 * supaya aman dirujuk dari mixin lain - kelas mixin tidak boleh dipanggil langsung dari kode lain.
 */
public final class RenderEntityContext {

    private static volatile LivingEntity current;

    private RenderEntityContext() {
    }

    public static LivingEntity current() {
        return current;
    }

    public static void set(LivingEntity entity) {
        current = entity;
    }
}

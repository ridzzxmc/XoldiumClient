package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;

/**
 * Item Physic - item yang dijatuhkan tidak lagi melayang-layang berputar, melainkan tergeletak rata di tanah
 * seperti pada mod ItemPhysicLite (CreativeCore, 1.21) yang dikirim pemakai.
 *
 * <p>PORTING KONSEP (bukan salin kode): ItemPhysicLite membatalkan render vanilla lalu menggambar ulang item
 * dengan {@code XP.rotation(90deg)} (tidur) + {@code ZP.rotation(yaw entitas)} (arah acak tetap), tanpa
 * bobbing/spin. Di 1.21.11 render item memakai {@code ItemEntityRenderState} + antrean render sehingga
 * kita tidak membatalkan apa pun: {@code mixin.visual.ItemPhysicMixin} hanya MENGGANTI dua hal di render vanilla -
 * fungsi sinus bobbing (dibuat konstan) dan rotasi spin sumbu-Y (diganti rotasi tidur + arah tetap per item) -
 * lalu menurunkan item ke tanah. Bagian yang bergantung API lama (CreativeCore, config, viskositas fluida)
 * tidak dipindahkan.
 */
public final class ItemPhysicModule extends Module {

    private static ItemPhysicModule instance;

    private final DoubleSetting height = addSetting(
            new DoubleSetting("height", "setting.xoldiummod.item_physic.height", 0.0, -5.0, 10.0, 1.0));
    private final BooleanSetting randomYaw = addSetting(
            new BooleanSetting("random_yaw", "setting.xoldiummod.item_physic.random_yaw", true));

    public ItemPhysicModule() {
        super("item_physic", "module.xoldiummod.item_physic", ModuleCategory.VISUAL, false);
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** Penyesuaian tinggi item (satuan 1/100 blok) dari setting. */
    public static float heightOffset() {
        return instance == null ? 0f : instance.height.get().floatValue() / 100f;
    }

    public static boolean randomYawEnabled() {
        return instance != null && instance.randomYaw.get();
    }
}

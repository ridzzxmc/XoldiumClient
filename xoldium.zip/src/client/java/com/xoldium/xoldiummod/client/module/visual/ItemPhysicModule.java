package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Item Physic - item yang dijatuhkan tidak lagi melayang-layang berputar, melainkan tergeletak rata di tanah
 * seperti pada mod ItemPhysicLite (CreativeCore, 1.21) yang dikirim pemakai.
 *
 * <p>PORTING KONSEP (bukan salin kode): ItemPhysicLite membatalkan render vanilla lalu menggambar ulang item
 * dengan {@code XP.rotation(90deg)} (tidur) + {@code ZP.rotation(yaw entitas)} (arah acak tetap), tanpa
 * bobbing/spin. Di 1.21.11 render item memakai {@code ItemEntityRenderState} + antrean render sehingga
 * kita tidak membatalkan apa pun: {@code mixin.visual.ItemPhysicMixin} hanya MENGGANTI dua hal di render vanilla -
 * fungsi sinus bobbing (dibuat konstan) dan rotasi spin sumbu-Y (diganti rotasi tidur + arah tetap per item) -
 * lalu menurunkan item ke tanah. Bagian yang bergantung API lama (CreativeCore, config, viskositas fluida)
 * tidak dipindahkan.
 */
public final class ItemPhysicModule extends Module {

    private static ItemPhysicModule instance;

    private final DoubleSetting height = addSetting(
            new DoubleSetting("height", "setting.xoldiummod.item_physic.height", 0.0, -5.0, 10.0, 1.0));
    private final BooleanSetting randomYaw = addSetting(
            new BooleanSetting("random_yaw", "setting.xoldiummod.item_physic.random_yaw", true));

    private static Field[] doubles;
    private static boolean fieldsResolved = false;

    public ItemPhysicModule() {
        super("item_physic", "module.xoldiummod.item_physic", ModuleCategory.VISUAL, false);
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /** Penyesuaian tinggi item (satuan 1/100 blok) dari setting. */
    public static float heightOffset() {
        return instance == null ? 0f : instance.height.get().floatValue() / 100f;
    }

    /**
     * Sudut yaw tetap per item (radian), diturunkan dari posisi dunianya (3 field double pertama pada kelas dasar
     * state render = x, y, z; dicari lewat TIPE/URUTAN karena nama aslinya intermediary). 0 bila tidak tersedia.
     */
    public static float yawFor(Object renderState) {
        if (instance == null || !instance.randomYaw.get() || renderState == null) {
            return 0f;
        }
        try {
            resolve(renderState.getClass());
            if (doubles == null || doubles.length < 3) {
                return 0f;
            }
            long hash = 1469598103934665603L;
            for (int i = 0; i < 3; i++) {
                long bits = Double.doubleToLongBits(Math.floor(doubles[i].getDouble(renderState) * 64.0));
                hash = (hash ^ bits) * 1099511628211L;
            }
            return (float) ((hash >>> 11) % 6283) / 1000f;
        } catch (Throwable t) {
            return 0f;
        }
    }

    private static void resolve(Class<?> stateClass) {
        if (fieldsResolved) {
            return;
        }
        fieldsResolved = true;
        Class<?> root = stateClass;
        while (root.getSuperclass() != null && root.getSuperclass() != Object.class) {
            root = root.getSuperclass();
        }
        Field[] found = new Field[3];
        int n = 0;
        for (Field f : root.getDeclaredFields()) {
            if (n < 3 && f.getType() == double.class && !Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                found[n++] = f;
            }
        }
        if (n == 3) {
            doubles = found;
        }
    }
}

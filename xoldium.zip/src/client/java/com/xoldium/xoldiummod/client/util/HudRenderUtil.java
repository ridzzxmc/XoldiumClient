package com.xoldium.xoldiummod.client.util;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Util render HUD bersama supaya seluruh modul teks Xoldium (FPS, Ping,
 * Coordinates, dst) punya gaya kotak label yang konsisten & satu tempat
 * untuk diperbaiki bila ada masalah tampilan - alih-alih setiap modul
 * menggambar kotaknya sendiri secara terpisah.
 *
 * <p>CATATAN VERIFIKASI MAPPING: sejak pembaruan render 2D Minecraft
 * (~1.21.2), transform GUI pada {@link DrawContext} memakai
 * {@code org.joml.Matrix3x2fStack} (method {@code pushMatrix()},
 * {@code popMatrix()}, {@code translate(x, y)} 2 argumen,
 * {@code scale(x, y)} 2 argumen) - BUKAN {@code MatrixStack} 3 argumen
 * gaya lama yang dipakai render 3D. Kode di bawah sudah memakai API baru
 * ini sesuai Yarn untuk rentang 1.21 - 1.21.11, tapi tetap verifikasi
 * ulang lewat {@code genSources}/IDE saat pindah ke build Yarn baru,
 * persis seperti catatan verifikasi mapping pada Mixin lain di proyek ini.
 */
public final class HudRenderUtil {

    public static final int TEXT_COLOR = 0xFFFFFFFF;
    /** Dulu biru ({@code 0xFF55C7F0}) - diganti abu sangat terang supaya baris "aksen" tetap sedikit beda dari teks biasa tanpa keluar dari skema hitam-putih. */
    public static final int ACCENT_COLOR = 0xFFE6E6E6;

    private HudRenderUtil() {
    }

    /** Warna latar hitam dengan alpha dari {@link HudModule#backgroundOpacity()} - 0.0 = transparan penuh (permintaan pemakai: "setting FPS background jadi transparan"). */
    private static int backgroundColor(HudModule module) {
        int alpha = (int) Math.round(module.backgroundOpacity() * 255.0);
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24);
    }

    /** Menggambar satu baris teks dengan latar semi-transparan pada posisi & skala modul, lalu mencatat ukuran terukur ke modul. */
    public static void drawLine(DrawContext context, HudModule module, String text) {
        drawLine(context, module, text, TEXT_COLOR);
    }

    public static void drawLine(DrawContext context, HudModule module, String text, int textColor) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = tr.getWidth(text) + 6;
        int rawHeight = tr.fontHeight + 4;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(module.x(), module.y());
        context.getMatrices().scale(module.scale(), module.scale());

        com.xoldium.xoldiummod.client.gui.anim.ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, backgroundColor(module));
        context.drawText(tr, text, 3, 2, textColor, true);

        context.getMatrices().popMatrix();
    }

    /** Varian multi-baris (satu kotak latar menaungi semua baris). */
    public static void drawLines(DrawContext context, HudModule module, String... lines) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = 0;
        for (String line : lines) {
            rawWidth = Math.max(rawWidth, tr.getWidth(line));
        }
        rawWidth += 6;
        int lineHeight = tr.fontHeight + 1;
        int rawHeight = lineHeight * lines.length + 3;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(module.x(), module.y());
        context.getMatrices().scale(module.scale(), module.scale());

        com.xoldium.xoldiummod.client.gui.anim.ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, backgroundColor(module));
        int y = 2;
        for (String line : lines) {
            context.drawText(tr, line, 3, y, TEXT_COLOR, true);
            y += lineHeight;
        }

        context.getMatrices().popMatrix();
    }

    // ------------------------------------------------------------------
    // Kartu HUD modern: ikon item + label kecil + nilai + (opsional) bar progres
    // ------------------------------------------------------------------

    /** Data satu kartu. {@code progress} < 0 = tanpa bar. */
    public record Card(net.minecraft.item.ItemStack icon, String label, String value, float progress, int valueColor) {
        public Card(net.minecraft.item.ItemStack icon, String label, String value, float progress) {
            this(icon, label, value, progress, 0xFFFFFFFF);
        }
    }

    private static final java.util.Map<net.minecraft.item.Item, net.minecraft.item.ItemStack> ICON_CACHE =
            new java.util.HashMap<>();

    /** ItemStack ikon yang di-cache supaya tidak membuat objek baru tiap frame. */
    public static net.minecraft.item.ItemStack icon(net.minecraft.item.Item item) {
        return ICON_CACHE.computeIfAbsent(item, net.minecraft.item.ItemStack::new);
    }

    public static void drawCard(DrawContext context, HudModule module, net.minecraft.item.Item icon,
                                String label, String value, float progress) {
        drawCards(context, module, java.util.List.of(new Card(icon(icon), label, value, progress)));
    }

    public static void drawCard(DrawContext context, HudModule module, net.minecraft.item.ItemStack icon,
                                String label, String value, float progress) {
        drawCards(context, module, java.util.List.of(new Card(icon, label, value, progress)));
    }

    public static void drawCard(DrawContext context, HudModule module, net.minecraft.item.Item icon,
                                String label, String value, float progress, int valueColor) {
        drawCards(context, module, java.util.List.of(new Card(icon(icon), label, value, progress, valueColor)));
    }

    /** Menggambar tumpukan kartu (satu modul HUD bisa punya beberapa kartu, mis. daftar pemain). */
    public static void drawCards(DrawContext context, HudModule module, java.util.List<Card> cards) {
        if (cards.isEmpty()) {
            module.setMeasuredSize(4f, 4f);
            return;
        }
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        final float labelScale = 0.75f;
        int textW = 0;
        for (Card c : cards) {
            textW = Math.max(textW, tr.getWidth(c.value()));
            textW = Math.max(textW, (int) Math.ceil(tr.getWidth(c.label()) * labelScale));
        }
        int w = 5 + 16 + 5 + Math.max(textW, 22) + 7;
        int gap = 3;
        int total = 0;
        for (Card c : cards) {
            total += cardHeight(c) + gap;
        }
        total -= gap;
        module.setMeasuredSize(w, total);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(module.x(), module.y());
        context.getMatrices().scale(module.scale(), module.scale());
        int top = 0;
        for (Card c : cards) {
            int h = cardHeight(c);
            drawOneCard(context, tr, module, c, top, w, h, labelScale);
            top += h + gap;
        }
        context.getMatrices().popMatrix();
    }

    private static int cardHeight(Card c) {
        return c.progress() >= 0f ? 27 : 24;
    }

    private static void drawOneCard(DrawContext context, TextRenderer tr, HudModule module, Card c, int top,
                                    int w, int h, float labelScale) {
        com.xoldium.xoldiummod.client.gui.anim.ScreenChrome.roundedFill(context, 0, top, w, top + h,
                module.backgroundOpacity() > 0.05 ? backgroundColor(module) : 0xB8101014);
        com.xoldium.xoldiummod.client.gui.anim.ScreenChrome.roundedBorder(context, 0, top, w, top + h, 0x38FFFFFF);
        // garis aksen putih di kiri
        context.fill(1, top + 4, 3, top + 20, 0xF0FFFFFF);
        // ubin ikon
        context.fill(5, top + 3, 5 + 18, top + 3 + 18, 0x55000000);
        if (c.icon() != null) {
            context.drawItem(c.icon(), 6, top + 4);
        }
        // label kecil + nilai
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(28f, top + 3f);
        context.getMatrices().scale(labelScale, labelScale);
        context.drawText(tr, c.label(), 0, 0, 0xFFA8A8A8, false);
        context.getMatrices().popMatrix();
        context.drawText(tr, c.value(), 28, top + 12, c.valueColor(), true);
        // bar progres
        if (c.progress() >= 0f) {
            float p = Math.max(0f, Math.min(1f, c.progress()));
            int bx1 = 5;
            int bx2 = w - 5;
            int by = top + h - 5;
            context.fill(bx1, by, bx2, by + 2, 0x66000000);
            int fill = Math.round((bx2 - bx1) * p);
            if (fill > 0) {
                context.fill(bx1, by, bx1 + fill, by + 2, 0xFFFFFFFF);
            }
        }
    }
}

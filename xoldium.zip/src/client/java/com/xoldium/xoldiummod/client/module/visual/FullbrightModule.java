package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;

/**
 * Fullbright - PERBAIKAN BUG (lihat {@code LightmapTextureManagerMixin}).
 *
 * <p>Pendekatan LAMA memaksa {@link net.minecraft.client.option.GameOptions#getGamma()}
 * lewat API publik ({@code SimpleOption#setValue}). Itu BUG-nya: opsi
 * Brightness vanilla adalah {@code SimpleOption<Double>} yang divalidasi
 * lewat callback slider-nya sendiri setiap kali {@code setValue()}
 * dipanggil - value di luar rentang slider tidak pernah benar-benar
 * tersimpan (ditolak/diabaikan diam-diam oleh validator tsb pada
 * Minecraft 1.21.11), jadi modul lama sering terlihat TIDAK memberi efek
 * fullbright sama sekali walau toggle sudah ON. Ini persis kenapa mod
 * referensi "Fullbright" (greenman999, source disertakan pemakai) SAMA
 * SEKALI tidak menyentuh GameOptions - dia langsung menimpa float gamma
 * yang dipakai internal saat lightmap texture dihitung ulang, lewat
 * Mixin ke {@code LightTexture#updateLightTexture} (nama Mojang mappings
 * mod tsb; padanan Yarn yang dipakai Xoldium adalah
 * {@code LightmapTextureManager#update} - lihat
 * {@link com.xoldium.xoldiummod.mixin.visual.LightmapTextureManagerMixin}).
 *
 * <p>Xoldium sekarang memakai teknik yang SAMA: modul ini murni jadi
 * status ON/OFF yang dibaca {@link #isActive()} oleh Mixin tsb - TIDAK
 * PERNAH memanggil {@code GameOptions#getGamma()} lagi, sehingga opsi
 * Brightness asli milik pemain (options.txt) tidak pernah ikut
 * tersentuh/berubah saat modul ini dinyalakan atau dimatikan.
 */
public final class FullbrightModule extends Module {

    /**
     * Dulu konstanta tetap {@code FORCED_GAMMA = 15.0F}, sekarang setting
     * "Brightness" (1.0 - 15.0, default tetap 15.0 supaya perilaku lama
     * tidak berubah kalau tidak disentuh) - dibaca lewat {@link #gamma()}.
     */
    private final DoubleSetting brightness = addSetting(
            new DoubleSetting("brightness", "setting.xoldiummod.fullbright.brightness", 15.0, 1.0, 15.0, 0.5));

    private static volatile FullbrightModule instance;

    public FullbrightModule() {
        super("fullbright", "module.xoldiummod.fullbright", ModuleCategory.VISUAL, false);
        instance = this;
    }

    /**
     * Dibaca oleh {@code LightmapTextureManagerMixin} setiap frame - aman
     * dipanggil sebelum modul terdaftar (fail-open ke false), dan otomatis
     * ikut mati bila modul di-nonaktifkan paksa oleh {@link #markCrashed}.
     */
    public static boolean isActive() {
        FullbrightModule i = instance;
        return i != null && i.isEnabled();
    }

    /** Nilai gamma yang dipaksa {@code LightmapTextureManagerMixin} saat modul aktif - lihat javadoc {@link #brightness}. */
    public static float gamma() {
        FullbrightModule i = instance;
        return i != null ? i.brightness.get().floatValue() : 15.0f;
    }
}

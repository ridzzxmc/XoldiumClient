package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** PackDisplayModule - kartu HUD dengan ikon, label, nilai. */
public final class PackDisplayModule extends HudModule {

    public PackDisplayModule() {
        super("pack_display", "module.xoldiummod.pack_display", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        java.util.Collection<String> enabled = MinecraftClient.getInstance().getResourcePackManager().getEnabledNames();
        String first = "default";
        int count = 0;
        for (String name : enabled) {
            if (name.equals("vanilla") || name.equals("fabric") || name.startsWith("fabric-") || name.startsWith("mod_")) {
                continue;
            }
            if (count == 0) {
                first = name.startsWith("file/") ? name.substring(5) : name;
            }
            count++;
        }
        if (first.length() > 22) {
            first = first.substring(0, 21) + "\u2026";
        }
        HudRenderUtil.drawCard(context, this, Items.PAINTING, "RESOURCE PACK" + (count > 1 ? "  +" + (count - 1) : ""),
                first, -1f);
    }

}

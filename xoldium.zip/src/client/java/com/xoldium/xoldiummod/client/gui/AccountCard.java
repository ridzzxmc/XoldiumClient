package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;

/**
 * Kartu akun di pause menu (meniru Aurora Client): kiri = kepala skin + nama
 * pemain; kanan = alamat server, bar sinyal + ping (ms) dan
 * jumlah pemain online. Singleplayer menampilkan "Singleplayer" tanpa ping.
 */
public final class AccountCard {

    public static final int HEIGHT = 36;

    private static final Anim.Timeline SHOWN = new Anim.Timeline(420f);

    private AccountCard() {
    }

    public static void render(DrawContext context, TextRenderer tr, int x1, int x2, int y) {
        float a = Anim.easeOutCubic(SHOWN.progress());
        int slide = Math.round((1f - a) * 8f);
        int top = y - slide;
        int bottom = top + HEIGHT;

        MinecraftClient client = MinecraftClient.getInstance();
        ServerInfo info = client.getCurrentServerEntry();
        String name = AccountBadge.username();
        var nameText = XoldiumFonts.bold(name);
        int face = 24;

        // --- data kanan (dihitung dulu supaya lebar kartu bisa menyesuaikan isi: dulu teks terpotong di tepi kanan)
        String address = info == null ? "Singleplayer" : (info.address == null ? "?" : info.address);
        int ping = -1;
        int online = 0;
        if (info != null && client.getNetworkHandler() != null) {
            online = client.getNetworkHandler().getPlayerList().size();
            if (client.player != null) {
                PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
                if (entry != null) {
                    ping = entry.getLatency();
                }
            }
        }
        String pingText = ping < 0 ? "-- ms" : ping + " ms";
        String onlineText = online + " online";
        int row2W = 16 + tr.getWidth(pingText) + 8 + tr.getWidth(onlineText);
        int rightW = info == null ? tr.getWidth(address) : Math.max(tr.getWidth(address), row2W);

        int leftW = 6 + face + 6 + tr.getWidth(nameText) + 8;
        int needed = leftW + 1 + 8 + rightW + 8;

        int screenW = client.getWindow().getScaledWidth();
        int width = Math.max(x2 - x1, needed);
        width = Math.min(width, screenW - 8);
        int cx = (x1 + x2) / 2;
        int left = Math.max(4, Math.min(cx - width / 2, screenW - width - 4));
        int right = left + width;

        ScreenChrome.roundedFill(context, left, top, right, bottom, Anim.withAlpha(0xD0101012, a));
        ScreenChrome.roundedBorder(context, left, top, right, bottom, Anim.withAlpha(0x60FFFFFF, a));

        // --- kiri: kepala + nama
        int fx = left + 6;
        int fy = top + (HEIGHT - face) / 2;
        if (!AccountBadge.drawHead(context, fx, fy, face)) {
            int color = 0xFF000000 | (name.hashCode() & 0x00FFFFFF) | 0x00404040;
            context.fill(fx, fy, fx + face, fy + face, Anim.withAlpha(color, a));
        }
        int nx = fx + face + 6;
        context.drawText(tr, nameText, nx, top + (HEIGHT - tr.fontHeight) / 2, Anim.withAlpha(0xFFFFFFFF, a), true);

        // --- pemisah + kanan: server / ping / online
        int splitX = left + leftW;
        context.fill(splitX, top + 6, splitX + 1, bottom - 6, Anim.withAlpha(0x40FFFFFF, a));
        int rx = splitX + 8;
        if (info == null) {
            context.drawText(tr, address, rx, top + (HEIGHT - tr.fontHeight) / 2, Anim.withAlpha(0xFFCCCCCC, a), false);
            return;
        }
        context.drawText(tr, address, rx, top + 8, Anim.withAlpha(0xFFFFFFFF, a), false);

        int row = top + 21;
        int pingColor = ping < 0 ? 0xFF888888 : ping < 80 ? 0xFF55FF55 : ping < 160 ? 0xFFFFFF55 : 0xFFFF5555;
        int bars = ping < 0 ? 0 : ping < 60 ? 4 : ping < 120 ? 3 : ping < 200 ? 2 : 1;
        for (int i = 0; i < 4; i++) {
            int bh = 2 + i * 2;
            int bx = rx + i * 3;
            int c = i < bars ? pingColor : 0xFF444444;
            context.fill(bx, row + 8 - bh, bx + 2, row + 8, Anim.withAlpha(c, a));
        }
        int tx = rx + 16;
        context.drawText(tr, pingText, tx, row, Anim.withAlpha(0xFFCCCCCC, a), false);
        context.drawText(tr, onlineText, tx + tr.getWidth(pingText) + 8, row, Anim.withAlpha(0xFFAAAAAA, a), false);
    }
}

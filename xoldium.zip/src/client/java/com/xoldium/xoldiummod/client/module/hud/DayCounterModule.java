package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** DayCounterModule - kartu HUD dengan ikon, label, nilai. */
public final class DayCounterModule extends HudModule {

    public DayCounterModule() {
        super("day_counter", "module.xoldiummod.day_counter", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        long t = client.world.getTimeOfDay();
        HudRenderUtil.drawCard(context, this, Items.DAYLIGHT_DETECTOR, "DAY", String.valueOf(t / 24000L),
                (t % 24000L) / 24000f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().world == null) {
            HudRenderUtil.drawCard(context, this, Items.DAYLIGHT_DETECTOR, "DAY", "12", 0.4f);
            return;
        }
        render(context, tickCounter);
    }

}

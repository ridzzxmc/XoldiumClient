package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Layar awal Xoldium (Right Shift) + HUD Editor: elemen HUD aktif digambar di
 * posisi aslinya dengan kotak batas yang bisa di-drag dan discroll (skala).
 * Dunia game tetap terlihat & berjalan di belakangnya (tanpa blur).
 *
 * <p>Animasi: logo & tombol meluncur naik + fade saat dibuka, vignette atas/
 * bawah memudar masuk, kotak batas HUD berganti halus saat hover/drag, dan
 * menutup dengan fade. Drag memakai override input lama (satu-satunya layar
 * yang membutuhkan drag) - bila build 1.21.9+ menolak signature-nya, cukup
 * sesuaikan tiga method mouse* di bawah.
 */
public final class XoldiumHomeScreen extends Screen {

    private static final Identifier LOGO_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int LOGO_WIDTH = 68;
    private static final int LOGO_HEIGHT = 102;

    private HudModule draggingModule;
    private float dragOffsetX;
    private float dragOffsetY;
    private final Screen parent;

    private final Anim.Timeline openTimeline = new Anim.Timeline(320f);
    private Anim.Timeline closeTimeline;
    private final Map<String, Anim.Smooth> hudHover = new HashMap<>();
    private ButtonWidget modMenuButton;
    private ButtonWidget settingsButton;

    /** Dibuka lewat keybind saat bermain - tidak ada layar induk, menutup akan kembali ke game. */
    public XoldiumHomeScreen() {
        this(null);
    }

    /** Dibuka dari layar lain (mis. Mod Menu) - menutup akan kembali ke layar tsb. */
    public XoldiumHomeScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.home.title"));
        this.parent = parent;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Dunia game harus tetap jernih: tidak ada latar/blur bawaan Screen. */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    private float alpha() {
        if (closeTimeline != null) {
            return 1f - Anim.easeInOutCubic(closeTimeline.progress());
        }
        return Anim.easeOutCubic(openTimeline.progress());
    }

    @Override
    protected void init() {
        int buttonWidth = 180;
        int centerX = this.width / 2 - buttonWidth / 2;
        int buttonsY = this.height / 2 + 20;

        modMenuButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.open_mod_menu"), button -> {
                    if (this.client != null && closeTimeline == null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY, buttonWidth, 20)
                .build();
        this.addDrawableChild(modMenuButton);

        settingsButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.settings"), button -> {
                    if (this.client != null && closeTimeline == null) {
                        this.client.setScreen(new XoldiumConfigScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY + 24, buttonWidth, 20)
                .build();
        this.addDrawableChild(settingsButton);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float a = alpha();
        int slide = Math.round(16f * (1f - a));
        int buttonsY = this.height / 2 + 20 + slide;
        modMenuButton.setY(buttonsY);
        settingsButton.setY(buttonsY + 24);
        modMenuButton.setAlpha(a);
        settingsButton.setAlpha(a);

        // Tidak memanggil renderBackground() - dunia game tetap tampil apa adanya di belakang layar ini.
        context.fillGradient(0, 0, this.width, 46, Anim.withAlpha(0xA0000000, a), 0x00000000);
        context.fillGradient(0, this.height - 60, this.width, this.height, 0x00000000, Anim.withAlpha(0xB0000000, a));

        renderLogo(context, a, slide);
        renderHudEditorOverlay(context, mouseX, mouseY, a);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("gui.xoldiummod.home.hint"),
                this.width / 2, this.height - 22, Anim.withAlpha(0xFFB0B0B8, a));

        super.render(context, mouseX, mouseY, delta);

        if (closeTimeline != null && closeTimeline.progress() >= 1f && this.client != null) {
            this.client.setScreen(parent);
        }
    }

    private void renderLogo(DrawContext context, float a, int slide) {
        int centerX = this.width / 2;
        int buttonsY = this.height / 2 + 20; // harus sama dengan init()
        int gapBeforeButtons = 14;
        int textHeight = this.textRenderer.fontHeight;

        int textY = buttonsY - gapBeforeButtons - textHeight;
        int logoY = Math.max(8, textY - 10 - LOGO_HEIGHT);

        if (a > 0.02f) {
            IconRenderer.drawTexture(context, LOGO_TEXTURE, centerX - LOGO_WIDTH / 2, logoY + slide, LOGO_WIDTH, LOGO_HEIGHT);
        }
        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold("XOLDIUM"),
                centerX, textY + slide, Anim.withAlpha(0xFFFFFFFF, a));
    }

    private void renderHudEditorOverlay(DrawContext context, int mouseX, int mouseY, float a) {
        List<HudModule> hudModules = ModuleManager.hudModules();
        RenderTickCounter tickCounter = this.client != null ? this.client.getRenderTickCounter() : null;
        if (tickCounter == null) {
            return;
        }

        for (HudModule hud : hudModules) {
            if (!hud.isEnabled()) {
                continue;
            }
            try {
                hud.renderPreview(context, tickCounter);
            } catch (Throwable t) {
                hud.markCrashed(t);
                continue;
            }

            boolean hovered = isHovering(hud, mouseX, mouseY);
            float target = hud == draggingModule ? 1f : (hovered ? 0.65f : 0.3f);
            float h = hudHover.computeIfAbsent(hud.id(), k -> new Anim.Smooth(0.3f, 14f)).update(target);
            int borderColor = Anim.withAlpha(0xFFFFFFFF, h * a);
            context.drawBorder((int) hud.x() - 1, (int) hud.y() - 1,
                    (int) hud.measuredWidth() + 2, (int) hud.measuredHeight() + 2, borderColor);
            if (h > 0.5f) {
                context.fill((int) hud.x() - 1, (int) hud.y() - 1,
                        (int) (hud.x() + hud.measuredWidth() + 1), (int) (hud.y() + hud.measuredHeight() + 1),
                        Anim.withAlpha(0x18FFFFFF, (h - 0.5f) * 2f * a));
            }
        }
    }

    private boolean isHovering(HudModule hud, double mouseX, double mouseY) {
        return mouseX >= hud.x() && mouseX <= hud.x() + hud.measuredWidth()
                && mouseY >= hud.y() && mouseY <= hud.y() + hud.measuredHeight();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (HudModule hud : ModuleManager.hudModules()) {
                if (hud.isEnabled() && isHovering(hud, mouseX, mouseY)) {
                    draggingModule = hud;
                    dragOffsetX = (float) mouseX - hud.x();
                    dragOffsetY = (float) mouseY - hud.y();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingModule != null) {
            float newX = (float) Math.max(0, Math.min(this.width - draggingModule.measuredWidth(), mouseX - dragOffsetX));
            float newY = (float) Math.max(0, Math.min(this.height - draggingModule.measuredHeight(), mouseY - dragOffsetY));
            draggingModule.setPosition(newX, newY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingModule != null) {
            draggingModule = null;
            ModuleManager.saveState();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.allowHudScaleScroll()) {
            return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled() && isHovering(hud, mouseX, mouseY)) {
                hud.setScale(hud.scale() + (float) verticalAmount * com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.scaleStep());
                ModuleManager.saveState();
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    /** Menutup dengan fade halus (layar induk baru dipasang setelah animasi selesai). */
    @Override
    public void close() {
        if (closeTimeline == null) {
            ModuleManager.saveState();
            closeTimeline = new Anim.Timeline(160f);
        }
    }
}

package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Layar awal Xoldium (dibuka dengan tombol Right Shift secara default -
 * lihat {@code XoldiumModClient}). Menampilkan logo + tombol "Open Mod
 * Menu"/"Settings", DAN sekaligus berfungsi sebagai HUD Editor: seluruh
 * elemen HUD yang aktif digambar pada posisi aslinya dengan kotak batas
 * yang bisa di-drag (klik-tahan-geser untuk memindah) dan discroll
 * (scroll wheel di atas elemen untuk mengubah skala 0.5x - 3.0x).
 *
 * <p>Layar ini SENGAJA tidak memanggil {@code renderBackground} (blur
 * pause-menu) dan meng-override {@link #shouldPause()} ke {@code false},
 * supaya dunia tetap terlihat & berjalan normal di baliknya persis
 * seperti pada tangkapan layar referensi (bukan menu jeda buram).
 */
public final class XoldiumHomeScreen extends Screen {

    private static final Identifier LOGO_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int LOGO_WIDTH = 68;
    private static final int LOGO_HEIGHT = 102;

    private HudModule draggingModule;
    private float dragOffsetX;
    private float dragOffsetY;
    private final Screen parent;

    /** Dibuka lewat keybind saat bermain - tidak ada layar induk, menutup akan kembali ke game. */
    public XoldiumHomeScreen() {
        this(null);
    }

    /** Dibuka dari layar lain (mis. Mod Menu) - menutup akan kembali ke layar tsb. */
    public XoldiumHomeScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.home.title"));
        this.parent = parent;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        int buttonWidth = 180;
        int centerX = this.width / 2 - buttonWidth / 2;
        int buttonsY = this.height / 2 + 20;

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.open_mod_menu"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY, buttonWidth, 20)
                .build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.home.settings"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new XoldiumConfigScreen(this));
                    }
                })
                .dimensions(centerX, buttonsY + 24, buttonWidth, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Tidak memanggil renderBackground() - dunia game tetap tampil apa adanya di belakang layar ini.
        renderLogo(context);
        renderHudEditorOverlay(context, mouseX, mouseY);
        super.render(context, mouseX, mouseY, delta);
    }

    /**
     * Menggambar logo Xoldium asli ({@code textures/gui/logo.png}) - dulu
     * di sini hanya badge lingkaran + huruf "X" karena overload
     * {@code DrawContext#drawTexture(...)} untuk PNG mentah berubah-ubah
     * bentuknya mengikuti perombakan render pipeline Minecraft (butuh
     * {@code RenderPipeline} eksplisit sejak 1.21.6+/1.21.7+). Overload
     * yang dipakai di bawah SUDAH diverifikasi lewat Yarn API docs
     * {@code yarn-1.21.11+build.4} - lihat javadoc {@link IconRenderer#drawTexture}.
     */
    private void renderLogo(DrawContext context) {
        int centerX = this.width / 2;

        // BUG FIX (dilaporkan pemakai - screenshot menunjukkan logo/teks "XOLDIUM"
        // ketabrak & terpotong tombol "Open Mod Menu"/"Settings" di bawahnya): posisi
        // logo dulu dihitung independen dari posisi tombol (offset "-24" tetap, tidak
        // ikut menyesuaikan tinggi logo/tombol), jadi teks label bisa tumpang-tindih
        // dengan tombol pertama saat tinggi window berubah. Sekarang dihitung MUNDUR
        // dari buttonsY (harus identik dengan nilai di init()) dengan jarak aman tetap,
        // supaya logo SELALU berhenti sebelum tombol pertama, berapa pun tingginya.
        int buttonsY = this.height / 2 + 20; // harus sama persis dengan init()
        int gapBeforeButtons = 14;
        int textHeight = this.textRenderer.fontHeight;

        int textY = buttonsY - gapBeforeButtons - textHeight;
        int logoY = Math.max(8, textY - 10 - LOGO_HEIGHT);

        IconRenderer.drawTexture(context, LOGO_TEXTURE, centerX - LOGO_WIDTH / 2, logoY, LOGO_WIDTH, LOGO_HEIGHT);

        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("XOLDIUM"),
                centerX, textY, 0xFFFFFFFF);
    }

    private void renderHudEditorOverlay(DrawContext context, int mouseX, int mouseY) {
        List<HudModule> hudModules = ModuleManager.hudModules();
        RenderTickCounter tickCounter = this.client != null ? this.client.getRenderTickCounter() : null;
        if (tickCounter == null) {
            return;
        }

        for (HudModule hud : hudModules) {
            if (!hud.isEnabled()) {
                continue;
            }
            try {
                hud.renderPreview(context, tickCounter);
            } catch (Throwable t) {
                hud.markCrashed(t);
                continue;
            }

            boolean hovered = isHovering(hud, mouseX, mouseY);
            int borderColor = hud == draggingModule ? 0xFFFFFFFF : (hovered ? 0xA0FFFFFF : 0x50FFFFFF);
            context.drawBorder((int) hud.x() - 1, (int) hud.y() - 1,
                    (int) hud.measuredWidth() + 2, (int) hud.measuredHeight() + 2, borderColor);
        }
    }

    private boolean isHovering(HudModule hud, double mouseX, double mouseY) {
        return mouseX >= hud.x() && mouseX <= hud.x() + hud.measuredWidth()
                && mouseY >= hud.y() && mouseY <= hud.y() + hud.measuredHeight();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (HudModule hud : ModuleManager.hudModules()) {
                if (hud.isEnabled() && isHovering(hud, mouseX, mouseY)) {
                    draggingModule = hud;
                    dragOffsetX = (float) mouseX - hud.x();
                    dragOffsetY = (float) mouseY - hud.y();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingModule != null) {
            float newX = (float) Math.max(0, Math.min(this.width - draggingModule.measuredWidth(), mouseX - dragOffsetX));
            float newY = (float) Math.max(0, Math.min(this.height - draggingModule.measuredHeight(), mouseY - dragOffsetY));
            draggingModule.setPosition(newX, newY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggingModule != null) {
            draggingModule = null;
            ModuleManager.saveState();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.allowHudScaleScroll()) {
            return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        for (HudModule hud : ModuleManager.hudModules()) {
            if (hud.isEnabled() && isHovering(hud, mouseX, mouseY)) {
                hud.setScale(hud.scale() + (float) verticalAmount * com.xoldium.xoldiummod.client.module.visual.ScrollSettingsModule.scaleStep());
                ModuleManager.saveState();
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}

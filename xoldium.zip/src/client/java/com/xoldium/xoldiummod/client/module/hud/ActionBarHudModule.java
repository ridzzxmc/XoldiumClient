package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.text.Text;

/** Menampilkan ulang pesan action bar server di kartu sendiri (bisa digeser). */
public final class ActionBarHudModule extends HudModule {

    private static final long DISPLAY_DURATION_MS = 4000;
    private static volatile String lastMessage = "";
    private static volatile long capturedAtMs = 0L;

    public ActionBarHudModule() {
        super("actionbar", "module.xoldiummod.actionbar", false, 4f, 4f);
    }

    public static void capture(Text message) {
        if (message == null) {
            return;
        }
        lastMessage = message.getString();
        capturedAtMs = System.currentTimeMillis();
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        long age = System.currentTimeMillis() - capturedAtMs;
        if (lastMessage.isEmpty() || age > DISPLAY_DURATION_MS) {
            return;
        }
        HudRenderUtil.drawCard(context, this, Items.OAK_SIGN, "ACTION BAR", lastMessage,
                1f - age / (float) DISPLAY_DURATION_MS);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        HudRenderUtil.drawCard(context, this, Items.OAK_SIGN, "ACTION BAR",
                lastMessage.isEmpty() ? "Action Bar message" : lastMessage, 0.6f);
    }
}

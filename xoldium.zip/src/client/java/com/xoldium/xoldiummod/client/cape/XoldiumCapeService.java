package com.xoldium.xoldiummod.client.cape;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xoldium.xoldiummod.XoldiumMod;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.lang.reflect.Method;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Klien untuk "Xoldium Cape API" (lihat folder {@code xoldium-cape-server}).
 *
 * <ul>
 *   <li><b>Register</b>: saat bermain, client memberi tahu API bahwa UUID pemain ini memakai Xoldium
 *       (diulang tiap ~4 menit; di server kedaluwarsa otomatis). Bila akun online, client lebih dulu
 *       {@code joinServer} ke Mojang dengan serverId acak sehingga API bisa membuktikan kepemilikan UUID
 *       ({@code hasJoined}). Akun offline tetap bisa terdaftar sebagai "tidak terverifikasi".</li>
 *   <li><b>Query</b>: tiap ~15 detik client menanyakan UUID pemain-pemain yang sedang dimuat di dunia; yang
 *       terdaftar akan menampilkan cape Xoldium.</li>
 * </ul>
 *
 * <p>Aturan stabilitas: SEMUA jaringan di thread latar (satu executor daemon) - thread render/tick tidak pernah
 * menunggu; semua error ditelan + backoff eksponensial (maks 5 menit) sehingga API mati/lambat tidak membuat
 * lag, spam, atau crash; tanpa {@code apiUrl} (kosong) tidak ada permintaan jaringan sama sekali.
 *
 * <p>Privasi: yang dikirim hanya UUID + username pemain (untuk verifikasi), dan daftar UUID pemain sekitar
 * saat query. Pemain bisa menolak lewat setting "Share My Cape".
 */
public final class XoldiumCapeService {

    /** Isi dengan alamat API milikmu (mis. "https://cape.domainmu.com") agar SEMUA pengguna otomatis terhubung. */
    public static final String DEFAULT_API_URL = "";

    private static final long REGISTER_INTERVAL_MS = 240_000L;
    private static final long QUERY_INTERVAL_MS = 15_000L;
    private static final long POSITIVE_TTL_MS = 120_000L;
    private static final long NEGATIVE_TTL_MS = 30_000L;
    private static final long MAX_BACKOFF_MS = 300_000L;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("xoldium_cape.json");

    private static final XoldiumCapeService INSTANCE = new XoldiumCapeService();

    public static XoldiumCapeService get() {
        return INSTANCE;
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Xoldium-Cape-Net");
        t.setDaemon(true);
        return t;
    });
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
    private final SecureRandom random = new SecureRandom();

    private final Map<UUID, Long> positive = new ConcurrentHashMap<>();   // uuid -> kedaluwarsa
    private final Map<UUID, Long> negativeUntil = new ConcurrentHashMap<>(); // uuid -> boleh ditanya lagi

    private final AtomicBoolean registering = new AtomicBoolean(false);
    private final AtomicBoolean querying = new AtomicBoolean(false);

    private volatile String apiUrl = null;      // null = belum dimuat, "" = nonaktif
    private volatile long nextRegisterAt = 0L;
    private volatile long nextQueryAt = 0L;
    private volatile long registerBackoff = 15_000L;
    private volatile long queryBackoff = 15_000L;
    private volatile boolean loggedNoApi = false;

    private XoldiumCapeService() {
    }

    // ------------------------------------------------------------------
    // Dipanggil dari thread client
    // ------------------------------------------------------------------

    public boolean isXoldiumUser(UUID uuid) {
        if (uuid == null) {
            return false;
        }
        Long exp = positive.get(uuid);
        return exp != null && exp > System.currentTimeMillis();
    }

    /** Panggil tiap tick client (murah). {@code share} = daftarkan diri; {@code others} = lihat cape pengguna lain. */
    public void tick(boolean share, boolean others) {
        try {
            String url = apiUrl();
            if (url.isEmpty()) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) {
                return;
            }
            long now = System.currentTimeMillis();

            if (share && now >= nextRegisterAt && registering.compareAndSet(false, true)) {
                // ambil semua data dari thread utama dulu, lalu kerjakan di thread latar
                final UUID uuid = mc.player.getUuid();
                final String username = mc.getSession().getUsername();
                final Object sessionService = findSessionService(mc);
                final String token = accessToken(mc);
                executor.execute(() -> doRegister(url, uuid, username, sessionService, token));
            }

            if (others && now >= nextQueryAt && querying.compareAndSet(false, true)) {
                List<UUID> wanted = new ArrayList<>();
                UUID self = mc.player.getUuid();
                for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                    UUID id = p.getUuid();
                    if (id.equals(self) || wanted.size() >= 150) {
                        continue;
                    }
                    Long until = negativeUntil.get(id);
                    Long exp = positive.get(id);
                    boolean freshPositive = exp != null && exp - now > POSITIVE_TTL_MS / 2;
                    boolean waitingNegative = until != null && until > now;
                    if (!freshPositive && !waitingNegative) {
                        wanted.add(id);
                    }
                }
                if (wanted.isEmpty()) {
                    nextQueryAt = now + 5_000L;
                    querying.set(false);
                } else {
                    executor.execute(() -> doQuery(url, wanted));
                }
            }
            if (positive.size() > 2000) {
                positive.clear();
            }
            if (negativeUntil.size() > 4000) {
                negativeUntil.clear();
            }
        } catch (Throwable t) {
            registering.set(false);
            querying.set(false);
        }
    }

    // ------------------------------------------------------------------
    // Thread latar
    // ------------------------------------------------------------------

    private void doRegister(String url, UUID uuid, String username, Object sessionService, String token) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("uuid", uuid.toString());
            body.addProperty("username", username == null ? "" : username);
            String serverId = tryJoin(sessionService, uuid, token);
            if (serverId != null) {
                body.addProperty("serverId", serverId);
            }
            int code = post(url + "/v1/register", body.toString(), null);
            if (code == 200) {
                nextRegisterAt = System.currentTimeMillis() + REGISTER_INTERVAL_MS;
                registerBackoff = 15_000L;
            } else {
                failRegister();
            }
        } catch (Throwable t) {
            failRegister();
        } finally {
            registering.set(false);
        }
    }

    private void failRegister() {
        nextRegisterAt = System.currentTimeMillis() + registerBackoff;
        registerBackoff = Math.min(MAX_BACKOFF_MS, registerBackoff * 2);
    }

    private void doQuery(String url, List<UUID> wanted) {
        try {
            JsonArray arr = new JsonArray();
            for (UUID id : wanted) {
                arr.add(id.toString());
            }
            JsonObject body = new JsonObject();
            body.add("uuids", arr);
            String[] out = new String[1];
            int code = post(url + "/v1/query", body.toString(), out);
            if (code == 200 && out[0] != null) {
                long now = System.currentTimeMillis();
                java.util.Set<UUID> found = new java.util.HashSet<>();
                JsonElement root = JsonParser.parseString(out[0]);
                if (root.isJsonObject() && root.getAsJsonObject().has("users")) {
                    for (JsonElement e : root.getAsJsonObject().getAsJsonArray("users")) {
                        try {
                            found.add(UUID.fromString(e.getAsString()));
                        } catch (Throwable ignored) {
                            // entri rusak dilewati
                        }
                    }
                }
                for (UUID id : wanted) {
                    if (found.contains(id)) {
                        positive.put(id, now + POSITIVE_TTL_MS);
                        negativeUntil.remove(id);
                    } else {
                        positive.remove(id);
                        negativeUntil.put(id, now + NEGATIVE_TTL_MS);
                    }
                }
                nextQueryAt = now + QUERY_INTERVAL_MS;
                queryBackoff = 15_000L;
            } else {
                failQuery();
            }
        } catch (Throwable t) {
            failQuery();
        } finally {
            querying.set(false);
        }
    }

    private void failQuery() {
        nextQueryAt = System.currentTimeMillis() + queryBackoff;
        queryBackoff = Math.min(MAX_BACKOFF_MS, queryBackoff * 2);
    }

    private int post(String url, String json, String[] responseOut) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(6))
                .header("Content-Type", "application/json")
                .header("User-Agent", "XoldiumClient")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (responseOut != null) {
            String b = res.body();
            responseOut[0] = b != null && b.length() <= 64 * 1024 ? b : null;
        }
        return res.statusCode();
    }

    // ------------------------------------------------------------------
    // Verifikasi akun Mojang (opsional, semua lewat refleksi + ditelan bila gagal)
    // ------------------------------------------------------------------

    /** Mengembalikan serverId bila joinServer sukses (akun online), selain itu null (tetap boleh mendaftar tanpa verifikasi). */
    private String tryJoin(Object sessionService, UUID uuid, String token) {
        if (sessionService == null || token == null || token.isEmpty() || token.equalsIgnoreCase("0")) {
            return null;
        }
        try {
            byte[] raw = new byte[16];
            random.nextBytes(raw);
            StringBuilder sb = new StringBuilder("xoldium");
            for (byte b : raw) {
                sb.append(String.format("%02x", b));
            }
            String serverId = sb.toString();
            for (Method m : sessionService.getClass().getMethods()) {
                if (m.getName().equals("joinServer") && m.getParameterCount() == 3
                        && m.getParameterTypes()[0] == UUID.class) {
                    m.invoke(sessionService, uuid, token, serverId);
                    return serverId;
                }
            }
        } catch (Throwable ignored) {
            // akun offline / token tidak valid -> daftar tanpa verifikasi
        }
        return null;
    }

    private static Object findSessionService(MinecraftClient mc) {
        try {
            for (Method m : MinecraftClient.class.getDeclaredMethods()) {
                if (m.getParameterCount() != 0 || java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                    continue;
                }
                String rt = m.getReturnType().getSimpleName();
                if (rt.equals("MinecraftSessionService")) {
                    m.setAccessible(true);
                    return m.invoke(mc);
                }
                if (rt.equals("ApiServices")) {
                    m.setAccessible(true);
                    Object api = m.invoke(mc);
                    if (api != null) {
                        for (Method a : api.getClass().getMethods()) {
                            if (a.getParameterCount() == 0 && a.getReturnType().getSimpleName().equals("MinecraftSessionService")) {
                                return a.invoke(api);
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            // tanpa verifikasi
        }
        return null;
    }

    private static String accessToken(MinecraftClient mc) {
        try {
            Object session = mc.getSession();
            for (Method m : session.getClass().getMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == String.class
                        && (m.getName().equals("getAccessToken") || m.getName().equals("accessToken"))) {
                    return (String) m.invoke(session);
                }
            }
        } catch (Throwable ignored) {
            // tanpa verifikasi
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Config
    // ------------------------------------------------------------------

    private String apiUrl() {
        String cached = apiUrl;
        if (cached != null) {
            return cached;
        }
        String url = DEFAULT_API_URL;
        try {
            if (Files.exists(CONFIG)) {
                JsonObject o = JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject();
                if (o.has("apiUrl") && !o.get("apiUrl").getAsString().isBlank()) {
                    url = o.get("apiUrl").getAsString();
                }
            } else {
                JsonObject o = new JsonObject();
                o.addProperty("apiUrl", DEFAULT_API_URL);
                o.addProperty("_info", "Isi apiUrl dengan alamat Xoldium Cape API (mis. https://cape.domainmu.com). Kosong = cape hanya tampil di pemain lokal.");
                Files.writeString(CONFIG, GSON.toJson(o));
            }
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal membaca config cape (memakai bawaan).", t);
        }
        url = url == null ? "" : url.trim();
        while (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }
        if (!url.isEmpty()) {
            String lower = url.toLowerCase(java.util.Locale.ROOT);
            if (!(lower.startsWith("https://") || lower.startsWith("http://localhost") || lower.startsWith("http://127.0.0.1"))) {
                XoldiumMod.LOGGER.warn("[Xoldium] apiUrl cape harus HTTPS (diabaikan): {}", url);
                url = "";
            }
        }
        if (url.isEmpty() && !loggedNoApi) {
            loggedNoApi = true;
            XoldiumMod.LOGGER.info("[Xoldium] Cape API belum diatur - cape hanya tampil di pemain lokal. Isi 'apiUrl' di config/xoldium_cape.json.");
        }
        apiUrl = url;
        return url;
    }
}

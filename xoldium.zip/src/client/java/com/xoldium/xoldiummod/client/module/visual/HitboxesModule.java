package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Hitboxes - kotak hitbox entitas yang selalu terlihat tanpa F3+B, dengan
 * warna berbeda saat entitas sedang dibidik (target) atau baru terkena hit
 * (hurt), garis tinggi mata dan arah pandang. Port dari mod "Combat Hitboxes"
 * (sootysplash, build 26.3) yang dikirim pemakai: fitur & nilai default sama
 * (hitbox putih, target merah, hurt magenta, tinggi mata merah, arah pandang
 * biru, sembunyikan item/kembang api opsional).
 *
 * <p>Mod referensi menggambar lewat API {@code Gizmos} milik rilis 26.x yang
 * tidak ada di 1.21.11, jadi garis digambar sebagai balok tipis lewat
 * {@link WorldOverlay#beam} (pola yang sama dengan Hit Range). Ketebalan garis
 * = setelan "Line Width" (satuan blok), jarak maksimum dibatasi supaya tidak
 * menggambar ratusan entitas jauh.
 */
public final class HitboxesModule extends Module {

    private final ModeSetting entities = addSetting(new ModeSetting("entities", "setting.xoldiummod.hitboxes.entities", 0,
            "setting.xoldiummod.hitboxes.entities.players",
            "setting.xoldiummod.hitboxes.entities.living",
            "setting.xoldiummod.hitboxes.entities.all"));
    private final DoubleSetting lineWidth = addSetting(
            new DoubleSetting("line_width", "setting.xoldiummod.hitboxes.line_width", 0.015, 0.004, 0.06, 0.002));
    private final DoubleSetting maxDistance = addSetting(
            new DoubleSetting("max_distance", "setting.xoldiummod.hitboxes.max_distance", 48.0, 8.0, 128.0, 4.0));
    private final ColorSetting boxColor = addSetting(
            new ColorSetting("box_color", "setting.xoldiummod.hitboxes.box_color", 0xFFFFFFFF, true));
    private final BooleanSetting changeTargetColor = addSetting(
            new BooleanSetting("target_color_on", "setting.xoldiummod.hitboxes.target_color_on", true));
    private final ColorSetting targetColor = addSetting(
            new ColorSetting("target_color", "setting.xoldiummod.hitboxes.target_color", 0xFFFF0000, true),
            () -> this.changeTargetColor.get());
    private final BooleanSetting hurtColorOn = addSetting(
            new BooleanSetting("hurt_color_on", "setting.xoldiummod.hitboxes.hurt_color_on", false));
    private final ColorSetting hurtColor = addSetting(
            new ColorSetting("hurt_color", "setting.xoldiummod.hitboxes.hurt_color", 0xFFFF00FF, true),
            () -> this.hurtColorOn.get());
    private final BooleanSetting eyeHeight = addSetting(
            new BooleanSetting("eye_height", "setting.xoldiummod.hitboxes.eye_height", true));
    private final ColorSetting eyeColor = addSetting(
            new ColorSetting("eye_color", "setting.xoldiummod.hitboxes.eye_color", 0xFFFF0000, true),
            () -> this.eyeHeight.get());
    private final BooleanSetting lookDir = addSetting(
            new BooleanSetting("look_dir", "setting.xoldiummod.hitboxes.look_dir", true));
    private final ColorSetting lookColor = addSetting(
            new ColorSetting("look_color", "setting.xoldiummod.hitboxes.look_color", 0xFF0000FF, true),
            () -> this.lookDir.get());
    private final BooleanSetting showSelf = addSetting(
            new BooleanSetting("show_self", "setting.xoldiummod.hitboxes.show_self", false));
    private final BooleanSetting hideItems = addSetting(
            new BooleanSetting("hide_items", "setting.xoldiummod.hitboxes.hide_items", true));
    private final BooleanSetting hideFireworks = addSetting(
            new BooleanSetting("hide_fireworks", "setting.xoldiummod.hitboxes.hide_fireworks", true));

    private boolean loggedError = false;

    public HitboxesModule() {
        super("hitboxes", "module.xoldiummod.hitboxes", ModuleCategory.VISUAL, false);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onAfterEntities);
    }

    private void onAfterEntities(WorldRenderContext context) {
        if (!isEnabled()) {
            return;
        }
        try {
            draw(context);
        } catch (Throwable t) {
            if (!loggedError) {
                loggedError = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Hitboxes gagal menggambar (dilewati, tidak crash).", t);
            }
        }
    }

    private void draw(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) {
            return;
        }
        VertexConsumer vc = WorldOverlay.quadConsumer(context);
        if (vc == null) {
            return;
        }
        MatrixStack matrices = WorldOverlay.matrices(context);
        Matrix4f m = WorldOverlay.positionMatrix(matrices);
        Vec3d cam = WorldOverlay.camera(context);
        float tickDelta = mc.getRenderTickCounter().getTickProgress(false);
        double maxSq = maxDistance.get() * maxDistance.get();
        double half = lineWidth.get() / 2.0;
        Entity targeted = mc.crosshairTarget instanceof EntityHitResult ehr ? ehr.getEntity() : null;
        int mode = entities.index();

        int drawn = 0;
        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player && !showSelf.get()) continue;
            if (entity.squaredDistanceTo(mc.player) > maxSq) continue;
            if (mode == 0 && !(entity instanceof PlayerEntity)) continue;
            if (mode == 1 && !(entity instanceof LivingEntity)) continue;
            if (hideItems.get() && entity instanceof ItemEntity) continue;
            if (hideFireworks.get() && entity instanceof FireworkRocketEntity) continue;
            if (entity.isInvisibleTo(mc.player) && !(entity instanceof PlayerEntity)) continue;

            Vec3d lerped = entity.getLerpedPos(tickDelta);
            Vec3d delta = lerped.subtract(entity.getPos());
            Box box = entity.getBoundingBox().offset(delta).offset(-cam.x, -cam.y, -cam.z);

            int color = boxColor.argb();
            if (hurtColorOn.get() && entity instanceof LivingEntity le && le.hurtTime != 0) {
                color = hurtColor.argb();
            } else if (changeTargetColor.get() && entity == targeted) {
                color = targetColor.argb();
            }
            edges(vc, m, box, color, half);

            if (eyeHeight.get() && entity instanceof LivingEntity) {
                double ey = box.minY + (entity.getEyeY() - entity.getY());
                Box eye = new Box(box.minX, ey - 0.01, box.minZ, box.maxX, ey + 0.01, box.maxZ);
                edges(vc, m, eye, eyeColor.argb(), half * 0.6);
            }
            if (lookDir.get() && entity instanceof LivingEntity) {
                Vec3d from = new Vec3d(box.getCenter().x, box.minY + (entity.getEyeY() - entity.getY()), box.getCenter().z);
                Vec3d dir = entity.getRotationVec(tickDelta).multiply(2.0);
                WorldOverlay.beam(vc, m, from.x, from.y, from.z, lookColor.argb(),
                        from.x + dir.x, from.y + dir.y, from.z + dir.z, lookColor.argb(), half);
            }
            drawn++;
        }
        if (drawn > 0) {
            WorldOverlay.flush(context);
        }
    }

    /** 12 rusuk balok sebagai balok tipis. */
    private static void edges(VertexConsumer vc, Matrix4f m, Box b, int c, double h) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        // bawah
        WorldOverlay.beam(vc, m, x1, y1, z1, c, x2, y1, z1, c, h);
        WorldOverlay.beam(vc, m, x2, y1, z1, c, x2, y1, z2, c, h);
        WorldOverlay.beam(vc, m, x2, y1, z2, c, x1, y1, z2, c, h);
        WorldOverlay.beam(vc, m, x1, y1, z2, c, x1, y1, z1, c, h);
        // atas
        WorldOverlay.beam(vc, m, x1, y2, z1, c, x2, y2, z1, c, h);
        WorldOverlay.beam(vc, m, x2, y2, z1, c, x2, y2, z2, c, h);
        WorldOverlay.beam(vc, m, x2, y2, z2, c, x1, y2, z2, c, h);
        WorldOverlay.beam(vc, m, x1, y2, z2, c, x1, y2, z1, c, h);
        // tiang
        WorldOverlay.beam(vc, m, x1, y1, z1, c, x1, y2, z1, c, h);
        WorldOverlay.beam(vc, m, x2, y1, z1, c, x2, y2, z1, c, h);
        WorldOverlay.beam(vc, m, x2, y1, z2, c, x2, y2, z2, c, h);
        WorldOverlay.beam(vc, m, x1, y1, z2, c, x1, y2, z2, c, h);
    }
}

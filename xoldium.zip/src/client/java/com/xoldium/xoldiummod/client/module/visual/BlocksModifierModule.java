package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Set;

/**
 * Blocks Modifier - menandai block-block "tak terlihat" bawaan vanilla
 * (barrier, light, structure void, dst) dengan outline warna terang saat
 * dibidik, supaya kelihatan sedang membidik block itu (biasanya menyatu
 * dengan udara kosong). Memakai event resmi
 * {@code WorldRenderEvents#BLOCK_OUTLINE} yang sama persis dengan
 * {@link BlockOverlayModule} - BUKAN mixin baru.
 *
 * <p>Warna diatur lewat gear-icon (setting "Hue", 0-360°, default 317° =
 * magenta seperti sebelumnya) - konversi HSV->RGB via
 * {@code MathHelper.hsvToRgb}, pola sama seperti {@link BlockOverlayModule}.
 */
public final class BlocksModifierModule extends Module {

    private static final Set<Block> SPECIAL_BLOCKS = Set.of(
            Blocks.BARRIER, Blocks.LIGHT, Blocks.STRUCTURE_VOID, Blocks.JIGSAW, Blocks.STRUCTURE_BLOCK);

    private final DoubleSetting hue = addSetting(
            new DoubleSetting("hue", "setting.xoldiummod.blocks_modifier.hue", 317.0, 0.0, 360.0, 1.0));

    public BlocksModifierModule() {
        super("blocks_modifier", "module.xoldiummod.blocks_modifier", ModuleCategory.VISUAL, false);
        WorldRenderEvents.BLOCK_OUTLINE.register(this::onBlockOutline);
    }

    private boolean onBlockOutline(WorldRenderContext context, WorldRenderEvents.BlockOutlineContext blockContext) {
        if (!isEnabled()) {
            return true;
        }
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world == null) {
                return true;
            }
            Block block = client.world.getBlockState(blockContext.blockPos()).getBlock();
            if (!SPECIAL_BLOCKS.contains(block)) {
                return true; // bukan block spesial - biarkan outline vanilla normal (atau modul lain, mis. Block Overlay)
            }

            Vec3d camPos = context.camera().getPos();
            Box box = new Box(blockContext.blockPos())
                    .offset(-camPos.x, -camPos.y, -camPos.z)
                    .expand(0.002);

            int packedRgb = MathHelper.hsvToRgb((float) (hue.get() / 360.0), 0.8f, 1.0f);
            float r = ((packedRgb >> 16) & 0xFF) / 255f;
            float g = ((packedRgb >> 8) & 0xFF) / 255f;
            float b = (packedRgb & 0xFF) / 255f;
            VertexConsumer consumer = context.consumers().getBuffer(RenderLayer.getLines());
            WorldRenderer.drawBox(context.matrixStack(), consumer, box, r, g, b, 1.0f);
        } catch (Throwable t) {
            markCrashed(t);
            return true;
        }
        return false;
    }
}

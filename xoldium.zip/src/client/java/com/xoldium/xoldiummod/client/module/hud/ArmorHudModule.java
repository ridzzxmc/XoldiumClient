package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class ArmorHudModule extends HudModule {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public ArmorHudModule() {
        super("armor_hud", "module.xoldiummod.armor_hud", false, 4f, 164f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<String> lines = new ArrayList<>();
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (stack.isEmpty()) {
                continue;
            }
            int percent = 100;
            if (stack.isDamageable() && stack.getMaxDamage() > 0) {
                percent = Math.round(100f * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage());
            }
            lines.add(stack.getName().getString() + " " + percent + "%");
        }

        if (lines.isEmpty()) {
            HudRenderUtil.drawLine(context, this, "Armor: none");
        } else {
            HudRenderUtil.drawLines(context, this, lines.toArray(new String[0]));
        }
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Armor HUD dengan tiga gaya:
 * <ul>
 *   <li><b>Icons</b>: baris [ikon item] + persen durabilitas berwarna.</li>
 *   <li><b>Tiles</b>: ubin gelap membulat + bar tipis + pil angka.</li>
 *   <li><b>Hotbar</b> (foto referensi): empat slot berbingkai dalam satu baris
 *       (helm, chestplate, legging, sepatu) dengan bar durabilitas di bawah ikon,
 *       slot kosong tampil samar, dan lencana merah "!!" berkedip saat ada armor hampir rusak.</li>
 * </ul>
 * Item yang dipegang (pedang dsb) SELALU digambar di ATAS armor sebagai slot tersendiri,
 * dipisahkan celah kecil - seperti slot tangan - bukan tercampur di daftar armor.
 *
 * <p>BUG "double armor" diperbaiki di {@code ModuleManager#onHudRender}: HUD Editor menggambar preview
 * sendiri, sedangkan HUD asli ikut tergambar di belakangnya sehingga tampil dua kali.
 */
public final class ArmorHudModule extends HudModule {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final int SLOT = 22;
    private static final int HELD_GAP = 4;

    private final ModeSetting style = addSetting(new ModeSetting("style", "setting.xoldiummod.armor_hud.style", 0,
            "setting.xoldiummod.armor_hud.style.icons", "setting.xoldiummod.armor_hud.style.tiles",
            "setting.xoldiummod.armor_hud.style.hotbar"));
    private final BooleanSetting showHeld = addSetting(new BooleanSetting("show_held",
            "setting.xoldiummod.armor_hud.show_held", true));

    /** Persen durabilitas yang dianimasikan halus: indeks 0 = item di tangan, 1..4 = helm..sepatu. */
    private final Anim.Smooth[] bars = new Anim.Smooth[5];
    private final Anim.Smooth warn = new Anim.Smooth(0f, 7f);

    public ArmorHudModule() {
        super("armor_hud", "module.xoldiummod.armor_hud", false, 4f, 164f, 0.0);
        for (int i = 0; i < bars.length; i++) {
            bars[i] = new Anim.Smooth(100f, 9f);
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        ItemStack held = showHeld.get() ? client.player.getMainHandStack() : ItemStack.EMPTY;
        ItemStack[] armor = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            armor[i] = client.player.getEquippedStack(ARMOR_SLOTS[i]);
        }
        draw(context, client.textRenderer, held, armor);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ItemStack[] sample = {
                new ItemStack(Items.NETHERITE_HELMET), new ItemStack(Items.NETHERITE_CHESTPLATE),
                new ItemStack(Items.NETHERITE_LEGGINGS), new ItemStack(Items.NETHERITE_BOOTS)
        };
        draw(context, client.textRenderer, showHeld.get() ? new ItemStack(Items.NETHERITE_SWORD) : ItemStack.EMPTY, sample);
    }

    // ------------------------------------------------------------------

    private void draw(DrawContext context, TextRenderer tr, ItemStack held, ItemStack[] armor) {
        int mode = style.index();
        boolean hasHeld = held != null && !held.isEmpty();

        // animasi halus persen durabilitas (+ deteksi armor hampir rusak untuk lencana "!!")
        boolean low = false;
        for (int i = 0; i < 4; i++) {
            if (!armor[i].isEmpty() && armor[i].isDamageable() && percent(armor[i]) <= 15) {
                low = true;
            }
        }
        float warnAlpha = warn.update(low ? 1f : 0f);
        if (hasHeld) {
            bars[0].update(percent(held));
        }
        for (int i = 0; i < 4; i++) {
            if (!armor[i].isEmpty()) {
                bars[i + 1].update(percent(armor[i]));
            } else {
                bars[i + 1].snap(100f);
            }
        }

        if (mode == 2) {
            drawHotbar(context, tr, held, hasHeld, armor, warnAlpha);
        } else {
            drawList(context, tr, mode == 1, held, hasHeld, armor);
        }
    }

    // ---------------------------- gaya Hotbar (foto) ----------------------------

    private void drawHotbar(DrawContext context, TextRenderer tr, ItemStack held, boolean hasHeld,
                            ItemStack[] armor, float warnAlpha) {
        int rowW = SLOT * 4 + 3; // 4 slot berbingkai, dua slot bertetangga berbagi 1px
        int top = hasHeld ? SLOT + HELD_GAP : 0;
        int rawW = rowW;
        int rawH = top + SLOT;
        setMeasuredSize(rawW, rawH);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);

        if (hasHeld) {
            int hx = (rowW - SLOT) / 2;
            slotFrame(context, hx, 0);
            context.drawItem(held, hx + 3, 3);
            if (held.isDamageable()) {
                durabilityBar(context, hx, 0, bars[0].get());
            } else if (held.getCount() > 1) {
                String c = String.valueOf(held.getCount());
                context.drawText(tr, c, hx + SLOT - 3 - tr.getWidth(c), 13, 0xFFFFFFFF, true);
            }
        }
        for (int i = 0; i < 4; i++) {
            int sx = i * (SLOT - 1);
            slotFrame(context, sx, top);
            ItemStack stack = armor[i];
            if (stack.isEmpty()) {
                ghost(context, sx, top);
            } else {
                context.drawItem(stack, sx + 3, top + 3);
                if (stack.isDamageable()) {
                    durabilityBar(context, sx, top, bars[i + 1].get());
                }
            }
        }

        // lencana merah "!!" - armor hampir rusak
        if (warnAlpha > 0.02f) {
            float pulse = 0.65f + 0.35f * (float) Math.sin(System.currentTimeMillis() / 180.0);
            float a = warnAlpha * pulse;
            int bx = -7;
            int by = top - 7;
            ScreenChrome.roundedFill(context, bx, by, bx + 14, by + 14, Anim.withAlpha(0xFFD22B2B, a));
            ScreenChrome.roundedBorder(context, bx, by, bx + 14, by + 14, Anim.withAlpha(0xFFFFB3B3, a));
            context.drawText(tr, "!!", bx + 7 - tr.getWidth("!!") / 2, by + 3, Anim.withAlpha(0xFFFFFFFF, a), false);
        }
        context.getMatrices().popMatrix();
    }

    /** Bingkai slot: tepi luar hitam, tepi dalam abu terang (atas/kiri) & gelap (bawah/kanan), isi gelap. */
    private static void slotFrame(DrawContext context, int x, int y) {
        context.fill(x, y, x + SLOT, y + SLOT, 0xFF000000);
        context.fill(x + 1, y + 1, x + SLOT - 1, y + SLOT - 1, 0xFF8B8B8B);
        context.fill(x + 2, y + 2, x + SLOT - 2, y + SLOT - 2, 0xA0262618);
        context.fill(x + SLOT - 2, y + 1, x + SLOT - 1, y + SLOT - 1, 0xFF555555);
        context.fill(x + 1, y + SLOT - 2, x + SLOT - 1, y + SLOT - 1, 0xFF555555);
    }

    /** Siluet samar untuk slot armor kosong. */
    private static void ghost(DrawContext context, int x, int y) {
        int c = 0x40FFFFFF;
        context.fill(x + 6, y + 5, x + SLOT - 6, y + 7, c);
        context.fill(x + 5, y + 7, x + 7, y + SLOT - 6, c);
        context.fill(x + SLOT - 7, y + 7, x + SLOT - 5, y + SLOT - 6, c);
        context.fill(x + 6, y + SLOT - 7, x + SLOT - 6, y + SLOT - 5, c);
    }

    /** Bar durabilitas tipis di bawah ikon (lebar mengikuti persen yang dianimasikan). */
    private static void durabilityBar(DrawContext context, int x, int y, float pct) {
        int bx = x + 3;
        int by = y + SLOT - 6;
        int full = SLOT - 6;
        int w = Math.max(1, Math.round(full * Math.max(0f, Math.min(100f, pct)) / 100f));
        context.fill(bx, by, bx + full, by + 2, 0xFF000000);
        context.fill(bx, by, bx + w, by + 2, barColor(pct));
    }

    // ---------------------------- gaya Icons / Tiles ----------------------------

    private void drawList(DrawContext context, TextRenderer tr, boolean tiles, ItemStack held, boolean hasHeld,
                          ItemStack[] armor) {
        int rowH = tiles ? 24 : 18;
        List<ItemStack> stacks = new ArrayList<>(5);
        List<Integer> barIndex = new ArrayList<>(5);
        if (hasHeld) {
            stacks.add(held);
            barIndex.add(0);
        }
        int heldRows = stacks.size();
        for (int i = 0; i < 4; i++) {
            if (!armor[i].isEmpty()) {
                stacks.add(armor[i]);
                barIndex.add(i + 1);
            }
        }
        if (stacks.isEmpty()) {
            setMeasuredSize(60, 12);
            return;
        }

        List<String> labels = new ArrayList<>(stacks.size());
        int textW = 0;
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack stack = stacks.get(i);
            String label = stack.isDamageable() ? Math.round(bars[barIndex.get(i)].get()) + "%"
                    : (stack.getCount() > 1 ? "x" + stack.getCount() : "");
            labels.add(label);
            textW = Math.max(textW, tr.getWidth(label));
        }
        int gap = (heldRows > 0 && stacks.size() > heldRows) ? HELD_GAP : 0;
        int rawWidth = tiles ? (3 + 22 + 3 + textW + 10) : (2 + 16 + 4 + textW + 2);
        int rawHeight = rowH * stacks.size() + gap;
        setMeasuredSize(rawWidth, rawHeight);

        int bg = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0) << 24;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        if (!tiles && (bg >>> 24) > 0) {
            ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, bg);
        }

        int rowY = 0;
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack stack = stacks.get(i);
            float pct = stack.isDamageable() ? bars[barIndex.get(i)].get() : 100f;
            int color = stack.isDamageable() ? barColor(pct) : 0xFFFFFFFF;
            if (tiles) {
                if (stack.isDamageable()) {
                    int barH = Math.max(1, Math.round(20f * pct / 100f));
                    context.fill(0, rowY + 1, 2, rowY + 21, 0x66000000);
                    context.fill(0, rowY + 21 - barH, 2, rowY + 21, color);
                }
                ScreenChrome.roundedFill(context, 3, rowY, 25, rowY + 22, 0xB0101014);
                ScreenChrome.roundedBorder(context, 3, rowY, 25, rowY + 22, 0x40FFFFFF);
                context.drawItem(stack, 6, rowY + 3);
                if (!labels.get(i).isEmpty()) {
                    int pillX = 28;
                    int pillW = textW + 8;
                    ScreenChrome.roundedFill(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0xB0101014);
                    ScreenChrome.roundedBorder(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0x30FFFFFF);
                    context.drawText(tr, labels.get(i), pillX + 4, rowY + 7, color, true);
                }
            } else {
                context.drawItem(stack, 2, rowY + 1);
                context.drawText(tr, labels.get(i), 2 + 16 + 4, rowY + 1 + (16 - tr.fontHeight) / 2, color, true);
            }
            rowY += rowH;
            if (i == heldRows - 1) {
                rowY += gap; // celah antara item di tangan dan armor
            }
        }
        context.getMatrices().popMatrix();
    }

    private static int percent(ItemStack stack) {
        if (stack.isDamageable() && stack.getMaxDamage() > 0) {
            return Math.max(0, Math.min(100, Math.round(100f * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage())));
        }
        return 100;
    }

    private static int barColor(float pct) {
        if (pct >= 60f) return 0xFF55FF55;
        if (pct >= 30f) return 0xFFFFFF55;
        return 0xFFFF5555;
    }
}

package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Kelas dasar layar Xoldium: animasi buka/tutup (fade + slide), latar redup
 * TANPA blur (menghindari crash "Can only blur once per frame" bila
 * renderBackground ikut dipanggil oleh Screen#render), dan helper tombol
 * transparan untuk area klik.
 *
 * <p>SENGAJA tidak meng-override method input (mouseClicked/keyPressed/dst):
 * seluruh interaksi memakai widget vanilla (ButtonWidget/TextFieldWidget/
 * SliderWidget) sehingga tidak bergantung pada signature input Minecraft yang
 * berubah di 1.21.9+ (Click/KeyInput).
 */
public abstract class XoldiumScreen extends Screen {

    protected static final float OPEN_MS = 240f;
    protected static final float CLOSE_MS = 140f;

    protected final Screen parent;
    private final Anim.Timeline openTimeline = new Anim.Timeline(OPEN_MS);
    private Anim.Timeline closeTimeline;
    private boolean bgDrawn = false;

    protected XoldiumScreen(Text title, Screen parent) {
        super(title);
        this.parent = parent;
    }

    public final boolean isClosing() {
        return closeTimeline != null;
    }

    /** 0..1 easing buka. */
    protected final float openProgress() {
        return Anim.easeOutCubic(openTimeline.progress());
    }

    /** Waktu sejak layar dibuka (ms, tidak dibatasi) - untuk animasi bertahap (stagger). */
    protected final float openElapsedMs() {
        return openTimeline.elapsedMs();
    }

    /** Offset Y (piksel) untuk efek slide-up saat membuka / slide-down saat menutup. */
    protected final int slideOffset(int distance) {
        if (closeTimeline != null) {
            return Math.round(distance * 0.5f * Anim.easeInOutCubic(closeTimeline.progress()));
        }
        return Math.round(distance * (1f - openProgress()));
    }

    /** Alpha keseluruhan layar 0..1 (buka naik, tutup turun). */
    protected final float screenAlpha() {
        if (closeTimeline != null) {
            return 1f - Anim.easeInOutCubic(closeTimeline.progress());
        }
        return openProgress();
    }

    protected boolean shouldCloseNow() {
        return closeTimeline != null && closeTimeline.progress() >= 1f;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        if (bgDrawn) {
            return;
        }
        bgDrawn = true;
        drawDim(context);
    }

    /** Latar redup gradien - override bila layar ingin dunia tetap terlihat jernih. */
    protected void drawDim(DrawContext context) {
        float a = screenAlpha();
        context.fillGradient(0, 0, this.width, this.height,
                Anim.withAlpha(0xC0050507, a), Anim.withAlpha(0xE0000000, a));
    }

    /** Panggil di awal render() milik subclass. */
    protected final void beginFrame(DrawContext context, int mouseX, int mouseY, float delta) {
        bgDrawn = false;
        this.renderBackground(context, mouseX, mouseY, delta);
        if (shouldCloseNow() && this.client != null) {
            this.client.setScreen(parent);
        }
    }

    /** Panggil di akhir render() milik subclass. */
    protected final void endFrame() {
        bgDrawn = false;
    }

    @Override
    public void close() {
        if (closeTimeline == null) {
            onClosing();
            closeTimeline = new Anim.Timeline(CLOSE_MS);
        }
    }

    /** Hook (mis. simpan config) tepat sebelum animasi tutup dimulai. */
    protected void onClosing() {
    }

    /** Tombol transparan penuh - hanya dipakai sebagai area klik untuk visual yang digambar manual. */
    protected static ButtonWidget hitArea(Runnable onClick) {
        ButtonWidget button = ButtonWidget.builder(Text.empty(), b -> onClick.run())
                .dimensions(0, 0, 10, 10)
                .build();
        button.setAlpha(0f);
        return button;
    }

    protected static void place(ButtonWidget w, int x, int y, int width, int height) {
        w.setX(x);
        w.setY(y);
        w.setWidth(width);
        w.setHeight(height);
    }
}

package com.xoldium.xoldiummod.client.render.motionblur;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.MappableRingBuffer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import java.util.OptionalInt;

/**
 * Velocity-based reprojection motion blur ("Natural Motion Blur" look).
 *
 * <p>PORTING NOTE (untuk pemakai): kelas ini adalah PORTING LANGSUNG dari
 * source code "Smooth Motion Blur" (by Jahleel) yang dikirim - build
 * {@code yarn_mappings=1.21.11+build.6} pada {@code gradle.properties}
 * mod referensi tsb SAMA PERSIS dengan build Yarn proyek Xoldium, jadi
 * SELURUH API GPU (RenderPipeline/GpuDevice/RenderPass/dst di bawah) bisa
 * dipindah nyaris apa adanya - hanya namespace {@code Identifier}
 * ("motionblur" -> "xoldiummod") & sumber nilai konfigurasi (dulu
 * {@code MotionBlurConfig} JSON terpisah, sekarang {@link MotionBlurModule}
 * lewat sistem Setting Xoldium sendiri, supaya muncul di gear-icon
 * ModuleSettingsScreen seperti modul lain) yang diubah.
 *
 * <p>Teknik blur diadaptasi dari "Natural Motion Blur" oleh ItsPasi
 * (LGPL-3.0-only, https://github.com/ItsPasi/natural-motionblur-fabric),
 * lewat porting "Smooth Motion Blur" oleh Jahleel - PENTING: shader
 * fragment ({@code assets/xoldiummod/shaders/post/motion_blur.fsh}) juga
 * disalin dari mod tsb tanpa perubahan logika, jadi lisensi LGPL-3.0
 * teknik ini tetap berlaku untuk file itu & kelas ini - pertahankan
 * atribusi ini bila didistribusikan.
 *
 * <p>Diimplementasikan murni di atas abstraksi {@code GpuDevice}/
 * {@code RenderPass} vanilla (bukan OpenGL mentah), supaya backend
 * pengganti seperti VulkanMod tetap berfungsi.
 */
public final class MotionBlurRenderer {

    private static final int MAX_SAMPLES = 100;
    private static final int UBO_SIZE = new Std140SizeCalculator()
            .putMat4f().putMat4f().putMat4f().putMat4f()
            .putVec3().putVec2().putFloat().putInt().putInt().putInt().putInt()
            .get();

    public static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder()
                    .withLocation(Identifier.of(XoldiumMod.MOD_ID, "pipeline/motion_blur"))
                    .withVertexShader("core/screenquad")
                    .withFragmentShader(Identifier.of(XoldiumMod.MOD_ID, "post/motion_blur"))
                    .withSampler("MainSampler")
                    .withSampler("MainDepthSampler")
                    .withUniform("MotionBlurUniforms", UniformType.UNIFORM_BUFFER)
                    .withoutBlend()
                    .withDepthWrite(false)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withVertexFormat(VertexFormats.EMPTY, VertexFormat.DrawMode.TRIANGLES)
                    .build());

    // Matriks yang ditangkap di awal world render frame ini.
    private static final Matrix4f modelView = new Matrix4f();
    private static final Matrix4f projection = new Matrix4f();
    private static final Matrix4f prevModelView = new Matrix4f();
    private static final Matrix4f prevProjection = new Matrix4f();
    private static final Matrix4f mvInverse = new Matrix4f();
    private static final Matrix4f projInverse = new Matrix4f();
    private static double camX, camY, camZ;
    private static double prevCamX, prevCamY, prevCamZ;
    private static boolean frameCaptured;
    private static boolean prevFrameReady;
    private static boolean blurRan;

    private static GpuTexture blurTarget;
    private static GpuTextureView blurTargetView;
    private static MappableRingBuffer uniformBuffer;
    private static boolean loggedFirstPass;

    private MotionBlurRenderer() {
    }

    /** Lupakan state frame sebelumnya - frame berikutnya akan menyeed ulang. Dipanggil saat modul dimatikan. */
    public static void reset() {
        prevFrameReady = false;
        frameCaptured = false;
        blurRan = false;
    }

    /** Dipanggil dari mixin WorldRenderer di awal tiap world render. */
    public static void captureFrame(Matrix4fc currentModelView, Matrix4fc currentProjection, Vec3d cameraPos) {
        if (frameCaptured) {
            // World render kedua di frame yang sama (mis. panorama) - pertahankan capture pertama.
            return;
        }
        modelView.set(currentModelView);
        projection.set(currentProjection);
        camX = cameraPos.x;
        camY = cameraPos.y;
        camZ = cameraPos.z;
        frameCaptured = true;
    }

    /** Dipanggil dari mixin GameRenderer tepat setelah world selesai dirender. */
    public static void onWorldRendered(MinecraftClient client) {
        boolean wantBlur = MotionBlurModule.isActive()
                && client.world != null
                && (!MotionBlurModule.pauseInGuis() || client.currentScreen == null);

        if (!frameCaptured) {
            blurRan = false;
            return;
        }
        frameCaptured = false;

        if (wantBlur && prevFrameReady) {
            renderBlur(client);
            blurRan = true;
        } else {
            blurRan = false;
        }

        prevModelView.set(modelView);
        prevProjection.set(projection);
        prevCamX = camX;
        prevCamY = camY;
        prevCamZ = camZ;
        prevFrameReady = true;
    }

    private static void renderBlur(MinecraftClient client) {
        Framebuffer main = client.getFramebuffer();
        GpuTexture color = main.getColorAttachment();
        GpuTextureView colorView = main.getColorAttachmentView();
        GpuTextureView depthView = main.getDepthAttachmentView();
        if (color == null || colorView == null || depthView == null) {
            return;
        }

        int width = main.textureWidth;
        int height = main.textureHeight;
        GpuDevice device = RenderSystem.getDevice();
        CommandEncoder encoder = device.createCommandEncoder();

        if (blurTarget == null || blurTarget.getWidth(0) != width || blurTarget.getHeight(0) != height) {
            closeTarget();
            blurTarget = device.createTexture(() -> "Xoldium motion blur target",
                    GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_TEXTURE_BINDING,
                    TextureFormat.RGBA8, width, height, 1, 1);
            blurTargetView = device.createTextureView(blurTarget);
        }
        if (uniformBuffer == null) {
            uniformBuffer = new MappableRingBuffer(() -> "Xoldium motion blur uniforms",
                    GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE, UBO_SIZE);
        }

        mvInverse.set(modelView).invert();
        projInverse.set(projection).invert();

        // Third person / menunggangi: kamera mengorbit/mengikuti pemain, jadi velocity
        // berbasis kamera akan mengaburkan seluruh layar termasuk tengahnya. Pakai
        // velocity per-piksel asli dari depth di situasi itu.
        boolean firstPersonOnFoot = client.options.getPerspective().isFirstPerson()
                && (client.player == null || !client.player.hasVehicle());

        try (GpuBuffer.MappedView mapped = encoder.mapBuffer(uniformBuffer.getBlocking(), false, true)) {
            Std140Builder.intoBuffer(mapped.data())
                    .putMat4f(mvInverse)
                    .putMat4f(projInverse)
                    .putMat4f(prevModelView)
                    .putMat4f(prevProjection)
                    .putVec3((float) (camX - prevCamX), (float) (camY - prevCamY), (float) (camZ - prevCamZ))
                    .putVec2(width, height)
                    .putFloat(MotionBlurModule.strength())
                    .putInt(MAX_SAMPLES)
                    .putInt(firstPersonOnFoot ? 0 : 1)
                    .putInt(0) // debug mode - fitur /motionblur debug dari mod asli sengaja tidak diporting
                    .putInt(depthSamplingWorks() ? 1 : 0);
        }

        if (!loggedFirstPass) {
            loggedFirstPass = true;
            XoldiumMod.LOGGER.info("[Xoldium] Motion blur pass berjalan: {}x{}, strength={}, backend={}",
                    width, height, MotionBlurModule.strength(), device.getBackendName());
        }

        try (RenderPass pass = encoder.createRenderPass(() -> "Xoldium motion blur", blurTargetView, OptionalInt.empty())) {
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("MotionBlurUniforms", uniformBuffer.getBlocking());
            pass.bindTexture("MainSampler", colorView, RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
            pass.bindTexture("MainDepthSampler", depthView, RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
            pass.draw(0, 3);
        }

        // Blit hasil balik ke framebuffer utama lewat fullscreen pass (bukan
        // copyTextureToTexture: di VulkanMod 0.6.x itu no-op belum diimplementasi,
        // yang membuat blur tidak terlihat sama sekali di backend Vulkan).
        try (RenderPass pass = encoder.createRenderPass(() -> "Xoldium motion blur blit", colorView, OptionalInt.empty())) {
            pass.setPipeline(RenderPipelines.TRACY_BLIT);
            RenderSystem.bindDefaultUniforms(pass);
            pass.bindTexture("InSampler", blurTargetView, RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
            pass.draw(0, 3);
        }
        uniformBuffer.rotate();
    }

    /** Backend VulkanMod tidak bisa sample depth attachment utama (selalu baca nol) - fallback ke blur murni berbasis gerakan kamera. */
    private static boolean depthSamplingWorks() {
        String backend = RenderSystem.getDevice().getBackendName();
        return backend == null || !backend.toLowerCase().contains("vulkan");
    }

    private static void closeTarget() {
        if (blurTargetView != null) {
            blurTargetView.close();
            blurTargetView = null;
        }
        if (blurTarget != null) {
            blurTarget.close();
            blurTarget = null;
        }
    }
}

package com.xoldium.xoldiummod.client.module.msg;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Auto GG (kategori MSG) - otomatis mengirim "gg" ke chat saat game selesai.
 *
 * <p>PORTING dari source "AutoGG-Fabric" (EinsLucaaa) yang dikirim pemakai.
 * Logika deteksinya SAMA: daftar server ({@code servers.json}: {@code hosts}
 * = alamat server, {@code identifiers} = potongan pesan penanda game selesai,
 * {@code separators} = karakter yang bila ada di pesan membuat pesan diabaikan,
 * pengaman agar chat pemain lain yang kebetulan menulis kalimat serupa tidak
 * memicu GG) dibaca dari file bawaan yang SAMA persis dengan milik mod
 * referensi, lalu tiap pesan game yang masuk dicocokkan ke alamat server yang
 * sedang dimasuki.
 *
 * <p>Perbedaan yang disengaja dari mod referensi (semuanya demi stabilitas):
 * <ul>
 *   <li>Mod referensi (mapping Mojang, MC 26.x) memakai AutoConfig/Cloth dan
 *       mengunduh {@code servers.json} dari GitHub saat start (memblokir
 *       thread game bila internet lambat). Di sini daftar dibaca HANYA dari
 *       file bawaan - tanpa jaringan, tanpa dependency tambahan.</li>
 *   <li>Mod referensi membuat thread {@code ScheduledExecutor} baru tiap kali
 *       GG dikirim. Di sini jeda dihitung lewat tick client
 *       ({@link #onClientTick()}), jadi semua berjalan di thread utama.</li>
 *   <li>Pesan GG & jeda dipilih lewat setting modul (bukan file config
 *       terpisah). Pengaman anti-ganda 15 detik tetap ada.</li>
 *   <li>Opsi "All Servers": deteksi umum (kata kunci "you won", "game over",
 *       dsb) untuk server yang tidak ada di daftar bawaan - default OFF.</li>
 * </ul>
 */
public final class AutoGgModule extends Module {

    private static final int RESET_TICKS = 15 * 20;

    /** Kata kunci umum untuk opsi All Servers (huruf kecil). */
    private static final String[] GENERIC_TRIGGERS = {
            "game over", "you won", "you win", "has won the game", "has won the match", "won the duel",
            "victory!", "winner", "match over", "match ended", "duel ended", "duel over", "game ended",
            "game has ended", "pemenang", "kamu menang", "anda menang", "permainan selesai"
    };

    private static final String[] MESSAGES = {"gg", "GG", "gg wp", "GG WP", "good game", "good game, well played"};

    private final ModeSetting message = addSetting(new ModeSetting("message", "setting.xoldiummod.autogg.message", 0,
            MESSAGES));
    private final DoubleSetting delay = addSetting(new DoubleSetting("delay", "setting.xoldiummod.autogg.delay",
            1.0, 0.0, 5.0, 0.5));
    private final BooleanSetting allServers = addSetting(new BooleanSetting("all_servers",
            "setting.xoldiummod.autogg.all_servers", true));

    private final List<ServerEntry> servers = new ArrayList<>();

    private int pendingTicks = -1;   // >= 0: menunggu jeda sebelum mengirim
    private int cooldownTicks = 0;   // > 0: GG baru saja terkirim, abaikan pemicu berikutnya

    public AutoGgModule() {
        super("auto_gg", "module.xoldiummod.auto_gg", ModuleCategory.MSG, false);
        loadServers();
        ClientReceiveMessageEvents.GAME.register((text, overlay) -> {
            if (overlay || !isEnabled()) {
                return;
            }
            try {
                onGameMessage(text.getString());
            } catch (Throwable t) {
                markCrashed(t);
            }
        });
    }

    @Override
    protected void onToggle(boolean enabled) {
        pendingTicks = -1;
        cooldownTicks = 0;
    }

    @Override
    public void onClientTick() {
        if (cooldownTicks > 0) {
            cooldownTicks--;
        }
        if (pendingTicks >= 0) {
            if (pendingTicks == 0) {
                pendingTicks = -1;
                send();
            } else {
                pendingTicks--;
            }
        }
    }

    // ------------------------------------------------------------------

    private void onGameMessage(String text) {
        if (text == null || text.isEmpty() || cooldownTicks > 0 || pendingTicks >= 0) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        ServerInfo info = client.getCurrentServerEntry();
        if (info == null || info.address == null) {
            return; // singleplayer - tidak ada game minigame untuk di-GG
        }
        String address = info.address.toLowerCase(Locale.ROOT);

        boolean matched = false;
        for (ServerEntry server : servers) {
            if (!server.matchesAddress(address)) {
                continue;
            }
            if (server.isFiltered(text)) {
                continue; // mengandung pemisah -> kemungkinan chat pemain, bukan pesan sistem
            }
            if (server.matchesIdentifier(text)) {
                matched = true;
                break;
            }
        }
        if (!matched && allServers.get()) {
            String lower = text.toLowerCase(Locale.ROOT);
            for (String trigger : GENERIC_TRIGGERS) {
                if (lower.contains(trigger) && !lower.contains("<") && !lower.contains("»") && !lower.contains(">")
                        && !lower.matches("^\\[?[\\w .\\-]{1,24}\\]?\\s*[:\\u00bb].*")) {
                    matched = true;
                    break;
                }
            }
        }
        if (matched) {
            pendingTicks = Math.round((float) (delay.get() * 20.0));
            cooldownTicks = RESET_TICKS;
        }
    }

    private void send() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) {
            return;
        }
        String text = MESSAGES[Math.max(0, Math.min(MESSAGES.length - 1, message.index()))];
        client.getNetworkHandler().sendChatMessage(text);
    }

    // ------------------------------------------------------------------
    // Data server (servers.json bawaan mod referensi)
    // ------------------------------------------------------------------

    private void loadServers() {
        try (InputStream in = AutoGgModule.class.getResourceAsStream("/assets/xoldiummod/autogg/servers.json")) {
            if (in == null) {
                XoldiumMod.LOGGER.warn("[Xoldium] Auto GG: servers.json bawaan tidak ditemukan.");
                return;
            }
            Wrapper wrapper = new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), Wrapper.class);
            if (wrapper == null || wrapper.servers == null) {
                return;
            }
            for (ServerEntry entry : wrapper.servers) {
                if (entry != null) {
                    servers.add(entry);
                }
            }
            XoldiumMod.LOGGER.info("[Xoldium] Auto GG: {} konfigurasi server dimuat.", servers.size());
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Auto GG: gagal membaca servers.json (modul tetap jalan, tanpa daftar server).", t);
        }
    }

    private static final class Wrapper {
        @SerializedName("servers")
        List<ServerEntry> servers;
    }

    private static final class ServerEntry {
        @SerializedName("hosts")
        List<String> hosts;
        @SerializedName("identifiers")
        List<String> identifiers;
        @SerializedName("separators")
        List<String> separators;

        boolean matchesAddress(String lowerAddress) {
            if (hosts == null) {
                return false;
            }
            for (String host : hosts) {
                if (host != null && lowerAddress.contains(host.toLowerCase(Locale.ROOT))) {
                    return true;
                }
            }
            return false;
        }

        boolean isFiltered(String text) {
            if (separators == null) {
                return false;
            }
            for (String s : separators) {
                if (s != null && !s.isEmpty() && text.contains(s)) {
                    return true;
                }
            }
            return false;
        }

        boolean matchesIdentifier(String text) {
            if (identifiers == null) {
                return false;
            }
            for (String id : identifiers) {
                if (id != null && !id.isEmpty() && text.contains(id)) {
                    return true;
                }
            }
            return false;
        }
    }
}

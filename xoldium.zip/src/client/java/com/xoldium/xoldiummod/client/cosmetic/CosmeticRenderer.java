package com.xoldium.xoldiummod.client.cosmetic;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Proxy;
import java.util.UUID;

/**
 * Menggambar cosmetic di dunia: milik sendiri (third person) dan milik pengguna XoldiumClient lain yang
 * pilihannya diterima lewat {@link CosmeticSync}. Geometri = quad berwarna ({@code RenderLayer#getDebugQuads},
 * jalur yang sama dengan Custom Block Highlight), dipasang pada pivot leher & mengikuti yaw badan / yaw+pitch kepala.
 */
public final class CosmeticRenderer {

    /** Tinggi pivot leher (1.5 blok x skala model pemain 0.9375). */
    private static final float NECK = 1.5f * 0.9375f;
    private static final float SCALE = 0.9375f;

    private static boolean broken = false;
    private static Method tickMethod;
    private static boolean tickResolved = false;

    // --- urutan gambar: cosmetic DIGAMBAR PALING AKHIR di frame (event END) bila terbukti aman ---
    // Dulu digambar di AFTER_ENTITIES; awan (digambar sesudahnya) menimpa cosmetic sehingga topi/sayap tampak
    // "tembus" awan. Di END semua awan/partikel sudah selesai, jadi cosmetic selalu di atas dan diuji kedalaman
    // terhadap dunia. END hanya dipakai setelah matriks kamera di END terbukti SAMA dengan di AFTER_ENTITIES
    // (kalau tidak, tetap pakai AFTER_ENTITIES seperti sebelumnya, jadi posisi tidak pernah meleset).
    private static boolean endRegistered = false;
    private static boolean useEnd = false;
    private static int verified = 0;
    private static int mismatches = 0;
    private static long frameNo = 0;
    private static long snapFrame = -1;
    private static Matrix4f snapStack;
    private static Matrix4f snapMv;
    private static Method mvMethod;
    private static boolean mvResolved = false;

    private CosmeticRenderer() {
    }

    public static void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(CosmeticRenderer::afterEntities);
        try {
            Field f = WorldRenderEvents.class.getField("END");
            Object event = f.get(null);
            Class<?> listener = (Class<?>) ((ParameterizedType) f.getGenericType()).getActualTypeArguments()[0];
            Object proxy = Proxy.newProxyInstance(listener.getClassLoader(), new Class<?>[]{listener}, (p, m, a) -> {
                if (m.getDeclaringClass() == Object.class) {
                    return switch (m.getName()) {
                        case "hashCode" -> System.identityHashCode(p);
                        case "equals" -> p == (a == null ? null : a[0]);
                        default -> "XoldiumCosmeticEnd";
                    };
                }
                if (a != null && a.length == 1 && a[0] instanceof WorldRenderContext c) {
                    atEnd(c);
                }
                return null;
            });
            net.fabricmc.fabric.api.event.Event.class.getMethod("register", Object.class).invoke(event, proxy);
            endRegistered = true;
        } catch (Throwable t) {
            endRegistered = false; // tetap pakai AFTER_ENTITIES
        }
    }

    private static Matrix4f readModelView() {
        try {
            if (!mvResolved) {
                mvResolved = true;
                for (Method m : RenderSystem.class.getDeclaredMethods()) {
                    if (Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0
                            && m.getReturnType() == Matrix4fStack.class) {
                        m.setAccessible(true);
                        mvMethod = m;
                        break;
                    }
                }
            }
            if (mvMethod != null) {
                Object r = mvMethod.invoke(null);
                if (r instanceof Matrix4f mat) {
                    return new Matrix4f(mat);
                }
            }
        } catch (Throwable ignored) {
            // tidak bisa dibaca -> END tidak akan diverifikasi
        }
        return null;
    }

    private static void afterEntities(WorldRenderContext ctx) {
        frameNo++;
        if (useEnd) {
            return;
        }
        try {
            MatrixStack st = ctx.matrixStack();
            snapStack = st != null ? new Matrix4f(WorldOverlay.positionMatrix(st)) : null;
            snapMv = readModelView();
            snapFrame = frameNo;
        } catch (Throwable t) {
            snapFrame = -1;
        }
        render(ctx);
    }

    private static void atEnd(WorldRenderContext ctx) {
        if (!endRegistered || broken) {
            return;
        }
        if (useEnd) {
            if (!render(ctx)) {
                // provider tidak tersedia di END: kembali ke AFTER_ENTITIES
                useEnd = false;
                endRegistered = false;
            }
            return;
        }
        try {
            boolean ok = snapFrame == frameNo && (snapStack != null || snapMv != null);
            if (ok && snapStack != null) {
                MatrixStack st = ctx.matrixStack();
                ok = st != null && new Matrix4f(WorldOverlay.positionMatrix(st)).equals(snapStack, 1.0e-4f);
            }
            if (ok && snapMv != null) {
                Matrix4f now = readModelView();
                ok = now != null && now.equals(snapMv, 1.0e-4f);
            }
            if (ok && ctx.consumers() == null) {
                ok = false;
            }
            if (ok) {
                if (++verified >= 5) {
                    useEnd = true;
                }
            } else {
                verified = 0;
                if (++mismatches > 40) {
                    endRegistered = false; // menyerah: tetap AFTER_ENTITIES
                }
            }
        } catch (Throwable t) {
            endRegistered = false;
        }
    }

    private static float tickDelta(MinecraftClient mc) {
        try {
            RenderTickCounter counter = mc.getRenderTickCounter();
            if (!tickResolved) {
                tickResolved = true;
                for (Method m : RenderTickCounter.class.getMethods()) {
                    if (m.getReturnType() == float.class && m.getParameterCount() == 1
                            && m.getParameterTypes()[0] == boolean.class) {
                        tickMethod = m;
                        break;
                    }
                }
            }
            if (tickMethod != null) {
                return (Float) tickMethod.invoke(counter, false);
            }
        } catch (Throwable ignored) {
            // jatuh ke 1.0
        }
        return 1.0f;
    }

    /** @return false hanya bila VertexConsumerProvider tidak tersedia di event ini. */
    private static boolean render(WorldRenderContext ctx) {
        if (broken) {
            return true;
        }
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.world == null || mc.player == null) {
                return true;
            }
            MatrixStack stack = WorldOverlay.matrices(ctx);
            if (stack == null) {
                return true;
            }
            VertexConsumer vc = null;
            Vec3d cam = WorldOverlay.camera(ctx);
            float td = tickDelta(mc);
            boolean first = mc.options.getPerspective().isFirstPerson();
            for (PlayerEntity p : mc.world.getPlayers()) {
                boolean self = p == mc.player;
                if (self && first) {
                    continue;
                }
                if (p.isInvisible() || p.isSpectator()) {
                    continue;
                }
                int headIdx;
                int backIdx;
                if (self) {
                    headIdx = Cosmetics.myHead();
                    backIdx = Cosmetics.myBack();
                } else {
                    if (!Cosmetics.showOthers()) {
                        continue;
                    }
                    int[] l = CosmeticSync.of(p.getUuid());
                    if (l == null) {
                        continue;
                    }
                    headIdx = l[0];
                    backIdx = l[1];
                }
                if (headIdx == 0 && backIdx == 0) {
                    continue;
                }
                Vec3d pos = p.getLerpedPos(td);
                double dx = pos.x - cam.x, dy = pos.y - cam.y, dz = pos.z - cam.z;
                if (dx * dx + dy * dy + dz * dz > 64.0 * 64.0) {
                    continue;
                }
                EntityPose pose = p.getPose();
                boolean sneaking = pose == EntityPose.CROUCHING;
                if (pose != EntityPose.STANDING && !sneaking) {
                    continue; // berenang / terbang elytra / tidur: lewati (hindari posisi salah)
                }
                if (vc == null) {
                    vc = WorldOverlay.quadConsumer(ctx);
                    if (vc == null) {
                        return false;
                    }
                }
                float light = 0.5f + 0.5f * (mc.world.getLightLevel(BlockPos.ofFloored(pos.x, pos.y + 1.2, pos.z)) / 15f);
                float bodyYaw = MathHelper.lerpAngleDegrees(td, p.lastBodyYaw, p.bodyYaw);
                float headYaw = MathHelper.lerpAngleDegrees(td, p.lastHeadYaw, p.headYaw);
                float pitch = p.getPitch(td);
                float neck = sneaking ? NECK - 0.2f : NECK;

                Matrix4f base = new Matrix4f(WorldOverlay.positionMatrix(stack));
                base.translate((float) dx, (float) (dy + neck), (float) dz);

                Cosmetics.Def back = Cosmetics.back(backIdx);
                if (back != null) {
                    Matrix4f m = new Matrix4f(base);
                    m.rotateY((float) Math.toRadians(180.0 - bodyYaw));
                    if (sneaking) {
                        m.rotateX(-0.45f);
                    }
                    m.translate(0f, 0f, com.xoldium.xoldiummod.client.gui.PlayerPreview.BACK_PUSH);
                    m.scale(SCALE);
                    draw(vc, m, back, light);
                }
                Cosmetics.Def head = Cosmetics.head(headIdx);
                if (head != null) {
                    Matrix4f m = new Matrix4f(base);
                    m.rotateY((float) Math.toRadians(180.0 - headYaw));
                    m.rotateX((float) Math.toRadians(-pitch));
                    m.scale(SCALE);
                    draw(vc, m, head, light);
                }
            }
            if (vc != null) {
                WorldOverlay.flush(ctx);
            }
            return true;
        } catch (Throwable t) {
            broken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Render cosmetic dimatikan karena error (client tetap normal).", t);
            return true;
        }
    }

    private static void draw(VertexConsumer vc, Matrix4f m, Cosmetics.Def def, float light) {
        float[] q = def.quads();
        int[] c = def.colors();
        for (int i = 0; i < c.length; i++) {
            int col = c[i];
            int r = Math.min(255, (int) (((col >> 16) & 255) * light));
            int g = Math.min(255, (int) (((col >> 8) & 255) * light));
            int b = Math.min(255, (int) ((col & 255) * light));
            int argb = 0xFF000000 | (r << 16) | (g << 8) | b;
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vc.vertex(m, q[o + k * 3], q[o + k * 3 + 1], q[o + k * 3 + 2]).color(argb);
            }
        }
    }

}

package com.xoldium.xoldiummod.client.cosmetic;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Menggambar cosmetic di dunia: milik sendiri (third person) dan milik pengguna XoldiumClient lain yang
 * pilihannya diterima lewat {@link CosmeticSync}. Geometri = quad berwarna ({@code RenderLayer#getDebugQuads},
 * jalur yang sama dengan Custom Block Highlight), dipasang pada pivot leher & mengikuti yaw badan / yaw+pitch kepala.
 */
public final class CosmeticRenderer {

    /** Tinggi pivot leher (1.5 blok x skala model pemain 0.9375). */
    private static final float NECK = 1.5f * 0.9375f;
    private static final float SCALE = 0.9375f;

    private static boolean broken = false;
    private static Method tickMethod;
    private static boolean tickResolved = false;

    private CosmeticRenderer() {
    }

    public static void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(CosmeticRenderer::render);
    }

    private static float tickDelta(MinecraftClient mc) {
        try {
            RenderTickCounter counter = mc.getRenderTickCounter();
            if (!tickResolved) {
                tickResolved = true;
                for (Method m : RenderTickCounter.class.getMethods()) {
                    if (m.getReturnType() == float.class && m.getParameterCount() == 1
                            && m.getParameterTypes()[0] == boolean.class) {
                        tickMethod = m;
                        break;
                    }
                }
            }
            if (tickMethod != null) {
                return (Float) tickMethod.invoke(counter, false);
            }
        } catch (Throwable ignored) {
            // jatuh ke 1.0
        }
        return 1.0f;
    }

    private static void render(WorldRenderContext ctx) {
        if (broken) {
            return;
        }
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.world == null || mc.player == null) {
                return;
            }
            MatrixStack stack = WorldOverlay.matrices(ctx);
            if (stack == null) {
                return;
            }
            VertexConsumer vc = null;
            Vec3d cam = WorldOverlay.camera(ctx);
            float td = tickDelta(mc);
            boolean first = mc.options.getPerspective().isFirstPerson();
            for (PlayerEntity p : mc.world.getPlayers()) {
                boolean self = p == mc.player;
                if (self && first) {
                    continue;
                }
                if (p.isInvisible() || p.isSpectator()) {
                    continue;
                }
                int headIdx;
                int backIdx;
                if (self) {
                    headIdx = Cosmetics.myHead();
                    backIdx = Cosmetics.myBack();
                } else {
                    if (!Cosmetics.showOthers()) {
                        continue;
                    }
                    int[] l = CosmeticSync.of(p.getUuid());
                    if (l == null) {
                        continue;
                    }
                    headIdx = l[0];
                    backIdx = l[1];
                }
                if (headIdx == 0 && backIdx == 0) {
                    continue;
                }
                Vec3d pos = p.getLerpedPos(td);
                double dx = pos.x - cam.x, dy = pos.y - cam.y, dz = pos.z - cam.z;
                if (dx * dx + dy * dy + dz * dz > 64.0 * 64.0) {
                    continue;
                }
                EntityPose pose = p.getPose();
                boolean sneaking = pose == EntityPose.CROUCHING;
                if (pose != EntityPose.STANDING && !sneaking) {
                    continue; // berenang / terbang elytra / tidur: lewati (hindari posisi salah)
                }
                if (vc == null) {
                    vc = WorldOverlay.quadConsumer(ctx);
                    if (vc == null) {
                        return;
                    }
                }
                float light = 0.5f + 0.5f * (mc.world.getLightLevel(BlockPos.ofFloored(pos.x, pos.y + 1.2, pos.z)) / 15f);
                float bodyYaw = MathHelper.lerpAngleDegrees(td, p.lastBodyYaw, p.bodyYaw);
                float headYaw = MathHelper.lerpAngleDegrees(td, p.lastHeadYaw, p.headYaw);
                float pitch = p.getPitch(td);
                float neck = sneaking ? NECK - 0.2f : NECK;

                Matrix4f base = new Matrix4f(WorldOverlay.positionMatrix(stack));
                base.translate((float) dx, (float) (dy + neck), (float) dz);

                Cosmetics.Def back = Cosmetics.back(backIdx);
                if (back != null) {
                    Matrix4f m = new Matrix4f(base);
                    m.rotateY((float) Math.toRadians(180.0 - bodyYaw));
                    if (sneaking) {
                        m.rotateX(-0.45f);
                    }
                    m.scale(SCALE);
                    draw(vc, m, back, light);
                }
                Cosmetics.Def head = Cosmetics.head(headIdx);
                if (head != null) {
                    Matrix4f m = new Matrix4f(base);
                    m.rotateY((float) Math.toRadians(180.0 - headYaw));
                    m.rotateX((float) Math.toRadians(-pitch));
                    m.scale(SCALE);
                    draw(vc, m, head, light);
                }
            }
            if (vc != null) {
                WorldOverlay.flush(ctx);
            }
        } catch (Throwable t) {
            broken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Render cosmetic dimatikan karena error (client tetap normal).", t);
        }
    }

    private static void draw(VertexConsumer vc, Matrix4f m, Cosmetics.Def def, float light) {
        float[] q = def.quads();
        int[] c = def.colors();
        for (int i = 0; i < c.length; i++) {
            int col = c[i];
            int r = Math.min(255, (int) (((col >> 16) & 255) * light));
            int g = Math.min(255, (int) (((col >> 8) & 255) * light));
            int b = Math.min(255, (int) ((col & 255) * light));
            int argb = 0xFF000000 | (r << 16) | (g << 8) | b;
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vc.vertex(m, q[o + k * 3], q[o + k * 3 + 1], q[o + k * 3 + 2]).color(argb);
            }
        }
    }

}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Keystrokes - tombol W/A/S/D + SPACE + klik kiri/kanan. Tiap tombol memudar halus saat ditekan/dilepas
 * (putih penuh saat ditekan), dan tombol mouse menampilkan CPS-nya.
 */
public final class KeystrokesModule extends HudModule {

    private static final int BOX = 18;
    private static final int GAP = 2;

    private final Map<String, Anim.Smooth> fades = new HashMap<>();
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeft;
    private boolean wasRight;

    public KeystrokesModule() {
        super("keystrokes", "module.xoldiummod.keystrokes", false, 4f, 4f, 0.0);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        boolean l = client.options.attackKey.isPressed();
        if (l && !wasLeft) {
            leftClicks.addLast(now);
        }
        wasLeft = l;
        boolean r = client.options.useKey.isPressed();
        if (r && !wasRight) {
            rightClicks.addLast(now);
        }
        wasRight = r;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) {
            leftClicks.pollFirst();
        }
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) {
            rightClicks.pollFirst();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        var o = client.options;
        TextRenderer tr = client.textRenderer;
        int gridWidth = BOX * 3 + GAP * 2;
        int gridHeight = BOX * 3 + GAP * 2 + 12 + GAP;
        setMeasuredSize(gridWidth, gridHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        int step = BOX + GAP;
        drawKey(context, tr, step, 0, BOX, BOX, o.forwardKey, "W", null);
        drawKey(context, tr, 0, step, BOX, BOX, o.leftKey, "A", null);
        drawKey(context, tr, step, step, BOX, BOX, o.backKey, "S", null);
        drawKey(context, tr, step * 2, step, BOX, BOX, o.rightKey, "D", null);
        drawKey(context, tr, 0, step * 2, BOX + BOX / 2, BOX, o.attackKey, "LMB", leftClicks.size() + " CPS");
        drawKey(context, tr, step + BOX / 2 + GAP, step * 2, BOX + BOX / 2, BOX, o.useKey, "RMB", rightClicks.size() + " CPS");
        drawKey(context, tr, 0, step * 3, gridWidth, 12, o.jumpKey, "SPACE", null);
        context.getMatrices().popMatrix();
    }

    private void drawKey(DrawContext context, TextRenderer tr, int bx, int by, int bw, int bh, KeyBinding binding,
                         String label, String sub) {
        boolean pressed = binding.isPressed();
        float f = fades.computeIfAbsent(label, k -> new Anim.Smooth(0f, 18f)).update(pressed ? 1f : 0f);
        int bg = Anim.lerpColor(0x99101012, 0xF2FFFFFF, f);
        ScreenChrome.roundedFill(context, bx, by, bx + bw, by + bh, bg);
        ScreenChrome.roundedBorder(context, bx, by, bx + bw, by + bh, Anim.lerpColor(0x44FFFFFF, 0xFFFFFFFF, f));
        int text = Anim.lerpColor(0xFFFFFFFF, 0xFF000000, f);
        if (sub == null) {
            context.drawText(tr, label, bx + (bw - tr.getWidth(label)) / 2, by + (bh - tr.fontHeight) / 2 + 1, text, f < 0.5f);
        } else {
            context.drawText(tr, label, bx + (bw - tr.getWidth(label)) / 2, by + 3, text, f < 0.5f);
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(bx + bw / 2f, by + 11f);
            context.getMatrices().scale(0.7f, 0.7f);
            int sc = Anim.lerpColor(0xFFB0B0B0, 0xFF444444, f);
            context.drawText(tr, sub, -tr.getWidth(sub) / 2, 0, sc, false);
            context.getMatrices().popMatrix();
        }
    }
}

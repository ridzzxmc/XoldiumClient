package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Keystrokes - tombol W/A/S/D + SPACE + klik kiri/kanan. Tiap tombol memudar halus saat ditekan/dilepas
 * (putih penuh saat ditekan), dan tombol mouse menampilkan CPS-nya.
 */
public final class KeystrokesModule extends HudModule {

    private static final int BOX = 22;
    private static final int GAP = 3;

    private final Map<String, Anim.Smooth> fades = new HashMap<>();
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeft;
    private boolean wasRight;

    public KeystrokesModule() {
        super("keystrokes", "module.xoldiummod.keystrokes", false, 4f, 4f, 0.0);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        boolean l = client.options.attackKey.isPressed();
        if (l && !wasLeft) {
            leftClicks.addLast(now);
        }
        wasLeft = l;
        boolean r = client.options.useKey.isPressed();
        if (r && !wasRight) {
            rightClicks.addLast(now);
        }
        wasRight = r;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) {
            leftClicks.pollFirst();
        }
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) {
            rightClicks.pollFirst();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        var o = client.options;
        TextRenderer tr = client.textRenderer;
        // Tampilan mengikuti desain referensi: kotak abu-abu solid, W di atas, A-S-D, LMB/RMB + CPS, spasi bergaris.
        int gridWidth = BOX * 3 + GAP * 2;
        int step = BOX + GAP;
        int space = 14;
        setMeasuredSize(gridWidth, step * 3 + space);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        int mouseW = (gridWidth - GAP) / 2;
        drawKey(context, tr, step, 0, BOX, BOX, o.forwardKey, "W", null, 1.25f);
        drawKey(context, tr, 0, step, BOX, BOX, o.leftKey, "A", null, 1.25f);
        drawKey(context, tr, step, step, BOX, BOX, o.backKey, "S", null, 1.25f);
        drawKey(context, tr, step * 2, step, BOX, BOX, o.rightKey, "D", null, 1.25f);
        drawKey(context, tr, 0, step * 2, mouseW, BOX, o.attackKey, "LMB", leftClicks.size() + " CPS", 1.0f);
        drawKey(context, tr, mouseW + GAP, step * 2, gridWidth - mouseW - GAP, BOX, o.useKey, "RMB", rightClicks.size() + " CPS", 1.0f);
        drawKey(context, tr, 0, step * 3, gridWidth, space, o.jumpKey, "SPACE", null, 1.0f);
        context.getMatrices().popMatrix();
    }

    private void drawKey(DrawContext context, TextRenderer tr, int bx, int by, int bw, int bh, KeyBinding binding,
                         String label, String sub, float textScale) {
        boolean pressed = binding.isPressed();
        float f = fades.computeIfAbsent(label, k -> new Anim.Smooth(0f, 18f)).update(pressed ? 1f : 0f);
        // abu-abu solid (0x666666) -> terang saat ditekan
        int bg = Anim.lerpColor(0xFF666666, 0xFFC8C8C8, f);
        context.fill(bx, by, bx + bw, by + bh, bg);
        int text = Anim.lerpColor(0xFFFFFFFF, 0xFF1A1A1A, f);
        boolean shadow = f < 0.5f;
        if (label.equals("SPACE")) {
            int lw = Math.round(bw * 0.4f);
            int lx = bx + (bw - lw) / 2;
            int ly = by + bh / 2;
            context.fill(lx, ly - 1, lx + lw, ly + 1, text);
            return;
        }
        if (sub == null) {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(bx + bw / 2f, by + bh / 2f);
            context.getMatrices().scale(textScale, textScale);
            context.drawText(tr, label, -tr.getWidth(label) / 2, -tr.fontHeight / 2 + 1, text, shadow);
            context.getMatrices().popMatrix();
        } else {
            context.drawText(tr, label, bx + (bw - tr.getWidth(label)) / 2, by + 3, text, shadow);
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(bx + bw / 2f, by + 12f);
            context.getMatrices().scale(0.7f, 0.7f);
            int sc = Anim.lerpColor(0xFFFFFFFF, 0xFF1A1A1A, f);
            context.drawText(tr, sub, -tr.getWidth(sub) / 2, 0, sc, shadow);
            context.getMatrices().popMatrix();
        }
    }
}

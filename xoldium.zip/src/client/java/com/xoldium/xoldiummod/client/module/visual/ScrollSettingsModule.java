package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;

/**
 * Scroll Settings - mengatur apakah scroll wheel di atas elemen HUD di
 * {@code XoldiumHomeScreen} (HUD Editor) mengubah skalanya (0.5x - 3.0x),
 * dan seberapa besar perubahan per notch scroll (setting "Scale Step",
 * dulu tetap {@code 0.1f}). Dibaca lewat {@link #allowHudScaleScroll()} &
 * {@link #scaleStep()} - lihat pemanggilnya di
 * {@code XoldiumHomeScreen#mouseScrolled}.
 */
public final class ScrollSettingsModule extends Module {

    private static ScrollSettingsModule instance;

    private final DoubleSetting scaleStep = addSetting(
            new DoubleSetting("scale_step", "setting.xoldiummod.scroll_settings.scale_step", 0.1, 0.02, 0.5, 0.02));

    public ScrollSettingsModule() {
        super("scroll_settings", "module.xoldiummod.scroll_settings", ModuleCategory.VISUAL, true);
        instance = this;
    }

    public static boolean allowHudScaleScroll() {
        return instance == null || instance.isEnabled();
    }

    public static float scaleStep() {
        return instance != null ? instance.scaleStep.get().floatValue() : 0.1f;
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Cart Counter - menghitung TNT Minecart di inventori (untuk Cart PvP), port dari mod "Cart Counter"
 * (fishwithchipswastaken) yang dikirim pemakai. Logika sama: hitung semua {@code TNT_MINECART} di inventori,
 * tampilkan ikon + jumlah dengan warna berdasarkan ambang (merah <= 3, oranye <= 5, hijau di atasnya),
 * disembunyikan saat creative/spectator kecuali diaktifkan, dan tidak ditampilkan bila jumlah 0.
 *
 * <p>Beda dengan mod asli: tanpa Fzzy Config/keybind F8-F9 (diatur lewat Mod Menu Xoldium), posisi default di
 * kiri-atas hotbar seperti aslinya dan bisa digeser di HUD Editor.
 */
public final class CartCounterModule extends HudModule {

    private final BooleanSetting showInCreative = addSetting(
            new BooleanSetting("show_in_creative", "setting.xoldiummod.cart_counter.show_in_creative", false));
    private final BooleanSetting showInSpectator = addSetting(
            new BooleanSetting("show_in_spectator", "setting.xoldiummod.cart_counter.show_in_spectator", false));
    private final DoubleSetting redThreshold = addSetting(
            new DoubleSetting("red_threshold", "setting.xoldiummod.cart_counter.red_threshold", 3, 0, 64, 1));
    private final DoubleSetting orangeThreshold = addSetting(
            new DoubleSetting("orange_threshold", "setting.xoldiummod.cart_counter.orange_threshold", 5, 0, 64, 1));
    private final ColorSetting redColor = addSetting(
            new ColorSetting("red_color", "setting.xoldiummod.cart_counter.red_color", 0xFFFF5555, false));
    private final ColorSetting orangeColor = addSetting(
            new ColorSetting("orange_color", "setting.xoldiummod.cart_counter.orange_color", 0xFFFFAA00, false));
    private final ColorSetting greenColor = addSetting(
            new ColorSetting("green_color", "setting.xoldiummod.cart_counter.green_color", 0xFF55FF55, false));

    public CartCounterModule() {
        super("cart_counter", "module.xoldiummod.cart_counter", false, 4f, 4f, 0.45);
    }

    /** Posisi default (kiri hotbar) dihitung sendiri bila belum pernah digeser. */
    @Override
    public boolean wantsAutoPlace() {
        return false;
    }

    private boolean positioned = false;

    private void ensureDefaultPosition() {
        if (positioned) {
            return;
        }
        positioned = true;
        if (y <= 4f && x <= 4f) {
            MinecraftClient client = MinecraftClient.getInstance();
            int sw = client.getWindow().getScaledWidth();
            int sh = client.getWindow().getScaledHeight();
            setPosition(sw / 2f - 99f - 30f, sh - 52f);
        }
    }

    private static int countCarts(PlayerEntity player) {
        int count = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            if (player.getInventory().getStack(i).isOf(Items.TNT_MINECART)) {
                count += player.getInventory().getStack(i).getCount();
            }
        }
        return count;
    }

    private int colorFor(int count) {
        if (count <= redThreshold.get()) {
            return redColor.argb() | 0xFF000000;
        }
        if (count <= orangeThreshold.get()) {
            return orangeColor.argb() | 0xFF000000;
        }
        return greenColor.argb() | 0xFF000000;
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) {
            return;
        }
        if (client.player.isCreative() && !showInCreative.get()) {
            return;
        }
        if (client.player.isSpectator() && !showInSpectator.get()) {
            return;
        }
        ensureDefaultPosition();
        int count = countCarts(client.player);
        if (count <= 0) {
            return;
        }
        draw(context, count);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        ensureDefaultPosition();
        MinecraftClient client = MinecraftClient.getInstance();
        int count = client.player == null ? 9 : Math.max(1, countCarts(client.player));
        draw(context, count);
    }

    private void draw(DrawContext context, int count) {
        HudRenderUtil.drawCard(context, this, Items.TNT_MINECART, "TNT CARTS", String.valueOf(count),
                Math.min(1f, count / 16f), colorFor(count));
    }
}

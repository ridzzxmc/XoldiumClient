package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Hit Range - lingkaran jangkauan serang (default 3 blok) di kaki pemain lain
 * (dan diri sendiri bila "Show Self"), berubah warna saat pemain lain masuk
 * jangkauan. Porting konsep mod "Hit Range" (uku3lig, LGPL/MIT): mode
 * Line/Thick/Filled, radius, ketebalan, tinggi, warna in-range, nearest-only,
 * jarak maksimum & jumlah segmen - semua ada di Module Setting.
 *
 * <p>Digambar sebagai quad berwarna per-vertex lewat {@link WorldOverlay}
 * (bukan pipeline khusus per versi seperti mod referensi 26.x).
 */
public final class HitRangeModule extends Module {

    private final DoubleSetting radius = addSetting(
            new DoubleSetting("radius", "setting.xoldiummod.hitrange.radius", 3.0, 1.0, 8.0, 0.1));
    private final ModeSetting renderMode = addSetting(
            new ModeSetting("render_mode", "setting.xoldiummod.hitrange.render_mode", 1,
                    "setting.xoldiummod.hitrange.mode.line",
                    "setting.xoldiummod.hitrange.mode.thick",
                    "setting.xoldiummod.hitrange.mode.filled"));
    private final DoubleSetting thickness = addSetting(
            new DoubleSetting("thickness", "setting.xoldiummod.hitrange.thickness", 0.12, 0.02, 0.6, 0.01),
            () -> this.renderMode.index() != 2);
    private final DoubleSetting height = addSetting(
            new DoubleSetting("height", "setting.xoldiummod.hitrange.height", 0.02, 0.0, 1.5, 0.01));
    private final ColorSetting color = addSetting(
            new ColorSetting("color", "setting.xoldiummod.hitrange.color", 0x80FF3030, true));
    private final BooleanSetting colorWhenInRange = addSetting(
            new BooleanSetting("color_in_range", "setting.xoldiummod.hitrange.color_in_range", true));
    private final ColorSetting inRangeColor = addSetting(
            new ColorSetting("in_range_color", "setting.xoldiummod.hitrange.in_range_color", 0x8030FF60, true),
            () -> this.colorWhenInRange.get());
    private final BooleanSetting nearestOnly = addSetting(
            new BooleanSetting("nearest_only", "setting.xoldiummod.hitrange.nearest_only", false));
    private final BooleanSetting showSelf = addSetting(
            new BooleanSetting("show_self", "setting.xoldiummod.hitrange.show_self", false));
    private final DoubleSetting maxDistance = addSetting(
            new DoubleSetting("max_distance", "setting.xoldiummod.hitrange.max_distance", 40.0, 8.0, 128.0, 4.0));
    private final DoubleSetting segments = addSetting(
            new DoubleSetting("segments", "setting.xoldiummod.hitrange.segments", 64.0, 16.0, 128.0, 4.0));

    private boolean loggedError = false;

    public HitRangeModule() {
        super("hit_range", "module.xoldiummod.hit_range", ModuleCategory.VISUAL, false);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onAfterEntities);
    }

    private void onAfterEntities(WorldRenderContext context) {
        if (!isEnabled()) {
            return;
        }
        try {
            draw(context);
        } catch (Throwable t) {
            if (!loggedError) {
                loggedError = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Hit Range gagal menggambar (dilewati, tidak crash).", t);
            }
        }
    }

    private void draw(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        ClientPlayerEntity self = mc.player;
        if (world == null || self == null) {
            return;
        }
        MatrixStack matrices = WorldOverlay.matrices(context);
        if (matrices == null) {
            return;
        }
        float tickDelta = mc.getRenderTickCounter().getTickProgress(false);
        Vec3d cam = WorldOverlay.camera(context);
        Matrix4f m = WorldOverlay.positionMatrix(matrices);
        VertexConsumer vc = WorldOverlay.quadConsumer(context);

        Vec3d selfPos = self.getLerpedPos(tickDelta);
        double maxDist = maxDistance.get();
        double r = radius.get();

        AbstractClientPlayerEntity nearest = null;
        if (nearestOnly.get()) {
            double best = Double.MAX_VALUE;
            for (AbstractClientPlayerEntity p : world.getPlayers()) {
                if (p == self || !p.isAlive()) continue;
                double d = p.squaredDistanceTo(self);
                if (d < best) {
                    best = d;
                    nearest = p;
                }
            }
        }

        for (AbstractClientPlayerEntity p : world.getPlayers()) {
            boolean isSelf = p == self;
            if (isSelf && !showSelf.get()) continue;
            if (!p.isAlive() || p.isSpectator() || p.isInvisibleTo(self) && !isSelf) continue;
            if (nearestOnly.get() && !isSelf && p != nearest) continue;

            Vec3d pos = p.getLerpedPos(tickDelta);
            if (pos.squaredDistanceTo(selfPos) > maxDist * maxDist) continue;

            int col = color.argb();
            if (!isSelf && colorWhenInRange.get() && pos.distanceTo(selfPos) <= r) {
                col = inRangeColor.argb();
            }
            double y = pos.y + height.get() + (p.isSneaking() ? 0.125 : 0.0);
            ring(vc, m, pos.x - cam.x, y - cam.y, pos.z - cam.z, r, col);
        }
    }

    private void ring(VertexConsumer vc, Matrix4f m, double cx, double cy, double cz, double r, int col) {
        int n = (int) Math.round(segments.get());
        int mode = renderMode.index();
        double half = mode == 2 ? 0 : (mode == 0 ? Math.max(0.01, thickness.get() * 0.25) : thickness.get() / 2.0);
        double inner = Math.max(0.001, r - half);
        double outer = r + half;
        for (int i = 0; i < n; i++) {
            double a0 = 2.0 * Math.PI * i / n;
            double a1 = 2.0 * Math.PI * (i + 1) / n;
            double s0 = Math.sin(a0), c0 = Math.cos(a0), s1 = Math.sin(a1), c1 = Math.cos(a1);
            if (mode == 2) {
                // disk terisi: tiap irisan = quad (pusat, p0, p1, p1)
                WorldOverlay.quad(vc, m,
                        cx, cy, cz, col,
                        cx + outer * s0, cy, cz + outer * c0, col,
                        cx + outer * s1, cy, cz + outer * c1, col,
                        cx + outer * s1, cy, cz + outer * c1, col);
            } else {
                WorldOverlay.quad(vc, m,
                        cx + inner * s0, cy, cz + inner * c0, col,
                        cx + outer * s0, cy, cz + outer * c0, col,
                        cx + outer * s1, cy, cz + outer * c1, col,
                        cx + inner * s1, cy, cz + inner * c1, col);
            }
        }
    }
}

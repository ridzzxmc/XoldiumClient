package com.xoldium.xoldiummod.client.module.setting;

/**
 * Setting berbentuk TOMBOL: menjalankan sebuah aksi saat diklik di layar
 * Module Setting (mis. membuka editor Custom Crosshair). Tidak menyimpan
 * nilai apa pun ke config - {@link com.xoldium.xoldiummod.client.module.ModuleManager}
 * melewatinya begitu saja (sama seperti {@link KeybindSetting}).
 */
public final class ActionSetting extends ModuleSetting<Boolean> {

    private final Runnable action;

    public ActionSetting(String id, String nameKey, Runnable action) {
        super(id, nameKey, Boolean.FALSE);
        this.action = action;
    }

    public void run() {
        try {
            action.run();
        } catch (Throwable t) {
            com.xoldium.xoldiummod.XoldiumMod.LOGGER.warn("[Xoldium] Aksi setting '{}' gagal (dilewati).", id(), t);
        }
    }

    /** Aksi tidak punya nilai - reset tidak melakukan apa-apa (dan tidak memicu save). */
    @Override
    public void reset() {
    }
}

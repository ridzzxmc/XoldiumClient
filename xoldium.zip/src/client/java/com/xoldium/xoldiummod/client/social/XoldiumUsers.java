package com.xoldium.xoldiummod.client.social;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.visual.XoldiumTagModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Deteksi pemain lain yang juga memakai Xoldium Client TANPA server/plugin
 * khusus.
 *
 * <p>Cara kerja: Minecraft mengirim "opsi klien" (bahasa, render distance,
 * dan {@code playerModelParts} = bitmask lapisan skin) ke server saat masuk
 * dunia, lalu server menyiarkan byte lapisan skin itu ke SEMUA pemain lain
 * lewat data tracker pemain ({@code PlayerEntity.PLAYER_MODEL_PARTS}).
 * Vanilla hanya memakai bit 0-6; bit ke-7 ({@code 0x80}) tidak dipakai. Saat
 * modul Xoldium Tag aktif, {@code SyncedClientOptionsMixin} menyalakan bit
 * itu di opsi klien kita sendiri, dan di sisi pemain lain kita cukup membaca
 * bit tersebut - bila menyala, orang itu pasti memakai Xoldium Client.
 * Berjalan di server vanilla/Paper/dll yang meneruskan byte itu apa adanya;
 * server yang menyaring byte tsb otomatis membuat logo tidak muncul (aman,
 * tidak ada efek lain).
 */
public final class XoldiumUsers {

    /** Bit penanda pada byte lapisan skin. */
    public static final int MARKER_BIT = 0x80;

    /** Karakter glyph logo pada font {@code xoldiummod:xoldium_icons}. */
    public static final String LOGO_GLYPH = "\uE000";

    public static final Identifier ICON_FONT = Identifier.of(XoldiumMod.MOD_ID, "xoldium_icons");

    private static final Style LOGO_STYLE = Style.EMPTY
            .withColor(TextColor.fromRgb(0xFFFFFF))
            .withFont(ICON_FONT);

    private static List<TrackedData<?>> byteData;
    private static boolean resolveFailed = false;

    private XoldiumUsers() {
    }

    /** Teks logo + spasi kecil yang ditempel di depan nama. */
    public static MutableText logoPrefix() {
        return Text.literal(LOGO_GLYPH).setStyle(LOGO_STYLE).append(Text.literal(" ").setStyle(Style.EMPTY));
    }

    /** Apakah pemain ini memakai Xoldium Client (bit penanda menyala pada byte lapisan skin)? */
    public static boolean isXoldiumUser(PlayerEntity player) {
        if (player == null || resolveFailed) {
            return false;
        }
        try {
            List<TrackedData<?>> fields = fields();
            if (fields.isEmpty()) {
                return false;
            }
            for (TrackedData<?> data : fields) {
                Object value = player.getDataTracker().get(data);
                if (value instanceof Byte b && (b & MARKER_BIT) != 0) {
                    return true;
                }
            }
        } catch (Throwable t) {
            resolveFailed = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Deteksi pengguna Xoldium dimatikan (data tracker tidak terbaca).", t);
        }
        return false;
    }

    /**
     * Semua field static {@code TrackedData<Byte>} milik PlayerEntity
     * (lapisan skin + lengan utama). Nilai lengan utama hanya 0/1 sehingga
     * tidak pernah punya bit 0x80 - aman dicek bersama.
     */
    private static synchronized List<TrackedData<?>> fields() throws Exception {
        if (byteData != null) {
            return byteData;
        }
        List<TrackedData<?>> found = new ArrayList<>();
        for (Field f : PlayerEntity.class.getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers()) || f.getType() != TrackedData.class) {
                continue;
            }
            Type generic = f.getGenericType();
            if (generic instanceof ParameterizedType pt && pt.getActualTypeArguments().length == 1
                    && pt.getActualTypeArguments()[0] == Byte.class) {
                f.setAccessible(true);
                Object v = f.get(null);
                if (v instanceof TrackedData<?> td) {
                    found.add(td);
                }
            }
        }
        byteData = found;
        if (found.isEmpty()) {
            XoldiumMod.LOGGER.warn("[Xoldium] Tidak menemukan TrackedData<Byte> pada PlayerEntity - logo nametag tidak aktif.");
        }
        return byteData;
    }

    /** Dipakai {@code PlayerDisplayNameMixin}: tempelkan logo di depan nama pemain pengguna Xoldium. */
    public static Text decorate(PlayerEntity player, Text original) {
        if (!XoldiumTagModule.showLogo()) {
            return original;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        boolean self = client != null && player == client.player;
        boolean marked = self ? XoldiumTagModule.shouldBroadcast() : isXoldiumUser(player);
        if (!marked) {
            return original;
        }
        return Text.empty().append(logoPrefix()).append(original);
    }
}

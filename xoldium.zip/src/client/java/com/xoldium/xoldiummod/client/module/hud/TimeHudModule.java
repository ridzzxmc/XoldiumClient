package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Waktu dunia (tick) + fase siang/malam + bar. */
public final class TimeHudModule extends HudModule {

    public TimeHudModule() {
        super("time", "module.xoldiummod.time", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        long time = client.world.getTimeOfDay() % 24000L;
        String phase = time < 12000 ? "DAY" : time < 13000 ? "SUNSET" : time < 23000 ? "NIGHT" : "SUNRISE";
        HudRenderUtil.drawCard(context, this, time < 12000 || time >= 23000 ? Items.CLOCK : Items.ECHO_SHARD,
                "WORLD TIME  \u2022  " + phase, String.valueOf(time), time / 24000f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().world == null) {
            HudRenderUtil.drawCard(context, this, Items.CLOCK, "WORLD TIME  \u2022  DAY", "6000", 0.25f);
            return;
        }
        render(context, tickCounter);
    }
}

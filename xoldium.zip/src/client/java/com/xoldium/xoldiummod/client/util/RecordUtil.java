package com.xoldium.xoldiummod.client.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;

/**
 * Utilitas refleksi untuk record Minecraft. Semua akses berdasarkan URUTAN & TIPE
 * komponen (bukan nama) karena nama method/field Minecraft di game asli (1.21.11
 * masih ter-obfuscate) adalah nama intermediary, bukan nama Yarn.
 */
public final class RecordUtil {

    private RecordUtil() {
    }

    public static Object get(Object record, int index) throws Throwable {
        RecordComponent c = record.getClass().getRecordComponents()[index];
        Method accessor = c.getAccessor();
        accessor.setAccessible(true);
        return accessor.invoke(record);
    }

    /** Salinan {@code record} dengan komponen ke-{@code index} diganti {@code newValue}. */
    public static Object copyWith(Object record, int index, Object newValue) throws Throwable {
        Class<?> type = record.getClass();
        RecordComponent[] comps = type.getRecordComponents();
        Object[] values = new Object[comps.length];
        Class<?>[] types = new Class<?>[comps.length];
        for (int i = 0; i < comps.length; i++) {
            Method accessor = comps[i].getAccessor();
            accessor.setAccessible(true);
            values[i] = i == index ? newValue : accessor.invoke(record);
            types[i] = comps[i].getType();
        }
        Constructor<?> ctor = type.getDeclaredConstructor(types);
        ctor.setAccessible(true);
        return ctor.newInstance(values);
    }

    /** Indeks semua komponen yang bertipe persis {@code type}. */
    public static int[] indicesOfType(Class<?> recordClass, Class<?> type) {
        RecordComponent[] comps = recordClass.getRecordComponents();
        int n = 0;
        for (RecordComponent c : comps) {
            if (c.getType() == type) n++;
        }
        int[] out = new int[n];
        int k = 0;
        for (int i = 0; i < comps.length; i++) {
            if (comps[i].getType() == type) out[k++] = i;
        }
        return out;
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.client.option.KeyBinding;

/** Pengingat tombol pembuka menu Xoldium. */
public final class SettingsHintHudModule extends HudModule {

    public SettingsHintHudModule() {
        super("settings", "module.xoldiummod.settings", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        String key = "?";
        for (KeyBinding binding : client.options.allKeys) {
            if ("key.xoldiummod.open_menu".equals(binding.getTranslationKey())) {
                key = binding.getBoundKeyLocalizedText().getString();
                break;
            }
        }
        HudRenderUtil.drawCard(context, this, Items.REDSTONE_TORCH, "XOLDIUM MENU", key, -1f);
    }
}

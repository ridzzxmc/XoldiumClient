package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

public final class PotionHudModule extends HudModule {

    public PotionHudModule() {
        super("potion_hud", "module.xoldiummod.potion_hud", false, 4f, 200f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<String> lines = new ArrayList<>();
        for (StatusEffectInstance instance : client.player.getStatusEffects()) {
            String name = instance.getEffectType().value().getName().getString();
            int amplifier = instance.getAmplifier() + 1;
            int seconds = instance.getDuration() / 20;
            lines.add(name + " " + amplifier + " (" + (seconds / 60) + ":" + String.format("%02d", seconds % 60) + ")");
        }

        if (lines.isEmpty()) {
            return; // tidak ada efek aktif - tidak perlu gambar kotak kosong
        }
        HudRenderUtil.drawLines(context, this, lines.toArray(new String[0]));
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Potion HUD - desain baru:
 * <ul>
 *   <li><b>Cards</b> (default): kartu gelap membulat per efek - garis aksen berwarna efek di kiri, ikon di
 *       ubin kecil, nama + level (angka Romawi) dan sisa waktu, serta bar durasi tipis di bawah.
 *       Efek baru meluncur masuk, efek habis memudar & kartu di bawahnya turun halus (tinggi kartu
 *       ikut dianimasikan), dan kartu berkedip lembut saat sisa waktu &lt; 10 detik.</li>
 *   <li><b>List</b>: baris ringkas [ikon] nama level (waktu).</li>
 * </ul>
 * Ikon efek diambil dari {@code textures/mob_effect/<id>.png} (tidak memakai StatusEffectSpriteManager karena
 * bentuk API render-nya berubah antar rilis). Bar durasi memakai durasi TERBESAR yang pernah terlihat untuk
 * efek itu sebagai 100% (klien tidak diberi durasi awal).
 */
public final class PotionHudModule extends HudModule {

    private static final int CARD_H = 28;
    private static final int GAP = 3;
    private static final int LIST_H = 18;

    private final ModeSetting style = addSetting(new ModeSetting("style", "setting.xoldiummod.potion_hud.style", 0,
            "setting.xoldiummod.potion_hud.style.tiles", "setting.xoldiummod.potion_hud.style.list"));

    private final Map<Identifier, Integer> maxSeen = new HashMap<>();
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Map<String, Entry> previewEntries = new LinkedHashMap<>();

    /** Data satu efek untuk digambar (dari efek nyata atau contoh preview). */
    private record Row(String key, Identifier icon, String name, int level, String time, float fraction,
                       int color, boolean blink) {
    }

    /** Status animasi satu kartu. */
    private static final class Entry {
        final Anim.Smooth vis = new Anim.Smooth(0f, 11f);
        final Anim.Smooth frac = new Anim.Smooth(1f, 10f);
        boolean alive;
        boolean fresh = true;
        Row row;
    }

    public PotionHudModule() {
        super("potion_hud", "module.xoldiummod.potion_hud", false, 4f, 200f, 0.0);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        List<Row> rows = new ArrayList<>();
        List<StatusEffectInstance> instances = new ArrayList<>(client.player.getStatusEffects());
        if (instances.isEmpty()) {
            maxSeen.clear();
        }
        for (StatusEffectInstance instance : instances) {
            rows.add(toRow(instance));
        }
        draw(context, client.textRenderer, rows, entries);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        List<Row> rows = new ArrayList<>();
        rows.add(sample("speed", "Speed", 2, 96, 0.8f, 0xFF7CAFC6));
        rows.add(sample("strength", "Strength", 2, 214, 0.55f, 0xFF932423));
        rows.add(sample("fire_resistance", "Fire Resistance", 1, 8, 0.1f, 0xFFE49A3A));
        draw(context, client.textRenderer, rows, previewEntries);
    }

    // ------------------------------------------------------------------

    private Row toRow(StatusEffectInstance instance) {
        Identifier id = effectId(instance);
        int dur = instance.getDuration();
        float frac = 1f;
        if (id != null) {
            int seen = maxSeen.getOrDefault(id, 0);
            if (dur > seen) {
                seen = dur;
                maxSeen.put(id, seen);
            }
            frac = seen <= 0 || dur < 0 ? 1f : Math.max(0f, Math.min(1f, dur / (float) seen));
        }
        int color = 0xFFFFFFFF;
        try {
            color = 0xFF000000 | instance.getEffectType().value().getColor();
        } catch (Throwable ignored) {
            // pakai putih
        }
        boolean blink = !instance.isInfinite() && dur >= 0 && dur < 200;
        String key = id == null ? name(instance) : id.toString();
        return new Row(key, iconFor(id), name(instance), instance.getAmplifier() + 1, time(instance), frac,
                Anim.lerpColor(color, 0xFFFFFFFF, 0.2f), blink);
    }

    private static Row sample(String path, String name, int level, int seconds, float frac, int color) {
        String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
        Identifier id = Identifier.of("minecraft", path);
        return new Row("preview:" + path, iconFor(id), name, level, time, frac, Anim.lerpColor(color, 0xFFFFFFFF, 0.2f),
                seconds < 10);
    }

    private void draw(DrawContext context, TextRenderer tr, List<Row> rows, Map<String, Entry> map) {
        boolean cards = style.index() == 0;
        int rowH = cards ? CARD_H + GAP : LIST_H;

        for (Entry e : map.values()) {
            e.alive = false;
        }
        for (Row row : rows) {
            Entry e = map.computeIfAbsent(row.key(), k -> new Entry());
            e.row = row;
            e.alive = true;
        }

        // lebar = kartu terlebar
        int textW = 0;
        for (Entry e : map.values()) {
            if (e.row == null) {
                continue;
            }
            textW = Math.max(textW, tr.getWidth(title(e.row)));
            textW = Math.max(textW, tr.getWidth(e.row.time()));
        }
        int cardW = cards ? Math.max(92, 32 + textW + 10) : 2 + 16 + 4 + tr.getWidth(widest(map, tr)) + 6;

        float cursor = 0f;
        Iterator<Map.Entry<String, Entry>> it = map.entrySet().iterator();
        List<Object[]> drawList = new ArrayList<>();
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            float v = e.vis.update(e.alive ? 1f : 0f);
            if (!e.alive && v <= 0.01f) {
                it.remove();
                continue;
            }
            if (e.fresh) {
                e.fresh = false;
                e.frac.snap(e.row.fraction());
            }
            float f = e.frac.update(e.row.fraction());
            drawList.add(new Object[]{e, cursor, v, f});
            cursor += rowH * v;
        }

        int totalH = Math.max(4, Math.round(cursor) - (cards && !drawList.isEmpty() ? GAP : 0));
        setMeasuredSize(Math.max(cardW, 40), cards ? Math.max(totalH, CARD_H) : Math.max(totalH, LIST_H));
        if (drawList.isEmpty()) {
            return;
        }

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        for (Object[] d : drawList) {
            Entry e = (Entry) d[0];
            int top = Math.round((Float) d[1]);
            float v = (Float) d[2];
            float f = (Float) d[3];
            if (cards) {
                drawCard(context, tr, e.row, top, cardW, v, f);
            } else {
                drawListRow(context, tr, e.row, top, v);
            }
        }
        context.getMatrices().popMatrix();
    }

    private void drawCard(DrawContext context, TextRenderer tr, Row row, int top, int w, float vis, float frac) {
        float blink = row.blink() ? 0.55f + 0.45f * (float) Math.sin(System.currentTimeMillis() / 130.0) : 1f;
        float a = Anim.easeOutCubic(vis) * blink;
        int slide = Math.round((1f - Anim.easeOutCubic(vis)) * -14f);
        int x1 = slide;
        int x2 = slide + w;
        int y2 = top + CARD_H;
        int accent = row.color();

        ScreenChrome.roundedFill(context, x1, top, x2, y2, Anim.withAlpha(0xC8101014, a));
        ScreenChrome.roundedBorder(context, x1, top, x2, y2, Anim.withAlpha(Anim.lerpColor(0x40FFFFFF, accent, 0.35f), a));
        // garis aksen berwarna efek
        context.fill(x1 + 2, top + 4, x1 + 4, y2 - 4, Anim.withAlpha(accent, a));
        // ubin ikon
        ScreenChrome.roundedFill(context, x1 + 7, top + 4, x1 + 27, top + 24, Anim.withAlpha(0x90000000, a));
        if (row.icon() != null && a > 0.3f) {
            context.drawTexture(row.icon(), x1 + 9, top + 6, 16, 16, 0f, 0f, 16, 16, 16, 16);
        }
        // nama + level, lalu waktu
        context.drawText(tr, title(row), x1 + 32, top + 5, Anim.withAlpha(0xFFFFFFFF, a), true);
        context.drawText(tr, row.time(), x1 + 32, top + 15, Anim.withAlpha(0xFFB9B9C2, a), false);
        // bar durasi
        int bx1 = x1 + 32;
        int bx2 = x2 - 7;
        int by = y2 - 5;
        int fill = Math.max(1, Math.round((bx2 - bx1) * Math.max(0f, Math.min(1f, frac))));
        context.fill(bx1, by, bx2, by + 2, Anim.withAlpha(0x66000000, a));
        context.fill(bx1, by, bx1 + fill, by + 2, Anim.withAlpha(accent, a));
    }

    private void drawListRow(DrawContext context, TextRenderer tr, Row row, int top, float vis) {
        float a = Anim.easeOutCubic(vis);
        int slide = Math.round((1f - a) * -10f);
        if (row.icon() != null && a > 0.3f) {
            context.drawTexture(row.icon(), 2 + slide, top, 16, 16, 0f, 0f, 16, 16, 16, 16);
        }
        String label = row.name() + " " + row.level() + " (" + row.time() + ")";
        context.drawText(tr, label, 2 + 16 + 4 + slide, top + (16 - tr.fontHeight) / 2,
                Anim.withAlpha(0xFFFFFFFF, a), true);
    }

    private static String widest(Map<String, Entry> map, TextRenderer tr) {
        String best = "";
        for (Entry e : map.values()) {
            if (e.row == null) {
                continue;
            }
            String label = e.row.name() + " " + e.row.level() + " (" + e.row.time() + ")";
            if (tr.getWidth(label) > tr.getWidth(best)) {
                best = label;
            }
        }
        return best;
    }

    private static String title(Row row) {
        return row.name() + " " + roman(row.level());
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 0 && n < r.length ? (n == 0 ? "I" : r[n]) : String.valueOf(n);
    }

    private static String name(StatusEffectInstance instance) {
        return instance.getEffectType().value().getName().getString();
    }

    private static String time(StatusEffectInstance instance) {
        if (instance.isInfinite()) {
            return "**:**";
        }
        int seconds = Math.max(0, instance.getDuration() / 20);
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    private static Identifier effectId(StatusEffectInstance instance) {
        try {
            return Registries.STATUS_EFFECT.getId(instance.getEffectType().value());
        } catch (Throwable t) {
            return null;
        }
    }

    private static Identifier iconFor(Identifier id) {
        return id == null ? null : Identifier.of(id.getNamespace(), "textures/mob_effect/" + id.getPath() + ".png");
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** SaturationHudModule - kartu HUD dengan ikon, label, nilai. */
public final class SaturationHudModule extends HudModule {

    public SaturationHudModule() {
        super("saturation_hud", "module.xoldiummod.saturation_hud", false, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        int food = client.player.getHungerManager().getFoodLevel();
        float sat = client.player.getHungerManager().getSaturationLevel();
        HudRenderUtil.drawCard(context, this, Items.COOKED_BEEF, "FOOD  /  SATURATION",
                food + "  /  " + String.format(Locale.ROOT, "%.1f", sat), food / 20f);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        if (MinecraftClient.getInstance().player == null) {
            HudRenderUtil.drawCard(context, this, Items.COOKED_BEEF, "FOOD  /  SATURATION", "18  /  4.2", 0.9f);
            return;
        }
        render(context, tickCounter);
    }

}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom - FOV mengecil dengan transisi HALUS (di-ease, bukan langsung
 * loncat) selagi tombol zoom ditahan (default 'C', bisa diubah lewat
 * gear-icon setting SEKALIGUS lewat menu Controls vanilla - lihat
 * {@link KeybindSetting}). Diterapkan lewat
 * {@code mixin.visual.ZoomFovMixin} yang meng-inject
 * {@code GameRenderer#getFov}.
 *
 * <p>CATATAN DESAIN: nilai easing ({@link #currentDivisor}) HANYA
 * dimutakhirkan sekali per client tick (lewat {@link #onClientTick()}),
 * BUKAN di dalam mixin FOV itu sendiri - {@code getFov} dipanggil
 * berkali-kali per frame render (untuk hand/held item, dsb), jadi
 * memutakhirkan easing di sana akan membuatnya maju berkali-kali lipat
 * per frame (animasi jadi tidak konsisten/terlalu cepat). Mixin murni
 * MEMBACA {@link #currentDivisor} yang sudah dihitung di sini.
 */
public final class ZoomModule extends Module {

    private static ZoomModule instance;

    private final KeyBinding keyBinding;
    private final DoubleSetting zoomAmount = addSetting(
            new DoubleSetting("amount", "setting.xoldiummod.zoom.amount", 4.0, 1.5, 10.0, 0.5));
    private final DoubleSetting smoothness = addSetting(
            new DoubleSetting("smoothness", "setting.xoldiummod.zoom.smoothness", 8.0, 1.0, 20.0, 1.0));

    /** 1.0 = FOV normal (tidak sedang zoom), makin kecil = makin zoom. Di-ease tiap tick menuju target. */
    private float currentDivisor = 1f;

    public ZoomModule() {
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, false);
        instance = this;
        keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", keyBinding));
    }

    @Override
    protected void onToggle(boolean enabled) {
        if (!enabled) {
            currentDivisor = 1f; // hindari FOV "nyangkut" ter-zoom bila dimatikan selagi menahan tombol
        }
    }

    @Override
    public void onClientTick() {
        boolean holding = keyBinding.isPressed();
        float target = holding ? (float) (1.0 / zoomAmount.get()) : 1f;
        float speed = smoothness.get().floatValue();
        // dt tetap (1 tick = 0.05 detik) - lihat javadoc kelas kenapa easing tidak dihitung di mixin.
        currentDivisor += (target - currentDivisor) * Math.min(1f, speed * 0.05f);
    }

    /** Dipanggil dari {@code ZoomFovMixin} - mengembalikan {@code baseFov} tidak berubah bila modul mati/tidak sedang zoom. */
    public static double applyZoom(double baseFov) {
        if (instance == null || !instance.isEnabled()) {
            return baseFov;
        }
        return baseFov * instance.currentDivisor;
    }
}

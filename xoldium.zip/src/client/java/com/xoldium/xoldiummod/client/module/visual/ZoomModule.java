package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom (gaya OkZoomer): tahan/toggle tombol zoom (default C) -> FOV mengecil
 * halus, scroll mouse mengubah kekuatan zoom, sensitivitas mouse ikut turun
 * supaya bidikan tetap presisi.
 *
 * <p>PERBAIKAN dari versi lama (zoom tidak bekerja): (1) hook FOV kini
 * dipasang untuk DUA bentuk return {@code GameRenderer#getFov} (float di
 * 1.21.2+, double sebelumnya) dengan {@code require = 0} - tidak ada lagi
 * kegagalan senyap karena descriptor salah; (2) easing dihitung dari WAKTU
 * NYATA per frame (bukan per tick); (3) mode Hold/Toggle, scroll-zoom dan
 * pengurangan sensitivitas ditambahkan; (4) semua efek dikunci
 * {@link #isEnabled()} - modul OFF berarti zoom mati total.
 *
 * <p>Sumber acuan: OkZoomer 16.0.0-beta.2 (LGPL/MIT - hook {@code getFov}
 * di mixin {@code GameRendererMixin}, hook scroll di {@code MouseHandlerMixin}).
 */
public final class ZoomModule extends Module {

    private static ZoomModule instance;

    private final KeyBinding keyBinding;
    private final DoubleSetting zoomAmount = addSetting(
            new DoubleSetting("amount", "setting.xoldiummod.zoom.amount", 4.0, 1.5, 30.0, 0.5));
    private final DoubleSetting smoothness = addSetting(
            new DoubleSetting("smoothness", "setting.xoldiummod.zoom.smoothness", 10.0, 1.0, 30.0, 1.0));
    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", 0,
                    "setting.xoldiummod.zoom.mode.hold", "setting.xoldiummod.zoom.mode.toggle"));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));

    private boolean zooming = false;
    private boolean lastPressed = false;
    /** Pengali FOV saat ini (1.0 = normal, kecil = zoom). Di-ease berdasar waktu nyata. */
    private float currentFactor = 1f;
    private long lastNanos = System.nanoTime();
    /** Kekuatan zoom runtime (diubah scroll), diawali dari setting "Zoom Amount". */
    private double runtimeAmount = -1;

    public ZoomModule() {
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, false);
        instance = this;
        keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", keyBinding));
    }

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        lastPressed = false;
        runtimeAmount = -1;
        if (!enabled) {
            currentFactor = 1f;
        }
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean pressed = keyBinding.isPressed() && client.currentScreen == null;
        if (mode.index() == 0) {
            zooming = pressed;
        } else {
            if (pressed && !lastPressed) {
                zooming = !zooming;
                runtimeAmount = -1;
            }
        }
        if (mode.index() == 0 && !pressed && lastPressed) {
            runtimeAmount = -1; // lepas tombol: kembali ke amount dari setting
        }
        lastPressed = pressed;
    }

    private double amount() {
        if (runtimeAmount < 0) {
            runtimeAmount = zoomAmount.get();
        }
        return runtimeAmount;
    }

    private void step() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;
        float target = zooming ? (float) (1.0 / amount()) : 1f;
        currentFactor += (target - currentFactor) * Math.min(1f, smoothness.get().floatValue() * dt);
        if (Math.abs(currentFactor - target) < 0.0005f) {
            currentFactor = target;
        }
    }

    // ------------------------------------------------------------------
    // API untuk mixin
    // ------------------------------------------------------------------

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.currentFactor < 0.999f);
    }

    /** Dipanggil hook FOV (float). Mengembalikan fov asli bila modul mati / tidak zoom. */
    public static float applyZoom(float baseFov) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled()) {
            return baseFov;
        }
        z.step();
        return z.currentFactor >= 0.999f ? baseFov : baseFov * z.currentFactor;
    }

    public static double applyZoom(double baseFov) {
        return applyZoom((float) baseFov);
    }

    /** Pengali delta kamera (sensitivitas) saat zoom. */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.reduceSensitivity.get() || z.currentFactor >= 0.999f) {
            return 1.0;
        }
        return Math.max(0.05, z.currentFactor);
    }

    /** Scroll mouse: true bila event dipakai zoom (jangan ganti slot hotbar). */
    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        double factor = vertical > 0 ? 1.15 : 1.0 / 1.15;
        z.runtimeAmount = Math.max(1.1, Math.min(60.0, z.amount() * factor));
        return true;
    }
}

package com.xoldium.xoldiummod.client.util;

import com.xoldium.xoldiummod.XoldiumMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Pengenal sesama pengguna XoldiumClient - TANPA server/API tambahan, bekerja
 * di server vanilla/Paper/Spigot biasa.
 *
 * <h3>Cara kerja</h3>
 * Saat client mengirim pengaturan ("Skin Customization") ke server, byte
 * {@code playerModelParts} hanya memakai bit 0..6 (cape, jaket, lengan, kaki,
 * topi). <b>Bit 7 (0x80) tidak dipakai vanilla.</b> Xoldium menyalakan bit 7 itu
 * di paket yang dikirimnya. Server menyimpan byte tersebut apa adanya sebagai
 * data entitas pemain dan menyiarkannya ke SEMUA client yang melihat pemain itu;
 * client Xoldium lain lalu membaca bit 7 dari pemain tersebut = "pengguna
 * Xoldium". Client non-Xoldium mengabaikan bit itu (vanilla hanya memeriksa bit
 * 0..6), jadi tidak ada efek visual atau gangguan bagi mereka.
 *
 * <h3>Keamanan</h3>
 * Pengubahan paket dilakukan lewat refleksi berbasis STRUKTUR (sidik jari tipe
 * komponen record), dijaga penuh: bila struktur paket tidak cocok persis, paket
 * dikirim apa adanya. Pembacaan dibungkus try/catch - kegagalan = "bukan
 * pengguna Xoldium", tidak pernah melempar exception.
 *
 * <h3>Batasan jujur</h3>
 * Hanya terlihat bila server meneruskan data entitas pemain (semua server
 * normal begitu). Server dengan anti-cheat/plugin yang menolak bit tak dikenal
 * pada opsi skin bisa membuang bit itu atau (jarang) menandainya; matikan
 * "Share Xoldium Status" di setting modul Cape bila itu terjadi. Perubahan
 * setting berlaku saat opsi dikirim ulang (join server / ubah opsi skin).
 */
public final class XoldiumUsers {

    public static final int FLAG = 0x80;

    private static volatile boolean shareEnabled = true;
    private static boolean sendBroken = false;

    private static List<TrackedData<?>> byteKeys;

    private XoldiumUsers() {
    }

    public static void setShareEnabled(boolean enabled) {
        shareEnabled = enabled;
    }

    // ------------------------------------------------------------------
    // KIRIM: tandai paket opsi client
    // ------------------------------------------------------------------

    /**
     * Dipanggil untuk setiap paket keluar. Bila paket adalah paket opsi client
     * (dikenali dari sidik jari struktur), kembalikan salinan dengan bit 0x80
     * menyala; selain itu kembalikan paket yang sama.
     */
    public static Packet<?> tagOutgoing(Packet<?> packet) {
        if (packet == null || sendBroken || !shareEnabled) {
            return packet;
        }
        try {
            Class<?> pc = packet.getClass();
            if (!pc.isRecord()) {
                return packet;
            }
            RecordComponent[] packetComps = pc.getRecordComponents();
            if (packetComps.length != 1 || !packetComps[0].getType().isRecord()) {
                return packet;
            }
            Class<?> optionsClass = packetComps[0].getType();
            if (!isOptionsFingerprint(optionsClass)) {
                return packet;
            }
            Object options = RecordUtil.get(packet, 0);
            if (options == null) {
                return packet;
            }
            int[] ints = RecordUtil.indicesOfType(optionsClass, int.class);
            int partsIndex = ints[1];
            int parts = (Integer) RecordUtil.get(options, partsIndex);
            if (parts < 0 || parts > 0x7F) {
                return packet; // sudah ditandai / nilai tak terduga
            }
            Object newOptions = RecordUtil.copyWith(options, partsIndex, parts | FLAG);
            Object newPacket = RecordUtil.copyWith(packet, 0, newOptions);
            return (Packet<?>) newPacket;
        } catch (Throwable t) {
            sendBroken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Penanda pengguna Xoldium dinonaktifkan karena error (game tetap normal).", t);
            return packet;
        }
    }

    /**
     * Sidik jari SyncedClientOptions: 9 komponen = 1 String, 2 int, 3 boolean, 3 enum
     * (bahasa; view distance & model parts; chat colors, filter teks, server listing;
     * chat visibility, tangan utama, mode partikel). Bila Mojang mengubah struktur ini,
     * tanda tidak dipasang (aman).
     */
    private static boolean isOptionsFingerprint(Class<?> c) {
        if (!c.isRecord()) {
            return false;
        }
        RecordComponent[] comps = c.getRecordComponents();
        if (comps.length != 9) {
            return false;
        }
        int strings = 0, ints = 0, booleans = 0, enums = 0;
        for (RecordComponent rc : comps) {
            Class<?> t = rc.getType();
            if (t == String.class) strings++;
            else if (t == int.class) ints++;
            else if (t == boolean.class) booleans++;
            else if (t.isEnum()) enums++;
        }
        return strings == 1 && ints == 2 && booleans == 3 && enums == 3;
    }

    // ------------------------------------------------------------------
    // BACA: apakah pemain ini pengguna Xoldium?
    // ------------------------------------------------------------------

    public static boolean isUser(AbstractClientPlayerEntity player) {
        if (player == null) {
            return false;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && player == mc.player) {
            return true; // diri sendiri selalu pengguna Xoldium
        }
        // pemindaian hierarki lengkap (sejak 1.21.9 byte "skin customization" ada di superclass PlayerEntity)
        return com.xoldium.xoldiummod.client.social.XoldiumUsers.isXoldiumUser(player);
    }

    /** (tidak dipakai lagi) pemindaian lama hanya PlayerEntity - dibiarkan untuk kompatibilitas. */
    @SuppressWarnings("unused")
    private static boolean legacyIsUser(AbstractClientPlayerEntity player) {
        try {
            List<TrackedData<?>> keys = byteKeys();
            for (TrackedData<?> key : keys) {
                @SuppressWarnings("unchecked")
                Object value = player.getDataTracker().get((TrackedData<Object>) key);
                if (value instanceof Byte b && (b & FLAG) != 0) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
            // anggap bukan pengguna Xoldium
        }
        return false;
    }

    /** Semua TrackedData<Byte> statis milik PlayerEntity (PLAYER_MODEL_PARTS & MAIN_ARM) - dicari lewat tipe, bukan nama. */
    private static List<TrackedData<?>> byteKeys() throws Throwable {
        if (byteKeys == null) {
            List<TrackedData<?>> found = new ArrayList<>();
            for (Field f : PlayerEntity.class.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) || f.getType() != TrackedData.class) {
                    continue;
                }
                Type g = f.getGenericType();
                if (g instanceof ParameterizedType pt && pt.getActualTypeArguments().length == 1
                        && pt.getActualTypeArguments()[0] == Byte.class) {
                    f.setAccessible(true);
                    Object v = f.get(null);
                    if (v instanceof TrackedData<?> td) {
                        found.add(td);
                    }
                }
            }
            byteKeys = found;
        }
        return byteKeys;
    }
}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Show Me Your Skin - sembunyikan armor (helm, chestplate, legging, sepatu) dan elytra supaya skin terlihat.
 * Diport dari mod "Show Me Your Skin" (enjarai): pilihan potongan yang disembunyikan, berlaku untuk diri
 * sendiri dan/atau pemain lain, "Show In Combat" (armor muncul lagi sesaat setelah terkena damage) dan
 * "Force Elytra When Flying" (elytra tetap tampil saat terbang).
 *
 * <p><b>Cara kerja (versi perbaikan).</b> Mod asli memutuskan per potongan apakah sebuah lapisan equipment
 * dirender. Di 1.21.11 data equipment yang dibaca renderer armor/elytra berasal dari satu method statis
 * {@code HumanoidMobRenderer#getEquipmentIfRenderable(LivingEntity, EquipmentSlot)} (dipanggil saat state
 * render pemain dibuat tiap frame). {@link com.xoldium.xoldiummod.mixin.visual.ShowSkinEquipmentMixin}
 * menimpa hasil method itu dengan {@code ItemStack.EMPTY} bila {@link #shouldHide} bernilai true, sehingga
 * armor maupun elytra tidak digambar - tanpa menyentuh inventori, statistik armor, atau server.
 *
 * <p>Versi sebelumnya memasang hook di {@code render(...)} milik ArmorFeatureRenderer/ElytraFeatureRenderer
 * dengan tipe antrian render yang salah, jadi hook tidak pernah terpasang (diam-diam, karena {@code require = 0}).
 */
public final class ShowMeYourSkinModule extends Module {

    private static ShowMeYourSkinModule instance;

    private final BooleanSetting onSelf = addSetting(new BooleanSetting("self", "setting.xoldiummod.smys.self", true));
    private final BooleanSetting onOthers = addSetting(new BooleanSetting("others", "setting.xoldiummod.smys.others", false));
    private final BooleanSetting hideHead = addSetting(new BooleanSetting("helmet", "setting.xoldiummod.smys.helmet", true));
    private final BooleanSetting hideChest = addSetting(new BooleanSetting("chestplate", "setting.xoldiummod.smys.chestplate", true));
    private final BooleanSetting hideLegs = addSetting(new BooleanSetting("leggings", "setting.xoldiummod.smys.leggings", true));
    private final BooleanSetting hideFeet = addSetting(new BooleanSetting("boots", "setting.xoldiummod.smys.boots", true));
    private final BooleanSetting hideElytra = addSetting(new BooleanSetting("elytra", "setting.xoldiummod.smys.elytra", false));
    private final BooleanSetting forceElytraFlying = addSetting(
            new BooleanSetting("force_elytra_flying", "setting.xoldiummod.smys.force_elytra_flying", true),
            () -> this.hideElytra.get());
    private final BooleanSetting showInCombat = addSetting(
            new BooleanSetting("show_in_combat", "setting.xoldiummod.smys.show_in_combat", true));
    private final DoubleSetting combatSeconds = addSetting(
            new DoubleSetting("combat_seconds", "setting.xoldiummod.smys.combat_seconds", 16.0, 1.0, 60.0, 1.0),
            () -> this.showInCombat.get());

    /** UUID pemain -> waktu (ms) terakhir terkena damage. Dipakai "Show In Combat". */
    private static final Map<UUID, Long> LAST_HURT = new ConcurrentHashMap<>();

    private static Method glideMethod;
    private static boolean glideResolved = false;

    public ShowMeYourSkinModule() {
        super("show_me_your_skin", "module.xoldiummod.show_me_your_skin", ModuleCategory.VISUAL, false);
        instance = this;
    }

    /** true bila modul aktif (ON dan tidak crash). */
    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    /**
     * Catat pemain yang baru terkena damage (hurtTime > 0) untuk fitur "Show In Combat".
     *
     * <p><b>Perbaikan bug "armor tetap terlihat setelah kill".</b> Sebelumnya pukulan terakhir yang membunuh
     * musuh juga tercatat sebagai "terkena damage", sehingga armor korban (dan armor pemain yang respawn
     * dengan UUID yang sama) tetap tampil sampai timer combat habis. Sekarang:
     * <ul>
     *   <li>pemain yang mati ({@code health <= 0} / {@code isDead} / {@code deathTime > 0}) tidak dicatat dan
     *       catatannya langsung dihapus - armor mereka kembali disembunyikan;</li>
     *   <li>catatan pemain yang sudah tidak ada di dunia (keluar, respawn, ganti dimensi) dihapus tiap tick;</li>
     *   <li>pemain yang baru membunuh musuh (pelaku) tidak lagi dianggap "sedang combat" lewat catatan lama.</li>
     * </ul>
     */
    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null) {
            LAST_HURT.clear();
            return;
        }
        long now = System.currentTimeMillis();
        java.util.Set<UUID> present = new java.util.HashSet<>();
        for (PlayerEntity player : client.world.getPlayers()) {
            UUID id = player.getUuid();
            present.add(id);
            if (isDeadOrDying(player)) {
                LAST_HURT.remove(id);
                continue;
            }
            if (player.hurtTime > 0) {
                LAST_HURT.put(id, now);
            }
        }
        if (!LAST_HURT.isEmpty()) {
            LAST_HURT.keySet().removeIf(id -> !present.contains(id));
        }
        if (LAST_HURT.size() > 64) {
            long maxAge = 61_000L;
            Iterator<Map.Entry<UUID, Long>> it = LAST_HURT.entrySet().iterator();
            while (it.hasNext()) {
                if (now - it.next().getValue() > maxAge) {
                    it.remove();
                }
            }
        }
    }

    /** true bila pemain sudah mati / sedang animasi mati (dipakai agar armor korban tidak "menempel"). */
    private static boolean isDeadOrDying(PlayerEntity player) {
        try {
            return player.isDead() || player.getHealth() <= 0.0f || player.deathTime > 0 || !player.isAlive();
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        LAST_HURT.clear();
    }

    /**
     * Dipanggil mixin untuk setiap potongan equipment yang akan dimasukkan ke state render.
     *
     * @param entity pemilik equipment (hanya {@link PlayerEntity} yang diubah, seperti mod asli)
     * @param slot   slot equipment (HEAD/CHEST/LEGS/FEET; slot lain diabaikan)
     * @param stack  item di slot itu (hasil asli)
     * @return true bila potongan ini harus disembunyikan
     */
    public static boolean shouldHide(LivingEntity entity, EquipmentSlot slot, ItemStack stack) {
        try {
            if (!active() || entity == null || slot == null || stack == null || stack.isEmpty()) {
                return false;
            }
            if (!(entity instanceof PlayerEntity player)) {
                return false;
            }
            ShowMeYourSkinModule m = instance;
            MinecraftClient client = MinecraftClient.getInstance();
            boolean self = client != null && player == client.player;
            if (!(self ? m.onSelf.get() : m.onOthers.get())) {
                return false;
            }
            if (m.showInCombat.get() && inCombat(player, m.combatSeconds.get())) {
                return false;
            }
            switch (slot) {
                case HEAD:
                    return m.hideHead.get();
                case LEGS:
                    return m.hideLegs.get();
                case FEET:
                    return m.hideFeet.get();
                case CHEST:
                    if (stack.isOf(Items.ELYTRA)) {
                        if (!m.hideElytra.get()) {
                            return false;
                        }
                        return !(m.forceElytraFlying.get() && isGliding(player));
                    }
                    return m.hideChest.get();
                default:
                    return false;
            }
        } catch (Throwable t) {
            // jangan pernah melempar ke render loop: armor tampil normal
            return false;
        }
    }

    private static boolean inCombat(PlayerEntity player, double seconds) {
        if (isDeadOrDying(player)) {
            LAST_HURT.remove(player.getUuid());
            return false;
        }
        Long last = LAST_HURT.get(player.getUuid());
        return last != null && System.currentTimeMillis() - last < (long) (seconds * 1000.0);
    }

    /**
     * Apakah pemain sedang terbang dengan elytra. Nama method berbeda antar mapping (Yarn: isGliding /
     * isFallFlying, runtime Minecraft ter-obfuscate: method_6128), jadi dicari lewat refleksi sekali saja.
     */
    private static boolean isGliding(LivingEntity entity) {
        if (!glideResolved) {
            glideResolved = true;
            for (String name : new String[]{"isGliding", "isFallFlying", "method_6128"}) {
                try {
                    Method m = LivingEntity.class.getMethod(name);
                    if (m.getReturnType() == boolean.class) {
                        glideMethod = m;
                        break;
                    }
                } catch (Throwable ignored) {
                    // coba nama berikutnya
                }
            }
            if (glideMethod == null) {
                XoldiumMod.LOGGER.warn("[Xoldium] Show Me Your Skin: method status terbang elytra tidak ditemukan "
                        + "(\"Force Elytra When Flying\" tidak berefek).");
            }
        }
        if (glideMethod == null) {
            return false;
        }
        try {
            return (Boolean) glideMethod.invoke(entity);
        } catch (Throwable t) {
            glideMethod = null;
            return false;
        }
    }
}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Show Me Your Skin - sembunyikan armor (helm, chestplate, legging, sepatu) dan elytra supaya skin terlihat,
 * port ringkas dari mod "Show Me Your Skin" (enjarai) yang dikirim pemakai.
 *
 * <p>Mod aslinya untuk Minecraft 26.2 (mapping Mojang, owo-lib, Cicada, Cardinal Components, sinkronisasi
 * server) sehingga tidak bisa disalin ke proyek Yarn 1.21.11 ini. Yang dipertahankan: pilihan potongan armor
 * yang disembunyikan, berlaku untuk diri sendiri dan/atau pemain lain. Cara kerja: selama
 * {@code ArmorFeatureRenderer}/{@code ElytraFeatureRenderer} merender, slot item pada state render
 * dikosongkan lalu DIKEMBALIKAN (inventori & statistik armor tidak berubah - hanya tampilan, hanya di client kita).
 * Transparansi per potongan, kontrol hat/shield, dan sinkronisasi server dari mod asli tidak ikut.
 *
 * <p>Refleksi memakai urutan & tipe field (4 field {@link ItemStack}: kepala, dada, kaki, sepatu), bukan nama,
 * karena 1.21.11 masih ter-obfuscate. Struktur tak sesuai dugaan -> fitur mati sendiri dengan satu baris log.
 */
public final class ShowMeYourSkinModule extends Module {

    private static ShowMeYourSkinModule instance;

    private final BooleanSetting onSelf = addSetting(new BooleanSetting("self", "setting.xoldiummod.smys.self", true));
    private final BooleanSetting onOthers = addSetting(new BooleanSetting("others", "setting.xoldiummod.smys.others", false));
    private final BooleanSetting hideHead = addSetting(new BooleanSetting("helmet", "setting.xoldiummod.smys.helmet", true));
    private final BooleanSetting hideChest = addSetting(new BooleanSetting("chestplate", "setting.xoldiummod.smys.chestplate", true));
    private final BooleanSetting hideLegs = addSetting(new BooleanSetting("leggings", "setting.xoldiummod.smys.leggings", true));
    private final BooleanSetting hideFeet = addSetting(new BooleanSetting("boots", "setting.xoldiummod.smys.boots", true));
    private final BooleanSetting hideElytra = addSetting(new BooleanSetting("elytra", "setting.xoldiummod.smys.elytra", false));

    /** state render -> apakah milik pemain lokal. Identitas objek (state tidak override equals), tidak bocor memori. */
    private static final Map<Object, Boolean> SELF_TAGS = new WeakHashMap<>();

    private static Field[] slotFields;
    private static boolean resolved = false;
    private static boolean broken = false;

    public ShowMeYourSkinModule() {
        super("show_me_your_skin", "module.xoldiummod.show_me_your_skin", ModuleCategory.VISUAL, false);
        instance = this;
    }

    public static boolean active() {
        return instance != null && instance.isEnabled() && !broken;
    }

    /** Dipanggil mixin pembuat state: tandai apakah state ini milik pemain lokal. */
    public static void tag(Object state, boolean self) {
        if (state != null) {
            synchronized (SELF_TAGS) {
                SELF_TAGS.put(state, self);
            }
        }
    }

    private static boolean isSelf(Object state) {
        synchronized (SELF_TAGS) {
            return Boolean.TRUE.equals(SELF_TAGS.get(state));
        }
    }

    private boolean appliesTo(Object state) {
        return isSelf(state) ? onSelf.get() : onOthers.get();
    }

    /**
     * Kosongkan slot armor (dan/atau dada utk elytra) sesuai setting. Mengembalikan data pemulihan
     * (pasangan Field, nilai lama ...) atau null bila tidak ada yang diubah.
     *
     * @param elytraRenderer true bila dipanggil dari ElytraFeatureRenderer (hanya slot dada, setting elytra)
     */
    public static Object[] hide(Object state, boolean elytraRenderer) {
        if (!active() || state == null || !instance.appliesTo(state)) {
            return null;
        }
        try {
            Field[] f = fields(state.getClass());
            if (f == null) {
                return null;
            }
            boolean[] want = elytraRenderer
                    ? new boolean[]{false, instance.hideElytra.get(), false, false}
                    : new boolean[]{instance.hideHead.get(), instance.hideChest.get(), instance.hideLegs.get(), instance.hideFeet.get()};
            List<Object> saved = new ArrayList<>();
            for (int i = 0; i < 4; i++) {
                if (!want[i]) {
                    continue;
                }
                Object old = f[i].get(state);
                if (old instanceof ItemStack stack && !stack.isEmpty()) {
                    f[i].set(state, ItemStack.EMPTY);
                    saved.add(f[i]);
                    saved.add(old);
                }
            }
            return saved.isEmpty() ? null : saved.toArray();
        } catch (Throwable t) {
            broken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Show Me Your Skin dinonaktifkan karena error (client tetap normal).", t);
            return null;
        }
    }

    public static void restore(Object state, Object[] saved) {
        if (saved == null) {
            return;
        }
        try {
            for (int i = 0; i + 1 < saved.length; i += 2) {
                ((Field) saved[i]).set(state, saved[i + 1]);
            }
        } catch (Throwable t) {
            broken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Show Me Your Skin: gagal mengembalikan slot armor.", t);
        }
    }

    private static Field[] fields(Class<?> stateClass) {
        if (resolved) {
            return slotFields;
        }
        resolved = true;
        for (Class<?> c = stateClass; c != null && c != Object.class; c = c.getSuperclass()) {
            List<Field> stacks = new ArrayList<>();
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && f.getType() == ItemStack.class) {
                    stacks.add(f);
                }
            }
            if (stacks.size() == 4) {
                for (Field f : stacks) {
                    f.setAccessible(true);
                }
                slotFields = stacks.toArray(new Field[0]);
                return slotFields;
            }
        }
        broken = true;
        XoldiumMod.LOGGER.warn("[Xoldium] Show Me Your Skin: struktur slot armor di state tidak sesuai dugaan (dimatikan).");
        return null;
    }
}

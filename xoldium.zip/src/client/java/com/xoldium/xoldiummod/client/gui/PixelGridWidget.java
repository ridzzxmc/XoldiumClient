package com.xoldium.xoldiummod.client.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;

public class PixelGridWidget extends ClickableWidget {
    private static final int GRID_SIZE = 15;
    private static final int CELL_SIZE = 12;
    private static final int GRID_PIXEL_SIZE = GRID_SIZE * CELL_SIZE;

    private boolean[][] grid;
    private int gridStartX;
    private int gridStartY;

    public PixelGridWidget(int x, int y, boolean[][] initialGrid) {
        super(x, y, GRID_PIXEL_SIZE, GRID_PIXEL_SIZE, Text.literal("Pixel Grid"));
        this.gridStartX = x;
        this.gridStartY = y;
        this.grid = new boolean[GRID_SIZE][GRID_SIZE];

        if (initialGrid != null) {
            for (int i = 0; i < GRID_SIZE; i++) {
                System.arraycopy(initialGrid[i], 0, this.grid[i], 0, GRID_SIZE);
            }
        }
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(gridStartX - 1, gridStartY - 1,
                gridStartX + GRID_PIXEL_SIZE + 1, gridStartY + GRID_PIXEL_SIZE + 1,
                0xFF000000);

        for (int x = 0; x < GRID_SIZE; x++) {
            for (int y = 0; y < GRID_SIZE; y++) {
                int cellX = gridStartX + x * CELL_SIZE;
                int cellY = gridStartY + y * CELL_SIZE;

                int color = grid[x][y] ? 0xFFFFFFFF : 0xFF2A2A2A;
                context.fill(cellX, cellY, cellX + CELL_SIZE - 1, cellY + CELL_SIZE - 1, color);

                context.fill(cellX + CELL_SIZE - 1, cellY, cellX + CELL_SIZE, cellY + CELL_SIZE, 0xFF555555);
                context.fill(cellX, cellY + CELL_SIZE - 1, cellX + CELL_SIZE, cellY + CELL_SIZE, 0xFF555555);
            }
        }

        int centerCellX = gridStartX + 7 * CELL_SIZE;
        int centerCellY = gridStartY + 7 * CELL_SIZE;
        drawBorder(context, centerCellX, centerCellY, CELL_SIZE, CELL_SIZE, 0xFFFF0000);

        if (isMouseOver(mouseX, mouseY)) {
            int gridX = (mouseX - gridStartX) / CELL_SIZE;
            int gridY = (mouseY - gridStartY) / CELL_SIZE;

            if (gridX >= 0 && gridX < GRID_SIZE && gridY >= 0 && gridY < GRID_SIZE) {
                int hoverX = gridStartX + gridX * CELL_SIZE;
                int hoverY = gridStartY + gridY * CELL_SIZE;
                drawBorder(context, hoverX, hoverY, CELL_SIZE, CELL_SIZE, 0xFF00FF00);
            }
        }
    }

    private static void drawBorder(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x,             y,              x + width,     y + 1,          color);
        context.fill(x,             y + height - 1, x + width,     y + height,     color);
        context.fill(x,             y,              x + 1,         y + height,     color);
        context.fill(x + width - 1, y,              x + width,     y + height,     color);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (this.isMouseOver(click.x(), click.y()) && click.button() == 0) {
            int gridX = (int)((click.x() - gridStartX) / CELL_SIZE);
            int gridY = (int)((click.y() - gridStartY) / CELL_SIZE);
            if (gridX >= 0 && gridX < GRID_SIZE && gridY >= 0 && gridY < GRID_SIZE) {
                grid[gridX][gridY] = !grid[gridX][gridY];
            }
            this.playDownSound(net.minecraft.client.MinecraftClient.getInstance().getSoundManager());
            return true;
        }
        return false;
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= gridStartX && mouseX < gridStartX + GRID_PIXEL_SIZE &&
                mouseY >= gridStartY && mouseY < gridStartY + GRID_PIXEL_SIZE;
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        this.appendDefaultNarrations(builder);
    }

    public boolean[][] getGrid() {
        return grid;
    }

    public void setGrid(boolean[][] newGrid) {
        for (int x = 0; x < GRID_SIZE; x++) {
            System.arraycopy(newGrid[x], 0, this.grid[x], 0, GRID_SIZE);
        }
    }

    public void clearGrid() {
        for (int x = 0; x < GRID_SIZE; x++) {
            for (int y = 0; y < GRID_SIZE; y++) {
                grid[x][y] = false;
            }
        }
    }
}
package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

/**
 * Layar setting per-modul (dibuka lewat ikon gear pada kartu modul di
 * {@link ModListScreen}) - dibangun dari widget vanilla saja
 * (CyclingButtonWidget untuk BooleanSetting, SliderWidget untuk
 * DoubleSetting, tombol capture-tombol untuk {@link KeybindSetting}),
 * sama seperti filosofi {@code FulconConfigScreen} asli: tidak menambah
 * dependency Cloth Config/YACL.
 *
 * <p>Untuk {@link KeybindSetting}: mengklik tombolnya masuk mode
 * "menunggu tombol" ({@link #capturing}) - key press BERIKUTNYA (apa
 * pun, termasuk ESC/tombol mouse) langsung dipakai sebagai keybind baru
 * lewat {@code KeyBinding#setBoundKey} + {@code KeyBinding#updateKeysByCode}
 * (API vanilla yang SAMA dipakai layar Controls bawaan Minecraft sendiri
 * untuk fitur ini - jadi terjamin konsisten & sudah otomatis tersimpan ke
 * {@code options.txt} lewat mekanisme vanilla, tanpa kode simpan manual
 * tambahan di sini).
 */
public final class ModuleSettingsScreen extends Screen {

    private final Screen parent;
    private final Module module;
    private KeybindSetting capturing;
    private final Map<KeybindSetting, ButtonWidget> keybindButtons = new HashMap<>();

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(module.displayName());
        this.parent = parent;
        this.module = module;
    }

    @Override
    protected void init() {
        int width = Math.min(this.width - 40, 360);
        int x = (this.width - width) / 2;
        int y = 40;
        int rowHeight = 22;

        for (ModuleSetting<?> setting : module.settings()) {
            if (setting instanceof BooleanSetting boolSetting) {
                CyclingButtonWidget<Boolean> widget = CyclingButtonWidget.onOffBuilder(boolSetting.get())
                        .build(x, y, width, 20, boolSetting.displayName(), (button, value) -> boolSetting.set(value));
                this.addDrawableChild(widget);
            } else if (setting instanceof DoubleSetting doubleSetting) {
                this.addDrawableChild(new DoubleSettingSlider(x, y, width, 20, doubleSetting));
            } else if (setting instanceof KeybindSetting keybindSetting) {
                ButtonWidget button = ButtonWidget.builder(keybindLabel(keybindSetting), b -> beginCapture(keybindSetting))
                        .dimensions(x, y, width, 20)
                        .build();
                keybindButtons.put(keybindSetting, button);
                this.addDrawableChild(button);
            }
            y += rowHeight;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> {
                    ModuleManager.saveState();
                    if (this.client != null) {
                        this.client.setScreen(this.parent);
                    }
                })
                .dimensions(x, y + 8, width, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFFFF);
    }

    /**
     * Diprioritaskan SEBELUM penanganan tombol normal (termasuk ESC-untuk-
     * tutup bawaan {@link Screen}) selagi sedang menunggu capture tombol
     * baru untuk sebuah {@link KeybindSetting} - supaya ESC/tombol apa pun
     * bisa dipakai sebagai keybind, bukan malah menutup layar ini.
     */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (capturing != null) {
            capturing.binding().setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
            finishCapture();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (capturing != null) {
            capturing.binding().setBoundKey(InputUtil.Type.MOUSE.createFromCode(button));
            finishCapture();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void beginCapture(KeybindSetting setting) {
        this.capturing = setting;
        ButtonWidget button = keybindButtons.get(setting);
        if (button != null) {
            button.setMessage(setting.displayName().copy()
                    .append(": ").append(Text.translatable("gui.xoldiummod.settings.press_any_key")));
        }
    }

    private void finishCapture() {
        if (capturing == null) {
            return;
        }
        KeyBinding.updateKeysByCode();
        ButtonWidget button = keybindButtons.get(capturing);
        if (button != null) {
            button.setMessage(keybindLabel(capturing));
        }
        capturing = null;
    }

    private static Text keybindLabel(KeybindSetting setting) {
        return setting.displayName().copy().append(": ").append(setting.binding().getBoundKeyLocalizedText());
    }

    @Override
    public void close() {
        ModuleManager.saveState();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    /** Slider vanilla sederhana yang terikat langsung ke satu {@link DoubleSetting}. */
    private static final class DoubleSettingSlider extends SliderWidget {

        private final DoubleSetting setting;

        DoubleSettingSlider(int x, int y, int width, int height, DoubleSetting setting) {
            super(x, y, width, height, Text.empty(), setting.sliderProgress());
            this.setting = setting;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(setting.displayName().copy()
                    .append(": ")
                    .append(Text.literal(String.format("%.2f", setting.get()))));
        }

        @Override
        protected void applyValue() {
            setting.setFromSliderProgress(this.value);
        }
    }
}

package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Pengaturan lanjutan optimasi (toggle mentah XoldiumConfig) - panel beranimasi seperti layar Xoldium lain. */
public final class XoldiumConfigScreen extends XoldiumScreen {

    private final List<ToggleEntry> toggles = new ArrayList<>();
    private final List<CyclingButtonWidget<Boolean>> widgets = new ArrayList<>();
    private ButtonWidget doneButton;
    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    public XoldiumConfigScreen(Screen parent) {
        super(Text.translatable("xoldiummod.config.title"), parent);
        registerToggles();
    }

    private void registerToggles() {
        XoldiumConfig cfg = XoldiumConfig.get();

        toggles.add(new ToggleEntry("xoldiummod.config.enabled", () -> cfg.enabled, v -> cfg.enabled = v));
        toggles.add(new ToggleEntry("xoldiummod.config.entity_frustum_culling", () -> cfg.entityFrustumCulling, v -> cfg.entityFrustumCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.player_culling", () -> cfg.playerCulling, v -> cfg.playerCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.block_entity_culling", () -> cfg.blockEntityCulling, v -> cfg.blockEntityCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.particle_frustum_culling", () -> cfg.particleFrustumCulling, v -> cfg.particleFrustumCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.tile_entity_distance_culling", () -> cfg.tileEntityDistanceCulling, v -> cfg.tileEntityDistanceCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.fast_entity_rendering", () -> cfg.fastEntityRendering, v -> cfg.fastEntityRendering = v));
        toggles.add(new ToggleEntry("xoldiummod.config.direct_particle_fast_path", () -> cfg.directParticleFastPath, v -> cfg.directParticleFastPath = v));
        toggles.add(new ToggleEntry("xoldiummod.config.occlusion_culling_boost", () -> cfg.occlusionCullingBoost, v -> cfg.occlusionCullingBoost = v));
        toggles.add(new ToggleEntry("xoldiummod.config.mob_ai_throttling", () -> cfg.mobAiThrottling, v -> cfg.mobAiThrottling = v));
    }

    @Override
    protected void init() {
        panelW = Math.min(this.width - 16, 380);
        int contentH = toggles.size() * 22 + 30 + 46;
        panelH = Math.min(this.height - 16, contentH + 30);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        widgets.clear();

        int width = panelW - 24;
        for (ToggleEntry entry : toggles) {
            CyclingButtonWidget<Boolean> widget = CyclingButtonWidget.onOffBuilder(entry.getter.get())
                    .build(0, 0, width, 20, Text.translatable(entry.labelKey), (button, value) -> {
                        entry.setter.accept(value);
                        XoldiumConfig.save();
                    });
            widgets.add(widget);
            this.addDrawableChild(widget);
        }
        doneButton = ButtonWidget.builder(Text.translatable("gui.done"), button -> this.close())
                .dimensions(0, 0, width, 20)
                .build();
        this.addDrawableChild(doneButton);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        beginFrame(context, mouseX, mouseY, delta);
        float a = screenAlpha();
        int oy = slideOffset(16);

        int x1 = panelX;
        int y1 = panelY + oy;
        int x2 = panelX + panelW;
        int y2 = panelY + panelH + oy;
        ScreenChrome.roundedFill(context, x1, y1, x2, y2, Anim.withAlpha(ScreenChrome.PANEL_BG, a));
        ScreenChrome.roundedBorder(context, x1, y1, x2, y2, Anim.withAlpha(ScreenChrome.PANEL_BORDER, a));
        context.drawCenteredTextWithShadow(this.textRenderer, XoldiumFonts.bold(this.title),
                this.width / 2, y1 + 10, Anim.withAlpha(0xFFFFFFFF, a));

        int y = y1 + 26;
        int x = x1 + 12;
        for (CyclingButtonWidget<Boolean> w : widgets) {
            w.setX(x);
            w.setY(y);
            w.setAlpha(a);
            y += 22;
        }
        doneButton.setX(x);
        doneButton.setY(y + 6);
        doneButton.setAlpha(a);

        super.render(context, mouseX, mouseY, delta);
        endFrame();
    }

    @Override
    protected void onClosing() {
        XoldiumConfig.save();
    }

    private record ToggleEntry(String labelKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
    }
}

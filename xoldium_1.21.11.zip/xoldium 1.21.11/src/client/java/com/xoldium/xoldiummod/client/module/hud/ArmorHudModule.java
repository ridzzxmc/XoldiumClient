package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * SESI 10: sebelumnya modul ini HANYA menggambar teks ("Sculk Crown 100%",
 * dst) lewat {@link com.xoldium.xoldiummod.client.util.HudRenderUtil} -
 * permintaan pemakai eksplisit: "jangan cuma tulisan, ada gambar armor
 * nya". Sekarang tiap slot digambar sebagai baris [ikon item asli 16x16]
 * + [nama & persen durabilitas], memakai {@code DrawContext#drawItem}
 * (overload yang sudah TERBUKTI compile & jalan di proyek ini - dipakai
 * {@link TotemCounterModule} untuk ikon Totem of Undying) - jadi berlaku
 * untuk armor VANILLA maupun armor custom dari mod/plugin server manapun
 * (mis. "Warden Armor", "Sculk Crown" pada tangkapan layar pemakai),
 * karena ikonnya diambil langsung dari model/tekstur item aslinya, bukan
 * dari daftar ikon tetap.
 */
public final class ArmorHudModule extends HudModule {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final int ICON_SIZE = 16;
    private static final int ROW_HEIGHT = 18;
    private static final int TEXT_GAP = 4;

    public ArmorHudModule() {
        super("armor_hud", "module.xoldiummod.armor_hud", false, 4f, 164f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<ItemStack> stacks = new ArrayList<>(ARMOR_SLOTS.length);
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                stacks.add(stack);
            }
        }

        TextRenderer tr = client.textRenderer;
        int alpha = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0);

        if (stacks.isEmpty()) {
            // Tidak ada item untuk digambar ikonnya - kotak kecil teks biasa saja.
            String text = "Armor: none";
            int rawWidth = tr.getWidth(text) + 6;
            int rawHeight = tr.fontHeight + 4;
            setMeasuredSize(rawWidth, rawHeight);

            context.getMatrices().pushMatrix();
            context.getMatrices().translate(x, y);
            context.getMatrices().scale(scale, scale);
            context.fill(0, 0, rawWidth, rawHeight, alpha << 24);
            context.drawText(tr, text, 3, 2, 0xFFFFFFFF, true);
            context.getMatrices().popMatrix();
            return;
        }

        List<String> labels = new ArrayList<>(stacks.size());
        int rawWidth = 0;
        for (ItemStack stack : stacks) {
            String label = label(stack);
            labels.add(label);
            rawWidth = Math.max(rawWidth, ICON_SIZE + TEXT_GAP + tr.getWidth(label));
        }
        rawWidth += 6;
        int rawHeight = ROW_HEIGHT * stacks.size() + 2;
        setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        context.fill(0, 0, rawWidth, rawHeight, alpha << 24);

        int rowY = 1;
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack stack = stacks.get(i);
            context.drawItem(stack, 2, rowY);
            int textY = rowY + (ICON_SIZE - tr.fontHeight) / 2;
            context.drawText(tr, labels.get(i), 2 + ICON_SIZE + TEXT_GAP, textY, 0xFFFFFFFF, true);
            rowY += ROW_HEIGHT;
        }

        context.getMatrices().popMatrix();
    }

    private static String label(ItemStack stack) {
        int percent = 100;
        if (stack.isDamageable() && stack.getMaxDamage() > 0) {
            percent = Math.round(100f * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage());
        }
        return stack.getName().getString() + " " + percent + "%";
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * SESI 10: sebelumnya modul ini HANYA menggambar teks ("Speed 1 (2:30)",
 * dst) - permintaan pemakai eksplisit: "potion HUD jangan cuma tulisan
 * ada gambar armor nya" (maksudnya: ikon efeknya). Sekarang tiap efek
 * digambar sebagai baris [ikon 16x16] + [nama, level, sisa waktu].
 *
 * <p>Ikon DIAMBIL LANGSUNG dari tekstur individual bawaan game di
 * {@code textures/mob_effect/<id>.png} (namespace mengikuti namespace ID
 * efeknya sendiri - jadi berlaku juga untuk efek custom dari mod/plugin
 * server yang mengikuti konvensi path yang sama), BUKAN lewat
 * {@code StatusEffectSpriteManager}/{@code drawSprite} - overload
 * {@code drawSprite} berubah-ubah bentuk mengikuti perombakan render
 * pipeline Minecraft (persis alasan {@link com.xoldium.xoldiummod.client.gui.IconRenderer}
 * menghindari {@code drawTexturedQuad}), sedangkan {@code drawTexture(Identifier,...)}
 * dipakai di sini sudah TERBUKTI stabil & dipakai di seluruh ikon lain
 * proyek ini. Bila server memakai efek custom yang tidak punya tekstur di
 * path tsb, Minecraft otomatis menampilkan tekstur "missing" bawaan
 * (checkerboard hitam-magenta) alih-alih gagal/crash.
 */
public final class PotionHudModule extends HudModule {

    private static final int ICON_SIZE = 16;
    private static final int ROW_HEIGHT = 18;
    private static final int TEXT_GAP = 4;

    public PotionHudModule() {
        super("potion_hud", "module.xoldiummod.potion_hud", false, 4f, 200f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<StatusEffectInstance> instances = new ArrayList<>(client.player.getStatusEffects());
        if (instances.isEmpty()) {
            return; // tidak ada efek aktif - tidak perlu gambar kotak kosong
        }

        TextRenderer tr = client.textRenderer;
        List<String> labels = new ArrayList<>(instances.size());
        List<Identifier> icons = new ArrayList<>(instances.size());
        int rawWidth = 0;
        for (StatusEffectInstance instance : instances) {
            String label = label(instance);
            labels.add(label);
            icons.add(iconFor(instance));
            rawWidth = Math.max(rawWidth, ICON_SIZE + TEXT_GAP + tr.getWidth(label));
        }
        rawWidth += 6;
        int rawHeight = ROW_HEIGHT * instances.size() + 2;
        setMeasuredSize(rawWidth, rawHeight);

        int alpha = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        context.fill(0, 0, rawWidth, rawHeight, alpha << 24);

        int rowY = 1;
        for (int i = 0; i < instances.size(); i++) {
            Identifier icon = icons.get(i);
            if (icon != null) {
                context.drawTexture(icon, 2, rowY, ICON_SIZE, ICON_SIZE, 0f, 0f, ICON_SIZE, ICON_SIZE, ICON_SIZE, ICON_SIZE);
            }
            int textY = rowY + (ICON_SIZE - tr.fontHeight) / 2;
            context.drawText(tr, labels.get(i), 2 + ICON_SIZE + TEXT_GAP, textY, 0xFFFFFFFF, true);
            rowY += ROW_HEIGHT;
        }

        context.getMatrices().popMatrix();
    }

    private static String label(StatusEffectInstance instance) {
        String name = instance.getEffectType().value().getName().getString();
        int amplifier = instance.getAmplifier() + 1;
        int seconds = instance.getDuration() / 20;
        return name + " " + amplifier + " (" + (seconds / 60) + ":" + String.format("%02d", seconds % 60) + ")";
    }

    /** Tekstur ikon efek individual - lihat javadoc kelas untuk alasan tidak memakai StatusEffectSpriteManager/atlas. */
    private static Identifier iconFor(StatusEffectInstance instance) {
        try {
            Identifier id = Registries.STATUS_EFFECT.getId(instance.getEffectType().value());
            if (id == null) {
                return null;
            }
            return Identifier.of(id.getNamespace(), "textures/mob_effect/" + id.getPath() + ".png");
        } catch (Throwable t) {
            return null;
        }
    }
}

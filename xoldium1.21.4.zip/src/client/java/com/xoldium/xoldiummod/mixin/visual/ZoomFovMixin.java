package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hook FOV untuk Zoom. Dipasang lewat NAMA method saja (tanpa descriptor return)
 * dan memakai {@code Number} supaya tetap benar baik bila {@code getFov} di versi ini
 * mengembalikan {@code float} maupun {@code double}. Tipe box yang dikembalikan
 * disamakan dengan tipe aslinya, jadi tidak ada ClassCastException.
 */
@Mixin(GameRenderer.class)
public abstract class ZoomFovMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$zoomFov(Camera camera, float tickProgress, boolean changingFov,
                                 CallbackInfoReturnable<Number> cir) {
        Number original = cir.getReturnValue();
        if (original == null) {
            return;
        }
        float zoomed = ZoomModule.applyZoom(original.floatValue(), changingFov);
        if (original instanceof Double) {
            cir.setReturnValue((double) zoomed);
        } else {
            cir.setReturnValue(zoomed);
        }
    }
}

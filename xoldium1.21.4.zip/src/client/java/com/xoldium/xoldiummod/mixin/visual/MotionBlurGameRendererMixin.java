package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook motion blur: di akhir {@code GameRenderer#renderWorld} - setelah dunia + tangan selesai digambar
 * dan SEBELUM HUD/GUI, titik yang sama dengan rantai post-effect pada BlurOnly (sehingga HUD tidak ter-blur).
 * Dipasang lewat nama method saja agar tidak bergantung pada descriptor.
 */
@Mixin(GameRenderer.class)
public abstract class MotionBlurGameRendererMixin {

    @Inject(method = "renderWorld", at = @At("RETURN"), require = 0)
    private void xoldium$motionBlur(RenderTickCounter tickCounter, CallbackInfo ci) {
        MotionBlurRenderer.applyFromMixin(MinecraftClient.getInstance());
    }
}

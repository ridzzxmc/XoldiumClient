package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook motion blur: di akhir {@code GameRenderer#render} (TAIL), sama seperti
 * {@code MixinGameRenderer} pada source motion blur asli.
 */
@Mixin(GameRenderer.class)
public abstract class MotionBlurGameRendererMixin {

    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V", at = @At("TAIL"), require = 0)
    private void xoldium$motionBlur(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        MotionBlurRenderer.apply(this.client);
    }
}

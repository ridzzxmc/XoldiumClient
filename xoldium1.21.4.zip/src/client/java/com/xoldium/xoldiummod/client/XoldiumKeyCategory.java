package com.xoldium.xoldiummod.client;

/**
 * Kategori keybind Xoldium di menu Controls.
 *
 * <p>Di 1.21.4 kategori keybind masih berupa String translation key biasa
 * (objek {@code KeyBinding.Category} baru ada sejak 1.21.9). Nama tampilnya
 * diambil dari lang key {@code key.category.xoldiummod.main}.
 */
public final class XoldiumKeyCategory {

    public static final String MAIN = "key.category.xoldiummod.main";

    private XoldiumKeyCategory() {
    }
}

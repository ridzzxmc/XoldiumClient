package com.xoldium.xoldiummod.client.render.motionblur;

import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;

/**
 * Motion blur Xoldium untuk Minecraft 1.21.4.
 *
 * <p>Algoritma DIPORT dari source "BlurOnly" (dev.hitsonly) yang dikirim pemakai: rantai post-effect
 * {@code bluronly:motion_blur} mencampur frame sekarang dengan frame sebelumnya
 * ({@code blend = min(amount, 99) / 100}, amount 0..100, default 50) dan dijalankan SETELAH dunia + tangan
 * dirender tetapi SEBELUM HUD/GUI, hanya saat di dalam dunia tanpa layar terbuka. Di sini hook-nya ada di akhir
 * {@code GameRenderer#renderWorld} (titik yang sama), sehingga HUD tidak ikut ter-blur.
 *
 * <p>Detail pass (dari motionblur-fabric / BlurOnly):
 * <ul>
 *   <li>ada target persisten {@code previous} (frame hasil blur sebelumnya),</li>
 *   <li>pass 1: {@code hasil = mix(frameSekarang, previous, blend)} - persis fragment shader
 *       {@code motion_blur.fsh} asli: {@code mix(curr.rgb, prev.rgb, eff)} (mode "linear",
 *       {@code eff = blend}),</li>
 *   <li>pass 2: hasil disalin kembali ke {@code previous} (blit "swap -> previous"),</li>
 *   <li>pass 3: hasil disalin ke layar utama (di sini langsung tertulis ke framebuffer utama).</li>
 * </ul>
 *
 * <p>Kenapa tidak memakai {@code post_effect/*.json} seperti mod aslinya: format post-effect
 * 1.21.11 (UBO {@code MotionBlurUniforms}, target {@code "persistent"}, {@code GpuBuffer} custom
 * uniform) TIDAK ada di 1.21.4. Persis efek yang sama dicapai di sini memakai blending alpha
 * pada framebuffer - hanya memakai API yang pasti ada di 1.21.4 (Framebuffer, RenderSystem,
 * BufferBuilder, shader vanilla position_tex_color), tanpa file shader/JSON kustom yang bisa
 * gagal dikompilasi. Seluruh jalur dibungkus try/catch: bila ada yang gagal, motion blur
 * dimatikan untuk sesi itu (game TIDAK crash).
 */
public final class MotionBlurRenderer {

    /** Sama dengan batas asli: {@code Math.min(strength, 99) / 100}. */
    private static final float MAX_BLEND = 0.99F;

    private static SimpleFramebuffer previous;
    private static int previousWidth = -1;
    private static int previousHeight = -1;
    private static boolean previousValid = false;
    private static boolean runtimeFailed = false;
    private static boolean loggedFirstPass = false;

    private MotionBlurRenderer() {
    }

    /** Dipanggil saat modul di-toggle: buang riwayat frame supaya tidak ada "hantu" frame lama. */
    public static void reset() {
        previousValid = false;
    }

    /**
     * Dipanggil di akhir {@code GameRenderer#render} (sama seperti {@code MixinGameRenderer}
     * pada mod asli: {@code @Inject(method = "render", at = @At("TAIL"))}).
     */
    public static void applyFromMixin(MinecraftClient client) {
        MixinDiag.alive("motion_blur");
        apply(client);
    }

    /** Cadangan lewat WorldRenderEvents.END: hanya berjalan bila mixin renderWorld TIDAK ter-apply. */
    public static void applyFallback() {
        if (MixinDiag.isAlive("motion_blur")) {
            return;
        }
        apply(MinecraftClient.getInstance());
    }

    private static void apply(MinecraftClient client) {
        if (runtimeFailed || client == null) {
            return;
        }
        boolean want = MotionBlurModule.isActive()
                && client.world != null
                && (!MotionBlurModule.pauseInGuis() || client.currentScreen == null);
        if (!want) {
            previousValid = false;
            return;
        }
        float blend = MotionBlurModule.blendFactor();
        if (blend <= 0.0F) {
            previousValid = false;
            return;
        }
        try {
            run(client, blend);
        } catch (Throwable t) {
            runtimeFailed = true;
            closeTarget();
            XoldiumMod.LOGGER.warn("[Xoldium] Motion blur dimatikan untuk sesi ini (error saat render, game tetap aman).", t);
        }
    }

    private static void run(MinecraftClient client, float blend) {
        RenderSystem.assertOnRenderThread();
        Framebuffer main = client.getFramebuffer();
        int width = main.textureWidth;
        int height = main.textureHeight;
        if (width <= 0 || height <= 0) {
            return;
        }
        ensureTarget(width, height);

        Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());
        ProjectionType savedType = RenderSystem.getProjectionType();
        RenderSystem.setProjectionMatrix(new Matrix4f().setOrtho(0.0F, 1.0F, 0.0F, 1.0F, -1.0F, 1.0F),
                ProjectionType.ORTHOGRAPHIC);
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().identity();
        try {
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();

            // Pass 1: main = mix(main, previous, blend)
            if (previousValid) {
                main.beginWrite(true);
                RenderSystem.colorMask(true, true, true, false);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                drawFullscreen(previous.getColorAttachment(), blend);
                RenderSystem.disableBlend();
                RenderSystem.colorMask(true, true, true, true);
            }

            // Pass 2: previous = main (hasil blur disimpan untuk frame berikutnya)
            previous.beginWrite(true);
            RenderSystem.disableBlend();
            drawFullscreen(main.getColorAttachment(), 1.0F);
            previousValid = true;
        } finally {
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.disableBlend();
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.enableCull();
            RenderSystem.getModelViewStack().popMatrix();
            RenderSystem.setProjectionMatrix(savedProjection, savedType);
            // Pass 3: hasil sudah ada di framebuffer utama - kembalikan sebagai target tulis.
            main.beginWrite(true);
        }
        if (!loggedFirstPass) {
            loggedFirstPass = true;
            XoldiumMod.LOGGER.info("[Xoldium] Motion blur aktif (frame blending, {}x{}, blend={}).", width, height, blend);
        }
    }

    private static void ensureTarget(int width, int height) {
        if (previous != null && previousWidth == width && previousHeight == height) {
            return;
        }
        closeTarget();
        previous = new SimpleFramebuffer(width, height, false);
        previousWidth = width;
        previousHeight = height;
        previousValid = false;
    }

    private static void closeTarget() {
        if (previous != null) {
            try {
                previous.delete();
            } catch (Throwable ignored) {
                // penutupan target murni pembersihan.
            }
            previous = null;
        }
        previousWidth = -1;
        previousHeight = -1;
        previousValid = false;
    }

    /** Menggambar tekstur {@code textureId} memenuhi seluruh target yang sedang aktif dengan alpha {@code alpha}. */
    private static void drawFullscreen(int textureId, float alpha) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, textureId);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(0.0F, 0.0F, 0.0F).texture(0.0F, 0.0F).color(1.0F, 1.0F, 1.0F, alpha);
        buffer.vertex(1.0F, 0.0F, 0.0F).texture(1.0F, 0.0F).color(1.0F, 1.0F, 1.0F, alpha);
        buffer.vertex(1.0F, 1.0F, 0.0F).texture(1.0F, 1.0F).color(1.0F, 1.0F, 1.0F, alpha);
        buffer.vertex(0.0F, 1.0F, 0.0F).texture(0.0F, 1.0F).color(1.0F, 1.0F, 1.0F, alpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    /** Dipakai {@link MotionBlurModule} untuk memetakan slider strength ke blend (batas atas sama dengan mod asli). */
    public static float clampBlend(float value) {
        return Math.max(0.0F, Math.min(MAX_BLEND, value));
    }
}

package com.xoldium.xoldiummod.client;

import com.xoldium.xoldiummod.XoldiumMod;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Diagnostik ringan: setiap mixin penting memanggil {@link #alive(String)} saat handler-nya
 * PERTAMA KALI benar-benar dijalankan. Jika baris "[Xoldium] mixin aktif: ..." untuk sebuah
 * fitur tidak muncul di latest.log padahal fiturnya dipakai, mixin itu tidak ter-apply.
 */
public final class MixinDiag {

    private static final Set<String> ALIVE = ConcurrentHashMap.newKeySet();

    private MixinDiag() {
    }

    public static void alive(String name) {
        if (ALIVE.add(name)) {
            XoldiumMod.LOGGER.info("[Xoldium] mixin aktif: {}", name);
        }
    }

    public static boolean isAlive(String name) {
        return ALIVE.contains(name);
    }
}

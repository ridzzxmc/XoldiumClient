package com.xoldium.xoldiummod.client.module.visual.zoom;

import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

/**
 * Mesin zoom - port langsung dari Zoomify ({@code ZoomHelper.kt}, {@code Interpolator.kt},
 * {@code DefaultZoomHelpers.kt}). Dipanggil {@link #tick} sekali per client tick (20x/detik) dan
 * {@link #getZoomDivisor} tiap kali FOV dihitung (interpolasi dengan partial tick).
 */
public final class ZoomHelper {

    // ---------------------------------------------------------------- interpolator

    public interface Interpolator {
        double tickInterpolation(double target, double current, double tickDelta);

        default double modifyInterpolation(double interpolation) {
            return interpolation;
        }

        default double modifyPrevInterpolation(double interpolation) {
            return interpolation;
        }

        boolean isSmooth();
    }

    private abstract static class LinearInterpolator implements Interpolator {
        protected boolean goingIn = true;

        @Override
        public double tickInterpolation(double target, double current, double tickDelta) {
            if (target > current) {
                goingIn = true;
                return Math.min(current + timeIncrement(false, tickDelta, target, current), target);
            } else if (target < current) {
                goingIn = false;
                return Math.max(current - timeIncrement(true, tickDelta, target, current), target);
            }
            goingIn = true;
            return target;
        }

        abstract double timeIncrement(boolean zoomingOut, double tickDelta, double target, double current);
    }

    private static class TimedInterpolator extends LinearInterpolator {
        private final DoubleSupplier timeIn;
        private final DoubleSupplier timeOut;

        TimedInterpolator(DoubleSupplier timeIn, DoubleSupplier timeOut) {
            this.timeIn = timeIn;
            this.timeOut = timeOut;
        }

        @Override
        double timeIncrement(boolean zoomingOut, double tickDelta, double target, double current) {
            return tickDelta / (zoomingOut ? timeOut.getAsDouble() : timeIn.getAsDouble());
        }

        @Override
        public boolean isSmooth() {
            return (goingIn && timeIn.getAsDouble() > 0.0) || (!goingIn && timeOut.getAsDouble() > 0.0);
        }
    }

    /** Interpolator zoom awal: waktu masuk/keluar + kurva transisi (default Zoomify: EASE_OUT_EXP). */
    public static final class TransitionInterpolator extends TimedInterpolator {
        private final Supplier<ZoomTransition> transitionIn;
        private final Supplier<ZoomTransition> transitionOutRaw;
        private ZoomTransition active;
        private ZoomTransition inactive;
        private double prevTarget = 0.0;
        private boolean justSwapped = false;

        public TransitionInterpolator(Supplier<ZoomTransition> transitionIn, Supplier<ZoomTransition> transitionOutRaw,
                                      DoubleSupplier timeIn, DoubleSupplier timeOut) {
            super(timeIn, timeOut);
            this.transitionIn = transitionIn;
            this.transitionOutRaw = transitionOutRaw;
            this.active = transitionIn.get();
            this.inactive = transitionOutRaw.get();
        }

        private ZoomTransition transitionOut() {
            return transitionOutRaw.get().opposite();
        }

        @Override
        public double tickInterpolation(double target, double current, double tickDelta) {
            double cur = current;
            if (target > current) {
                active = transitionIn.get();
                inactive = transitionOut();
                if (prevTarget < target && active.hasInverse()) {
                    justSwapped = true;
                    cur = active.inverse(inactive.apply(cur));
                }
            } else if (target < current) {
                active = transitionOut();
                inactive = transitionIn.get();
                if (prevTarget > target && active.hasInverse()) {
                    justSwapped = true;
                    cur = active.inverse(inactive.apply(cur));
                }
            }
            prevTarget = target;
            if (active == ZoomTransition.INSTANT) {
                return target;
            }
            return super.tickInterpolation(target, cur, tickDelta);
        }

        @Override
        public double modifyInterpolation(double interpolation) {
            return active.apply(interpolation);
        }

        @Override
        public double modifyPrevInterpolation(double interpolation) {
            if (justSwapped) {
                justSwapped = false;
                return active.inverse(inactive.apply(interpolation));
            }
            return interpolation;
        }

        @Override
        public boolean isSmooth() {
            return !justSwapped && super.isSmooth() && active != ZoomTransition.INSTANT;
        }
    }

    /** Interpolator scroll: makin dekat target makin pelan (eksponensial). */
    public static final class SmoothInterpolator extends LinearInterpolator {
        private final DoubleSupplier smoothness;

        public SmoothInterpolator(DoubleSupplier smoothness) {
            this.smoothness = smoothness;
        }

        @Override
        double timeIncrement(boolean zoomingOut, double tickDelta, double target, double current) {
            double diff = !zoomingOut ? target - current : current - target;
            return diff * smoothness.getAsDouble() / 0.05 * tickDelta;
        }

        @Override
        public double tickInterpolation(double target, double current, double tickDelta) {
            if (!isSmooth()) {
                return target;
            }
            return super.tickInterpolation(target, current, tickDelta);
        }

        @Override
        public boolean isSmooth() {
            return smoothness.getAsDouble() != 1.0;
        }
    }

    // ---------------------------------------------------------------- helper

    private final Interpolator initialInterpolator;
    private final Interpolator scrollInterpolator;
    private final DoubleSupplier initialZoom;
    private final DoubleSupplier zoomPerStep;
    private final DoubleSupplier maxScrollTiers;

    private double prevInitialInterpolation = 0.0;
    private double initialInterpolation = 0.0;
    private boolean zoomingLastTick = false;
    private double prevScrollInterpolation = 0.0;
    private double scrollInterpolation = 0.0;
    private int lastScrollTier = 0;
    private boolean resetting = false;
    private double resetMultiplier = 0.0;

    public ZoomHelper(Interpolator initialInterpolator, Interpolator scrollInterpolator,
                      DoubleSupplier initialZoom, DoubleSupplier zoomPerStep, DoubleSupplier maxScrollTiers) {
        this.initialInterpolator = initialInterpolator;
        this.scrollInterpolator = scrollInterpolator;
        this.initialZoom = initialZoom;
        this.zoomPerStep = zoomPerStep;
        this.maxScrollTiers = maxScrollTiers;
    }

    public void tick(boolean zooming, int scrollTiers) {
        tick(zooming, scrollTiers, 0.05);
    }

    public void tick(boolean zooming, int scrollTiers, double lastFrameDuration) {
        tickInitial(zooming, lastFrameDuration);
        tickScroll(scrollTiers, lastFrameDuration);
    }

    private void tickInitial(boolean zooming, double lastFrameDuration) {
        if (zooming && !zoomingLastTick) {
            resetting = false;
        }
        double targetZoom = zooming ? 1.0 : 0.0;
        prevInitialInterpolation = initialInterpolation;
        initialInterpolation = initialInterpolator.tickInterpolation(targetZoom, initialInterpolation, lastFrameDuration);
        prevInitialInterpolation = initialInterpolator.modifyPrevInterpolation(prevInitialInterpolation);
        if (!initialInterpolator.isSmooth()) {
            prevInitialInterpolation = initialInterpolation;
        }
        zoomingLastTick = zooming;
    }

    private void tickScroll(int scrollTiers, double lastFrameDuration) {
        if (scrollTiers > lastScrollTier) {
            resetting = false;
        }
        double max = maxScrollTiers.getAsDouble();
        double targetZoom = max > 0 ? scrollTiers / max : 0.0;
        prevScrollInterpolation = scrollInterpolation;
        scrollInterpolation = scrollInterpolator.tickInterpolation(targetZoom, scrollInterpolation, lastFrameDuration);
        prevScrollInterpolation = scrollInterpolator.modifyPrevInterpolation(prevScrollInterpolation);
        if (!initialInterpolator.isSmooth()) {
            prevInitialInterpolation = initialInterpolation;
        }
        lastScrollTier = scrollTiers;
    }

    public double getZoomDivisor(float tickDelta) {
        double initialMultiplier = getInitialZoomMultiplier(tickDelta);
        double baseDivisor = 1 / initialMultiplier;

        double scrollT;
        if (resetting) {
            scrollT = 0.0;
        } else if (scrollInterpolator.isSmooth()) {
            scrollT = scrollInterpolator.modifyInterpolation(lerp(tickDelta, prevScrollInterpolation, scrollInterpolation));
        } else {
            scrollT = scrollInterpolation;
        }

        double stepMultiplier = zoomPerStep.getAsDouble() / 100.0;
        double currentStep = scrollT * maxScrollTiers.getAsDouble();
        double rawDivisor = baseDivisor * Math.pow(stepMultiplier, currentStep);
        double finalDivisor = Math.max(0.5, Math.min(500.0, rawDivisor));

        if (initialInterpolation == 0.0 && scrollInterpolation == 0.0) {
            resetting = false;
        }
        if (!resetting) {
            resetMultiplier = 1 / finalDivisor;
        }
        return finalDivisor;
    }

    private double getInitialZoomMultiplier(float tickDelta) {
        double t;
        if (initialInterpolator.isSmooth()) {
            t = initialInterpolator.modifyInterpolation(lerp(tickDelta, prevInitialInterpolation, initialInterpolation));
        } else {
            t = initialInterpolation;
        }
        return lerp(t, 1.0, !resetting ? 1 / initialZoom.getAsDouble() : resetMultiplier);
    }

    public void reset() {
        if (!resetting && scrollInterpolation > 0.0) {
            resetting = true;
            scrollInterpolation = 0.0;
            prevScrollInterpolation = 0.0;
        }
    }

    public void setToZero() {
        initialInterpolation = 0.0;
        prevInitialInterpolation = 0.0;
        zoomingLastTick = false;
        scrollInterpolation = 0.0;
        prevScrollInterpolation = 0.0;
        lastScrollTier = 0;
        resetting = false;
    }

    private static double lerp(double delta, double start, double end) {
        return start + delta * (end - start);
    }
}

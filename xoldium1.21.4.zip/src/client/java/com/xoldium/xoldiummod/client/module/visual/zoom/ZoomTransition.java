package com.xoldium.xoldiummod.client.module.visual.zoom;

import java.util.function.DoubleUnaryOperator;

/**
 * Kurva transisi zoom - port dari {@code TransitionType} Zoomify (dev.isxander.zoomify.utils).
 * {@code inverse} bernilai null untuk kurva yang tidak punya invers (sama seperti Zoomify).
 */
public enum ZoomTransition {
    INSTANT(t -> t, null),
    LINEAR(t -> t, null),
    EASE_IN_SINE(t -> 1 - Math.cos((t * Math.PI) / 2), x -> Math.acos(-(x - 1)) * 2 / Math.PI),
    EASE_OUT_SINE(t -> Math.sin((t * Math.PI) / 2), x -> Math.asin(x) * 2 / Math.PI),
    EASE_IN_QUAD(t -> t * t, Math::sqrt),
    EASE_OUT_QUAD(t -> 1 - (1 - t) * (1 - t), x -> -(Math.sqrt(-(x - 1)) - 1)),
    EASE_IN_CUBIC(t -> t * t * t, x -> Math.pow(x, 1 / 3.0)),
    EASE_OUT_CUBIC(t -> 1 - Math.pow(1 - t, 3), x -> -Math.pow(-x + 1, 1.0 / 3.0) + 1),
    EASE_IN_EXP(
            t -> t == 0.0 ? 0.0 : t == 1.0 ? 1.0 : Math.pow(2.0, 10.0 * t - K.LOG2_1023) - 1 / 1023.0,
            x -> x == 0.0 ? 0.0 : x == 1.0 ? 1.0 : Math.log(1023 * x + 1) / (10 * Math.log(2.0))),
    EASE_OUT_EXP(
            t -> t == 0.0 ? 0.0 : t == 1.0 ? 1.0 : 1.0 - Math.pow(2.0, 10.0 - K.LOG2_1023 - 10.0 * t) + 1 / 1023.0,
            x -> x == 0.0 ? 0.0 : x == 1.0 ? 1.0
                    : -((Math.log(-((1023 * x - 1024) / 1023)) - K.TEN_LN2 + K.LN_1023) / K.TEN_LN2));

    /** Konstanta di kelas terpisah supaya lambda enum tidak kena "illegal forward reference". */
    private static final class K {
        static final double LOG2_1023 = Math.log(1023.0) / Math.log(2.0);
        static final double TEN_LN2 = 10.0 * Math.log(2.0);
        static final double LN_1023 = Math.log(1023.0);

        private K() {
        }
    }

    private final DoubleUnaryOperator apply;
    private final DoubleUnaryOperator inverse;

    ZoomTransition(DoubleUnaryOperator apply, DoubleUnaryOperator inverse) {
        this.apply = apply;
        this.inverse = inverse;
    }

    public double apply(double t) {
        return apply.applyAsDouble(t);
    }

    public boolean hasInverse() {
        return inverse != null;
    }

    public double inverse(double x) {
        if (inverse == null) {
            throw new UnsupportedOperationException();
        }
        return inverse.applyAsDouble(x);
    }

    public ZoomTransition opposite() {
        return switch (this) {
            case INSTANT -> INSTANT;
            case LINEAR -> LINEAR;
            case EASE_IN_SINE -> EASE_OUT_SINE;
            case EASE_OUT_SINE -> EASE_IN_SINE;
            case EASE_IN_QUAD -> EASE_OUT_QUAD;
            case EASE_OUT_QUAD -> EASE_IN_QUAD;
            case EASE_IN_CUBIC -> EASE_OUT_CUBIC;
            case EASE_OUT_CUBIC -> EASE_IN_CUBIC;
            case EASE_IN_EXP -> EASE_OUT_EXP;
            case EASE_OUT_EXP -> EASE_IN_EXP;
        };
    }
}

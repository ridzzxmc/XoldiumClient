package com.xoldium.xoldiummod.client.module.visual.zoom;

/**
 * Mode transisi zoom - port dari paket {@code zoom.transitions} Ok Zoomer 10.0.0-beta.9
 * ({@code InstantTransitionMode}, {@code SmoothTransitionMode}, {@code LinearTransitionMode}).
 * Logika tick dipertahankan; {@code Mth} diganti helper lokal (tanpa dependency mapping) dan
 * bagian "fade" (khusus overlay/crosshair Ok Zoomer) tidak dibawa.
 */
public interface ZoomTransition {

    /** True selagi transisi masih mempengaruhi FOV (sedang zoom atau sedang kembali ke normal). */
    boolean getActive();

    /** FOV x pengali transisi, diinterpolasi antar tick dengan {@code tickDelta}. */
    float applyZoom(float fov, float tickDelta);

    /** Dipanggil sekali per client tick. */
    void tick(boolean active, double divisor);

    /** Pengali internal saat ini (1 / divisor bila sudah penuh) - dipakai pengurang sensitivitas mouse. */
    double getInternalMultiplier();

    static float lerp(float delta, float start, float end) {
        return start + delta * (end - start);
    }

    static float safeMultiplier(double divisor) {
        return (divisor > 0.0 && Double.isFinite(divisor)) ? (float) (1.0 / divisor) : 1.0F;
    }

    /** Tanpa animasi: FOV langsung dibagi divisor. */
    final class Instant implements ZoomTransition {
        private boolean active = false;
        private double divisor = 1.0;

        @Override
        public boolean getActive() {
            return active;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * safeMultiplier(divisor);
        }

        @Override
        public void tick(boolean active, double divisor) {
            this.active = active;
            this.divisor = divisor;
        }

        @Override
        public double getInternalMultiplier() {
            return safeMultiplier(divisor);
        }
    }

    /** Transisi halus: tiap tick mendekati target sebesar {@code smoothMultiplier} dari selisihnya. */
    final class Smooth implements ZoomTransition {
        private boolean active = false;
        private final float smoothMultiplier;
        private float internalMultiplier = 1.0F;
        private float lastInternalMultiplier = 1.0F;

        public Smooth(float smoothMultiplier) {
            this.smoothMultiplier = Math.max(0.01F, Math.min(1.0F, smoothMultiplier));
        }

        @Override
        public boolean getActive() {
            return active || internalMultiplier != 1.0F;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * lerp(tickDelta, lastInternalMultiplier, internalMultiplier);
        }

        @Override
        public void tick(boolean active, double divisor) {
            float target = active ? safeMultiplier(divisor) : 1.0F;
            lastInternalMultiplier = internalMultiplier;
            internalMultiplier += (target - internalMultiplier) * smoothMultiplier;
            // Tambahan keamanan: tanpa ini float bisa "nyaris 1" lama sekali -> transisi tak pernah berhenti aktif.
            if (!active && Math.abs(internalMultiplier - 1.0F) < 0.0005F) {
                internalMultiplier = 1.0F;
            }
            this.active = active;
        }

        @Override
        public double getInternalMultiplier() {
            return internalMultiplier;
        }
    }

    /** Transisi linear: pengali bergerak dengan langkah tetap {@code linearStep} per tick. */
    final class Linear implements ZoomTransition {
        private boolean active = false;
        private final float linearStep;
        private float internalMultiplier = 1.0F;
        private float lastInternalMultiplier = 1.0F;

        public Linear(float linearStep) {
            this.linearStep = Math.max(0.001F, linearStep);
        }

        private static float approach(float current, float target, float step) {
            return current < target ? Math.min(current + step, target) : Math.max(current - step, target);
        }

        @Override
        public boolean getActive() {
            return active || internalMultiplier != 1.0F;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * lerp(tickDelta, lastInternalMultiplier, internalMultiplier);
        }

        @Override
        public void tick(boolean active, double divisor) {
            float target = active ? safeMultiplier(divisor) : 1.0F;
            lastInternalMultiplier = internalMultiplier;
            internalMultiplier = approach(internalMultiplier, target, linearStep);
            this.active = active;
        }

        @Override
        public double getInternalMultiplier() {
            return internalMultiplier;
        }
    }
}

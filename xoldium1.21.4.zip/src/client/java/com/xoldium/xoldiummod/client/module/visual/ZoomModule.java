package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.zoom.ZoomTransition;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom Xoldium - mesin zoom dari mod Ok Zoomer 10.0.0-beta.9:
 * <ul>
 *   <li>sinyal zoom Hold / Toggle / Persistent = {@code ManageZoomEvent}</li>
 *   <li>langkah scroll eksponensial: divisor = base^(langkah / resolusi) = {@code ZoomUtils}</li>
 *   <li>transisi Instant / Smooth / Linear = {@code zoom.transitions} (lihat {@link ZoomTransition})</li>
 *   <li>FOV = FOV asli x pengali transisi (akhir {@code GameRenderer#getFov}), sensitivitas mouse =
 *       delta x pengali transisi = {@code ZoomDivisorMouseModifier}</li>
 * </ul>
 * Tidak dibawa: overlay vinyet/spyglass, kamera sinematik, GUI-zoom, view-bobbing, mode spyglass.
 *
 * <p>Perbaikan "zoom tidak jalan": tombol C bentrok dengan keybind vanilla "Save Hotbar Activator".
 * Minecraft hanya menyimpan SATU keybind per tombol fisik, jadi bila yang vanilla yang menang,
 * {@code zoomKey.isPressed()} tidak pernah true. Karena itu status tombol juga dibaca langsung dari GLFW
 * ({@link #readZoomKey}), sehingga zoom tetap jalan walau ada bentrok.
 */
public final class ZoomModule extends Module {

    private static final int MODE_HOLD = 0;
    private static final int MODE_TOGGLE = 1;
    private static final int MODE_PERSISTENT = 2;

    private static final int TRANSITION_INSTANT = 0;
    private static final int TRANSITION_SMOOTH = 1;
    private static final int TRANSITION_LINEAR = 2;

    private static ZoomModule instance;

    private final KeyBinding zoomKey;
    private final KeyBinding zoomInKey;
    private final KeyBinding zoomOutKey;
    private final KeyBinding zoomResetKey;

    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", MODE_HOLD,
                    "setting.xoldiummod.zoom.mode.hold",
                    "setting.xoldiummod.zoom.mode.toggle",
                    "setting.xoldiummod.zoom.mode.persistent"));
    private final ModeSetting transition = addSetting(
            new ModeSetting("transition_type", "setting.xoldiummod.zoom.transition_type", TRANSITION_SMOOTH,
                    "setting.xoldiummod.zoom.transition.instant",
                    "setting.xoldiummod.zoom.transition.smooth",
                    "setting.xoldiummod.zoom.transition.linear"));
    private final DoubleSetting smoothFactor = addSetting(
            new DoubleSetting("smooth_factor", "setting.xoldiummod.zoom.smooth_factor", 0.6, 0.05, 1.0, 0.05));
    private final DoubleSetting linearStep = addSetting(
            new DoubleSetting("linear_step", "setting.xoldiummod.zoom.linear_step", 0.2, 0.05, 1.0, 0.05));
    private final DoubleSetting defaultStep = addSetting(
            new DoubleSetting("default_step", "setting.xoldiummod.zoom.default_step", 10.0, 0.0, 30.0, 1.0));
    private final DoubleSetting scrollSteps = addSetting(
            new DoubleSetting("scroll_steps", "setting.xoldiummod.zoom.scroll_steps", 30.0, 1.0, 50.0, 1.0));
    private final DoubleSetting scrollBase = addSetting(
            new DoubleSetting("scroll_base", "setting.xoldiummod.zoom.scroll_base", 2.0, 2.0, 8.0, 1.0));
    private final DoubleSetting scrollResolution = addSetting(
            new DoubleSetting("scroll_resolution", "setting.xoldiummod.zoom.scroll_resolution", 5.0, 1.0, 10.0, 1.0));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));
    private final BooleanSetting affectHand = addSetting(
            new BooleanSetting("affect_hand", "setting.xoldiummod.zoom.affect_hand", true));

    private ZoomTransition transitionMode = new ZoomTransition.Instant();
    private int builtType = -1;
    private float builtParam = Float.NaN;

    private boolean zooming = false;
    private boolean lastZooming = false;
    private boolean persistentZoom = false;
    private boolean keyHeld = false;
    private boolean modifierActive = false;
    private double zoomDivisor = 4.0;
    private int zoomStep = 0;

    private boolean fovHookAlive = false;
    private boolean warnedNoHook = false;
    private int ticksZoomingWithoutHook = 0;

    public ZoomModule() {
        // Zoom adalah fitur dasar: aktif sejak awal (tombol C), tidak perlu dinyalakan manual dulu.
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, true);
        instance = this;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomResetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_reset", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", zoomKey));
        addSetting(new KeybindSetting("key_in", "setting.xoldiummod.zoom.key_in", zoomInKey));
        addSetting(new KeybindSetting("key_out", "setting.xoldiummod.zoom.key_out", zoomOutKey));
        addSetting(new KeybindSetting("key_reset", "setting.xoldiummod.zoom.key_reset", zoomResetKey));
        ensureTransition();
        resetZoomDivisor();
    }

    // ------------------------------------------------------------------ transisi

    /** Bangun ulang transisi bila jenis / parameternya di pengaturan berubah. */
    private void ensureTransition() {
        int type = Math.max(TRANSITION_INSTANT, Math.min(TRANSITION_LINEAR, transition.index()));
        float param = switch (type) {
            case TRANSITION_SMOOTH -> (float) smoothFactor.get().doubleValue();
            case TRANSITION_LINEAR -> (float) linearStep.get().doubleValue();
            default -> 0.0F;
        };
        if (type == builtType && Float.compare(param, builtParam) == 0) {
            return;
        }
        transitionMode = switch (type) {
            case TRANSITION_SMOOTH -> new ZoomTransition.Smooth(param);
            case TRANSITION_LINEAR -> new ZoomTransition.Linear(param);
            default -> new ZoomTransition.Instant();
        };
        builtType = type;
        builtParam = param;
    }

    // ------------------------------------------------------------------ langkah zoom (Ok Zoomer: ZoomUtils)

    private int stepLimit() {
        return Math.max(1, (int) Math.round(scrollSteps.get()));
    }

    private double divisorForStep(int step) {
        if (step == 0) {
            return 1.0;
        }
        int base = Math.max(2, (int) Math.round(scrollBase.get()));
        int resolution = Math.max(1, (int) Math.round(scrollResolution.get()));
        double d = Math.pow(base, (double) step / resolution);
        return (Double.isFinite(d) && d >= 1.0) ? d : 1.0;
    }

    private void changeZoomDivisor(boolean increase) {
        zoomStep = increase ? Math.min(zoomStep + 1, stepLimit()) : Math.max(zoomStep - 1, 0);
        zoomDivisor = divisorForStep(zoomStep);
    }

    private void resetZoomDivisor() {
        zoomStep = Math.min((int) Math.round(defaultStep.get()), stepLimit());
        zoomDivisor = divisorForStep(zoomStep);
    }

    private void keepZoomStepWithinBounds() {
        zoomStep = Math.max(0, Math.min(zoomStep, stepLimit()));
        zoomDivisor = divisorForStep(zoomStep);
    }

    // ------------------------------------------------------------------ siklus modul

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        lastZooming = false;
        persistentZoom = false;
        keyHeld = false;
        modifierActive = false;
        builtType = -1;
        ensureTransition();
        resetZoomDivisor();
    }

    /**
     * Status tombol zoom. Selain {@code KeyBinding#isPressed} (bisa selalu false bila tombol dipakai
     * bersama keybind vanilla lain), tombol fisiknya juga dibaca langsung dari GLFW saat tidak ada layar terbuka.
     */
    private boolean readZoomKey(MinecraftClient client) {
        if (zoomKey.isPressed()) {
            return true;
        }
        if (client.currentScreen != null) {
            return false;
        }
        try {
            InputUtil.Key bound = KeyBindingHelper.getBoundKeyOf(zoomKey);
            if (bound == null) {
                return false;
            }
            int code = bound.getCode();
            if (code < 0) {
                return false;
            }
            long handle = client.getWindow().getHandle();
            InputUtil.Type type = bound.getCategory();
            if (type == InputUtil.Type.MOUSE) {
                return GLFW.glfwGetMouseButton(handle, code) == GLFW.GLFW_PRESS;
            }
            if (type == InputUtil.Type.KEYSYM) {
                return GLFW.glfwGetKey(handle, code) == GLFW.GLFW_PRESS;
            }
        } catch (Throwable ignored) {
            // pembacaan GLFW hanya cadangan - bila gagal, andalkan KeyBinding biasa.
        }
        return false;
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ensureTransition();

        if (client.player == null) {
            if (zooming || transitionMode.getActive()) {
                builtType = -1;
                ensureTransition();
            }
            zooming = false;
            lastZooming = false;
            keyHeld = false;
            modifierActive = false;
            return;
        }

        // --- sinyal zoom (Ok Zoomer: ManageZoomEvent) ---
        boolean keyDown = readZoomKey(client);
        keyHeld = keyDown;
        while (zoomKey.wasPressed()) {
            // habiskan klik antrean agar tidak menumpuk
        }

        int zoomMode = mode.index();
        if (zoomMode != MODE_HOLD) {
            if (!persistentZoom) {
                persistentZoom = true;
                lastZooming = true;
                resetZoomDivisor();
            }
        } else if (persistentZoom) {
            persistentZoom = false;
            lastZooming = true;
        }

        if (keyDown != lastZooming) {
            switch (zoomMode) {
                case MODE_TOGGLE -> {
                    if (keyDown) {
                        zooming = !zooming;
                        resetZoomDivisor();
                    }
                }
                case MODE_PERSISTENT -> {
                    zooming = true;
                    keepZoomStepWithinBounds();
                }
                default -> {
                    zooming = keyDown;
                    resetZoomDivisor();
                }
            }
            lastZooming = keyDown;
        }

        // --- tombol ekstra zoom masuk/keluar/reset (Ok Zoomer: ManageExtraKeysEvent) ---
        boolean in = zoomInKey.isPressed();
        boolean out = zoomOutKey.isPressed();
        boolean reset = zoomResetKey.isPressed();
        while (zoomInKey.wasPressed()) {
            // habiskan
        }
        while (zoomOutKey.wasPressed()) {
            // habiskan
        }
        while (zoomResetKey.wasPressed()) {
            // habiskan
        }
        if (zooming) {
            if (out && !in) {
                changeZoomDivisor(false);
            }
            if (in && !out) {
                changeZoomDivisor(true);
            }
            if (reset) {
                resetZoomDivisor();
            }
        }

        // --- tick transisi (Ok Zoomer: GameRendererMixin#tickInstances) ---
        if (zooming || transitionMode.getActive() || modifierActive) {
            transitionMode.tick(zooming, zooming ? zoomDivisor : 1.0);
            modifierActive = reduceSensitivity.get() && zooming;
        }

        // --- diagnostik: hook FOV tidak ter-apply ---
        if (zooming && !fovHookAlive) {
            ticksZoomingWithoutHook++;
            if (ticksZoomingWithoutHook > 40 && !warnedNoHook) {
                warnedNoHook = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Zoom aktif tapi hook GameRenderer#getFov belum pernah terpanggil - "
                        + "mixin ZoomFovMixin tidak ter-apply (cek baris '[Xoldium] mixin aktif: zoom_fov' di latest.log).");
                try {
                    client.inGameHud.setOverlayMessage(
                            Text.literal("[Xoldium] Zoom: hook FOV tidak aktif - kirim latest.log"), false);
                } catch (Throwable ignored) {
                    // pesan layar hanya bantuan diagnosa.
                }
            }
        } else if (!zooming) {
            ticksZoomingWithoutHook = 0;
        }
    }

    // ------------------------------------------------------------------ API untuk mixin

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.transitionMode.getActive());
    }

    /**
     * Dipanggil dari akhir {@code GameRenderer#getFov} (Ok Zoomer: {@code GameRendererMixin#modifyFov}).
     *
     * @param useFovSetting true untuk FOV dunia, false untuk FOV tangan/item (changingFov = false di vanilla)
     */
    public static double applyZoom(double baseFov, float tickDelta, boolean useFovSetting) {
        ZoomModule z = instance;
        if (z == null) {
            return baseFov;
        }
        z.fovHookAlive = true;
        MixinDiag.alive("zoom_fov");
        if (!z.isEnabled() || !z.transitionMode.getActive() || (!useFovSetting && !z.affectHand.get())) {
            return baseFov;
        }
        double result = z.transitionMode.applyZoom((float) baseFov, tickDelta);
        return Double.isFinite(result) ? Math.max(0.1, result) : baseFov;
    }

    /** Pengali gerakan kamera (Ok Zoomer: {@code ZoomDivisorMouseModifier}): delta x pengali transisi. */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.modifierActive) {
            return 1.0;
        }
        double m = z.transitionMode.getInternalMultiplier();
        return (Double.isFinite(m) && m > 0.0) ? m : 1.0;
    }

    /** Scroll saat zoom -> naik/turun langkah zoom (Ok Zoomer: {@code MouseHandlerMixin#zoomerOnMouseScroll}). */
    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        if (z.mode.index() == MODE_PERSISTENT && !z.keyHeld) {
            return false; // mode Persistent: scroll hanya mengatur zoom selagi tombol zoom ditahan
        }
        z.changeZoomDivisor(vertical > 0);
        return true;
    }
}

package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.zoom.EasedTransitionMode;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom Xoldium - memakai mesin zoom dari mod Ok Zoomer 5.4.0 (lihat {@link EasedTransitionMode}):
 * <ul>
 *   <li>sinyal zoom (Hold/Toggle) dan reset langkah scroll = {@code ManageZoomEvent}</li>
 *   <li>langkah scroll eksponensial: divisor = base^(langkah / resolusi), base 2, resolusi 5 = {@code ZoomUtils}</li>
 *   <li>transisi masuk/keluar/scroll berbasis tick = {@code EasedTransitionMode}</li>
 *   <li>FOV = FOV asli x multiplier transisi (di akhir {@code GameRenderer#getFov}); sensitivitas mouse
 *       = delta x multiplier transisi = {@code ZoomDivisorMouseModifier}</li>
 * </ul>
 * Overlay vinyet/spyglass, GUI-zoom, view-bobbing, dan mode spyglass Ok Zoomer tidak dibawa.
 */
public final class ZoomModule extends Module {

    private static final int SCROLL_BASE = 2;
    private static final int SCROLL_RESOLUTION = 5;
    private static final int SCROLL_TICKS = 8;

    private static final int TRANSITION_INSTANT = 0;

    private static ZoomModule instance;

    private final KeyBinding zoomKey;
    private final KeyBinding zoomInKey;
    private final KeyBinding zoomOutKey;
    private final KeyBinding zoomResetKey;

    private final DoubleSetting defaultStep = addSetting(
            new DoubleSetting("default_step", "setting.xoldiummod.zoom.default_step", 10.0, 1.0, 30.0, 1.0));
    private final DoubleSetting scrollSteps = addSetting(
            new DoubleSetting("scroll_steps", "setting.xoldiummod.zoom.scroll_steps", 30.0, 1.0, 50.0, 1.0));
    private final DoubleSetting zoomInTime = addSetting(
            new DoubleSetting("zoom_in_time", "setting.xoldiummod.zoom.zoom_in_time", 0.4, 0.0, 5.0, 0.05));
    private final DoubleSetting zoomOutTime = addSetting(
            new DoubleSetting("zoom_out_time", "setting.xoldiummod.zoom.zoom_out_time", 0.4, 0.0, 5.0, 0.05));
    private final ModeSetting transition = addSetting(
            new ModeSetting("transition", "setting.xoldiummod.zoom.transition", 2,
                    "setting.xoldiummod.zoom.transition.instant",
                    "setting.xoldiummod.zoom.transition.linear",
                    "setting.xoldiummod.zoom.transition.smooth",
                    "setting.xoldiummod.zoom.transition.sine",
                    "setting.xoldiummod.zoom.transition.balanced",
                    "setting.xoldiummod.zoom.transition.spring"));
    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", 0,
                    "setting.xoldiummod.zoom.mode.hold", "setting.xoldiummod.zoom.mode.toggle"));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));
    private final BooleanSetting affectHand = addSetting(
            new BooleanSetting("affect_hand", "setting.xoldiummod.zoom.affect_hand", true));

    private EasedTransitionMode transitionMode = buildTransition(2, 8, 8);
    private int builtMode = 2;
    private int builtStartTicks = 8;
    private int builtEndTicks = 8;

    private boolean zooming = false;
    private boolean lastKeyDown = false;
    private boolean modifierActive = false;
    private double zoomDivisor = 4.0;
    private int zoomStep = 0;

    private boolean fovHookAlive = false;
    private boolean warnedNoHook = false;
    private int ticksZoomingWithoutHook = 0;

    public ZoomModule() {
        // Zoom adalah fitur dasar: aktif sejak awal (tombol C), tidak perlu dinyalakan manual dulu.
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, true);
        instance = this;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomResetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_reset", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", zoomKey));
        addSetting(new KeybindSetting("key_in", "setting.xoldiummod.zoom.key_in", zoomInKey));
        addSetting(new KeybindSetting("key_out", "setting.xoldiummod.zoom.key_out", zoomOutKey));
        addSetting(new KeybindSetting("key_reset", "setting.xoldiummod.zoom.key_reset", zoomResetKey));
    }

    // ------------------------------------------------------------------ transisi (Ok Zoomer: getZoomTransitionOperator)

    private static EasedTransitionMode.Curve curve(int index) {
        return switch (index) {
            case 0 -> f -> 1.0F;
            case 1 -> f -> f;
            case 2 -> f -> (float) (1.0 - Math.pow(2.0, -10.0 * f));
            case 3 -> f -> (float) (1.0 - Math.cos(f * Math.PI / 2.0));
            case 4 -> f -> (float) (1.0 - Math.pow(1.0 - f, 3.0));
            default -> f -> (float) (Math.pow(2.0, -10.0F * f) * MathHelper.sin((f * 10.0F - 0.75F) * 1.5F) + 1.0F);
        };
    }

    private static EasedTransitionMode buildTransition(int modeIndex, int startTicks, int endTicks) {
        EasedTransitionMode.Curve c = curve(modeIndex);
        int scrollTicks = modeIndex == TRANSITION_INSTANT ? 0 : SCROLL_TICKS;
        return new EasedTransitionMode(c, c, c, startTicks, endTicks, scrollTicks, false, false);
    }

    /** Bangun ulang transisi bila pengaturan (kurva / waktu) berubah. */
    private void ensureTransition() {
        int m = Math.max(0, Math.min(5, transition.index()));
        int start = m == TRANSITION_INSTANT ? 0 : (int) Math.round(zoomInTime.get() * 20.0);
        int end = m == TRANSITION_INSTANT ? 0 : (int) Math.round(zoomOutTime.get() * 20.0);
        if (m != builtMode || start != builtStartTicks || end != builtEndTicks) {
            transitionMode = buildTransition(m, start, end);
            builtMode = m;
            builtStartTicks = start;
            builtEndTicks = end;
        }
    }

    // ------------------------------------------------------------------ langkah zoom (Ok Zoomer: ZoomUtils)

    private int stepLimit() {
        return Math.max(1, (int) Math.round(scrollSteps.get()));
    }

    private void changeZoomDivisor(boolean increase) {
        zoomStep = increase ? Math.min(zoomStep + 1, stepLimit()) : Math.max(zoomStep - 1, 0);
        zoomDivisor = zoomStep != 0 ? Math.pow(SCROLL_BASE, (double) zoomStep / SCROLL_RESOLUTION) : 1.0;
    }

    private void resetZoomDivisor() {
        zoomStep = Math.min((int) Math.round(defaultStep.get()), stepLimit());
        zoomDivisor = Math.pow(SCROLL_BASE, (double) zoomStep / SCROLL_RESOLUTION);
    }

    private void setZooming(boolean value) {
        zooming = value;
        resetZoomDivisor();
    }

    // ------------------------------------------------------------------ siklus modul

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        lastKeyDown = false;
        modifierActive = false;
        zoomStep = 0;
        zoomDivisor = 4.0;
        builtMode = -1; // paksa transisi dibangun ulang (state bersih)
        ensureTransition();
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ensureTransition();

        if (client.player == null) {
            zooming = false;
            lastKeyDown = false;
            return;
        }

        // --- sinyal zoom (Ok Zoomer: ManageZoomEvent) ---
        boolean keyDown = zoomKey.isPressed();
        while (zoomKey.wasPressed()) {
            // habiskan klik antrean agar tidak menumpuk
        }
        if (mode.index() == 0) {
            if (zooming != keyDown) {
                setZooming(keyDown);
            }
        } else if (keyDown && !lastKeyDown) {
            setZooming(!zooming);
        }
        lastKeyDown = keyDown;

        // --- tombol ekstra zoom masuk/keluar/reset (Ok Zoomer: ManageExtraKeysEvent) ---
        boolean in = zoomInKey.isPressed();
        boolean out = zoomOutKey.isPressed();
        boolean reset = zoomResetKey.isPressed();
        while (zoomInKey.wasPressed()) {
            // habiskan
        }
        while (zoomOutKey.wasPressed()) {
            // habiskan
        }
        while (zoomResetKey.wasPressed()) {
            // habiskan
        }
        if (zooming) {
            if (out && !in) {
                changeZoomDivisor(false);
            }
            if (in && !out) {
                changeZoomDivisor(true);
            }
            if (reset) {
                resetZoomDivisor();
            }
        }

        // --- tick transisi (Ok Zoomer: GameRendererMixin#tickInstances) ---
        if (zooming || transitionMode.getActive() || modifierActive) {
            double divisor = zooming ? zoomDivisor : 1.0;
            transitionMode.tick(zooming, divisor);
            modifierActive = reduceSensitivity.get() && zooming;
        }

        if (zooming && !fovHookAlive) {
            ticksZoomingWithoutHook++;
            if (ticksZoomingWithoutHook > 40 && !warnedNoHook) {
                warnedNoHook = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Zoom aktif tapi hook GameRenderer#getFov belum pernah terpanggil - "
                        + "mixin ZoomFovMixin tidak ter-apply (cek baris '[Xoldium] mixin aktif: zoom_fov' di latest.log).");
            }
        } else if (!zooming) {
            ticksZoomingWithoutHook = 0;
        }
    }

    // ------------------------------------------------------------------ API untuk mixin

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.transitionMode.getActive());
    }

    /**
     * Dipanggil dari akhir {@code GameRenderer#getFov} (Ok Zoomer: {@code GameRendererMixin#modifyFov}).
     *
     * @param useFovSetting true untuk FOV dunia, false untuk FOV tangan/item (changingFov = false di vanilla)
     */
    public static double applyZoom(double baseFov, float tickDelta, boolean useFovSetting) {
        ZoomModule z = instance;
        if (z == null) {
            return baseFov;
        }
        z.fovHookAlive = true;
        MixinDiag.alive("zoom_fov");
        if (!z.isEnabled() || !z.transitionMode.getActive() || (!useFovSetting && !z.affectHand.get())) {
            return baseFov;
        }
        return Math.max(0.1, z.transitionMode.applyZoom((float) baseFov, tickDelta));
    }

    /** Pengali gerakan kamera (Ok Zoomer: {@code ZoomDivisorMouseModifier}): delta x multiplier transisi. */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.modifierActive) {
            return 1.0;
        }
        return z.transitionMode.getInternalMultiplier();
    }

    /** Scroll saat zoom -> naik/turun langkah zoom (Ok Zoomer: {@code MouseHandlerMixin#zoomScrollOnScroll}). */
    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        z.changeZoomDivisor(vertical > 0);
        return true;
    }
}

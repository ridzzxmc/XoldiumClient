package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.zoom.ZoomHelper;
import com.xoldium.xoldiummod.client.module.visual.zoom.ZoomTransition;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom Xoldium - memakai mesin zoom dari mod Zoomify (lihat paket {@code visual.zoom}):
 * zoom awal dengan waktu masuk/keluar + kurva transisi (default EASE_OUT_EXP, masuk 1.0 dtk, keluar 0.5 dtk),
 * scroll untuk menambah/mengurangi zoom per langkah (geometris, default 10 langkah x150%),
 * sensitivitas mouse relatif terhadap zoom, dan FOV dibagi zoom divisor di akhir {@code GameRenderer#getFov}.
 */
public final class ZoomModule extends Module {

    private static final ZoomTransition[] TRANSITIONS = {
            ZoomTransition.LINEAR,
            ZoomTransition.EASE_OUT_SINE,
            ZoomTransition.EASE_OUT_QUAD,
            ZoomTransition.EASE_OUT_CUBIC,
            ZoomTransition.EASE_OUT_EXP
    };

    private static ZoomModule instance;

    private final KeyBinding zoomKey;
    private final KeyBinding zoomInKey;
    private final KeyBinding zoomOutKey;

    private final DoubleSetting initialZoom = addSetting(
            new DoubleSetting("amount", "setting.xoldiummod.zoom.amount", 4.0, 1.5, 30.0, 0.5));
    private final DoubleSetting zoomInTime = addSetting(
            new DoubleSetting("zoom_in_time", "setting.xoldiummod.zoom.zoom_in_time", 1.0, 0.0, 5.0, 0.1));
    private final DoubleSetting zoomOutTime = addSetting(
            new DoubleSetting("zoom_out_time", "setting.xoldiummod.zoom.zoom_out_time", 0.5, 0.0, 5.0, 0.1));
    private final ModeSetting transition = addSetting(
            new ModeSetting("transition", "setting.xoldiummod.zoom.transition", 4,
                    "setting.xoldiummod.zoom.transition.linear",
                    "setting.xoldiummod.zoom.transition.ease_out_sine",
                    "setting.xoldiummod.zoom.transition.ease_out_quad",
                    "setting.xoldiummod.zoom.transition.ease_out_cubic",
                    "setting.xoldiummod.zoom.transition.ease_out_exp"));
    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", 0,
                    "setting.xoldiummod.zoom.mode.hold", "setting.xoldiummod.zoom.mode.toggle"));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final DoubleSetting scrollSteps = addSetting(
            new DoubleSetting("scroll_steps", "setting.xoldiummod.zoom.scroll_steps", 10.0, 1.0, 30.0, 1.0));
    private final DoubleSetting stepPercent = addSetting(
            new DoubleSetting("step_percent", "setting.xoldiummod.zoom.step_percent", 150.0, 105.0, 300.0, 5.0));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));
    private final DoubleSetting relativeSensitivity = addSetting(
            new DoubleSetting("relative_sensitivity", "setting.xoldiummod.zoom.relative_sensitivity", 100.0, 0.0, 100.0, 5.0),
            () -> this.reduceSensitivity.get());
    private final BooleanSetting affectHand = addSetting(
            new BooleanSetting("affect_hand", "setting.xoldiummod.zoom.affect_hand", true));

    private final ZoomHelper helper = new ZoomHelper(
            new ZoomHelper.TransitionInterpolator(
                    this::currentTransition, this::currentTransition,
                    () -> zoomInTime.get(), () -> zoomOutTime.get()),
            // Sama dengan Zoomify: scrollZoomSmoothness 70 -> lerp(0.7, 1.0, 0.1)
            new ZoomHelper.SmoothInterpolator(() -> 1.0 + (0.1 - 1.0) * 0.7),
            () -> Math.max(1.0, initialZoom.get()),
            () -> stepPercent.get(),
            () -> (double) maxTier());

    private boolean zooming = false;
    private int scrollTier = 0;
    private double previousDivisor = 1.0;

    private boolean fovHookAlive = false;
    private boolean warnedNoHook = false;
    private int ticksZoomingWithoutHook = 0;

    public ZoomModule() {
        // Zoom adalah fitur dasar: aktif sejak awal (tombol C), tidak perlu dinyalakan manual dulu.
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, true);
        instance = this;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", zoomKey));
        addSetting(new KeybindSetting("key_in", "setting.xoldiummod.zoom.key_in", zoomInKey));
        addSetting(new KeybindSetting("key_out", "setting.xoldiummod.zoom.key_out", zoomOutKey));
    }

    private ZoomTransition currentTransition() {
        int i = Math.max(0, Math.min(TRANSITIONS.length - 1, transition.index()));
        return TRANSITIONS[i];
    }

    private int maxTier() {
        return (int) Math.round(scrollSteps.get());
    }

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        scrollTier = 0;
        previousDivisor = 1.0;
        helper.setToZero();
    }

    @Override
    public void onClientTick() {
        if (mode.index() == 0) {
            zooming = zoomKey.isPressed();
            while (zoomKey.wasPressed()) {
                // habiskan klik antrean agar tidak menumpuk
            }
        } else {
            while (zoomKey.wasPressed()) {
                zooming = !zooming;
            }
        }

        if (zooming) {
            while (zoomInKey.wasPressed()) {
                scrollTier++;
            }
            while (zoomOutKey.wasPressed()) {
                scrollTier--;
            }
        } else {
            while (zoomInKey.wasPressed()) {
                // diabaikan saat tidak zoom
            }
            while (zoomOutKey.wasPressed()) {
                // diabaikan saat tidak zoom
            }
        }
        scrollTier = Math.max(0, Math.min(maxTier(), scrollTier));

        helper.tick(zooming, scrollTier);

        if (zooming && !fovHookAlive) {
            ticksZoomingWithoutHook++;
            if (ticksZoomingWithoutHook > 40 && !warnedNoHook) {
                warnedNoHook = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Zoom aktif tapi hook GameRenderer#getFov belum pernah terpanggil - "
                        + "mixin ZoomFovMixin tidak ter-apply (cek baris '[Xoldium] mixin aktif: zoom_fov' di latest.log).");
            }
        } else if (!zooming) {
            ticksZoomingWithoutHook = 0;
        }
    }

    /** Sama dengan {@code Zoomify.getZoomDivisor}: reset langkah scroll saat zoom dilepas. */
    private double divisor(float tickDelta) {
        if (!zooming) {
            scrollTier = 0;
            helper.reset();
        }
        double d = helper.getZoomDivisor(tickDelta);
        previousDivisor = d;
        return d;
    }

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.previousDivisor > 1.001);
    }

    /**
     * Dipanggil dari akhir {@code GameRenderer#getFov}.
     *
     * @param worldPass true untuk FOV dunia, false untuk FOV tangan/item (changingFov = false di vanilla)
     */
    public static float applyZoom(float baseFov, float tickDelta, boolean worldPass) {
        ZoomModule z = instance;
        if (z == null) {
            return baseFov;
        }
        z.fovHookAlive = true;
        MixinDiag.alive("zoom_fov");
        if (!z.isEnabled()) {
            return baseFov;
        }
        double divisor = z.divisor(tickDelta);
        if (!worldPass && !z.affectHand.get()) {
            return baseFov;
        }
        if (divisor <= 1.0005 && divisor >= 0.9995) {
            return baseFov;
        }
        return (float) Math.max(0.1, baseFov / divisor);
    }

    /** Faktor pengali gerakan kamera: sensitivitas dibagi lerp(relatif, 1, zoomDivisor) seperti Zoomify. */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.reduceSensitivity.get() || z.previousDivisor <= 1.0005) {
            return 1.0;
        }
        double t = z.relativeSensitivity.get() / 100.0;
        double effective = 1.0 + (z.previousDivisor - 1.0) * t;
        return 1.0 / Math.max(1.0, effective);
    }

    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        z.scrollTier = Math.max(0, Math.min(z.maxTier(), z.scrollTier + (vertical > 0 ? 1 : -1)));
        return true;
    }

    public static int currentTier() {
        return instance != null ? instance.scrollTier : 0;
    }
}

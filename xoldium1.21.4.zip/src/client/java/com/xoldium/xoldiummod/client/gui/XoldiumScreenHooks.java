package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.anim.Anim;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Tombol & lencana Xoldium di Title Screen dan menu Pause.
 *
 * <p>Dipasang lewat Fabric API {@code ScreenEvents.AFTER_INIT} - BUKAN lewat mixin ke
 * {@code TitleScreen}/{@code GameMenuScreen}. Alasannya: AFTER_INIT dijalankan setelah SEMUA mod lain
 * (termasuk Mod Menu) selesai menambah tombolnya, jadi posisi tombol akurat, dan tidak bergantung
 * pada refmap/mapping mixin sama sekali sehingga bekerja identik di 1.21.4 maupun 1.21.11.
 *
 * <ul>
 *   <li>Title Screen: kolom kiri "Mod Menu / HUD Editor / Settings" + lencana akun (nama &amp; kepala skin)
 *       di kanan-atas + teks versi di kiri-bawah.</li>
 *   <li>Menu Pause: tombol "HUD Settings" tepat di bawah tombol paling bawah (Disconnect) + lencana akun.</li>
 * </ul>
 */
public final class XoldiumScreenHooks {

    private static final Identifier BADGE_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final int BADGE_SIZE = 14;

    private XoldiumScreenHooks() {
    }

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            try {
                if (screen instanceof TitleScreen) {
                    decorateTitle(client, screen, scaledWidth, scaledHeight);
                } else if (screen instanceof GameMenuScreen) {
                    decoratePause(client, screen, scaledWidth, scaledHeight);
                }
            } catch (Throwable t) {
                XoldiumMod.LOGGER.warn("[Xoldium] Gagal menambah tombol Xoldium di {}", screen.getClass().getName(), t);
            }
        });
    }

    private static void decorateTitle(MinecraftClient client, Screen screen, int width, int height) {
        TextRenderer textRenderer = client.textRenderer;
        List<ClickableWidget> buttons = Screens.getButtons(screen);

        final int buttonWidth = 88;
        final int buttonHeight = 18;
        final int gap = 3;
        final int x = 8;
        final int startY = height / 2 - 30;

        ButtonWidget modMenu = ButtonWidget.builder(
                        XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.mod_menu")),
                        button -> client.setScreen(new ModListScreen(screen)))
                .dimensions(x, startY, buttonWidth, buttonHeight)
                .build();
        ButtonWidget hudEditor = ButtonWidget.builder(
                        XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.hud_editor")),
                        button -> client.setScreen(new XoldiumHomeScreen(screen)))
                .dimensions(x, startY + (buttonHeight + gap), buttonWidth, buttonHeight)
                .build();
        ButtonWidget settings = ButtonWidget.builder(
                        XoldiumFonts.medium(Text.translatable("gui.xoldiummod.title_screen.settings")),
                        button -> client.setScreen(new XoldiumConfigScreen(screen)))
                .dimensions(x, startY + 2 * (buttonHeight + gap), buttonWidth, buttonHeight)
                .build();
        buttons.add(modMenu);
        buttons.add(hudEditor);
        buttons.add(settings);

        // Animasi masuk: kolom tombol meluncur dari kiri layar dengan jeda bertahap + fade.
        final Anim.Timeline intro = new Anim.Timeline(520f);
        final ButtonWidget[] column = {modMenu, hudEditor, settings};
        final String version = FabricLoader.getInstance().getModContainer(XoldiumMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");

        ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, delta) -> {
            for (int i = 0; i < column.length; i++) {
                float t = Anim.easeOutCubic(Anim.clamp01((intro.elapsedMs() - i * 70f) / 380f));
                column[i].setX(Math.round(Anim.lerp(-buttonWidth - 8, x, t)));
                column[i].setAlpha(t);
            }
            // Lencana akun Minecraft (username + kepala skin) di kanan-atas.
            AccountBadge.render(context, textRenderer, width, 8);
            // Badge kecil + teks versi di kiri-bawah.
            int textY = height - 20;
            IconRenderer.drawTexture(context, BADGE_TEXTURE, 4, textY - 3, BADGE_SIZE, BADGE_SIZE);
            context.drawText(textRenderer, Text.literal("Xoldium v" + version),
                    4 + BADGE_SIZE + 4, textY, 0xFFAAAAAA, true);
        });
    }

    private static void decoratePause(MinecraftClient client, Screen screen, int width, int height) {
        TextRenderer textRenderer = client.textRenderer;

        ButtonWidget lowest = null;
        for (Element child : screen.children()) {
            if (child instanceof ButtonWidget button && button.visible) {
                if (lowest == null || button.getY() + button.getHeight() > lowest.getY() + lowest.getHeight()) {
                    lowest = button;
                }
            }
        }
        if (lowest == null) {
            return; // menu jeda tanpa tombol (mis. F3+Esc) - tidak ada yang perlu ditambah
        }

        int y = lowest.getY() + lowest.getHeight() + 4;
        if (y + 20 > height - 2) {
            y = height - 22;
        }
        ButtonWidget hudSettings = ButtonWidget.builder(
                        XoldiumFonts.medium(Text.translatable("gui.xoldiummod.pause.hud_settings")),
                        button -> client.setScreen(new XoldiumHomeScreen(screen)))
                .dimensions(lowest.getX(), y, lowest.getWidth(), 20)
                .build();
        Screens.getButtons(screen).add(hudSettings);

        ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, delta) ->
                AccountBadge.render(context, textRenderer, width, 8));
    }
}

package com.xoldium.xoldiummod.client.module.visual.zoom;

import net.minecraft.util.math.MathHelper;

/**
 * Mesin transisi zoom - port langsung dari {@code EasedTransitionMode} Ok Zoomer
 * (page.langeweile.ok_zoomer.zoom.transitions). Logika tick, mode scroll, dan
 * perhitungan multiplier dipertahankan persis; hanya {@code Mth} diganti
 * {@code MathHelper} (Yarn) dan {@code FloatUnaryOperator} diganti {@link Curve}
 * supaya tidak bergantung pada fastutil.
 */
public final class EasedTransitionMode {

    /** Kurva easing: progress 0..1 -> nilai 0..1 (boleh melewati 1 untuk efek spring). */
    @FunctionalInterface
    public interface Curve {
        float apply(float t);
    }

    private final Curve startTransition;
    private final Curve endTransition;
    private final Curve scrollTransition;
    private final int targetStartTicks;
    private final int targetEndTicks;
    private final int targetScrollTicks;
    private final boolean invertStartTransition;
    private final boolean invertEndTransition;

    private boolean active;
    private int ticks;
    private float startZoomMultiplier;
    private float startFadeMultiplier;
    private float lastZoomMultiplier;
    private float internalMultiplier;
    private float lastInternalMultiplier;
    private float internalFade;
    private float lastInternalFade;
    private boolean scrollMode;

    public EasedTransitionMode(Curve startTransition, Curve endTransition, Curve scrollTransition,
                               int targetStartTicks, int targetEndTicks, int targetScrollTicks,
                               boolean invertStartTransition, boolean invertEndTransition) {
        this.startTransition = startTransition;
        this.endTransition = endTransition;
        this.scrollTransition = scrollTransition;
        this.targetStartTicks = targetStartTicks;
        this.targetEndTicks = targetEndTicks;
        this.targetScrollTicks = targetScrollTicks;
        this.invertStartTransition = invertStartTransition;
        this.invertEndTransition = invertEndTransition;

        this.active = false;
        this.ticks = 1;
        this.startZoomMultiplier = 1.0F;
        this.startFadeMultiplier = 0.0F;
        this.lastZoomMultiplier = 1.0F;
        this.internalMultiplier = 1.0F;
        this.lastInternalMultiplier = 1.0F;
        this.internalFade = 0.0F;
        this.lastInternalFade = 0.0F;
        this.scrollMode = false;
    }

    public boolean getActive() {
        return this.active || this.ticks <= this.targetEndTicks;
    }

    public float applyZoom(float fov, float tickDelta) {
        return fov * MathHelper.lerp(tickDelta, this.lastInternalMultiplier, this.internalMultiplier);
    }

    public float getFade(float tickDelta) {
        return MathHelper.lerp(tickDelta, this.lastInternalFade, this.internalFade);
    }

    public void tick(boolean active, double divisor) {
        float zoomMultiplier = (float) (1.0 / divisor);
        float fadeMultiplier = active ? 1.0F : 0.0F;

        boolean skipTransition = active && this.targetStartTicks == 0 || !active && this.targetEndTicks == 0;

        if (skipTransition) {
            this.internalMultiplier = active ? zoomMultiplier : 1.0F;
            this.internalFade = active ? fadeMultiplier : 0.0F;
            this.lastInternalMultiplier = this.internalMultiplier;
            this.lastInternalFade = this.internalFade;
        } else {
            int targetTicks = active ? (this.scrollMode ? this.targetScrollTicks : this.targetStartTicks) : this.targetEndTicks;
            int oppositeTargetTicks = active ? this.targetEndTicks : this.targetStartTicks;
            boolean invert = active ? (!this.scrollMode && this.invertStartTransition) : this.invertEndTransition;

            if (this.ticks <= targetTicks) {
                this.ticks += 1;
            }

            this.lastInternalMultiplier = this.internalMultiplier;
            this.lastInternalFade = this.internalFade;

            if (this.active != active) {
                if (active && this.ticks >= oppositeTargetTicks) {
                    this.internalMultiplier = 1.0F;
                    this.internalFade = 0.0F;
                }
                this.ticks = 1;
                this.startZoomMultiplier = this.internalMultiplier;
                this.startFadeMultiplier = this.internalFade;
                this.scrollMode = false;
            }

            if (active && this.ticks != 1 && zoomMultiplier != this.lastZoomMultiplier) {
                this.scrollMode = true;
                this.ticks = this.targetScrollTicks / 2;
                this.lastZoomMultiplier = this.internalMultiplier;
            }

            if (this.scrollMode) {
                if (this.targetScrollTicks == 0) {
                    this.internalMultiplier = active ? zoomMultiplier : 1.0F;
                    this.lastInternalMultiplier = this.internalMultiplier;
                }

                if (zoomMultiplier != this.lastZoomMultiplier) {
                    this.ticks = 1;
                    this.startZoomMultiplier = this.lastZoomMultiplier;
                    this.startFadeMultiplier = fadeMultiplier;
                }
            }

            float rawProgress = Math.min(this.ticks, targetTicks) / (float) targetTicks;
            if (invert) {
                rawProgress = 1.0F - rawProgress;
            }
            float progress = this.ticks <= targetTicks
                    ? (active
                    ? (this.scrollMode ? this.scrollTransition.apply(rawProgress) : this.startTransition.apply(rawProgress))
                    : this.endTransition.apply(rawProgress))
                    : 1.0F;
            progress = Math.min(invert ? 1.0F - progress : progress, 1.2F);

            if (this.ticks <= targetTicks) {
                this.internalMultiplier = MathHelper.lerp(progress, this.startZoomMultiplier, active ? zoomMultiplier : 1.0F);
                this.internalFade = MathHelper.lerp(progress, this.startFadeMultiplier, active ? fadeMultiplier : 0.0F);
            }
        }

        this.active = active;
        this.lastZoomMultiplier = zoomMultiplier;
    }

    public double getInternalMultiplier() {
        return this.internalMultiplier;
    }
}

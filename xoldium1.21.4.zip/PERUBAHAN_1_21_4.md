# Xoldium Client - Port ke Minecraft 1.21.4

Tampilan, GUI, fitur, dan tombol title screen (Mod Menu / HUD Editor / Settings + lencana akun kanan-atas) sama dengan versi 1.21.11.

## Build
- gradle.properties: minecraft 1.21.4, yarn 1.21.4+build.8, fabric-api 0.119.4+1.21.4, modmenu 13.0.3, loader 0.16.14.
- Jalankan: `./gradlew build` -> jar di build/libs/ (pakai yang TANPA -sources).

## Perubahan API (1.21.11 -> 1.21.4)
- DrawContext matrix: pushMatrix/popMatrix/translate(x,y)/scale(x,y) -> push/pop/translate(x,y,0)/scale(x,y,1).
- Gambar tekstur: drawTexturedQuad -> drawTexture(RenderLayer::getGuiTextured, ...) lewat IconRenderer.drawTexture.
- XoldiumKeyCategory: objek KeyBinding.Category -> String translation key.
- Hotbar: getSelectedSlot() -> field selectedSlot. HitRange: getTickProgress -> getTickDelta.
- ZoomFovMixin: aman untuk return float maupun double.
- FrustumContext: frustum juga di-refresh di WorldRenderEvents.AFTER_SETUP.
- Motion blur: ditulis ulang untuk 1.21.4 (lihat di bawah).

## Motion blur
Algoritma dari source motionblur-fabric yang dikirim: blend frame sekarang dengan frame sebelumnya
(`mix(curr, prev, blend)`), simpan hasil ke target "previous", tampilkan ke layar. Hook di TAIL GameRenderer#render
seperti MixinGameRenderer aslinya. Pipeline post-effect 1.21.11 (UBO, GpuBuffer, RenderPass) tidak ada di 1.21.4,
jadi dipakai framebuffer + blending vanilla. Jika error, motion blur mati untuk sesi itu (tidak crash).

## Ikon nametag XoldiumClient (perbaikan kotak)
- Tidak ada assets/minecraft/font/default.json (tidak ada yang menimpa font default).
- xoldium_icons.json: ditambah provider `space` untuk " " (advance 4.0).
- XoldiumUsers.logoPrefix(): spasi memakai LOGO_STYLE (bukan Style.EMPTY).
- Penanda pengguna Xoldium = bit 0x80 pada Skin Parts, sama di 1.21.4 dan 1.21.11, jadi saling terlihat.

## Catatan jujur
Belum bisa di-compile di lingkungan pembuatan (tanpa internet/Gradle). Mixin memakai require=0, jadi bila satu
target tidak cocok, hanya fitur itu yang nonaktif (tidak crash). Cek log `latest.log` untuk "[Xoldium]".

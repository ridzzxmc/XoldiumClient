# Xoldium Client - Port ke Minecraft 1.21.4

Tampilan, GUI, fitur, dan tombol title screen (Mod Menu / HUD Editor / Settings + lencana akun kanan-atas) sama dengan versi 1.21.11.

## Build
- gradle.properties: minecraft 1.21.4, yarn 1.21.4+build.8, fabric-api 0.119.4+1.21.4, modmenu 13.0.3, loader 0.16.14.
- Jalankan: `./gradlew build` -> jar di build/libs/ (pakai yang TANPA -sources).

## Perubahan API (1.21.11 -> 1.21.4)
- DrawContext matrix: pushMatrix/popMatrix/translate(x,y)/scale(x,y) -> push/pop/translate(x,y,0)/scale(x,y,1).
- Gambar tekstur: drawTexturedQuad -> drawTexture(RenderLayer::getGuiTextured, ...) lewat IconRenderer.drawTexture.
- XoldiumKeyCategory: objek KeyBinding.Category -> String translation key.
- Hotbar: getSelectedSlot() -> field selectedSlot. HitRange: getTickProgress -> getTickDelta.
- ZoomFovMixin: aman untuk return float maupun double.
- FrustumContext: frustum juga di-refresh di WorldRenderEvents.AFTER_SETUP.
- Motion blur: ditulis ulang untuk 1.21.4 (lihat di bawah).

## Motion blur
Algoritma dari source motionblur-fabric yang dikirim: blend frame sekarang dengan frame sebelumnya
(`mix(curr, prev, blend)`), simpan hasil ke target "previous", tampilkan ke layar. Hook di TAIL GameRenderer#render
seperti MixinGameRenderer aslinya. Pipeline post-effect 1.21.11 (UBO, GpuBuffer, RenderPass) tidak ada di 1.21.4,
jadi dipakai framebuffer + blending vanilla. Jika error, motion blur mati untuk sesi itu (tidak crash).

## Ikon nametag XoldiumClient (perbaikan kotak)
- Tidak ada assets/minecraft/font/default.json (tidak ada yang menimpa font default).
- xoldium_icons.json: ditambah provider `space` untuk " " (advance 4.0).
- XoldiumUsers.logoPrefix(): spasi memakai LOGO_STYLE (bukan Style.EMPTY).
- Penanda pengguna Xoldium = bit 0x80 pada Skin Parts, sama di 1.21.4 dan 1.21.11, jadi saling terlihat.

## Catatan jujur
Belum bisa di-compile di lingkungan pembuatan (tanpa internet/Gradle). Mixin memakai require=0, jadi bila satu
target tidak cocok, hanya fitur itu yang nonaktif (tidak crash). Cek log `latest.log` untuk "[Xoldium]".

---
# Revisi 2 (berdasarkan tes di 1.21.4)

## Penyebab utama: semua fitur berbasis mixin tidak aktif
Tombol title screen, ikon nametag sendiri, zoom, dan motion blur semuanya bergantung pada mixin client.
Konfigurasi mixin lama (satu file di `src/main/resources` dengan `refmap` ditulis manual untuk class di source set client)
tidak ter-apply di build 1.21.4 (error injeksi tidak muncul karena `defaultRequire: 0`). Sekarang dipisah mengikuti
template Fabric standar:
- `src/main/resources/xoldiummod.mixins.json` -> hanya mixin sisi umum (MobAiThrottle).
- `src/client/resources/xoldiummod.client.mixins.json` -> semua mixin client, TANPA `refmap` manual (Loom mengisinya otomatis).
- `fabric.mod.json` mendaftarkan keduanya (yang client dengan `environment: client`).

## Tombol & lencana akun (tanpa mixin)
`XoldiumScreenHooks` memakai Fabric API `ScreenEvents.AFTER_INIT`:
- Title Screen: Mod Menu / HUD Editor / Settings di kiri + lencana akun (nama + kepala skin) kanan-atas + teks versi.
- Menu Pause: tombol **HUD Settings** tepat di bawah Disconnect (membuka HUD Editor) + lencana akun.
Karena tidak memakai mixin, bagian ini tidak bergantung pada mapping.

## Zoom = engine Zoomify
Port `ZoomHelper`, `Interpolator`, `TransitionType`, dan `DefaultZoomHelpers` dari Zoomify 2.15.2:
zoom awal x4, waktu masuk 1.0 dtk / keluar 0.5 dtk, transisi EASE_OUT_EXP, scroll 10 langkah x150%, sensitivitas relatif,
tangan ikut ter-zoom. FOV dibagi zoom divisor di akhir `GameRenderer#getFov` (sama seperti Zoomify). Aktif sejak awal, tombol C.

## Motion blur = BlurOnly
`amount` 0-100 (default 50), `blend = min(amount, 99) / 100`, dijalankan di akhir `GameRenderer#renderWorld`
(sebelum HUD, seperti rantai post-effect BlurOnly), hanya saat di dalam dunia tanpa layar terbuka.
Ada cadangan lewat `WorldRenderEvents.END` bila mixin tidak ter-apply. Aktif sejak awal.

## Diagnostik
Setiap mixin penting menulis `[Xoldium] mixin aktif: <nama>` di latest.log saat pertama kali jalan
(zoom_fov, motion_blur, own_nametag, player_display_name, zoom_scroll). Jika baris itu tidak ada, mixin tersebut tidak ter-apply.

---
# Revisi 3 - Zoom ditulis ulang dari Ok Zoomer 10.0.0-beta.9

## Kenapa zoom tidak jalan
Tombol zoom default `C` sama dengan keybind vanilla "Save Hotbar Activator". Minecraft hanya menyimpan SATU keybind
per tombol fisik, jadi sering yang vanilla yang menang dan `KeyBinding#isPressed` zoom tidak pernah true
(Ok Zoomer sendiri harus meng-unbind tombol itu karena alasan yang sama). Sekarang status tombol zoom juga dibaca
langsung dari GLFW (`ZoomModule#readZoomKey`), jadi zoom jalan walau ada bentrok.

## Isi
- `ZoomModule`: sinyal Hold/Toggle/Persistent (ManageZoomEvent), langkah scroll eksponensial (ZoomUtils),
  tombol zoom masuk/keluar/reset, sensitivitas mouse (ZoomDivisorMouseModifier).
- `zoom/ZoomTransition`: transisi Instant / Smooth / Linear (port dari paket zoom.transitions).
- `EasedTransitionMode` (port Ok Zoomer 5.4) dihapus.
- Config v4: status aktif & setting zoom lama di-reset sekali (id setting berubah).
- Tidak dibawa: overlay vinyet/spyglass, kamera sinematik, GUI-zoom, view-bobbing, mode spyglass.
- Jika masih tidak zoom: lihat action bar in-game / `latest.log` untuk "[Xoldium] mixin aktif: zoom_fov".

# Ringkasan Perubahan

## Sesi 8 (terbaru) - Zoom, Hit Range, Xoldium Tag, Mod Menu transparan, HUD Editor

> **Status verifikasi jujur:** lingkungan pembuatan kode ini tidak punya Minecraft/Gradle/internet, jadi mod BELUM
> di-compile penuh. Yang dicek: seluruh file Java lolos parser `javac` (tanpa error sintaks; error "package does not exist"
> = wajar karena tanpa jar Minecraft), JSON/lang valid. Titik yang bergantung nama API Minecraft dicantumkan di bawah.

### 1. Crash saat menekan keybind (Zoom/FreeLook/Totem) - DIPERBAIKI
Penyebab (dari crash report): `ModuleSettingsScreen#pollCapture` memanggil `GLFW.glfwGetKey` untuk kode 32..348; stub GLFW
Android (Zalith/Pojav) memakai buffer kecil -> `IndexOutOfBoundsException` di `DirectByteBuffer.get`. Sekarang hanya kode
keyboard yang nyata di-poll, tiap panggilan dibungkus try/catch dan kode yang gagal dibuang dari daftar (self-healing).

### 2. Zoom (mengacu Zoomify 2.15.2)
`ZoomModule` ditulis ulang: Initial Zoom + scroll bertingkat (pembagi = initial x stepMultiplier^tier), transisi halus
(waktu nyata), Relative Sensitivity (`1 / lerp(1, divisor, persen)`), Hold/Toggle, tombol **Zoom In / Zoom Out** terpisah
(HP tanpa scroll wheel), tangan tidak ikut zoom (hook `getFov` memakai argumen `changingFov`). Zoom "tidak bisa" karena
tombol tidak bisa diganti (crash #1) dan tombol bawaan `C` tidak terjangkau kontrol sentuh: di Zalith tambahkan tombol
kontrol yang dipetakan ke tombol Zoom. Log mencatat peringatan bila hook `getFov` tidak ter-apply.

### 3. Hit Range (mengacu mod Hit Range uku3lig)
Default kini sama dengan mod referensi: radius 3, Thick 0.15, merah `0x80FF0000`, hijau saat dalam jangkauan, 60 segmen,
jarak maks 100, **Show Around Myself = ON** (lingkaran merah di sekitar pemain sendiri seperti di gambar). Perbaikan:
tidak lagi berhenti diam-diam bila `MatrixStack` event `null`; quad di-flush pada matriks pass dunia; quad dua sisi.
Log mencatat "Hit Range menggambar N cincin" sekali. Setting Hit Range & Zoom lama di `xoldiumclient.json` di-reset SEKALI
(`configVersion` 2) karena config lama menyimpan default lama.

### 4. Xoldium Tag ala Feather (logo di samping nametag)
- Penyebab logo tak pernah muncul: sejak 1.21.9 data tracker skin pindah ke superclass `PlayerEntity`; pemindaian lama hanya
  membaca `PlayerEntity` ("Tidak menemukan TrackedData<Byte>"). Sekarang seluruh hierarki dipindai.
- **Error masuk server DIPERBAIKI:** `SyncedClientOptionsMixin` (konstruktor record, HEAD) dihapus -> diganti
  `SyncedOptionsMarkerMixin` (`GameOptions#getSyncedOptions` RETURN + refleksi record). Tidak ada lagi
  "handler before this() invocation must be static" / "Mixin transformation of class_8791 failed".
- `OwnNametagMixin`: nametag diri sendiri tampil di third-person (F5) lengkap dengan logo (setting "Show My Nametag").
- Keterbatasan: butuh server yang meneruskan byte lapisan skin apa adanya (Paper/Spigot/Velocity umumnya begitu).
- `defaultRequire` mixin diubah 1 -> 0: target mixin yang hilang di versi ini dilewati, bukan menjatuhkan game.

### 5. Mod Menu transparan
`ScreenChrome`: gaya menu **Transparent (default)** / Glass / Solid, dipilih di Home > Settings > Menu Style
(`menuStyle` di config). Redup layar penuh dan "tirai" hitam animasi dihapus; panel & kartu semi-transparan.

### 6. HUD Editor
Tombol **- / +** (0.3x-4.0x), **1x**, panah geser 1 piksel, **Prev/Next** pilih HUD; scroll wheel selalu aktif (tidak lagi
bergantung modul Scroll Settings yang default OFF). **Garis sejajar (snap)**: sisi kiri/tengah/kanan & atas/tengah/bawah
menempel ke HUD lain dan tepi/tengah layar (garis merah muda = X, biru = Y) + pembaca koordinat X/Y saat drag.
Drag memakai polling tombol kiri GLFW di `render` (tanpa override `mouseClicked/Dragged/Released` yang berubah di 1.21.9+).

### Titik yang perlu dicek saat compile
| File | Yang dicek |
|---|---|
| `mixin/visual/ZoomFovMixin` | descriptor `getFov(Camera;FZ)F` (require=0) |
| `mixin/network/SyncedOptionsMarkerMixin` | nama method `GameOptions#getSyncedOptions` (require=0) |
| `mixin/entity/OwnNametagMixin` | descriptor `LivingEntityRenderer#hasLabel(LivingEntity;D)Z` (require=0) |
| `client/render/WorldOverlay` | `WorldRenderContext#matrixStack()/consumers()/camera()`, `VertexConsumerProvider.Immediate#draw(RenderLayer)` |
| `client/social/XoldiumUsers` | `Style#withFont(Identifier)` |

## Sesi 7 — Title/Pause menu pro, animasi halus, modul diperbaiki, Custom Block Highlight, Hit Range, Xoldium Tag

> **Status verifikasi jujur:** lingkungan pembuatan kode ini tidak punya Minecraft/Gradle/internet, jadi
> mod BELUM di-compile penuh. Yang sudah dicek: seluruh 100+ file Java lolos parser `javac` (tanpa error sintaks),
> pemanggilan antar-kelas Xoldium konsisten, JSON/lang valid. Titik yang bergantung nama API Minecraft/Fabric
> tertentu dikumpulkan di bagian **"Titik yang perlu dicek saat compile"** di bawah, dan hampir semua mixin baru
> memakai `require = 0` (gagal-aman: fitur itu saja yang tidak jalan, game tidak crash).

### 1. Bug title Xoldium kepotong — DIPERBAIKI
Penyebab: `LogoDrawer` vanilla hanya menggambar bagian atas (256x44 dari kanvas 256x64) tekstur
`title/minecraft.png`, sedangkan logo Xoldium 1024x233 memenuhi seluruh tinggi kanvas - bagian bawah (blok 3D)
terpotong. Solusi murni aset (tanpa kode, tanpa mixin): logo diskala proporsional & diletakkan di area yang
benar-benar digambar (`minecraft.png` & `minceraft.png` jadi 1024x256, logo di 176px teratas). Splash kuning
sekarang juga tidak lagi menimpa huruf "M".

### 2. Tombol XoldiumClient di Game Menu (pause)
`mixin/titlescreen/GameMenuScreenMixin.java`: tombol **XoldiumClient** otomatis diletakkan tepat di bawah tombol
paling bawah (Disconnect / Save and Quit) dengan lebar sama, membuka Mod Menu. Ditambah lencana akun di kanan atas.

### 3. Tombol & widget vanilla bergaya profesional (semua menu)
Override sprite vanilla (`assets/minecraft/textures/gui/sprites/widget/`): `button`, `button_highlighted`,
`button_disabled`, `slider`, `slider_highlighted`, `slider_handle(_highlighted)`, `text_field(_highlighted)`
(+ `.mcmeta` nine-slice). Efeknya ke SEMUA tombol: Singleplayer, Multiplayer, Realms, Mods, Options, Quit,
Back to Game, Advancements, Statistics, dst. Hitam-abu bersudut membulat, hover = border putih. Tanpa kode -> aman lintas versi.

### 4. Animasi halus
`gui/anim/Anim.java` (easing + `Smooth` + `Timeline`), `gui/anim/ScreenChrome.java`, `gui/XoldiumScreen.java`
(basis semua layar Xoldium: fade + slide buka/tutup). Mod Menu: kartu masuk bertahap (stagger), hover ease,
garis tab meluncur, scroll halus, toggle geser, ikon membesar saat hover. HUD Editor & Settings ikut fade/slide.
Layar baru dibangun dari widget vanilla saja (area klik = `ButtonWidget` transparan) - TANPA override
`mouseClicked/keyPressed`, jadi tidak tergantung perubahan signature input Minecraft 1.21.9+.

### 5. Akun Minecraft di atas menu awal
`gui/AccountBadge.java`: username + kepala skin (skin sungguhan bila akun online; skin default bila offline),
tampil di Title Screen & Game Menu. Pencarian skin lewat refleksi berbasis tipe (bukan nama) + fallback avatar inisial.

### 6. Module Setting untuk SEMUA modul + tipe setting baru
`ColorSetting` (R/G/B/Opacity + pratinjau), `ModeSetting` (pilihan), `visibleWhen` (setting muncul sesuai kondisi),
tombol **Reset to Default**, layar setting scroll-able. Tersimpan di `xoldiumclient.json`
(`moduleColorSettings`, `moduleModeSettings`).

### 7. Modul
- **Zoom (ditulis ulang, mengacu OkZoomer):** penyebab lama = mixin `getFov` memakai descriptor return `D`
  (double) padahal 1.21.11 mengembalikan `float`. Sekarang dua injector (F & D, `require=0`), mode Hold/Toggle,
  scroll untuk ubah zoom, sensitivitas mouse dikurangi saat zoom, easing berbasis waktu.
- **Fullbright:** mixin gamma tetap (pola mod referensi greenman999) + mode **Night Vision** klien-saja sebagai
  cadangan; default "Gamma + Night Vision" supaya pasti terang walau salah satu jalur gagal.
- **Totem Counter (diperbaiki, mengacu uku3lig):** penyebab lama = status totem (35) TIDAK sampai ke
  `LivingEntity#handleStatus`, ditangani `ClientPlayNetworkHandler#onEntityStatus`. Sekarang hook di sana (+ hook lama
  dengan dedupe). Fitur: pop SEMUA pemain di nametag ("Nama | -3", warna bertingkat), HUD jumlah totem inventory / pop sendiri, keybind reset.
- **Custom Block Highlight** menggantikan Block Overlay & Blocks Modifier (dua-duanya dihapus): outline tebal
  (balok tipis), isi sisi, gradient (Vertical/Horizontal/Diagonal/Rainbow/Pulse) + animasi, dua warna outline & isi,
  ketebalan, expand, bentuk block tepat (tangga/slab/pagar), fade, gerak halus, sembunyikan outline vanilla.
- **Hit Range (baru, mengacu uku3lig):** cincin jangkauan di kaki pemain lain - radius, mode Line/Thick/Filled,
  warna & warna saat dalam jangkauan, nearest-only, show-self, jarak maksimum, segmen.
- **Xoldium Tag (baru):** logo Xoldium di nametag sesama pengguna Xoldium. Deteksi tanpa server khusus: bit ke-7
  (`0x80`) byte lapisan skin yang dikirim ke server dan disiarkan ke pemain lain (vanilla hanya memakai bit 0-6).
  `SyncedClientOptionsMixin` menyalakan bit itu, `XoldiumUsers` membacanya, `PlayerDisplayNameMixin` menempel
  glyph logo (font `xoldiummod:xoldium_icons`). Berjalan di server yang meneruskan byte itu apa adanya.
- **Semua modul hanya aktif bila dinyalakan di Mod Menu:** default FPS/Ping/Coordinates/Scroll Settings diubah
  jadi OFF; semua efek modul (mixin/event) dicek `isEnabled()`. (Pengecualian sengaja: Credit HUD dan Xoldium Tag default ON;
  keduanya tetap bisa dimatikan.)

### Titik yang perlu dicek saat compile (semuanya terisolasi)
| File | Yang dicek |
|---|---|
| `client/render/WorldOverlay.java` | 4 method tipis (`camera`, `matrices`, `quadConsumer`, `positionMatrix`) = satu-satunya kode yang menyentuh API render dunia untuk Custom Block Highlight & Hit Range. Di Fabric API baru event ada di `...rendering.v1.world` (`BEFORE_BLOCK_OUTLINE`, `AFTER_ENTITIES`/`END_MAIN`). |
| `CustomBlockHighlightModule` / `HitRangeModule` | Nama event `WorldRenderEvents.BLOCK_OUTLINE` / `AFTER_ENTITIES` sesuai versi Fabric API. |
| `XoldiumHomeScreen` | Override `mouseClicked/mouseDragged/mouseReleased` (HUD Editor drag) - bila memakai 1.21.9+ signature-nya berbasis `Click`. Layar lain sengaja bebas dari override ini. |
| `mixin/visual/ZoomFovMixin`, `LightmapTextureManagerMixin` | Descriptor `getFov(...)F/D` dan ordinal `Double#floatValue` (semua `require=0`). |
| `mixin/network/SyncedClientOptionsMixin` | Nama kelas `SyncedClientOptions` & konstruktor record (target string, `require=0`). |
| `gui/AccountBadge.java` | `MinecraftClient#getSession/getSkinProvider/getGameProfile`, `PlayerSkinDrawer` (refleksi + fallback). |
| `gradle.properties` | Versi ModMenu/Loom/Fabric API harus cocok dengan 1.21.11 - contoh referensi yang jalan di 1.21.11: Loom 1.14+, Loader 0.18+, Fabric API 0.139+, ModMenu 17.0.0-alpha.1. |

## Sesi 6 — Setiap Module punya Module Setting sendiri

Sesi 5 baru kasih setting nyata ke 4 modul (Motion Blur/Zoom/FreeLook/Time
Changer) - gear-icon TIDAK muncul di 39 modul lainnya. Sekarang **SEMUA**
modul (HUD, Optimization, Visual, Movement) punya minimal satu setting
NYATA (bukan hiasan/palsu):

- **Semua modul HUD** (32 modul): setting universal baru "Background
  Opacity" (0.0-1.0, default 0.56 = alpha lama) ditambahkan sekali di
  `HudModule` (kelas dasar) - otomatis diwarisi semua modul HUD tanpa
  perlu diulang manual. Ini yang langsung jawab contoh permintaan "setting
  FPS background jadi transparan" - set ke 0.0 = latar transparan penuh.
  `HudRenderUtil` diubah supaya benar-benar memakai nilai ini (dulu
  konstanta `BACKGROUND = 0x90000000` tetap, sekarang dihitung per-modul).
- **Semua modul Optimization** (10 modul): setting universal "Notify in
  Chat" (kirim pesan chat lokal saat di-toggle) ditambahkan di
  `OptimizationToggleModule`. 7 dari 10 modul JUGA dapat slider numerik
  nyata yang terhubung LANGSUNG ke field `XoldiumConfig` yang sama yang
  dibaca mixin culling (bukan penyimpanan terpisah): Frustum Margin, Cull
  Distance, Render Distance, Safe Radius, Freeze Distance (sudah ada
  sebelumnya di config), plus 3 field BARU yang ditambahkan sesi ini:
  `playerCullMinDistance` (Player Culling - jarak aman pemain lain tidak
  pernah di-cull), `blockEntityCullMargin` (Block Entity Culling, dulu
  konstanta tetap `1.0` di mixin), `FrustumContext.extraCullMargin`
  (Occlusion Boost - margin tambahan di atas radius otomatis).
- **Movement**: Auto Sprint dapat setting "Sprint While Sneaking".
- **Visual** (10 modul, semuanya sekarang ada settingnya): Fullbright
  ("Brightness" 1-15, dulu konstanta tetap 15), Damage Indicator
  ("Duration" 0.3-3.0 detik, dulu tetap 0.9 detik), No Hurt Cam
  ("Reduction" 0.0-1.0, dulu selalu hard 0), Block Overlay & Blocks
  Modifier (masing-masing "Hue" 0-360°, dikonversi HSV->RGB lewat
  `MathHelper.hsvToRgb` vanilla, dulu warna tetap), Scroll Settings
  ("Scale Step", dulu konstanta tetap `0.1f` di `XoldiumHomeScreen`).

Total: 4 (Sesi 5) + 39 (sesi ini) = SEMUA modul yang terdaftar di
`ModuleManager` sekarang menampilkan gear-icon dengan setting yang
sungguhan berefek.

## Sesi 5 — Bug title/HUD Editor + 20 module baru + animasi

### Bug title screen (logo jadi checkerboard hitam-magenta) — DIPERBAIKI
`mixin/titlescreen/TitleScreenMixin.java`: `title_logo.png` yang dipakai
sejak Sesi 2 TERNYATA TIDAK PERNAH ada di
`src/main/resources/assets/xoldiummod/` — Minecraft otomatis mengganti
tekstur yang gagal di-load dengan checkerboard hitam-magenta bawaan,
persis bentuk bug di screenshot. Wordmark "XOLDIUM CLIENT" yang tampil
benar itu sebenarnya dari override tekstur vanilla
`assets/minecraft/textures/gui/title/minecraft.png` (tidak berhubungan
dengan konstanta yang rusak itu). Drawable banner lebar yang rusak
dihapus total (bukan dicari file penggantinya - vanilla logo sudah cukup),
diganti badge kecil `logo.png` (yang benar-benar ada) di pojok kiri-bawah
dekat teks versi.

### Bug posisi logo HUD Editor ketabrak tombol — DIPERBAIKI
`client/gui/XoldiumHomeScreen.java#renderLogo`: posisi logo dulu dihitung
independen dari posisi tombol (`-24` tetap), sekarang dihitung MUNDUR dari
`buttonsY` dengan jarak aman tetap (14px) supaya tidak pernah tabrakan lagi.

### Setting keybind per-modul
`client/module/setting/KeybindSetting.java` (baru) membungkus `KeyBinding`
vanilla asli - persistensi otomatis lewat `options.txt` Minecraft sendiri.
`client/gui/ModuleSettingsScreen.java` ditambah tombol "tekan tombol..."
untuk mengubahnya langsung dari gear-icon modul (dipakai Zoom & FreeLook).

### Animasi smooth (bukan cuma ganti warna)
- `client/gui/IconRenderer.java`: toggle switch sekarang di-ease
  berdasarkan waktu nyata (knob geser + warna fade, ~150ms), progres
  animasi disimpan per-`module.id()` supaya tiap kartu independen.
- `client/gui/ModListScreen.java`: transisi buka/tutup Mod Menu pakai
  teknik "tirai" fade hitam (overlay alpha, BUKAN scale/translate
  transform) - aman karena tidak pernah mengubah posisi hit-test tombol
  vanilla selagi animasi jalan. ESC ikut memicu fade-tutup yang sama
  lewat override `close()`.

### 20 module baru (dari daftar id lengkap yang diminta)
13 sudah ada sebelumnya (fps/ping/cps/coords/armor/potions/keystrokes/
memory/pack/chat/fullbright/compass=direction_hud/outline=block_overlay)
- TIDAK ditambahkan ulang. 20 sisanya baru:

**4 dari source code yang dikirim:**
- `render/motionblur/MotionBlurRenderer.java` + `module/visual/MotionBlurModule.java`
  + 2 mixin baru (`MotionBlurGameRendererMixin`, `MotionBlurWorldRendererMixin`):
  PORTING HAMPIR LANGSUNG dari "Smooth Motion Blur" - `gradle.properties`
  mod referensi pakai `yarn_mappings=1.21.11+build.6`, SAMA PERSIS dengan
  proyek ini, jadi seluruh API GPU dipindah nyaris apa adanya. Setting
  "Strength" (0.05-5.0) & "Pause in GUIs" muncul di gear-icon. **Lisensi
  LGPL-3.0-only** (teknik asli oleh ItsPasi) - atribusi dipertahankan di
  javadoc `MotionBlurRenderer`, mohon pertahankan juga bila didistribusikan.
- `module/visual/ZoomModule.java` + `mixin/visual/ZoomFovMixin.java`:
  source Zoomify yang dikirim pakai mapping Mojang untuk versi berbeda,
  jadi DI-IMPLEMENTASI ULANG dari nol (bukan porting) - FOV di-ease halus
  (bukan loncat) selagi tombol ditahan, amount & smoothness diatur lewat
  setting.
- `module/visual/FreeLookModule.java` + `mixin/visual/FreeLookEntityMixin.java`
  + `mixin/visual/FreeLookCameraMixin.java`: source Freelook yang dikirim
  juga pakai mapping Mojang - konsepnya diporting (bukan kodenya) ke 2
  hook Yarn yang jauh lebih stabil (`Entity#changeLookDirection` +
  `Camera#update` TAIL) dibanding meniru method privat `alignWithEntity`
  mod referensi.
- `module/hud/TotemCounterModule.java` + `mixin/entity/TotemPopMixin.java`:
  source Totem Counter yang dikirim pakai mapping Mojang + arsitektur
  multi-loader berbeda - disederhanakan jadi hook tunggal
  `LivingEntity#handleStatus` (byte 35 = pakai totem), ditampilkan sebagai
  HUD sendiri (bukan di tab-list seperti mod referensi).

**16 module baru lainnya** (HUD kecuali disebutkan): Action Bar, Boss Bar
(baca lewat refleksi generik ke field `Map` internal `BossBarHud` - aman,
tidak pernah crash walau field-nya berubah nama), Bow (persentase tarikan),
Crosshair (info block/entity yang dibidik), Hotbar (slot terpilih), Item
Update (popup ganti item), Player (HP/absorption presisi), Scoreboard
(judul+jumlah entri sidebar lewat API publik `Scoreboard`), Settings
(pengingat keybind menu), Speed (block/detik), Time (waktu in-game, beda
dengan Clock HUD yang jam dunia nyata), TPS (perkiraan dari timing tick
client), UHC Overlay (rincian HP/Absorption/Hunger), Blocks Modifier
(**Visual** - outline magenta untuk barrier/light/structure_void yang
dibidik), Scroll Settings (**Visual** - toggle scroll-untuk-skala di HUD
Editor), Time Changer (**Visual** - kirim `/time set` berkala, hanya
berefek bila pemain berwenang).

Ikon: 20 file dari paket "Logo Module" kedua yang dikirim (semua module id
di daftar ternyata sudah punya ikon sendiri) disalin ke
`textures/gui/modules/` & dipetakan di `IconRenderer.MODULE_ICONS`.

## Sesi 4 — Perbaikan crash saat start
### Crash "Mixin transformation of net.minecraft.class_702 failed" — DIPERBAIKI
`mixin/particle/ParticleSpawnCullMixin.java` menargetkan
`ParticleManager#addParticle(...)` dengan descriptor return `V` (void).
Di Yarn 1.21.11, method ini sebenarnya mengembalikan `@Nullable Particle`,
bukan `void` — descriptor lama tidak pernah cocok dengan bytecode asli
(apalagi refmap mod ini tidak ter-load di lingkungan ini), sehingga Mixin
gagal menemukan target dan game crash total setiap kali `MinecraftClient`
membuat `ParticleManager` (persis di awal startup, sebelum menu utama
muncul). Diperbaiki dengan descriptor return yang benar
(`...)Lnet/minecraft/client/particle/Particle;`) dan callback
`CallbackInfoReturnable<Particle>` (`cir.setReturnValue(null)` untuk
membatalkan), bukan `CallbackInfo` biasa. Mixin lain (BlockEntityRenderCull,
EntityRenderCull, ChatHudTimestamp, LightmapTextureManager, TitleScreen,
MobAiThrottle) sudah dicek ulang dan targetnya masih valid di 1.21.11.

## Sesi 3
- **Renderer Optimization DIHAPUS TOTAL** (tidak berguna menurut kamu) -
  file `RendererOptimizationModule.java` dihapus, registrasinya di
  `ModuleManager.java` dan translation key-nya di `en_us.json`/`id_id.json`
  juga dihapus. Tidak ada sisa referensi di source manapun.
- **Damage Indicator dikembalikan ke MERAH** (`0xFF5050`) - permintaan
  "hitam-putih di luar Mod Menu" sebelumnya sudah kelewat jauh sampai
  ke sini, sekarang dibatalkan khusus untuk modul ini.

## Sesi 2
### Hitam-putih di luar Mod Menu
- `client/util/HudRenderUtil.java`: `ACCENT_COLOR` (dulu biru, dipakai
  Combo Counter & Credit HUD) -> abu sangat terang.
- `client/module/hud/KeystrokesModule.java`: kotak tombol ditekan (dulu
  biru) -> putih terang, teks otomatis jadi hitam di atasnya.
- Damage Indicator: lihat Sesi 3 di atas - DIBATALKAN, kembali merah.

### Logo title screen pakai gambar asli
`textures/gui/title_logo.png` (banner "XOLDIUM CLIENT" 1024x265) +
`mixin/titlescreen/TitleScreenMixin.java` digambar 220x57 di atas title
screen, menggantikan wordmark teks polos.

## Sesi 1
### Bug Fullbright — DIPERBAIKI
Mixin langsung ke perhitungan lightmap texture
(`mixin/visual/LightmapTextureManagerMixin.java`), TIDAK lagi lewat
`GameOptions#getGamma()` yang value-nya ditolak diam-diam oleh validator
slider vanilla di Minecraft 1.21.11.

### Mod Menu diperkecil & hitam-putih
`client/gui/ModListScreen.java` (panel ~460x300, kartu ~104x66) +
`client/gui/IconRenderer.java` (toggle & badge hitam-putih-abu netral).

### Ikon modul asli
21 dari 24 modul pakai ikon PNG dari `Logo Module.zip`, dipetakan di
`IconRenderer.MODULE_ICONS`; Biome HUD & No Hurt Cam tetap fallback
badge inisial huruf (tidak ada file ikon yang cocok).

### Logo asli di HUD Editor
`client/gui/XoldiumHomeScreen.java`: badge "X" diganti gambar
`logo.png` asli.

### UI khas title screen (ala Hyper Client)
Tombol "Mod Menu / HUD Editor / Settings" tambahan di kiri layar lewat
`Screen#addDrawable(...)` di `init()` (di 1.21.11 `TitleScreen` sudah
tidak meng-override `render(...)` sendiri lagi - Mixin ke render akan
crash saat start).

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Mengurangi view bobbing saat zoom (padanan {@code GameRendererMixin#modifyBob} Ok Zoomer beta.6).
 * Satu-satunya pemanggilan {@code MathHelper#lerp(FFF)F} di {@code GameRenderer#bobView} adalah
 * interpolasi kekuatan bobbing; nilainya dikalikan pengali zoom. {@code require = 0}: bila target tidak
 * cocok, dilewati tanpa crash.
 */
@Mixin(GameRenderer.class)
public abstract class ZoomBobMixin {

    @Redirect(
            method = "bobView",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F"),
            require = 0
    )
    private float xoldium$reduceBob(float delta, float start, float end) {
        return ZoomModule.applyBob(MathHelper.lerp(delta, start, end), delta);
    }
}

package com.xoldium.xoldiummod.mixin.visual;

import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

/**
 * Akses daftar pass milik {@link PostEffectProcessor} supaya uniform shader motion blur bisa diisi
 * (yang dikerjakan library Satin di mod aslinya natural-motionblur; di sini langsung lewat vanilla).
 */
@Mixin(PostEffectProcessor.class)
public interface PostEffectProcessorAccessor {

    @Accessor("passes")
    List<PostEffectPass> xoldium$getPasses();
}

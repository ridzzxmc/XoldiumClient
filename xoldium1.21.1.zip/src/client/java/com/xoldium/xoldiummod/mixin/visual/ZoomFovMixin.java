package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.ZoomModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hook FOV untuk Zoom - padanan {@code GameRendererMixin#modifyFov} milik Ok Zoomer 10.0.0-beta.6
 * (yang juga menargetkan Minecraft 1.21.1): nilai kembalian {@code GameRenderer#getFov} dikalikan
 * pengali transisi zoom. Di 1.21.1 {@code getFov(Camera, float, boolean)} mengembalikan {@code double}.
 *
 * <p>Dipasang lewat nama method (sama seperti Ok Zoomer) sehingga refmap Loom yang memetakannya ke
 * nama intermediary. {@code require = 0}: bila gagal ter-apply, game TIDAK crash (zoom saja yang mati,
 * dan {@code ZoomModule} menulis peringatan di log).
 */
@Mixin(GameRenderer.class)
public abstract class ZoomFovMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void xoldium$zoomFov(Camera camera, float tickDelta, boolean changingFov,
                                 CallbackInfoReturnable<Double> cir) {
        Double original = cir.getReturnValue();
        if (original == null) {
            return;
        }
        double zoomed = ZoomModule.applyZoom(original, tickDelta, changingFov);
        if (zoomed != original) {
            cir.setReturnValue(zoomed);
        }
    }
}

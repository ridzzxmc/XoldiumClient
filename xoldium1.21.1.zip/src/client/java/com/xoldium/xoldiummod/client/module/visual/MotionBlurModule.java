package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.render.motionblur.MotionBlurRenderer;

/**
 * Motion Blur - port dari mod "Natural Motion Blur" (natural-motionblur-fabric 1.20.6) ke 1.21.1.
 * Implementasi shader-nya ada di {@link MotionBlurRenderer}. Setting mengikuti {@code ConfigEntries}
 * aslinya: kekuatan (bawaan 1.0, dianjurkan tetap 1), refresh rate scaling, depth blur, algoritma blur
 * (Backwards / Centered), dan render di third-person (F5). Ditambah "jeda saat GUI terbuka".
 */
public final class MotionBlurModule extends Module {

    private static MotionBlurModule instance;

    private final DoubleSetting strengthSetting = addSetting(
            new DoubleSetting("strength", "setting.xoldiummod.motionblur.strength", 1.0, 0.05, 5.0, 0.05));
    private final BooleanSetting refreshScalingSetting = addSetting(
            new BooleanSetting("refresh_rate_scaling", "setting.xoldiummod.motionblur.refresh_rate_scaling", true));
    private final BooleanSetting depthBlurSetting = addSetting(
            new BooleanSetting("depth_blur", "setting.xoldiummod.motionblur.depth_blur", true));
    private final ModeSetting algorithmSetting = addSetting(
            new ModeSetting("blur_algorithm", "setting.xoldiummod.motionblur.algorithm", 1,
                    "setting.xoldiummod.motionblur.algorithm.backwards",
                    "setting.xoldiummod.motionblur.algorithm.centered"));
    private final BooleanSetting thirdPersonSetting = addSetting(
            new BooleanSetting("render_f5", "setting.xoldiummod.motionblur.render_f5", true));
    private final BooleanSetting pauseInGuisSetting = addSetting(
            new BooleanSetting("pause_in_guis", "setting.xoldiummod.motionblur.pause_in_guis", true));

    public MotionBlurModule() {
        super("motionblur", "module.xoldiummod.motionblur", ModuleCategory.VISUAL, true);
        instance = this;
    }

    @Override
    protected void onToggle(boolean enabled) {
        MotionBlurRenderer.reset();
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static float strength() {
        return instance != null ? instance.strengthSetting.get().floatValue() : 1.0F;
    }

    public static boolean refreshRateScaling() {
        return instance == null || instance.refreshScalingSetting.get();
    }

    public static boolean depthBlur() {
        return instance == null || instance.depthBlurSetting.get();
    }

    /** 0 = BACKWARDS, 1 = CENTERED (urutan enum {@code BlurAlgorithm} asli). */
    public static int blurAlgorithm() {
        return instance != null ? instance.algorithmSetting.index() : 1;
    }

    public static boolean renderInThirdPerson() {
        return instance == null || instance.thirdPersonSetting.get();
    }

    public static boolean pauseInGuis() {
        return instance == null || instance.pauseInGuisSetting.get();
    }
}

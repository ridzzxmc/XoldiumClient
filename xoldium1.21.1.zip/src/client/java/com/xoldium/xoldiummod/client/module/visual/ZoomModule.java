package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.XoldiumKeyCategory;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import com.xoldium.xoldiummod.client.module.visual.zoom.ZoomTransition;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom Xoldium untuk Minecraft 1.21.1 - port dari mod Ok Zoomer 10.0.0-beta.6 (versi yang memang
 * dibuat untuk 1.21.1). Pemetaan ke source aslinya:
 * <ul>
 *   <li>sinyal zoom Hold / Toggle / Persistent = {@code ManageZoomEvent}</li>
 *   <li>tombol tambahan zoom masuk / keluar / reset = {@code ManageExtraKeysEvent}</li>
 *   <li>langkah scroll = {@code ZoomUtils#changeZoomDivisor} (divisor diinterpolasi linear antara
 *       divisor awal, divisor minimum dan divisor maksimum menurut jumlah langkah atas/bawah)</li>
 *   <li>transisi Instant / Smooth / Linear = {@code zoom.transitions} (lihat {@link ZoomTransition})</li>
 *   <li>FOV = FOV asli x pengali transisi, di akhir {@code GameRenderer#getFov}
 *       ({@code GameRendererMixin#modifyFov})</li>
 *   <li>sensitivitas mouse = delta x pengali transisi ({@code ZoomDivisorMouseModifier})</li>
 *   <li>view bobbing ikut dikurangi ({@code GameRendererMixin#modifyBob})</li>
 *   <li>pengurai tombol C yang bentrok dengan "Save Toolbar Activator" = {@code ZoomUtils#unbindConflictingKey}</li>
 * </ul>
 * Nilai bawaan sama dengan {@code OkZoomerConfig} beta.6: divisor 4, minimum 1, maksimum 50, 5 langkah
 * bawah, 10 langkah atas, smooth 0.6, linear 0.16-0.22, mode Hold.
 *
 * <p>Tidak dibawa (sengaja, demi stabilitas): overlay vinyet/spyglass, kamera sinematik, zoom pada GUI,
 * mode spyglass.
 */
public final class ZoomModule extends Module {

    private static final int MODE_HOLD = 0;
    private static final int MODE_TOGGLE = 1;
    private static final int MODE_PERSISTENT = 2;

    private static final int TRANSITION_INSTANT = 0;
    private static final int TRANSITION_SMOOTH = 1;
    private static final int TRANSITION_LINEAR = 2;

    private static ZoomModule instance;

    private final KeyBinding zoomKey;
    private final KeyBinding zoomInKey;
    private final KeyBinding zoomOutKey;
    private final KeyBinding zoomResetKey;

    private final ModeSetting mode = addSetting(
            new ModeSetting("mode", "setting.xoldiummod.zoom.mode", MODE_HOLD,
                    "setting.xoldiummod.zoom.mode.hold",
                    "setting.xoldiummod.zoom.mode.toggle",
                    "setting.xoldiummod.zoom.mode.persistent"));
    private final ModeSetting transition = addSetting(
            new ModeSetting("transition_type", "setting.xoldiummod.zoom.transition_type", TRANSITION_SMOOTH,
                    "setting.xoldiummod.zoom.transition.instant",
                    "setting.xoldiummod.zoom.transition.smooth",
                    "setting.xoldiummod.zoom.transition.linear"));
    private final DoubleSetting zoomDivisorSetting = addSetting(
            new DoubleSetting("zoom_divisor", "setting.xoldiummod.zoom.divisor", 4.0, 1.0, 50.0, 0.5));
    private final DoubleSetting minDivisorSetting = addSetting(
            new DoubleSetting("min_divisor", "setting.xoldiummod.zoom.min_divisor", 1.0, 0.5, 4.0, 0.25));
    private final DoubleSetting maxDivisorSetting = addSetting(
            new DoubleSetting("max_divisor", "setting.xoldiummod.zoom.max_divisor", 50.0, 5.0, 200.0, 5.0));
    private final DoubleSetting lowerStepsSetting = addSetting(
            new DoubleSetting("lower_steps", "setting.xoldiummod.zoom.lower_steps", 5.0, 1.0, 20.0, 1.0));
    private final DoubleSetting upperStepsSetting = addSetting(
            new DoubleSetting("upper_steps", "setting.xoldiummod.zoom.upper_steps", 10.0, 1.0, 40.0, 1.0));
    private final DoubleSetting smoothFactor = addSetting(
            new DoubleSetting("smooth_factor", "setting.xoldiummod.zoom.smooth_factor", 0.6, 0.05, 1.0, 0.05));
    private final DoubleSetting linearMin = addSetting(
            new DoubleSetting("linear_min", "setting.xoldiummod.zoom.linear_min", 0.16, 0.01, 1.0, 0.01));
    private final DoubleSetting linearMax = addSetting(
            new DoubleSetting("linear_max", "setting.xoldiummod.zoom.linear_max", 0.22, 0.01, 1.0, 0.01));
    private final BooleanSetting scrollZoom = addSetting(
            new BooleanSetting("scroll_zoom", "setting.xoldiummod.zoom.scroll", true));
    private final BooleanSetting reduceSensitivity = addSetting(
            new BooleanSetting("reduce_sensitivity", "setting.xoldiummod.zoom.reduce_sensitivity", true));
    private final BooleanSetting reduceBobbing = addSetting(
            new BooleanSetting("reduce_bobbing", "setting.xoldiummod.zoom.reduce_bobbing", true));
    private final BooleanSetting affectHand = addSetting(
            new BooleanSetting("affect_hand", "setting.xoldiummod.zoom.affect_hand", true));
    private final BooleanSetting forgetDivisor = addSetting(
            new BooleanSetting("forget_divisor", "setting.xoldiummod.zoom.forget_divisor", true));
    private final BooleanSetting unbindConflict = addSetting(
            new BooleanSetting("unbind_conflict", "setting.xoldiummod.zoom.unbind_conflict", true));

    private ZoomTransition transitionMode = new ZoomTransition.Instant();
    private int builtType = -1;
    private float builtParamA = Float.NaN;
    private float builtParamB = Float.NaN;

    private boolean zooming = false;
    private boolean lastZooming = false;
    private boolean persistentZoom = false;
    private boolean keyHeld = false;
    private boolean modifierActive = false;
    private double zoomDivisor = 4.0;
    private int zoomStep = 0;
    private boolean conflictChecked = false;

    private boolean fovHookAlive = false;
    private boolean warnedNoHook = false;
    private int ticksZoomingWithoutHook = 0;

    public ZoomModule() {
        // Zoom adalah fitur dasar: aktif sejak awal (tombol C), tidak perlu dinyalakan manual dulu.
        super("zoom", "module.xoldiummod.zoom", ModuleCategory.VISUAL, true);
        instance = this;
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, XoldiumKeyCategory.MAIN));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        zoomResetKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.zoom_reset", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, XoldiumKeyCategory.MAIN));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.zoom.key", zoomKey));
        addSetting(new KeybindSetting("key_in", "setting.xoldiummod.zoom.key_in", zoomInKey));
        addSetting(new KeybindSetting("key_out", "setting.xoldiummod.zoom.key_out", zoomOutKey));
        addSetting(new KeybindSetting("key_reset", "setting.xoldiummod.zoom.key_reset", zoomResetKey));
        ensureTransition();
        resetZoomDivisor(true);
    }

    // ------------------------------------------------------------------ transisi

    /** Bangun ulang transisi bila jenis / parameternya di pengaturan berubah. */
    private void ensureTransition() {
        int type = Math.max(TRANSITION_INSTANT, Math.min(TRANSITION_LINEAR, transition.index()));
        float a = 0.0F;
        float b = 0.0F;
        if (type == TRANSITION_SMOOTH) {
            a = smoothFactor.get().floatValue();
        } else if (type == TRANSITION_LINEAR) {
            a = linearMin.get().floatValue();
            b = linearMax.get().floatValue();
        }
        if (type == builtType && Float.compare(a, builtParamA) == 0 && Float.compare(b, builtParamB) == 0) {
            return;
        }
        transitionMode = switch (type) {
            case TRANSITION_SMOOTH -> new ZoomTransition.Smooth(a);
            case TRANSITION_LINEAR -> new ZoomTransition.Linear(a, b);
            default -> new ZoomTransition.Instant();
        };
        builtType = type;
        builtParamA = a;
        builtParamB = b;
    }

    // ------------------------------------------------------------------ langkah zoom (Ok Zoomer: ZoomUtils)

    private int upperSteps() {
        return Math.max(1, (int) Math.round(upperStepsSetting.get()));
    }

    private int lowerSteps() {
        return Math.max(1, (int) Math.round(lowerStepsSetting.get()));
    }

    /** Port {@code ZoomUtils#changeZoomDivisor}. */
    private void changeZoomDivisor(boolean increase) {
        double base = zoomDivisorSetting.get();
        double min = Math.min(minDivisorSetting.get(), base);
        double max = Math.max(maxDivisorSetting.get(), base);
        int upper = upperSteps();
        int lower = lowerSteps();

        zoomStep = increase ? Math.min(zoomStep + 1, upper) : Math.max(zoomStep - 1, -lower);
        applyStep(base, min, max, upper, lower);
    }

    private void applyStep(double base, double min, double max, int upper, int lower) {
        double d;
        if (zoomStep > 0) {
            d = base + ((max - base) / upper * zoomStep);
        } else if (zoomStep == 0) {
            d = base;
        } else {
            d = base + ((min - base) / lower * -zoomStep);
        }
        zoomDivisor = (Double.isFinite(d) && d > 0.0) ? d : base;
    }

    /**
     * Port {@code ZoomUtils#resetZoomDivisor}: bila bukan permintaan pengguna dan opsi "lupakan divisor"
     * mati, divisor dibiarkan apa adanya.
     */
    private void resetZoomDivisor(boolean userPrompted) {
        if (!userPrompted && !forgetDivisor.get()) {
            return;
        }
        zoomStep = 0;
        zoomDivisor = zoomDivisorSetting.get();
    }

    /** Port {@code ZoomUtils#keepZoomStepsWithinBounds}. */
    private void keepZoomStepWithinBounds() {
        zoomStep = Math.max(-lowerSteps(), Math.min(zoomStep, upperSteps()));
        double base = zoomDivisorSetting.get();
        applyStep(base, Math.min(minDivisorSetting.get(), base), Math.max(maxDivisorSetting.get(), base),
                upperSteps(), lowerSteps());
    }

    // ------------------------------------------------------------------ siklus modul

    @Override
    protected void onToggle(boolean enabled) {
        zooming = false;
        lastZooming = false;
        persistentZoom = false;
        keyHeld = false;
        modifierActive = false;
        builtType = -1;
        ensureTransition();
        resetZoomDivisor(true);
    }

    /**
     * Port {@code ZoomUtils#unbindConflictingKey}: tombol C bawaan dipakai juga oleh "Save Toolbar
     * Activator" milik vanilla, dan Minecraft hanya menyimpan SATU keybind per tombol fisik - tanpa ini
     * zoom bisa tidak pernah menerima penekanan tombol. Dilakukan sekali saja, hanya bila kedua
     * keybind masih di nilai bawaan (C).
     */
    private void resolveKeyConflict(MinecraftClient client) {
        if (conflictChecked) {
            return;
        }
        conflictChecked = true;
        if (!unbindConflict.get() || !zoomKey.isDefault()) {
            return;
        }
        try {
            for (KeyBinding other : client.options.allKeys) {
                if (other != zoomKey && other.isDefault()
                        && "key.saveToolbarActivator".equals(other.getTranslationKey())
                        && other.getBoundKeyTranslationKey().equals(zoomKey.getBoundKeyTranslationKey())) {
                    other.setBoundKey(InputUtil.UNKNOWN_KEY);
                    KeyBinding.updateKeysByCode();
                    client.options.write();
                    XoldiumMod.LOGGER.info("[Xoldium] Keybind 'Save Toolbar Activator' ditempati tombol C - dilepas supaya Zoom bisa memakai C.");
                    break;
                }
            }
        } catch (Throwable t) {
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal melepas keybind yang bentrok dengan tombol Zoom (dilewati, aman).", t);
        }
    }

    /**
     * Status tombol zoom. Selain {@code KeyBinding#isPressed}, tombol fisiknya juga dibaca langsung dari
     * GLFW saat tidak ada layar terbuka (cadangan bila keybind lain masih berbagi tombol yang sama).
     */
    private boolean readZoomKey(MinecraftClient client) {
        if (zoomKey.isPressed()) {
            return true;
        }
        if (client.currentScreen != null) {
            return false;
        }
        try {
            InputUtil.Key bound = KeyBindingHelper.getBoundKeyOf(zoomKey);
            if (bound == null) {
                return false;
            }
            int code = bound.getCode();
            if (code < 0) {
                return false;
            }
            long handle = client.getWindow().getHandle();
            InputUtil.Type type = bound.getCategory();
            if (type == InputUtil.Type.MOUSE) {
                return GLFW.glfwGetMouseButton(handle, code) == GLFW.GLFW_PRESS;
            }
            if (type == InputUtil.Type.KEYSYM) {
                return GLFW.glfwGetKey(handle, code) == GLFW.GLFW_PRESS;
            }
        } catch (Throwable ignored) {
            // pembacaan GLFW hanya cadangan - bila gagal, andalkan KeyBinding biasa.
        }
        return false;
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ensureTransition();

        if (client.player == null) {
            if (zooming || transitionMode.getActive()) {
                builtType = -1;
                ensureTransition();
            }
            zooming = false;
            lastZooming = false;
            keyHeld = false;
            modifierActive = false;
            return;
        }

        resolveKeyConflict(client);

        // --- sinyal zoom (Ok Zoomer: ManageZoomEvent) ---
        boolean keyDown = readZoomKey(client);
        keyHeld = keyDown;
        while (zoomKey.wasPressed()) {
            // habiskan klik antrean agar tidak menumpuk
        }

        int zoomMode = mode.index();
        if (zoomMode != MODE_HOLD) {
            if (!persistentZoom) {
                persistentZoom = true;
                lastZooming = true;
                resetZoomDivisor(false);
            }
        } else if (persistentZoom) {
            persistentZoom = false;
            lastZooming = true;
        }

        if (keyDown != lastZooming) {
            switch (zoomMode) {
                case MODE_TOGGLE -> {
                    if (keyDown) {
                        zooming = !zooming;
                        resetZoomDivisor(false);
                    }
                }
                case MODE_PERSISTENT -> {
                    zooming = true;
                    keepZoomStepWithinBounds();
                }
                default -> {
                    zooming = keyDown;
                    resetZoomDivisor(false);
                }
            }
            lastZooming = keyDown;
        }

        // --- tombol ekstra zoom masuk/keluar/reset (Ok Zoomer: ManageExtraKeysEvent) ---
        boolean in = zoomInKey.isPressed();
        boolean out = zoomOutKey.isPressed();
        boolean reset = zoomResetKey.isPressed();
        while (zoomInKey.wasPressed()) {
            // habiskan
        }
        while (zoomOutKey.wasPressed()) {
            // habiskan
        }
        while (zoomResetKey.wasPressed()) {
            // habiskan
        }
        if (out && !in) {
            changeZoomDivisor(false);
        }
        if (in && !out) {
            changeZoomDivisor(true);
        }
        if (reset) {
            resetZoomDivisor(true);
        }

        // --- tick transisi (Ok Zoomer: GameRendererMixin#tickInstances) ---
        if (zooming || transitionMode.getActive() || modifierActive) {
            transitionMode.tick(zooming, zooming ? zoomDivisor : 1.0);
            modifierActive = reduceSensitivity.get() && zooming;
        }

        // --- diagnostik: hook FOV tidak ter-apply ---
        if (zooming && !fovHookAlive) {
            ticksZoomingWithoutHook++;
            if (ticksZoomingWithoutHook > 40 && !warnedNoHook) {
                warnedNoHook = true;
                XoldiumMod.LOGGER.warn("[Xoldium] Zoom aktif tapi hook GameRenderer#getFov belum pernah terpanggil - "
                        + "mixin ZoomFovMixin tidak ter-apply (cek baris '[Xoldium] mixin aktif: zoom_fov' di latest.log).");
                try {
                    client.inGameHud.setOverlayMessage(
                            Text.literal("[Xoldium] Zoom: hook FOV tidak aktif - kirim latest.log"), false);
                } catch (Throwable ignored) {
                    // pesan layar hanya bantuan diagnosa.
                }
            }
        } else if (!zooming) {
            ticksZoomingWithoutHook = 0;
        }
    }

    // ------------------------------------------------------------------ API untuk mixin

    public static boolean isZooming() {
        return instance != null && instance.isEnabled() && (instance.zooming || instance.transitionMode.getActive());
    }

    /**
     * Dipanggil dari akhir {@code GameRenderer#getFov} (Ok Zoomer: {@code GameRendererMixin#modifyFov}).
     *
     * @param useFovSetting true untuk FOV dunia, false untuk FOV tangan/item (changingFov = false di vanilla)
     */
    public static double applyZoom(double baseFov, float tickDelta, boolean useFovSetting) {
        ZoomModule z = instance;
        if (z == null) {
            return baseFov;
        }
        z.fovHookAlive = true;
        MixinDiag.alive("zoom_fov");
        if (!z.isEnabled() || !z.transitionMode.getActive() || (!useFovSetting && !z.affectHand.get())) {
            return baseFov;
        }
        double result = z.transitionMode.applyZoom((float) baseFov, tickDelta);
        return Double.isFinite(result) ? Math.max(0.1, result) : baseFov;
    }

    /** Pengali gerakan kamera (Ok Zoomer: {@code ZoomDivisorMouseModifier}): delta x pengali transisi. */
    public static double lookScale() {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.modifierActive) {
            return 1.0;
        }
        double m = z.transitionMode.getInternalMultiplier();
        return (Double.isFinite(m) && m > 0.0) ? m : 1.0;
    }

    /** Pengurangan view bobbing saat zoom (Ok Zoomer: {@code GameRendererMixin#modifyBob}). */
    public static float applyBob(float bob, float tickDelta) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.zooming || !z.reduceBobbing.get()) {
            return bob;
        }
        float result = z.transitionMode.applyZoom(bob, tickDelta);
        return Float.isFinite(result) ? result : bob;
    }

    /** Scroll saat zoom -> naik/turun langkah zoom (Ok Zoomer: {@code MouseHandlerMixin#zoomerOnMouseScroll}). */
    public static boolean handleScroll(double vertical) {
        ZoomModule z = instance;
        if (z == null || !z.isEnabled() || !z.scrollZoom.get() || !z.zooming || vertical == 0) {
            return false;
        }
        if (z.mode.index() == MODE_PERSISTENT && !z.keyHeld) {
            return false; // mode Persistent: scroll hanya mengatur zoom selagi tombol zoom ditahan
        }
        z.changeZoomDivisor(vertical > 0);
        return true;
    }
}

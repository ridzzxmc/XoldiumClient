package com.xoldium.xoldiummod.client.module.visual.zoom;

/**
 * Mode transisi zoom - port langsung dari {@code TransitionMode} milik Ok Zoomer 10.0.0-beta.6
 * ({@code InstantTransitionMode}, {@code SmoothTransitionMode}, {@code LinearTransitionMode}).
 * Menentukan bagaimana FOV biasa berpindah ke FOV zoom dan sebaliknya.
 */
public interface ZoomTransition {

    boolean getActive();

    /** FOV x pengali transisi (diinterpolasi antar tick dengan {@code tickDelta}). */
    float applyZoom(float fov, float tickDelta);

    /** Dipanggil SATU kali per tick game. */
    void tick(boolean active, double divisor);

    /** Pengali saat ini (1.0 = tanpa zoom, 0.25 = zoom x4) - dipakai pengurang sensitivitas mouse. */
    double getInternalMultiplier();

    static float lerp(float delta, float start, float end) {
        return start + delta * (end - start);
    }

    static float safeMultiplier(double divisor) {
        return (divisor > 0.0 && Double.isFinite(divisor)) ? (float) (1.0 / divisor) : 1.0F;
    }

    /** Port {@code InstantTransitionMode}: zoom langsung tanpa transisi. */
    final class Instant implements ZoomTransition {
        private boolean active = false;
        private double divisor = 1.0;

        @Override
        public boolean getActive() {
            return active;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * safeMultiplier(divisor);
        }

        @Override
        public void tick(boolean active, double divisor) {
            this.active = active;
            this.divisor = divisor;
        }

        @Override
        public double getInternalMultiplier() {
            return safeMultiplier(divisor);
        }
    }

    /** Port {@code SmoothTransitionMode} (faktor bawaan 0.6 pada konfigurasi beta.6). */
    final class Smooth implements ZoomTransition {
        private boolean active = false;
        private final float smoothMultiplier;
        private float internalMultiplier = 1.0F;
        private float lastInternalMultiplier = 1.0F;

        public Smooth(float smoothMultiplier) {
            this.smoothMultiplier = Math.max(0.01F, Math.min(1.0F, smoothMultiplier));
        }

        @Override
        public boolean getActive() {
            return active || internalMultiplier != 1.0F;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * lerp(tickDelta, lastInternalMultiplier, internalMultiplier);
        }

        @Override
        public void tick(boolean active, double divisor) {
            float target = active ? safeMultiplier(divisor) : 1.0F;
            lastInternalMultiplier = internalMultiplier;
            internalMultiplier += (target - internalMultiplier) * smoothMultiplier;
            // Pengaman: tanpa ini float bisa "nyaris 1" sangat lama -> transisi tak pernah berhenti aktif.
            if (!active && Math.abs(internalMultiplier - 1.0F) < 0.0005F) {
                internalMultiplier = 1.0F;
            }
            this.active = active;
        }

        @Override
        public double getInternalMultiplier() {
            return internalMultiplier;
        }
    }

    /**
     * Port {@code LinearTransitionMode}: langkah = {@code clamp(1/divisor, minimumStep, maximumStep)}
     * (bawaan beta.6: 0.16 .. 0.22), bergerak lurus ke target dengan {@code Mth.approach}.
     */
    final class Linear implements ZoomTransition {
        private boolean active = false;
        private final float minimumStep;
        private final float maximumStep;
        private float internalMultiplier = 1.0F;
        private float lastInternalMultiplier = 1.0F;

        public Linear(float minimumStep, float maximumStep) {
            float lo = Math.max(0.001F, Math.min(minimumStep, maximumStep));
            float hi = Math.max(lo, Math.max(minimumStep, maximumStep));
            this.minimumStep = lo;
            this.maximumStep = hi;
        }

        private static float approach(float current, float target, float step) {
            return current < target ? Math.min(current + step, target) : Math.max(current - step, target);
        }

        @Override
        public boolean getActive() {
            return active || internalMultiplier != 1.0F;
        }

        @Override
        public float applyZoom(float fov, float tickDelta) {
            return fov * lerp(tickDelta, lastInternalMultiplier, internalMultiplier);
        }

        @Override
        public void tick(boolean active, double divisor) {
            float target = active ? safeMultiplier(divisor) : 1.0F;
            lastInternalMultiplier = internalMultiplier;
            float step = Math.max(minimumStep, Math.min(maximumStep, safeMultiplier(divisor)));
            internalMultiplier = approach(internalMultiplier, target, step);
            this.active = active;
        }

        @Override
        public double getInternalMultiplier() {
            return internalMultiplier;
        }
    }
}

package com.xoldium.xoldiummod.client.render.motionblur;

import com.mojang.blaze3d.systems.RenderSystem;
import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.MixinDiag;
import com.xoldium.xoldiummod.client.module.visual.MotionBlurModule;
import com.xoldium.xoldiummod.client.render.WorldOverlay;
import com.xoldium.xoldiummod.mixin.visual.PostEffectProcessorAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.JsonEffectShaderProgram;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;

import java.util.List;

/**
 * Motion blur Xoldium untuk Minecraft 1.21.1 - port dari mod "Natural Motion Blur"
 * (natural-motionblur-fabric 1.20.6) yang dikirim pemakai.
 *
 * <p>Yang dibawa apa adanya dari source aslinya:
 * <ul>
 *   <li>shader fragment {@code motion_blur.fsh} + {@code program/motion_blur.json} + {@code post/motion_blur.json}
 *       (reprojection kecepatan dari depth buffer + matriks frame sebelumnya, jitter noise, blur centered/backwards),</li>
 *   <li>urutan kerja {@code ShaderManager}: hitung delta waktu & FPS, skala kekuatan terhadap refresh rate
 *       monitor ({@code MonitorInfoProvider}), isi uniform {@code BlendFactor, view_res, view_pixel_size,
 *       motionBlurSamples, blurAlgorithm, useDepth}, lalu render efek,</li>
 *   <li>matriks {@code modelView / prevModelView / projection / prevProjection / cameraPos / prevCameraPos}
 *       (posisi kamera di-modulo 30000 seperti aslinya).</li>
 * </ul>
 *
 * <p>Perbedaan dengan mod aslinya (semua demi tanpa dependency tambahan): library Satin TIDAK dipakai.
 * Efeknya dimuat langsung lewat {@link PostEffectProcessor} vanilla, dan sampler depth
 * ({@code DiffuseDepthSampler}, yang di mod asli diatur Satin lewat {@code "minecraft:main:depth"}) dipasang
 * manual lewat {@link PostEffectPass#addAuxTarget}. Matriks diambil dari {@link WorldRenderContext} pada
 * {@link WorldRenderEvents#END}, sehingga tidak perlu mixin ke {@code WorldRenderer}.
 *
 * <p>Seluruh jalur dibungkus try/catch: bila ada yang gagal (mis. driver menolak shader), motion blur
 * dimatikan untuk sesi itu dan game TIDAK crash.
 */
public final class MotionBlurRenderer {

    private static final Identifier POST_ID = Identifier.of(XoldiumMod.MOD_ID, "shaders/post/motion_blur.json");
    private static final float CAMERA_WRAP = 30000.0F;

    private static PostEffectProcessor processor;
    private static JsonEffectShaderProgram program;
    private static int builtWidth = -1;
    private static int builtHeight = -1;
    private static boolean runtimeFailed = false;
    private static boolean loggedFirstPass = false;

    private static final Matrix4f prevModelView = new Matrix4f();
    private static final Matrix4f prevProjection = new Matrix4f();
    private static final Vector3f prevCameraPos = new Vector3f();
    private static boolean havePrev = false;

    private static long lastNano = 0L;
    private static float currentFps = 0.0F;
    private static int sampleAmount = 100;

    // MonitorInfoProvider
    private static long lastMonitorHandle = 0L;
    private static int lastRefreshRate = 60;
    private static long lastMonitorCheck = 0L;

    private MotionBlurRenderer() {
    }

    public static void register() {
        WorldRenderEvents.END.register(MotionBlurRenderer::onWorldEnd);
    }

    /** Dipanggil saat modul di-toggle: lupakan matriks frame lama supaya tidak ada lonjakan blur. */
    public static void reset() {
        havePrev = false;
    }

    private static void onWorldEnd(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        // Delta waktu & FPS (ShaderManager.registerShaderCallbacks)
        long now = System.nanoTime();
        float deltaTime = lastNano == 0L ? 0.0F : (now - lastNano) / 1_000_000_000.0F;
        lastNano = now;
        currentFps = (deltaTime > 0.0F && deltaTime < 1.0F) ? 1.0F / deltaTime : 0.0F;

        Matrix4f modelView = new Matrix4f(WorldOverlay.positionMatrix(context.matrixStack()));
        Matrix4f projection = new Matrix4f(context.projectionMatrix());
        Vec3d cam = context.camera().getPos();
        Vector3f cameraPos = new Vector3f((float) (cam.x % CAMERA_WRAP), (float) (cam.y % CAMERA_WRAP), (float) (cam.z % CAMERA_WRAP));

        try {
            if (!runtimeFailed && shouldRender(client)) {
                MixinDiag.alive("motion_blur");
                apply(client, modelView, projection, cameraPos, deltaTime * 20.0F);
            }
        } catch (Throwable t) {
            runtimeFailed = true;
            closeProcessor();
            XoldiumMod.LOGGER.warn("[Xoldium] Motion blur dimatikan untuk sesi ini (error saat render, game tetap aman).", t);
        } finally {
            // MixinLevelRenderer RETURN: simpan matriks frame ini untuk frame berikutnya.
            prevModelView.set(modelView);
            prevProjection.set(projection);
            prevCameraPos.set(cameraPos);
            havePrev = true;
        }
    }

    /** ShaderManager.shouldRenderMotionBlur */
    private static boolean shouldRender(MinecraftClient client) {
        if (!MotionBlurModule.isActive() || client.world == null || MotionBlurModule.strength() <= 0.0F) {
            return false;
        }
        if (MotionBlurModule.pauseInGuis() && client.currentScreen != null) {
            return false;
        }
        if (!havePrev) {
            return false; // frame pertama: belum ada matriks sebelumnya
        }
        return client.options.getPerspective().isFirstPerson() || MotionBlurModule.renderInThirdPerson();
    }

    private static void apply(MinecraftClient client, Matrix4f modelView, Matrix4f projection,
                              Vector3f cameraPos, float deltaTick) {
        Framebuffer main = client.getFramebuffer();
        int width = main.textureWidth;
        int height = main.textureHeight;
        if (width <= 0 || height <= 0) {
            return;
        }
        ensureProcessor(client, main, width, height);
        if (processor == null || program == null) {
            return;
        }

        // Skala kekuatan terhadap refresh rate (ShaderManager.applyMotionBlur)
        updateDisplayInfo(client);
        float scaledStrength = MotionBlurModule.strength();
        if (MotionBlurModule.refreshRateScaling()) {
            float fpsOverRefresh = lastRefreshRate > 0 ? currentFps / lastRefreshRate : 1.0F;
            if (fpsOverRefresh < 1.0F) {
                fpsOverRefresh = 1.0F; // jangan melemahkan blur di bawah refresh rate
            }
            scaledStrength *= fpsOverRefresh;
            if (fpsOverRefresh > 1.0F) {
                sampleAmount = Math.min(400, (int) (100 * fpsOverRefresh));
            }
        }

        set1(program, "BlendFactor", scaledStrength);
        set2(program, "view_res", (float) width, (float) height);
        set2(program, "view_pixel_size", 1.0F / width, 1.0F / height);
        setInt(program, "motionBlurSamples", Math.max(4, sampleAmount));
        setInt(program, "blurAlgorithm", MotionBlurModule.blurAlgorithm());
        setInt(program, "useDepth", MotionBlurModule.depthBlur() ? 1 : 0);

        // ShaderManager.setFrameMotionBlur
        setMat(program, "modelView", modelView);
        setMat(program, "prevModelView", prevModelView);
        setMat(program, "projection", projection);
        setMat(program, "prevProjection", prevProjection);
        setMat(program, "projInverse", new Matrix4f(projection).invert());
        setMat(program, "mvInverse", new Matrix4f(modelView).invert());
        set3(program, "cameraPos", cameraPos.x, cameraPos.y, cameraPos.z);
        set3(program, "prevCameraPos", prevCameraPos.x, prevCameraPos.y, prevCameraPos.z);

        Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());
        var savedType = RenderSystem.getProjectionType();
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        try {
            processor.render(deltaTick);
        } finally {
            RenderSystem.enableDepthTest();
            RenderSystem.setProjectionMatrix(savedProjection, savedType);
            main.beginWrite(true);
        }
        if (!loggedFirstPass) {
            loggedFirstPass = true;
            XoldiumMod.LOGGER.info("[Xoldium] Motion blur aktif (shader natural-motionblur, {}x{}, refresh {} Hz).",
                    width, height, lastRefreshRate);
        }
    }

    private static void ensureProcessor(MinecraftClient client, Framebuffer main, int width, int height) {
        if (processor != null && builtWidth == width && builtHeight == height) {
            return;
        }
        closeProcessor();
        try {
            PostEffectProcessor created = new PostEffectProcessor(
                    client.getTextureManager(), client.getResourceManager(), main, POST_ID);
            created.setupDimensions(width, height);
            List<PostEffectPass> passes = ((PostEffectProcessorAccessor) created).xoldium$getPasses();
            if (passes.isEmpty()) {
                created.close();
                throw new IllegalStateException("post effect motion_blur tidak punya pass");
            }
            PostEffectPass blurPass = passes.get(0);
            // Pengganti "minecraft:main:depth" milik Satin: depth framebuffer utama sebagai DiffuseDepthSampler.
            blurPass.addAuxTarget("DiffuseDepthSampler", main::getDepthAttachment, width, height);
            processor = created;
            program = blurPass.getProgram();
            builtWidth = width;
            builtHeight = height;
        } catch (Throwable t) {
            runtimeFailed = true;
            processor = null;
            program = null;
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal memuat shader motion blur - fitur dimatikan untuk sesi ini (game tetap aman).", t);
        }
    }

    private static void closeProcessor() {
        if (processor != null) {
            try {
                processor.close();
            } catch (Throwable ignored) {
                // pembersihan murni.
            }
        }
        processor = null;
        program = null;
        builtWidth = -1;
        builtHeight = -1;
    }

    // ------------------------------------------------------------------ uniform helpers

    private static void set1(JsonEffectShaderProgram p, String name, float a) {
        GlUniform u = p.getUniformByNameOrDummy(name);
        u.set(a);
    }

    private static void set2(JsonEffectShaderProgram p, String name, float a, float b) {
        GlUniform u = p.getUniformByNameOrDummy(name);
        u.set(a, b);
    }

    private static void set3(JsonEffectShaderProgram p, String name, float a, float b, float c) {
        GlUniform u = p.getUniformByNameOrDummy(name);
        u.set(a, b, c);
    }

    private static void setInt(JsonEffectShaderProgram p, String name, int a) {
        GlUniform u = p.getUniformByNameOrDummy(name);
        u.set(a);
    }

    private static void setMat(JsonEffectShaderProgram p, String name, Matrix4f m) {
        GlUniform u = p.getUniformByNameOrDummy(name);
        u.set(m);
    }

    // ------------------------------------------------------------------ MonitorInfoProvider

    private static void updateDisplayInfo(MinecraftClient client) {
        long now = System.nanoTime();
        if (now - lastMonitorCheck < 1_000_000_000L) {
            return;
        }
        lastMonitorCheck = now;
        try {
            if (client.getWindow() == null) {
                return;
            }
            long window = client.getWindow().getHandle();
            long monitor = GLFW.glfwGetWindowMonitor(window);
            if (monitor == 0L) {
                monitor = monitorFromWindowPosition(window, client.getWindow().getWidth(), client.getWindow().getHeight());
            }
            if (monitor != lastMonitorHandle) {
                lastRefreshRate = refreshRateOf(monitor);
                lastMonitorHandle = monitor;
            }
        } catch (Throwable ignored) {
            // deteksi refresh rate hanya pelengkap - bertahan di nilai terakhir (60 Hz).
        }
    }

    private static long monitorFromWindowPosition(long window, int w, int h) {
        int[] wx = new int[1];
        int[] wy = new int[1];
        GLFW.glfwGetWindowPos(window, wx, wy);
        int cx = wx[0] + w / 2;
        int cy = wy[0] + h / 2;
        long result = GLFW.glfwGetPrimaryMonitor();
        PointerBuffer monitors = GLFW.glfwGetMonitors();
        if (monitors != null) {
            for (int i = 0; i < monitors.limit(); i++) {
                long m = monitors.get(i);
                int[] mx = new int[1];
                int[] my = new int[1];
                GLFW.glfwGetMonitorPos(m, mx, my);
                GLFWVidMode mode = GLFW.glfwGetVideoMode(m);
                if (mode == null) {
                    continue;
                }
                if (cx >= mx[0] && cx < mx[0] + mode.width() && cy >= my[0] && cy < my[0] + mode.height()) {
                    result = m;
                    break;
                }
            }
        }
        return result;
    }

    private static int refreshRateOf(long monitor) {
        if (monitor == 0L) {
            return 60;
        }
        GLFWVidMode mode = GLFW.glfwGetVideoMode(monitor);
        return mode != null && mode.refreshRate() > 0 ? mode.refreshRate() : 60;
    }
}

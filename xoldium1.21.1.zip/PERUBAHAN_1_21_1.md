# Xoldium Client - Port ke Minecraft 1.21.1

Tampilan/GUI/fitur sama dengan versi 1.21.4/1.21.11.

## Build
`gradle.properties`: minecraft 1.21.1, yarn 1.21.1+build.3, fabric-api 0.107.0+1.21.1, modmenu 11.0.3, loader 0.16.14.
Jalankan `./gradlew build` (JDK 21 + internet) -> jar di `build/libs/xoldiummod-1.0.0.jar` (bukan yang `-sources`).

## Title screen & pause menu
`XoldiumScreenHooks` (Fabric `ScreenEvents.AFTER_INIT`, tanpa mixin):
- Title: tombol **Mod Menu / HUD Editor / Settings** di kiri, lencana akun (kepala skin + nama) kanan-atas.
- Pause: tombol **XoldiumClient - HUD Editor** tepat di bawah Disconnect + lencana akun.

## Zoom = Ok Zoomer 10.0.0-beta.6 (versi 1.21.1)
Port `ManageZoomEvent` (Hold/Toggle/Persistent), `ManageExtraKeysEvent`, `ZoomUtils` (langkah scroll, unbind
Save Toolbar), transisi Instant/Smooth/Linear, `ZoomDivisorMouseModifier`, pengurang view bobbing.
Default sama dengan `OkZoomerConfig`: divisor 4, min 1, max 50, 5 langkah bawah, 10 atas, smooth 0.6, linear 0.16-0.22.
Hook: `ZoomFovMixin` (GameRenderer#getFov, double), `ZoomInputMixin`, `ZoomLookMixin`, `ZoomBobMixin`. Tombol: C.

## Motion Blur = natural-motionblur (shader asli)
Shader `motion_blur.fsh` + JSON dibawa apa adanya (namespace `xoldiummod`). Tanpa library Satin: efek dimuat lewat
`PostEffectProcessor` vanilla, depth dipasang lewat `PostEffectPass#addAuxTarget` (`PostEffectProcessorAccessor`),
matriks dari `WorldRenderEvents.END`. Setting: strength, refresh rate scaling, depth blur, algoritma, F5.

## Perubahan API 1.21.4 -> 1.21.1
- `drawTexture(RenderLayer::getGuiTextured, ...)` -> `drawTexture(Identifier, x, y, w, h, u, v, rw, rh, tw, th)`.
- `GameRenderer#getFov` mengembalikan `double`.
- `LivingEntityRenderer#hasLabel(LivingEntity)` (tanpa parameter jarak).

## Catatan jujur
BELUM bisa di-compile di lingkungan pembuatan (tanpa internet). Hanya lolos pengecekan sintaks Java + JSON valid.
Semua mixin memakai `require = 0` (kegagalan satu mixin hanya mematikan fitur itu, tidak crash); motion blur dibungkus
try/catch. Cek `latest.log` untuk baris `[Xoldium]` bila ada fitur yang tidak jalan.

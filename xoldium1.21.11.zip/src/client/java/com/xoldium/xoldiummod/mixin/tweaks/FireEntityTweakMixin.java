package com.xoldium.xoldiummod.mixin.tweaks;

import com.xoldium.xoldiummod.client.module.tweaks.TweaksModule;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.FireCommandRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.texture.AtlasManager;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Fire Overlay (bagian entitas): skala api pada entitas yang terbakar - sama dengan FireEntityMixin PvP Tweaks. */
@Mixin(FireCommandRenderer.class)
public abstract class FireEntityTweakMixin {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void xoldium$scaleEntityFire(MatrixStack.Entry matricesEntry, VertexConsumerProvider vertexConsumers,
                                         EntityRenderState renderState, Quaternionf rotation,
                                         AtlasManager atlasManager, CallbackInfo ci) {
        if (!TweaksModule.FireOverlay.active()) {
            return;
        }
        float scale = TweaksModule.FireOverlay.entityScale();
        if (scale != 1.0f) {
            matricesEntry.scale(scale, scale, scale);
        }
    }
}

package com.xoldium.xoldiummod.mixin.hud;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Membaca FPS asli dari engine ({@code MinecraftClient#currentFps}) - cara yang sama dengan mod FPS Display
 * (grayray75). Didaftarkan di {@code xoldiummod-safe.mixins.json} (required=false): bila gagal diterapkan,
 * {@code FpsModule} otomatis memakai penghitung frame sendiri sebagai cadangan, bukan crash.
 */
@Mixin(MinecraftClient.class)
public interface MinecraftClientFpsAccessor {
    @Accessor("currentFps")
    int xoldium$getCurrentFps();
}

package com.xoldium.xoldiummod.mixin.visual;

import com.xoldium.xoldiummod.client.module.visual.XoldiumCapeModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook cape Xoldium: setelah vanilla selesai mengisi state render pemain
 * ({@code updateRenderState}), ganti cape-nya bila pemain itu pengguna Xoldium
 * (diri sendiri atau pemain lain yang terdeteksi). TAIL + {@code require = 0}:
 * bila method tidak ditemukan, cape vanilla tetap tampil (tidak crash).
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class XoldiumCapeMixin {

    @Inject(method = "updateRenderState(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL"), require = 0)
    private void xoldium$applyCape(AbstractClientPlayerEntity player, PlayerEntityRenderState state, float tickProgress,
                                   CallbackInfo ci) {
        try {
            XoldiumCapeModule.apply(state, player);
        } catch (Throwable ignored) {
            // jangan pernah melempar ke render loop
        }
    }
}

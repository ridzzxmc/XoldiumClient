package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Potion HUD bergaya foto referensi pemakai:
 * <ul>
 *   <li><b>Tiles</b> (default): ubin gelap membulat berisi ikon efek dengan
 *       level kecil di pojok kanan-atas, bar sisa durasi tipis di kiri, dan pil
 *       waktu (mm:ss) di kanan.</li>
 *   <li><b>List</b>: baris [ikon] + nama, level, waktu (gaya lama).</li>
 * </ul>
 * Ikon efek diambil dari {@code textures/mob_effect/<id>.png} (lihat catatan di
 * versi sebelumnya: tidak memakai StatusEffectSpriteManager karena bentuk API
 * render-nya berubah antar rilis). Bar durasi memakai durasi TERBESAR yang
 * pernah terlihat untuk efek itu sebagai 100% (klien tidak diberi durasi awal).
 */
public final class PotionHudModule extends HudModule {

    private final ModeSetting style = addSetting(new ModeSetting("style", "setting.xoldiummod.potion_hud.style", 0,
            "setting.xoldiummod.potion_hud.style.tiles", "setting.xoldiummod.potion_hud.style.list"));

    private final Map<Identifier, Integer> maxSeen = new HashMap<>();

    public PotionHudModule() {
        super("potion_hud", "module.xoldiummod.potion_hud", false, 4f, 200f, 0.0);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        List<StatusEffectInstance> instances = new ArrayList<>(client.player.getStatusEffects());
        if (instances.isEmpty()) {
            maxSeen.clear();
            return;
        }
        draw(context, client.textRenderer, instances);
    }

    private void draw(DrawContext context, TextRenderer tr, List<StatusEffectInstance> instances) {
        boolean tiles = style.index() == 0;
        int rowH = tiles ? 24 : 18;

        List<String> labels = new ArrayList<>(instances.size());
        List<Identifier> icons = new ArrayList<>(instances.size());
        List<Float> fractions = new ArrayList<>(instances.size());
        int textW = 0;
        for (StatusEffectInstance instance : instances) {
            Identifier id = effectId(instance);
            int dur = instance.getDuration();
            if (id != null) {
                int seen = maxSeen.getOrDefault(id, 0);
                if (dur > seen) {
                    seen = dur;
                    maxSeen.put(id, seen);
                }
                fractions.add(seen <= 0 || dur < 0 ? 1f : Math.max(0f, Math.min(1f, dur / (float) seen)));
            } else {
                fractions.add(1f);
            }
            String label = tiles ? time(instance) : name(instance) + " " + (instance.getAmplifier() + 1) + " (" + time(instance) + ")";
            labels.add(label);
            icons.add(iconFor(id));
            textW = Math.max(textW, tr.getWidth(label));
        }
        int rawWidth = tiles ? (3 + 22 + 3 + textW + 8) : (2 + 16 + 4 + textW + 6);
        int rawHeight = rowH * instances.size() + (tiles ? 0 : 2);
        setMeasuredSize(rawWidth, rawHeight);

        int bg = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0) << 24;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        if (!tiles && (bg >>> 24) > 0) {
            ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, bg);
        }

        int rowY = tiles ? 0 : 1;
        for (int i = 0; i < instances.size(); i++) {
            Identifier icon = icons.get(i);
            if (tiles) {
                float frac = fractions.get(i);
                int barH = Math.max(1, Math.round(20f * frac));
                int barColor = frac > 0.5f ? 0xFF55FF55 : frac > 0.2f ? 0xFFFFAA33 : 0xFFFF5555;
                context.fill(0, rowY + 1, 2, rowY + 21, 0x66000000);
                context.fill(0, rowY + 21 - barH, 2, rowY + 21, barColor);
                ScreenChrome.roundedFill(context, 3, rowY, 25, rowY + 22, 0xB0101014);
                ScreenChrome.roundedBorder(context, 3, rowY, 25, rowY + 22, 0x40FFFFFF);
                if (icon != null) {
                    context.drawTexture(icon, 6, rowY + 3, 16, 16, 0f, 0f, 16, 16, 16, 16);
                }
                // level kecil di pojok kanan-atas ubin
                String level = String.valueOf(instances.get(i).getAmplifier() + 1);
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(24 - tr.getWidth(level) * 0.6f, rowY + 2);
                context.getMatrices().scale(0.6f, 0.6f);
                context.drawText(tr, level, 0, 0, 0xFFFFFFFF, true);
                context.getMatrices().popMatrix();
                // pil waktu
                int pillX = 28;
                int pillW = textW + 8;
                ScreenChrome.roundedFill(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0xB0101014);
                ScreenChrome.roundedBorder(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0x30FFFFFF);
                context.drawText(tr, labels.get(i), pillX + 4, rowY + 7, 0xFFFFFFFF, true);
            } else {
                if (icon != null) {
                    context.drawTexture(icon, 2, rowY, 16, 16, 0f, 0f, 16, 16, 16, 16);
                }
                context.drawText(tr, labels.get(i), 2 + 16 + 4, rowY + (16 - tr.fontHeight) / 2, 0xFFFFFFFF, true);
            }
            rowY += rowH;
        }
        context.getMatrices().popMatrix();
    }

    private static String name(StatusEffectInstance instance) {
        return instance.getEffectType().value().getName().getString();
    }

    private static String time(StatusEffectInstance instance) {
        if (instance.isInfinite()) {
            return "**:**";
        }
        int seconds = Math.max(0, instance.getDuration() / 20);
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    private static Identifier effectId(StatusEffectInstance instance) {
        try {
            return Registries.STATUS_EFFECT.getId(instance.getEffectType().value());
        } catch (Throwable t) {
            return null;
        }
    }

    private static Identifier iconFor(Identifier id) {
        return id == null ? null : Identifier.of(id.getNamespace(), "textures/mob_effect/" + id.getPath() + ".png");
    }
}

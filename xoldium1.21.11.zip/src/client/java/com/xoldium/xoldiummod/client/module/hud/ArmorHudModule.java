package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Armor HUD bergaya foto referensi pemakai:
 * <ul>
 *   <li><b>Icons</b> (default, foto 1): baris [ikon item] + persen durabilitas
 *       berwarna (hijau &rarr; kuning &rarr; merah), tanpa kotak latar.</li>
 *   <li><b>Tiles</b> (foto 2): ubin gelap membulat berisi ikon item, bar
 *       durabilitas tipis di kiri ubin, dan pil angka persen di kanan.</li>
 * </ul>
 * Item di tangan (pedang dsb) bisa ikut ditampilkan. Ikon diambil dari item
 * aslinya lewat {@code DrawContext#drawItem}, jadi armor custom server tetap
 * punya ikon.
 */
public final class ArmorHudModule extends HudModule {

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private final ModeSetting style = addSetting(new ModeSetting("style", "setting.xoldiummod.armor_hud.style", 0,
            "setting.xoldiummod.armor_hud.style.icons", "setting.xoldiummod.armor_hud.style.tiles"));
    private final BooleanSetting showHeld = addSetting(new BooleanSetting("show_held",
            "setting.xoldiummod.armor_hud.show_held", true));

    public ArmorHudModule() {
        super("armor_hud", "module.xoldiummod.armor_hud", false, 4f, 164f, 0.0);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        List<ItemStack> stacks = new ArrayList<>(5);
        if (showHeld.get()) {
            ItemStack held = client.player.getMainHandStack();
            if (!held.isEmpty() && held.isDamageable()) {
                stacks.add(held);
            }
        }
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                stacks.add(stack);
            }
        }
        draw(context, client.textRenderer, stacks);
    }

    @Override
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        List<ItemStack> sample = new ArrayList<>();
        sample.add(new ItemStack(net.minecraft.item.Items.NETHERITE_SWORD));
        sample.add(new ItemStack(net.minecraft.item.Items.NETHERITE_HELMET));
        sample.add(new ItemStack(net.minecraft.item.Items.NETHERITE_CHESTPLATE));
        sample.add(new ItemStack(net.minecraft.item.Items.NETHERITE_LEGGINGS));
        sample.add(new ItemStack(net.minecraft.item.Items.NETHERITE_BOOTS));
        draw(context, client.textRenderer, sample);
    }

    private void draw(DrawContext context, TextRenderer tr, List<ItemStack> stacks) {
        boolean tiles = style.index() == 1;
        int rowH = tiles ? 24 : 18;

        if (stacks.isEmpty()) {
            setMeasuredSize(60, 12);
            return;
        }

        List<String> labels = new ArrayList<>(stacks.size());
        int textW = 0;
        for (ItemStack stack : stacks) {
            String label = percent(stack) + "%";
            labels.add(label);
            textW = Math.max(textW, tr.getWidth(label));
        }
        int rawWidth = tiles ? (3 + 22 + 3 + textW + 10) : (2 + 16 + 4 + textW + 2);
        int rawHeight = rowH * stacks.size();
        setMeasuredSize(rawWidth, rawHeight);

        int bg = (int) Math.round(Math.max(0.0, Math.min(1.0, backgroundOpacity())) * 255.0) << 24;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        if (!tiles && (bg >>> 24) > 0) {
            ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, bg);
        }

        int rowY = 0;
        for (int i = 0; i < stacks.size(); i++) {
            ItemStack stack = stacks.get(i);
            int pct = percent(stack);
            int color = colorFor(pct);
            if (tiles) {
                // bar durabilitas tipis
                int barH = Math.max(1, Math.round(20f * pct / 100f));
                context.fill(0, rowY + 1, 2, rowY + 21, 0x66000000);
                context.fill(0, rowY + 21 - barH, 2, rowY + 21, color);
                // ubin ikon
                ScreenChrome.roundedFill(context, 3, rowY, 25, rowY + 22, 0xB0101014);
                ScreenChrome.roundedBorder(context, 3, rowY, 25, rowY + 22, 0x40FFFFFF);
                context.drawItem(stack, 6, rowY + 3);
                // pil angka
                int pillX = 28;
                int pillW = textW + 8;
                ScreenChrome.roundedFill(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0xB0101014);
                ScreenChrome.roundedBorder(context, pillX, rowY + 4, pillX + pillW, rowY + 18, 0x30FFFFFF);
                context.drawText(tr, labels.get(i), pillX + 4, rowY + 7, color, true);
            } else {
                context.drawItem(stack, 2, rowY + 1);
                context.drawText(tr, labels.get(i), 2 + 16 + 4, rowY + 1 + (16 - tr.fontHeight) / 2, color, true);
            }
            rowY += rowH;
        }
        context.getMatrices().popMatrix();
    }

    private static int percent(ItemStack stack) {
        if (stack.isDamageable() && stack.getMaxDamage() > 0) {
            return Math.max(0, Math.min(100, Math.round(100f * (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage())));
        }
        return 100;
    }

    private static int colorFor(int pct) {
        if (pct >= 60) return 0xFF55FF55;
        if (pct >= 30) return 0xFFFFFF55;
        return 0xFFFF5555;
    }
}

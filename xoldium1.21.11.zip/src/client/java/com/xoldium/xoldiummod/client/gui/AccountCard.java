package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;

/**
 * Kartu akun di pause menu (meniru Aurora Client): kiri = kepala skin + nama
 * pemain + lencana "Beta"; kanan = alamat server, bar sinyal + ping (ms) dan
 * jumlah pemain online. Singleplayer menampilkan "Singleplayer" tanpa ping.
 */
public final class AccountCard {

    public static final int HEIGHT = 36;

    private static final Anim.Timeline SHOWN = new Anim.Timeline(420f);

    private AccountCard() {
    }

    public static void render(DrawContext context, TextRenderer tr, int x1, int x2, int y) {
        float a = Anim.easeOutCubic(SHOWN.progress());
        int slide = Math.round((1f - a) * 8f);
        int top = y - slide;
        int bottom = top + HEIGHT;

        ScreenChrome.roundedFill(context, x1, top, x2, bottom, Anim.withAlpha(0xD0101012, a));
        ScreenChrome.roundedBorder(context, x1, top, x2, bottom, Anim.withAlpha(0x60FFFFFF, a));

        // --- kiri: kepala + nama + Beta
        String name = AccountBadge.username();
        int face = 24;
        int fx = x1 + 6;
        int fy = top + (HEIGHT - face) / 2;
        if (!AccountBadge.drawHead(context, fx, fy, face)) {
            int color = 0xFF000000 | (name.hashCode() & 0x00FFFFFF) | 0x00404040;
            context.fill(fx, fy, fx + face, fy + face, Anim.withAlpha(color, a));
        }
        int nx = fx + face + 6;
        var nameText = XoldiumFonts.bold(name);
        context.drawText(tr, nameText, nx, top + 7, Anim.withAlpha(0xFFFFFFFF, a), true);
        // lencana Beta
        String beta = "Beta";
        int bw = tr.getWidth(beta) + 12;
        int by = top + 20;
        ScreenChrome.roundedFill(context, nx, by, nx + bw, by + 10, Anim.withAlpha(0x40FFFFFF, a));
        context.fill(nx + 3, by + 4, nx + 6, by + 7, Anim.withAlpha(0xFF8F7BFF, a));
        context.drawText(tr, beta, nx + 8, by + 1, Anim.withAlpha(0xFFDDDDDD, a), false);

        // --- pemisah + kanan: server / ping / online
        int leftEnd = nx + Math.max(bw, tr.getWidth(nameText)) + 6;
        int splitX = Math.max(leftEnd, x1 + (x2 - x1) * 52 / 100);
        context.fill(splitX, top + 6, splitX + 1, bottom - 6, Anim.withAlpha(0x40FFFFFF, a));

        MinecraftClient client = MinecraftClient.getInstance();
        ServerInfo info = client.getCurrentServerEntry();
        int rx = splitX + 8;
        int maxW = x2 - rx - 4;
        if (info == null) {
            context.drawText(tr, "Singleplayer", rx, top + (HEIGHT - tr.fontHeight) / 2,
                    Anim.withAlpha(0xFFCCCCCC, a), false);
            return;
        }
        String address = info.address == null ? "?" : info.address;
        if (tr.getWidth(address) > maxW) {
            address = tr.trimToWidth(address, Math.max(8, maxW - tr.getWidth(".."))) + "..";
        }
        context.drawText(tr, address, rx, top + 8, Anim.withAlpha(0xFFFFFFFF, a), false);

        int ping = -1;
        int online = 0;
        if (client.getNetworkHandler() != null) {
            online = client.getNetworkHandler().getPlayerList().size();
            if (client.player != null) {
                PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
                if (entry != null) {
                    ping = entry.getLatency();
                }
            }
        }
        int row = top + 21;
        int pingColor = ping < 0 ? 0xFF888888 : ping < 80 ? 0xFF55FF55 : ping < 160 ? 0xFFFFFF55 : 0xFFFF5555;
        int bars = ping < 0 ? 0 : ping < 60 ? 4 : ping < 120 ? 3 : ping < 200 ? 2 : 1;
        for (int i = 0; i < 4; i++) {
            int bh = 2 + i * 2;
            int bx = rx + i * 3;
            int c = i < bars ? pingColor : 0xFF444444;
            context.fill(bx, row + 8 - bh, bx + 2, row + 8, Anim.withAlpha(c, a));
        }
        String pingText = ping < 0 ? "-- ms" : ping + " ms";
        int tx = rx + 16;
        context.drawText(tr, pingText, tx, row, Anim.withAlpha(0xFFCCCCCC, a), false);
        context.drawText(tr, online + " online", tx + tr.getWidth(pingText) + 8, row, Anim.withAlpha(0xFFAAAAAA, a), false);
    }
}

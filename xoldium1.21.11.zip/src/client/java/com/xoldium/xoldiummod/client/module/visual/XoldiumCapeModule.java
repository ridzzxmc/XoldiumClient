package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.util.RecordUtil;
import com.xoldium.xoldiummod.client.util.XoldiumUsers;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Xoldium Cape - setiap pengguna XoldiumClient mendapat cape Xoldium (logo X),
 * dan sesama pengguna Xoldium saling melihatnya ({@link XoldiumUsers}).
 * Tekstur: {@code assets/xoldiummod/textures/cape/xoldium_cape.png} (1024x512).
 *
 * <ul>
 *   <li><b>Penggantian cape:</b> setelah vanilla mengisi state render pemain,
 *       {@code XoldiumCapeMixin} memanggil {@link #apply}; bagian "cape" pada
 *       SkinTextures di state itu diganti tekstur Xoldium (skin asli tidak
 *       disentuh). Berlaku bagi diri sendiri dan pemain yang terdeteksi
 *       sebagai pengguna Xoldium.</li>
 *   <li><b>Cape tetap tampil saat memakai chestplate:</b> vanilla menyembunyikan
 *       cape bila ada chestplate. {@code CapeChestMixin} mengosongkan slot
 *       chestplate di state HANYA selama fitur cape dirender lalu
 *       mengembalikannya (armor tetap tampil normal), dan menggeser cape sedikit
 *       ke belakang agar tidak menembus armor.</li>
 * </ul>
 *
 * <p>Semua refleksi memakai URUTAN & TIPE komponen (bukan nama): di game asli
 * (1.21.11 masih ter-obfuscate) nama method/field adalah nama intermediary.
 * Bila struktur tidak sesuai dugaan, fitur yang bersangkutan mati sendiri dengan
 * satu baris log - tidak pernah melempar exception ke render loop.
 */
public final class XoldiumCapeModule extends Module {

    private static final Identifier CAPE_ID = Identifier.of("xoldiummod", "cape/xoldium_cape");
    private static final Identifier CAPE_PATH = Identifier.of("xoldiummod", "textures/cape/xoldium_cape.png");

    private static XoldiumCapeModule instance;
    private static boolean capeBroken = false;
    private static boolean chestBroken = false;

    private final BooleanSetting showWithChestplate = addSetting(new BooleanSetting("show_with_chestplate",
            "setting.xoldiummod.cape.show_with_chestplate", true));
    private final BooleanSetting shareStatus = addSetting(new BooleanSetting("share_status",
            "setting.xoldiummod.cape.share_status", true));

    /** Cache: SkinTextures asli -> hasil rakitan (LRU kecil; record punya equals/hashCode berbasis nilai). */
    private static final Map<Object, Object> CACHE = new LinkedHashMap<>(32, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Object, Object> eldest) {
            return size() > 64;
        }
    };

    private static Field cachedSkinField;
    private static Field cachedChestField;
    private static boolean chestResolved = false;

    public XoldiumCapeModule() {
        super("xoldium_cape", "module.xoldiummod.xoldium_cape", ModuleCategory.VISUAL, true);
        instance = this;
        XoldiumUsers.setShareEnabled(shareStatus.get());
    }

    @Override
    public void onClientTick() {
        XoldiumUsers.setShareEnabled(shareStatus.get());
    }

    public static boolean active() {
        return instance != null && instance.isEnabled();
    }

    // ------------------------------------------------------------------
    // Ganti cape
    // ------------------------------------------------------------------

    /** Ganti cape pada state render pemain bila pemain itu pengguna Xoldium. Aman dipanggil tiap frame. */
    public static void apply(Object state, AbstractClientPlayerEntity player) {
        if (!active() || capeBroken || state == null || !XoldiumUsers.isUser(player)) {
            return;
        }
        try {
            Field skinField = skinField(state.getClass());
            if (skinField == null) {
                failCape("field SkinTextures tidak ditemukan di state render pemain");
                return;
            }
            Object original = skinField.get(state);
            if (original == null) {
                return;
            }
            Object result = CACHE.get(original);
            if (result == null) {
                result = rebuild(original);
                if (result == null) {
                    return;
                }
                CACHE.put(original, result);
            }
            skinField.set(state, result);
        } catch (Throwable t) {
            capeBroken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Cape dinonaktifkan karena error (client tetap normal).", t);
        }
    }

    private static Field skinField(Class<?> stateClass) {
        if (cachedSkinField != null) {
            return cachedSkinField;
        }
        // SkinTextures = satu-satunya field record bertipe record dengan 5 komponen (3 aset sejenis, model, secure)
        for (Class<?> c = stateClass; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && isSkinTexturesClass(f.getType())) {
                    f.setAccessible(true);
                    cachedSkinField = f;
                    return f;
                }
            }
        }
        return null;
    }

    private static boolean isSkinTexturesClass(Class<?> c) {
        if (!c.isRecord()) {
            return false;
        }
        RecordComponent[] comps = c.getRecordComponents();
        if (comps.length != 5) {
            return false;
        }
        int[] same = RecordUtil.indicesOfType(c, comps[0].getType());
        boolean hasBoolean = false;
        boolean hasEnum = false;
        for (RecordComponent rc : comps) {
            if (rc.getType() == boolean.class) hasBoolean = true;
            if (rc.getType().isEnum()) hasEnum = true;
        }
        return same.length == 3 && hasBoolean && hasEnum && !comps[0].getType().isPrimitive();
    }

    /** SkinTextures baru = salinan {@code original} dengan aset cape (aset sejenis ke-2) diganti tekstur Xoldium. */
    private static Object rebuild(Object original) throws Throwable {
        Class<?> skinClass = original.getClass();
        int[] assets = RecordUtil.indicesOfType(skinClass, skinClass.getRecordComponents()[0].getType());
        if (assets.length != 3) {
            failCape("struktur SkinTextures tidak sesuai dugaan");
            return null;
        }
        Object body = RecordUtil.get(original, assets[0]);
        if (body == null) {
            return null; // skin belum siap
        }
        Object capeAsset = makeAsset(body.getClass());
        if (capeAsset == null) {
            return null;
        }
        return RecordUtil.copyWith(original, assets[1], capeAsset);
    }

    /** Aset tekstur (record dengan 1-2 Identifier: [id,] texturePath) yang menunjuk ke cape Xoldium. */
    private static Object makeAsset(Class<?> sampleClass) throws Throwable {
        if (!sampleClass.isRecord()) {
            failCape("aset tekstur bukan record");
            return null;
        }
        RecordComponent[] comps = sampleClass.getRecordComponents();
        Class<?>[] types = new Class<?>[comps.length];
        Object[] args = new Object[comps.length];
        for (int i = 0; i < comps.length; i++) {
            types[i] = comps[i].getType();
            if (types[i] != Identifier.class) {
                failCape("komponen aset bukan Identifier");
                return null;
            }
            args[i] = i == comps.length - 1 ? CAPE_PATH : CAPE_ID; // terakhir = texturePath
        }
        if (comps.length < 1 || comps.length > 2) {
            failCape("jumlah komponen aset tak dikenal");
            return null;
        }
        Constructor<?> ctor = sampleClass.getDeclaredConstructor(types);
        ctor.setAccessible(true);
        return ctor.newInstance(args);
    }

    /** Apakah state ini sedang memakai cape Xoldium (hasil {@link #apply})? */
    public static boolean hasXoldiumCape(Object state) {
        if (!active() || capeBroken || state == null) {
            return false;
        }
        try {
            Field f = skinField(state.getClass());
            if (f == null) {
                return false;
            }
            Object skin = f.get(state);
            if (skin == null) {
                return false;
            }
            int[] assets = RecordUtil.indicesOfType(skin.getClass(), skin.getClass().getRecordComponents()[0].getType());
            if (assets.length != 3) {
                return false;
            }
            Object cape = RecordUtil.get(skin, assets[1]);
            if (cape == null || !cape.getClass().isRecord()) {
                return false;
            }
            RecordComponent[] cc = cape.getClass().getRecordComponents();
            return RecordUtil.get(cape, cc.length - 1) instanceof Identifier id && id.equals(CAPE_PATH);
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // Cape + chestplate
    // ------------------------------------------------------------------

    /**
     * Kosongkan slot chestplate pada state selama fitur cape dirender. Mengembalikan
     * nilai lama (untuk {@link #restoreChest}) atau null bila tidak ada yang diubah
     * (fitur mati, bukan cape Xoldium, atau tidak sedang memakai chestplate).
     */
    public static Object[] hideChest(Object state) {
        if (!active() || chestBroken || !instance.showWithChestplate.get() || !hasXoldiumCape(state)) {
            return null;
        }
        try {
            Field f = chestField(state.getClass());
            if (f == null) {
                return null;
            }
            Object old = f.get(state);
            if (!(old instanceof ItemStack stack) || stack.isEmpty()) {
                return null;
            }
            f.set(state, ItemStack.EMPTY);
            return new Object[]{f, old};
        } catch (Throwable t) {
            chestBroken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Cape+chestplate dinonaktifkan karena error (client tetap normal).", t);
            return null;
        }
    }

    public static void restoreChest(Object state, Object[] saved) {
        if (saved == null) {
            return;
        }
        try {
            ((Field) saved[0]).set(state, saved[1]);
        } catch (Throwable t) {
            chestBroken = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Gagal mengembalikan slot chestplate di state render.", t);
        }
    }

    /**
     * Field ItemStack "chestplate" pada state: state armor memiliki tepat 4 field ItemStack
     * berurutan kepala, DADA, kaki, sepatu - diambil yang ke-2. Jika jumlahnya bukan 4,
     * fitur dimatikan (lebih baik cape tersembunyi di balik chestplate daripada salah ambil slot).
     */
    private static Field chestField(Class<?> stateClass) {
        if (chestResolved) {
            return cachedChestField;
        }
        chestResolved = true;
        for (Class<?> c = stateClass; c != null && c != Object.class; c = c.getSuperclass()) {
            List<Field> stacks = new ArrayList<>();
            for (Field f : c.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && f.getType() == ItemStack.class) {
                    stacks.add(f);
                }
            }
            if (stacks.size() == 4) {
                Field chest = stacks.get(1);
                chest.setAccessible(true);
                cachedChestField = chest;
                return chest;
            }
        }
        chestBroken = true;
        XoldiumMod.LOGGER.warn("[Xoldium] Cape+chestplate: struktur slot armor di state tidak sesuai dugaan (dimatikan).");
        return null;
    }

    private static void failCape(String reason) {
        capeBroken = true;
        XoldiumMod.LOGGER.warn("[Xoldium] Cape tidak bisa dipasang: {} (modul dinonaktifkan, client tetap normal).", reason);
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.Anim;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Keystrokes - susunan mengikuti foto referensi: W di atas, baris A-S-D, batang spasi (bergaris) lebar
 * penuh, lalu LMB / RMB + CPS. Kotak rapat dengan jarak tipis. Tiap tombol memudar halus saat
 * ditekan/dilepas. Semua warna (kotak, kotak ditekan, teks, teks ditekan, outline), opasitas, jarak,
 * bayangan teks, dan bagian mana yang tampil (spasi, mouse, CPS) bisa diatur di setting modul.
 * "Background Opacity" bawaan modul HUD = panel latar di belakang seluruh keystrokes (default 0 = tanpa panel).
 */
public final class KeystrokesModule extends HudModule {

    private static final int BOX = 20;
    private static final int SPACE_HEIGHT = 9;

    private final ColorSetting keyColor = addSetting(
            new ColorSetting("key_color", "setting.xoldiummod.keystrokes.key_color", 0xFF000000, false));
    private final DoubleSetting keyOpacity = addSetting(
            new DoubleSetting("key_opacity", "setting.xoldiummod.keystrokes.key_opacity", 0.55, 0.0, 1.0, 0.05));
    private final ColorSetting pressedColor = addSetting(
            new ColorSetting("pressed_color", "setting.xoldiummod.keystrokes.pressed_color", 0xFFFFFFFF, false));
    private final DoubleSetting pressedOpacity = addSetting(
            new DoubleSetting("pressed_opacity", "setting.xoldiummod.keystrokes.pressed_opacity", 0.85, 0.0, 1.0, 0.05));
    private final ColorSetting textColor = addSetting(
            new ColorSetting("text_color", "setting.xoldiummod.keystrokes.text_color", 0xFFFFFFFF, false));
    private final ColorSetting pressedTextColor = addSetting(
            new ColorSetting("pressed_text_color", "setting.xoldiummod.keystrokes.pressed_text_color", 0xFF000000, false));
    private final BooleanSetting outline = addSetting(
            new BooleanSetting("outline", "setting.xoldiummod.keystrokes.outline", false));
    private final ColorSetting outlineColor = addSetting(
            new ColorSetting("outline_color", "setting.xoldiummod.keystrokes.outline_color", 0xFFFFFFFF, false),
            outline::get);
    private final DoubleSetting spacing = addSetting(
            new DoubleSetting("spacing", "setting.xoldiummod.keystrokes.spacing", 2.0, 0.0, 6.0, 1.0));
    private final BooleanSetting textShadow = addSetting(
            new BooleanSetting("text_shadow", "setting.xoldiummod.keystrokes.text_shadow", true));
    private final BooleanSetting showSpace = addSetting(
            new BooleanSetting("show_space", "setting.xoldiummod.keystrokes.show_space", true));
    private final BooleanSetting showMouse = addSetting(
            new BooleanSetting("show_mouse", "setting.xoldiummod.keystrokes.show_mouse", true));
    private final BooleanSetting showCps = addSetting(
            new BooleanSetting("show_cps", "setting.xoldiummod.keystrokes.show_cps", true),
            showMouse::get);

    private final Map<String, Anim.Smooth> fades = new HashMap<>();
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeft;
    private boolean wasRight;

    public KeystrokesModule() {
        super("keystrokes", "module.xoldiummod.keystrokes", false, 4f, 4f, 0.0);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        boolean l = client.options.attackKey.isPressed();
        if (l && !wasLeft) {
            leftClicks.addLast(now);
        }
        wasLeft = l;
        boolean r = client.options.useKey.isPressed();
        if (r && !wasRight) {
            rightClicks.addLast(now);
        }
        wasRight = r;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) {
            leftClicks.pollFirst();
        }
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) {
            rightClicks.pollFirst();
        }
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        var o = client.options;
        TextRenderer tr = client.textRenderer;

        int gap = (int) Math.round(spacing.get());
        int step = BOX + gap;
        int gridWidth = BOX * 3 + gap * 2;
        boolean space = showSpace.get();
        boolean mouse = showMouse.get();

        int spaceY = step * 2;
        int mouseY = spaceY + (space ? SPACE_HEIGHT + gap : 0);
        int totalHeight = mouse ? mouseY + BOX : (space ? spaceY + SPACE_HEIGHT : spaceY - gap);
        setMeasuredSize(gridWidth, totalHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);

        // panel latar opsional di belakang seluruh keystrokes
        int panelAlpha = (int) Math.round(backgroundOpacity() * 255.0);
        if (panelAlpha > 0) {
            context.fill(-2, -2, gridWidth + 2, totalHeight + 2, (Math.min(255, panelAlpha) << 24));
        }

        drawKey(context, tr, step, 0, BOX, BOX, o.forwardKey, "W", null);
        drawKey(context, tr, 0, step, BOX, BOX, o.leftKey, "A", null);
        drawKey(context, tr, step, step, BOX, BOX, o.backKey, "S", null);
        drawKey(context, tr, step * 2, step, BOX, BOX, o.rightKey, "D", null);
        if (space) {
            drawKey(context, tr, 0, spaceY, gridWidth, SPACE_HEIGHT, o.jumpKey, "SPACE", null);
        }
        if (mouse) {
            int mouseW = (gridWidth - gap) / 2;
            boolean cps = showCps.get();
            drawKey(context, tr, 0, mouseY, mouseW, BOX, o.attackKey, "LMB",
                    cps ? leftClicks.size() + " CPS" : null);
            drawKey(context, tr, mouseW + gap, mouseY, gridWidth - mouseW - gap, BOX, o.useKey, "RMB",
                    cps ? rightClicks.size() + " CPS" : null);
        }
        context.getMatrices().popMatrix();
    }

    private void drawKey(DrawContext context, TextRenderer tr, int bx, int by, int bw, int bh, KeyBinding binding,
                         String label, String sub) {
        boolean pressed = binding.isPressed();
        float f = fades.computeIfAbsent(label, k -> new Anim.Smooth(0f, 18f)).update(pressed ? 1f : 0f);

        int base = argb(keyColor.get(), keyOpacity.get());
        int down = argb(pressedColor.get(), pressedOpacity.get());
        context.fill(bx, by, bx + bw, by + bh, Anim.lerpColor(base, down, f));

        if (outline.get()) {
            int oc = 0xFF000000 | (outlineColor.get() & 0xFFFFFF);
            context.fill(bx, by, bx + bw, by + 1, oc);
            context.fill(bx, by + bh - 1, bx + bw, by + bh, oc);
            context.fill(bx, by + 1, bx + 1, by + bh - 1, oc);
            context.fill(bx + bw - 1, by + 1, bx + bw, by + bh - 1, oc);
        }

        int text = Anim.lerpColor(0xFF000000 | (textColor.get() & 0xFFFFFF),
                0xFF000000 | (pressedTextColor.get() & 0xFFFFFF), f);
        boolean shadow = textShadow.get() && f < 0.5f;

        if (label.equals("SPACE")) {
            int lw = Math.round(bw * 0.4f);
            int lx = bx + (bw - lw) / 2;
            int ly = by + (bh - 2) / 2;
            context.fill(lx, ly, lx + lw, ly + 2, text);
            return;
        }

        if (sub == null) {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(bx + bw / 2f, by + bh / 2f);
            context.getMatrices().scale(1.0f, 1.0f);
            context.drawText(tr, label, -tr.getWidth(label) / 2, -tr.fontHeight / 2 + 1, text, shadow);
            context.getMatrices().popMatrix();
        } else {
            context.drawText(tr, label, bx + (bw - tr.getWidth(label)) / 2, by + 3, text, shadow);
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(bx + bw / 2f, by + 12f);
            context.getMatrices().scale(0.6f, 0.6f);
            context.drawText(tr, sub, -tr.getWidth(sub) / 2, 0, text, shadow);
            context.getMatrices().popMatrix();
        }
    }

    /** RGB (alpha diabaikan) + opasitas 0..1 -> ARGB. */
    private static int argb(int rgb, double opacity) {
        int a = (int) Math.round(Math.max(0.0, Math.min(1.0, opacity)) * 255.0);
        return (a << 24) | (rgb & 0xFFFFFF);
    }
}

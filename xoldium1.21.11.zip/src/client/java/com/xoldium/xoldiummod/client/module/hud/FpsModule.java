package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.gui.anim.ScreenChrome;
import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.mixin.hud.MinecraftClientFpsAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * FPS Display - kotak teks polos "NN FPS" (tanpa ikon). Angka FPS dibaca langsung dari engine
 * ({@code MinecraftClient#currentFps}) seperti mod FPS Display, plus statistik min/avg/max opsional
 * (riwayat 420 tick ~ 21 detik, sama dengan FPS Display). Warna teks, warna latar, bayangan, dan
 * warna otomatis menurut FPS bisa diatur di setting modul.
 */
public final class FpsModule extends HudModule {

    private static final int HISTORY_LIMIT = 420;

    private final ColorSetting textColor = addSetting(
            new ColorSetting("text_color", "setting.xoldiummod.fps.text_color", 0xFFFFFFFF, false));
    private final ColorSetting backgroundColor = addSetting(
            new ColorSetting("background_color", "setting.xoldiummod.fps.background_color", 0xFF000000, false));
    private final BooleanSetting dynamicColor = addSetting(
            new BooleanSetting("dynamic_color", "setting.xoldiummod.fps.dynamic_color", false));
    private final BooleanSetting shadow = addSetting(
            new BooleanSetting("text_shadow", "setting.xoldiummod.fps.text_shadow", false));
    private final BooleanSetting advancedStats = addSetting(
            new BooleanSetting("advanced_stats", "setting.xoldiummod.fps.advanced_stats", false));

    // cadangan bila accessor mixin tidak aktif: hitung frame sendiri
    private int frameCounter = 0;
    private int fallbackFps = 0;
    private long windowStartMs = System.currentTimeMillis();

    // riwayat FPS (ring buffer) untuk statistik min/avg/max
    private final int[] history = new int[HISTORY_LIMIT];
    private int historySize = 0;
    private int historyHead = 0;

    public FpsModule() {
        super("fps", "module.xoldiummod.fps", false, 4f, 4f);
    }

    @Override
    public void onClientTick() {
        addHistory(currentFps());
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer tr = client.textRenderer;

        frameCounter++;
        long now = System.currentTimeMillis();
        long elapsed = now - windowStartMs;
        if (elapsed >= 500) {
            fallbackFps = (int) Math.round(frameCounter * 1000.0 / elapsed);
            frameCounter = 0;
            windowStartMs = now;
        }

        int fps = currentFps();
        String text;
        if (advancedStats.get() && historySize > 0) {
            text = String.format("%d FPS (%d min | %d avg | %d max)", fps, historyMin(), historyAvg(), historyMax());
        } else {
            text = fps + " FPS";
        }

        int rawWidth = tr.getWidth(text) + 8;
        int rawHeight = tr.fontHeight + 6;
        setMeasuredSize(rawWidth, rawHeight);

        int color = dynamicColor.get() ? colorForFps(fps) : (0xFF000000 | (textColor.get() & 0xFFFFFF));
        int alpha = (int) Math.round(backgroundOpacity() * 255.0);
        alpha = Math.max(0, Math.min(255, alpha));
        int bg = (alpha << 24) | (backgroundColor.get() & 0xFFFFFF);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(scale, scale);
        if (alpha > 0) {
            ScreenChrome.roundedFill(context, 0, 0, rawWidth, rawHeight, bg);
        }
        context.drawText(tr, text, 4, 3, color, shadow.get());
        context.getMatrices().popMatrix();
    }

    /** FPS asli dari engine; bila accessor tidak aktif / nilai belum valid -> pakai hitungan frame sendiri. */
    private int currentFps() {
        Object client = MinecraftClient.getInstance();
        if (client instanceof MinecraftClientFpsAccessor accessor) {
            try {
                int v = accessor.xoldium$getCurrentFps();
                if (v > 0) {
                    return v;
                }
            } catch (Throwable ignored) {
                // jatuh ke cadangan di bawah
            }
        }
        return fallbackFps;
    }

    private static int colorForFps(int fps) {
        if (fps >= 60) {
            return 0xFF55FF55;
        }
        if (fps >= 30) {
            return 0xFFFFFF55;
        }
        return 0xFFFF5555;
    }

    private void addHistory(int fps) {
        history[historyHead] = fps;
        historyHead = (historyHead + 1) % HISTORY_LIMIT;
        if (historySize < HISTORY_LIMIT) {
            historySize++;
        }
    }

    private int historyMin() {
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < historySize; i++) {
            min = Math.min(min, history[i]);
        }
        return min == Integer.MAX_VALUE ? 0 : min;
    }

    private int historyMax() {
        int max = 0;
        for (int i = 0; i < historySize; i++) {
            max = Math.max(max, history[i]);
        }
        return max;
    }

    private int historyAvg() {
        if (historySize == 0) {
            return 0;
        }
        long sum = 0;
        for (int i = 0; i < historySize; i++) {
            sum += history[i];
        }
        return (int) (sum / historySize);
    }
}

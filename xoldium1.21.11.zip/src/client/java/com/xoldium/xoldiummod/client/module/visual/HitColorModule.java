package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.ColorSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import org.lwjgl.system.MemoryUtil;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Hit Color (menggantikan Damage Indicator) - mengganti warna kilatan merah
 * saat entitas terkena hit/damage.
 *
 * <p>PORTING KONSEP dari source "CookeyMod" (rizecookey) yang dikirim pemakai:
 * di CookeyMod opsi {@code damageColor} bekerja dengan menimpa 8 baris piksel
 * pertama {@code OverlayTexture} (tekstur 16x16 "Entity Color Overlay" yang
 * dipakai shader entitas untuk kilatan merah saat terkena hit; baris 8-15
 * adalah kilatan PUTIH - creeper meledak dsb - dan sengaja tidak disentuh).
 * Alfa piksel di tekstur itu = seberapa banyak warna ASLI entitas dipertahankan
 * (vanilla: 178/255 = 70% asli + 30% merah), jadi "Intensity" di sini = persen
 * warna kilatan yang dicampurkan (default 30% = vanilla).
 *
 * <p>Cara menulisnya BERBEDA dari CookeyMod (mapping Mojang + Mixin ke
 * konstruktor {@code OverlayTexture}): di sini tekstur dicari lewat TIPE
 * (bukan nama field/method) lalu piksel ditulis langsung ke memori
 * {@code NativeImage} (RGBA 16x16) dan di-upload ulang, supaya tidak ada satu
 * pun nama method Yarn yang perlu ditebak. Penulisan ke memori native DIJAGA:
 * sebelum menulis, isi tekstur diverifikasi (baris merah vanilla & baris putih
 * harus persis seperti yang diharapkan) - bila tidak cocok, modul menyerah
 * dengan aman (log sekali), TIDAK menulis ke alamat yang tidak jelas.
 */
public final class HitColorModule extends Module {

    private static final int SIZE = 16;
    /** Piksel merah vanilla sebagai int little-endian RGBA-bytes: A=0xB2, B=0, G=0, R=0xFF. */
    private static final int VANILLA_RED_ABGR = 0xB20000FF;

    private final ColorSetting color = addSetting(
            new ColorSetting("color", "setting.xoldiummod.hit_color.color", 0xFFFF0000, false));
    private final DoubleSetting intensity = addSetting(
            new DoubleSetting("intensity", "setting.xoldiummod.hit_color.intensity", 30.0, 0.0, 100.0, 1.0));

    private int appliedKey = Integer.MIN_VALUE;
    private boolean failed = false;
    private boolean verified = false;

    public HitColorModule() {
        super("hit_color", "module.xoldiummod.hit_color", ModuleCategory.VISUAL, false);
    }

    @Override
    public void onClientTick() {
        if (failed) {
            return;
        }
        int key = (color.argb() & 0x00FFFFFF) * 131 + (int) Math.round(intensity.get());
        if (key == appliedKey) {
            return;
        }
        int keep = 255 - (int) Math.round(Math.max(0.0, Math.min(100.0, intensity.get())) * 2.55);
        if (write(color.red(), color.green(), color.blue(), keep)) {
            appliedKey = key;
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        appliedKey = Integer.MIN_VALUE;
        if (!enabled && !failed) {
            write(255, 0, 0, 178); // kembali ke merah vanilla
        }
    }

    // ------------------------------------------------------------------

    private boolean write(int r, int g, int b, int keepAlpha) {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            GameRenderer renderer = client.gameRenderer;
            if (renderer == null) {
                return false; // belum siap - coba lagi tick berikutnya
            }
            Object overlay = fieldOfType(renderer, OverlayTexture.class);
            if (overlay == null) {
                return fail("OverlayTexture tidak ditemukan di GameRenderer");
            }
            Object texture = fieldOfType(overlay, NativeImageBackedTexture.class);
            if (texture == null) {
                return fail("NativeImageBackedTexture tidak ditemukan di OverlayTexture");
            }
            NativeImage image = imageOf(texture);
            if (image == null) {
                return fail("NativeImage tidak ditemukan");
            }
            long pointer = pointerOf(image);
            if (pointer == 0L || !sizeIs16(image)) {
                return fail("pointer/ukuran NativeImage tidak valid");
            }
            if (!verified) {
                // Verifikasi isi: baris 0 = merah vanilla (bila kita belum pernah mengubahnya), baris 8 kolom 0 = putih pekat.
                int row0 = MemoryUtil.memGetInt(pointer);
                int row8 = MemoryUtil.memGetInt(pointer + 4L * (8 * SIZE));
                if (row0 != VANILLA_RED_ABGR || row8 != 0xFFFFFFFF) {
                    return fail("isi OverlayTexture tidak sesuai dugaan (mod lain mengubahnya?)");
                }
                verified = true;
            }
            int abgr = ((keepAlpha & 0xFF) << 24) | ((b & 0xFF) << 16) | ((g & 0xFF) << 8) | (r & 0xFF);
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < SIZE; col++) {
                    MemoryUtil.memPutInt(pointer + 4L * (row * SIZE + col), abgr);
                }
            }
            return upload(texture) || fail("method upload() tidak ditemukan");
        } catch (Throwable t) {
            failed = true;
            XoldiumMod.LOGGER.warn("[Xoldium] Hit Color dinonaktifkan karena error (client tetap normal).", t);
            return false;
        }
    }

    private boolean fail(String reason) {
        failed = true;
        XoldiumMod.LOGGER.warn("[Xoldium] Hit Color tidak bisa dipasang: {}", reason);
        return false;
    }

    private static Object fieldOfType(Object owner, Class<?> type) throws IllegalAccessException {
        for (Class<?> c = owner.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (type.isAssignableFrom(f.getType()) && !Modifier.isStatic(f.getModifiers())) {
                    f.setAccessible(true);
                    Object value = f.get(owner);
                    if (value != null) {
                        return value;
                    }
                }
            }
        }
        return null;
    }

    private static NativeImage imageOf(Object texture) throws Exception {
        for (Method m : texture.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == NativeImage.class) {
                m.setAccessible(true);
                return (NativeImage) m.invoke(texture);
            }
        }
        return null;
    }

    private static long pointerOf(NativeImage image) throws Exception {
        Method found = null;
        for (Method m : NativeImage.class.getMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == long.class && !Modifier.isStatic(m.getModifiers())) {
                if (found != null) {
                    return 0L; // ambigu -> menyerah
                }
                found = m;
            }
        }
        if (found == null) {
            return 0L;
        }
        found.setAccessible(true);
        return (long) found.invoke(image);
    }

    private static boolean sizeIs16(NativeImage image) throws Exception {
        int seen = 0;
        for (Method m : NativeImage.class.getMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == int.class && !Modifier.isStatic(m.getModifiers())) {
                m.setAccessible(true);
                if ((int) m.invoke(image) != SIZE) {
                    return false;
                }
                seen++;
            }
        }
        return seen >= 2; // lebar & tinggi
    }

    private static boolean upload(Object texture) throws Exception {
        Method found = null;
        for (Method m : texture.getClass().getDeclaredMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == void.class
                    && !Modifier.isStatic(m.getModifiers()) && !m.getName().equals("close")) {
                if (found != null) {
                    return false; // ambigu -> menyerah
                }
                found = m;
            }
        }
        if (found == null) {
            return false;
        }
        found.setAccessible(true);
        found.invoke(texture);
        return true;
    }
}

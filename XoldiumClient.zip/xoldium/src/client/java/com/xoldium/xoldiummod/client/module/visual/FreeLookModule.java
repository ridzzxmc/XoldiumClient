package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.setting.KeybindSetting;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * FreeLook - melihat sekeliling TANPA memutar arah hadap badan pemain,
 * selagi tombol ditahan (default Left Alt).
 *
 * <p>PORTING KONSEP (bukan porting kode langsung): source code "Freelook"
 * yang dikirim pemakai memakai mapping Mojang resmi ({@code Minecraft},
 * {@code LocalPlayer}, {@code Camera#alignWithEntity}, dst) untuk
 * Minecraft versi berbeda - proyek Xoldium memakai mapping Yarn
 * ({@code MinecraftClient}, {@code ClientPlayerEntity}, dst), jadi nama
 * kelas/method TIDAK bisa dipindah apa adanya. Mekanismenya diimplementasi
 * ulang dari nol dengan logika yang SAMA (akumulasi delta mouse terpisah
 * dari badan, lalu di-apply ke kamera saja) memakai DUA titik hook Yarn
 * yang jauh lebih stabil/dikenal luas daripada method internal
 * {@code alignWithEntity} milik mod referensi:
 * <ul>
 *   <li>{@code mixin.visual.FreeLookEntityMixin} - membatalkan
 *       {@code Entity#changeLookDirection(double,double)} (method yang
 *       dipanggil vanilla tiap gerakan mouse untuk memutar badan/kepala)
 *       selagi FreeLook aktif, lalu mengumpulkan delta itu ke sini lewat
 *       {@link #accumulate}.</li>
 *   <li>{@code mixin.visual.FreeLookCameraMixin} - meng-override rotasi
 *       akhir kamera lewat {@code Camera#setRotation} di akhir
 *       {@code Camera#update}, memakai {@link #cameraYaw}/{@link #cameraPitch}
 *       yang terkumpul, TANPA menyentuh yaw/pitch badan pemain sama sekali.</li>
 * </ul>
 * Hasilnya: badan pemain benar-benar diam (beku persis di posisi saat
 * FreeLook mulai ditahan) selagi kamera bisa berputar bebas - begitu
 * tombol dilepas, kontrol kembali normal dari posisi badan yang sama
 * (tidak ada "snap").
 */
public final class FreeLookModule extends Module {

    private static FreeLookModule instance;

    private final KeyBinding keyBinding;

    private float cameraYaw;
    private float cameraPitch;
    private boolean anchored = false;

    public FreeLookModule() {
        super("freelook", "module.xoldiummod.freelook", ModuleCategory.VISUAL, false);
        instance = this;
        keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "key.categories.xoldiummod"));
        addSetting(new KeybindSetting("key", "setting.xoldiummod.freelook.key", keyBinding));
    }

    @Override
    protected void onToggle(boolean enabled) {
        anchored = false;
    }

    @Override
    public void onClientTick() {
        if (!isHeld()) {
            anchored = false;
        }
    }

    /** Apakah FreeLook sedang benar-benar aktif detik ini (modul ON + tombol ditahan). Dibaca live oleh kedua mixin, bukan cache per-tick, supaya responsif per-frame. */
    public static boolean isActive() {
        return instance != null && instance.isEnabled() && instance.isHeld();
    }

    private boolean isHeld() {
        return keyBinding.isPressed();
    }

    /** Dipanggil {@code FreeLookEntityMixin} tiap delta mouse selagi aktif - badan TIDAK ikut berputar, hanya kamera. */
    public static void accumulate(double cursorDeltaX, double cursorDeltaY) {
        if (instance == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (!instance.anchored && client.player != null) {
            instance.cameraYaw = client.player.getYaw();
            instance.cameraPitch = client.player.getPitch();
            instance.anchored = true;
        }
        // Faktor tetap 0.15 (sama seperti mod referensi) - SENGAJA tidak ikut membaca
        // opsi sensitivitas mouse vanilla di sini supaya tidak menambah satu lagi
        // pemetaan API GameOptions yang perlu diverifikasi; hasilnya kecepatan
        // FreeLook sedikit independen dari slider sensitivitas mouse vanilla,
        // trade-off yang wajar untuk modul opsional seperti ini.
        double factor = 0.15;
        instance.cameraYaw += (float) (cursorDeltaX * factor);
        instance.cameraPitch = MathHelper.clamp(instance.cameraPitch + (float) (cursorDeltaY * factor), -90.0f, 90.0f);
    }

    public static float getCameraYaw() {
        return instance != null ? instance.cameraYaw : 0f;
    }

    public static float getCameraPitch() {
        return instance != null ? instance.cameraPitch : 0f;
    }
}

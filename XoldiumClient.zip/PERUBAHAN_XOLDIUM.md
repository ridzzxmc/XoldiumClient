# Ringkasan Perubahan

## Sesi 3 (terbaru)
- **Renderer Optimization DIHAPUS TOTAL** (tidak berguna menurut kamu) -
  file `RendererOptimizationModule.java` dihapus, registrasinya di
  `ModuleManager.java` dan translation key-nya di `en_us.json`/`id_id.json`
  juga dihapus. Tidak ada sisa referensi di source manapun.
- **Damage Indicator dikembalikan ke MERAH** (`0xFF5050`) - permintaan
  "hitam-putih di luar Mod Menu" sebelumnya sudah kelewat jauh sampai
  ke sini, sekarang dibatalkan khusus untuk modul ini.

## Sesi 2
### Hitam-putih di luar Mod Menu
- `client/util/HudRenderUtil.java`: `ACCENT_COLOR` (dulu biru, dipakai
  Combo Counter & Credit HUD) -> abu sangat terang.
- `client/module/hud/KeystrokesModule.java`: kotak tombol ditekan (dulu
  biru) -> putih terang, teks otomatis jadi hitam di atasnya.
- Damage Indicator: lihat Sesi 3 di atas - DIBATALKAN, kembali merah.

### Logo title screen pakai gambar asli
`textures/gui/title_logo.png` (banner "XOLDIUM CLIENT" 1024x265) +
`mixin/titlescreen/TitleScreenMixin.java` digambar 220x57 di atas title
screen, menggantikan wordmark teks polos.

## Sesi 1
### Bug Fullbright — DIPERBAIKI
Mixin langsung ke perhitungan lightmap texture
(`mixin/visual/LightmapTextureManagerMixin.java`), TIDAK lagi lewat
`GameOptions#getGamma()` yang value-nya ditolak diam-diam oleh validator
slider vanilla di Minecraft 1.21.11.

### Mod Menu diperkecil & hitam-putih
`client/gui/ModListScreen.java` (panel ~460x300, kartu ~104x66) +
`client/gui/IconRenderer.java` (toggle & badge hitam-putih-abu netral).

### Ikon modul asli
21 dari 24 modul pakai ikon PNG dari `Logo Module.zip`, dipetakan di
`IconRenderer.MODULE_ICONS`; Biome HUD & No Hurt Cam tetap fallback
badge inisial huruf (tidak ada file ikon yang cocok).

### Logo asli di HUD Editor
`client/gui/XoldiumHomeScreen.java`: badge "X" diganti gambar
`logo.png` asli.

### UI khas title screen (ala Hyper Client)
Tombol "Mod Menu / HUD Editor / Settings" tambahan di kiri layar lewat
`Screen#addDrawable(...)` di `init()` (di 1.21.11 `TitleScreen` sudah
tidak meng-override `render(...)` sendiri lagi - Mixin ke render akan
crash saat start).

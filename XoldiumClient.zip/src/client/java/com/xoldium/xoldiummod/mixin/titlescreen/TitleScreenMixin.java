package com.xoldium.xoldiummod.mixin.titlescreen;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.gui.IconRenderer;
import com.xoldium.xoldiummod.client.gui.ModListScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumConfigScreen;
import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * UI khas Xoldium Client di title screen - permintaan pemakai: "Buatkan
 * juga XoldiumClient ada UI nya sendiri seperti di foto Hyper Client yang
 * sudah aku kirim". Ditiru dari struktur foto referensi tsb: wordmark
 * brand + versi kecil di atas, dan kolom tombol kecil (Mod Menu/HUD
 * Editor/Settings - padanan "Language/Shots/Switch UI/Mod Menu" pada
 * referensi; tiga di sini sengaja hanya yang SUNGGUHAN fungsional di
 * Xoldium, bukan tombol dekorasi kosong) di sisi kiri layar - SEMUA murni
 * TAMBAHAN (additive) di atas title screen vanilla, sama seperti pada
 * foto referensi yang juga masih menampilkan tombol Singleplayer/
 * Multiplayer/Options/Quit Game bawaan Minecraft apa adanya di tengah,
 * tidak diganti/di-relayout sama sekali.
 *
 * <p>CATATAN VERIFIKASI PENTING: di Minecraft 1.21.11, {@code TitleScreen}
 * TERNYATA TIDAK LAGI meng-override {@code render(DrawContext,int,int,float)}
 * sendiri (dikonfirmasi lewat Yarn API docs {@code yarn-1.21.11+build.3} -
 * method itu sudah tidak ada di daftar method deklarasi {@code TitleScreen},
 * kemungkinan digantikan komponen {@code LogoDrawer} terpisah menyusul
 * perombakan render pipeline). Meng-Mixin {@code @Inject} ke {@code render}
 * pada {@code TitleScreen.class} langsung akan GAGAL dipasang (Mixin
 * apply error saat game start, karena method target harus benar-benar
 * DIDEKLARASIKAN di kelas yang di-{@code @Mixin}, bukan sekadar
 * ter-inherit). Solusinya: branding digambar lewat
 * {@code Screen#addDrawable(Drawable)} yang didaftarkan di dalam
 * {@code init()} (method yang TERKONFIRMASI ADA langsung di
 * {@code TitleScreen}) - {@code Drawable} adalah functional interface
 * ({@code render(DrawContext,int,int,float)}) sehingga bisa didaftarkan
 * sebagai lambda tanpa perlu Mixin kedua ke method render manapun sama
 * sekali.
 *
 * <p>Pola "mixin class extends Screen" di bawah ini standar untuk mixin
 * yang perlu memanggil method ter-inherit yang protected (di sini
 * {@code addDrawableChild}/{@code addDrawable}, dideklarasikan di
 * {@link Screen}, ter-inherit oleh {@link TitleScreen}) - constructor
 * tidak pernah benar-benar dipanggil saat runtime (Mixin transformer
 * menyuntikkan body method ke kelas target asli, {@code TitleScreen}),
 * murni supaya kelas ini kompilasi bersih.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    private static final Identifier LOGO_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/title_logo.png");
    /** Rasio asli file (1024x265) supaya banner tidak gepeng/melar saat diskalakan. */
    private static final int LOGO_DISPLAY_WIDTH = 220;
    private static final int LOGO_DISPLAY_HEIGHT = 57;

    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init()V", at = @At("TAIL"))
    private void xoldium$addBrandingButtons(CallbackInfo ci) {
        int buttonWidth = 88;
        int buttonHeight = 18;
        int gap = 3;
        int x = 8;
        int startY = this.height / 2 - 30;

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.title_screen.mod_menu"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new ModListScreen(this));
                    }
                })
                .dimensions(x, startY, buttonWidth, buttonHeight)
                .build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.title_screen.hud_editor"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new XoldiumHomeScreen(this));
                    }
                })
                .dimensions(x, startY + (buttonHeight + gap), buttonWidth, buttonHeight)
                .build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.xoldiummod.title_screen.settings"), button -> {
                    if (this.client != null) {
                        this.client.setScreen(new XoldiumConfigScreen(this));
                    }
                })
                .dimensions(x, startY + 2 * (buttonHeight + gap), buttonWidth, buttonHeight)
                .build());

        String version = FabricLoader.getInstance().getModContainer(XoldiumMod.MOD_ID)
                .map(container -> container.getMetadata().getVersion().getFriendlyString())
                .orElse("?");

        // Drawable murni (bukan tombol) untuk banner "XOLDIUM CLIENT" (title_logo.png, gambar
        // yang dikirim pemakai - bukan teks gambar sendiri lagi) + versi - lihat catatan
        // verifikasi di javadoc kelas ini kenapa ini TIDAK lewat @Inject ke render().
        this.addDrawable((context, mouseX, mouseY, delta) -> {
            int centerX = this.width / 2;
            int topY = 6;

            IconRenderer.drawTexture(context, LOGO_TEXTURE,
                    centerX - LOGO_DISPLAY_WIDTH / 2, topY, LOGO_DISPLAY_WIDTH, LOGO_DISPLAY_HEIGHT);
            context.drawText(this.textRenderer, Text.literal("Xoldium v" + version), 4, this.height - 20, 0xFFAAAAAA, true);
        });
    }
}

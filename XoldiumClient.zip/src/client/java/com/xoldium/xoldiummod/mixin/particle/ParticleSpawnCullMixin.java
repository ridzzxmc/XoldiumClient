package com.xoldium.xoldiummod.mixin.particle;

import com.xoldium.xoldiummod.client.particle.ParticleCullHelper;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mencegat {@code ParticleManager#addParticle(...)} SEBELUM objek
 * {@code Particle} dibuat - keputusan CPU-side murni, nol interaksi dengan
 * render backend (GL maupun Vulkan).
 */
@Mixin(ParticleManager.class)
public abstract class ParticleSpawnCullMixin {

    @Inject(
            method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void xoldium$cullOffscreenParticle(
            ParticleEffect parameters, double x, double y, double z,
            double velocityX, double velocityY, double velocityZ, CallbackInfo ci) {

        if (!ParticleCullHelper.isEligible(x, y, z)) {
            ci.cancel();
        }
    }
}

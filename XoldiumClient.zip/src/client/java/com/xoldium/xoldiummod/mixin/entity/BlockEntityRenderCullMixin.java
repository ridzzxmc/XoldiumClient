package com.xoldium.xoldiummod.mixin.entity;

import com.xoldium.xoldiummod.client.core.FrustumContext;
import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Meng-cull pemanggilan render untuk {@link BlockEntity} (chest, sign,
 * spawner, dll) yang berada di luar frustum kamera DAN/ATAU di luar jarak
 * ambang tertentu, sebelum renderer-nya membangun geometry apa pun.
 */
@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderCullMixin {

    @Inject(
            method = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private <E extends BlockEntity> void xoldium$cullOffscreenBlockEntity(
            E blockEntity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {

        if (blockEntity == null) {
            return;
        }

        XoldiumConfig cfg = XoldiumConfig.get();
        if (!cfg.enabled) {
            return;
        }

        Box box = new Box(blockEntity.getPos()).expand(1.0);

        if (cfg.tileEntityDistanceCulling) {
            Camera camera = FrustumContext.camera();
            if (camera != null) {
                Vec3d camPos = camera.getPos();
                double cx = (box.minX + box.maxX) * 0.5;
                double cy = (box.minY + box.maxY) * 0.5;
                double cz = (box.minZ + box.maxZ) * 0.5;
                double dx = cx - camPos.x;
                double dy = cy - camPos.y;
                double dz = cz - camPos.z;
                double distSq = dx * dx + dy * dy + dz * dz;
                if (distSq > cfg.tileEntityCullDistance * cfg.tileEntityCullDistance) {
                    ci.cancel();
                    return;
                }
            }
        }

        if (cfg.blockEntityCulling) {
            long cacheKey = blockEntity.getPos().asLong();
            if (!FrustumContext.isBlockEntityVisible(cacheKey, box)) {
                ci.cancel();
            }
        }
    }
}

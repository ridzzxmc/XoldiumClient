package com.xoldium.xoldiummod.client.module;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Modul kategori HUD - elemen teks/ikon kecil yang digambar di layar setiap
 * frame lewat {@code HudRenderCallback} (didaftarkan terpusat oleh
 * {@link ModuleManager}, bukan oleh masing-masing modul, agar urutan
 * render & pembungkusan try/catch konsisten untuk semua elemen HUD).
 *
 * <p>Posisi ({@link #x}/{@link #y}) adalah koordinat piksel absolut dari
 * pojok kiri-atas layar, diatur lewat drag-and-drop di
 * {@code XoldiumHomeScreen} (HUD Editor). {@link #scale} mengalikan ukuran
 * render (dibatasi 0.5x - 3.0x).
 */
public abstract class HudModule extends Module {

    protected float x;
    protected float y;
    protected float scale = 1.0f;

    private float measuredWidth = 40f;
    private float measuredHeight = 10f;

    protected HudModule(String id, String nameKey, boolean defaultEnabled, float defaultX, float defaultY) {
        super(id, nameKey, ModuleCategory.HUD, defaultEnabled);
        this.x = defaultX;
        this.y = defaultY;
    }

    /**
     * Gambar elemen HUD ini. Dipanggil hanya bila {@link #isEnabled()} true.
     * Implementasi WAJIB memanggil {@link #setMeasuredSize(float, float)}
     * dengan ukuran mentah (sebelum dikali scale) supaya bounding box di
     * HUD Editor akurat untuk drag & scroll-to-scale.
     */
    public abstract void render(DrawContext context, RenderTickCounter tickCounter);

    /**
     * Render pratinjau statis untuk HUD Editor (dipanggil sebagai ganti
     * {@link #render} saat home screen dalam mode edit, supaya elemen yang
     * datanya butuh dunia/pemain tetap terlihat dengan data contoh walau
     * screen sedang terbuka). Default memanggil {@link #render} langsung -
     * override bila butuh tampilan placeholder yang berbeda.
     */
    public void renderPreview(DrawContext context, RenderTickCounter tickCounter) {
        render(context, tickCounter);
    }

    public float x() {
        return x;
    }

    public float y() {
        return y;
    }

    public float scale() {
        return scale;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void setScale(float scale) {
        this.scale = Math.max(0.5f, Math.min(3.0f, scale));
    }

    public float measuredWidth() {
        return measuredWidth * scale;
    }

    public float measuredHeight() {
        return measuredHeight * scale;
    }

    public void setMeasuredSize(float rawWidth, float rawHeight) {
        this.measuredWidth = Math.max(rawWidth, 4f);
        this.measuredHeight = Math.max(rawHeight, 4f);
    }
}

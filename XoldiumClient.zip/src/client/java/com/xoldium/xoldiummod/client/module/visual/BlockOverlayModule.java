package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Block Overlay: menggambar ulang outline block yang sedang dibidik dengan
 * warna aksen Xoldium (menggantikan outline hitam vanilla), lewat event
 * resmi Fabric Rendering {@code WorldRenderEvents#BLOCK_OUTLINE} - BUKAN
 * Mixin ke {@code WorldRenderer} internal.
 *
 * <p>CATATAN VERIFIKASI MAPPING: nama nested type persis
 * ({@code WorldRenderEvents.BlockOutlineContext}) dan method
 * {@code WorldRenderer.drawBox(...)} sudah stabil selama beberapa rilis,
 * tapi tetap verifikasi ulang lewat {@code genSources}/IDE saat pindah ke
 * build Yarn/Fabric API baru.
 */
public final class BlockOverlayModule extends Module {

    public BlockOverlayModule() {
        super("block_overlay", "module.xoldiummod.block_overlay", ModuleCategory.VISUAL, false);
        WorldRenderEvents.BLOCK_OUTLINE.register(this::onBlockOutline);
    }

    private boolean onBlockOutline(WorldRenderContext context, WorldRenderEvents.BlockOutlineContext blockContext) {
        if (!isEnabled()) {
            return true; // biarkan vanilla menggambar outline normal
        }
        try {
            Vec3d camPos = context.camera().getPos();
            Box box = new Box(blockContext.blockPos())
                    .offset(-camPos.x, -camPos.y, -camPos.z)
                    .expand(0.002);

            VertexConsumer consumer = context.consumers().getBuffer(RenderLayer.getLines());
            WorldRenderer.drawBox(context.matrixStack(), consumer, box, 0.33f, 0.78f, 0.94f, 1.0f);
        } catch (Throwable t) {
            markCrashed(t);
            return true;
        }
        return false; // sudah digambar sendiri, cegah outline vanilla dobel
    }
}

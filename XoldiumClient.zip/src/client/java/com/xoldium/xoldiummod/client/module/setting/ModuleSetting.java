package com.xoldium.xoldiummod.client.module.setting;

import net.minecraft.text.Text;

/** Setting generik tambahan milik sebuah Module, ditampilkan di ModuleSettingsScreen (ikon gear). */
public abstract class ModuleSetting<T> {

    private final String id;
    private final String nameKey;
    protected T value;

    protected ModuleSetting(String id, String nameKey, T defaultValue) {
        this.id = id;
        this.nameKey = nameKey;
        this.value = defaultValue;
    }

    public String id() {
        return id;
    }

    public Text displayName() {
        return Text.translatable(nameKey);
    }

    public T get() {
        return value;
    }

    public void set(T value) {
        this.value = value;
        com.xoldium.xoldiummod.client.module.ModuleManager.saveState();
    }

    /** Dipakai ModuleManager saat memuat dari config - tanpa memicu save ulang. */
    public void setFromConfig(T value) {
        this.value = value;
    }
}

package com.xoldium.xoldiummod.client.util;

import com.xoldium.xoldiummod.client.module.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Util render HUD bersama supaya seluruh modul teks Xoldium (FPS, Ping,
 * Coordinates, dst) punya gaya kotak label yang konsisten & satu tempat
 * untuk diperbaiki bila ada masalah tampilan - alih-alih setiap modul
 * menggambar kotaknya sendiri secara terpisah.
 *
 * <p>CATATAN VERIFIKASI MAPPING: sejak pembaruan render 2D Minecraft
 * (~1.21.2), transform GUI pada {@link DrawContext} memakai
 * {@code org.joml.Matrix3x2fStack} (method {@code pushMatrix()},
 * {@code popMatrix()}, {@code translate(x, y)} 2 argumen,
 * {@code scale(x, y)} 2 argumen) - BUKAN {@code MatrixStack} 3 argumen
 * gaya lama yang dipakai render 3D. Kode di bawah sudah memakai API baru
 * ini sesuai Yarn untuk rentang 1.21 - 1.21.11, tapi tetap verifikasi
 * ulang lewat {@code genSources}/IDE saat pindah ke build Yarn baru,
 * persis seperti catatan verifikasi mapping pada Mixin lain di proyek ini.
 */
public final class HudRenderUtil {

    public static final int BACKGROUND = 0x90000000;
    public static final int TEXT_COLOR = 0xFFFFFFFF;
    public static final int ACCENT_COLOR = 0xFF55C7F0;

    private HudRenderUtil() {
    }

    /** Menggambar satu baris teks dengan latar semi-transparan pada posisi & skala modul, lalu mencatat ukuran terukur ke modul. */
    public static void drawLine(DrawContext context, HudModule module, String text) {
        drawLine(context, module, text, TEXT_COLOR);
    }

    public static void drawLine(DrawContext context, HudModule module, String text, int textColor) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = tr.getWidth(text) + 6;
        int rawHeight = tr.fontHeight + 4;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(module.x(), module.y());
        context.getMatrices().scale(module.scale(), module.scale());

        context.fill(0, 0, rawWidth, rawHeight, BACKGROUND);
        context.drawText(tr, text, 3, 2, textColor, true);

        context.getMatrices().popMatrix();
    }

    /** Varian multi-baris (satu kotak latar menaungi semua baris). */
    public static void drawLines(DrawContext context, HudModule module, String... lines) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int rawWidth = 0;
        for (String line : lines) {
            rawWidth = Math.max(rawWidth, tr.getWidth(line));
        }
        rawWidth += 6;
        int lineHeight = tr.fontHeight + 1;
        int rawHeight = lineHeight * lines.length + 3;
        module.setMeasuredSize(rawWidth, rawHeight);

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(module.x(), module.y());
        context.getMatrices().scale(module.scale(), module.scale());

        context.fill(0, 0, rawWidth, rawHeight, BACKGROUND);
        int y = 2;
        for (String line : lines) {
            context.drawText(tr, line, 3, y, TEXT_COLOR, true);
            y += lineHeight;
        }

        context.getMatrices().popMatrix();
    }
}

package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;

public final class CoordinatesModule extends HudModule {

    public CoordinatesModule() {
        super("coordinates", "module.xoldiummod.coordinates", true, 4f, 32f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        BlockPos pos = client.player.getBlockPos();
        HudRenderUtil.drawLine(context, this,
                String.format("X: %d  Y: %d  Z: %d", pos.getX(), pos.getY(), pos.getZ()));
    }
}

package com.xoldium.xoldiummod.client.module.setting;

public final class DoubleSetting extends ModuleSetting<Double> {

    private final double min;
    private final double max;
    private final double step;

    public DoubleSetting(String id, String nameKey, double defaultValue, double min, double max, double step) {
        super(id, nameKey, clamp(defaultValue, min, max));
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double min() {
        return min;
    }

    public double max() {
        return max;
    }

    public double step() {
        return step;
    }

    /** Set nilai dari posisi slider 0.0-1.0. */
    public void setFromSliderProgress(double progress) {
        double raw = min + (max - min) * progress;
        double stepped = step > 0 ? Math.round(raw / step) * step : raw;
        set(clamp(stepped, min, max));
    }

    public double sliderProgress() {
        if (max <= min) return 0.0;
        return (get() - min) / (max - min);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}

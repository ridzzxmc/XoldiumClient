package com.xoldium.xoldiummod.client.module.hud;

import com.xoldium.xoldiummod.client.module.HudModule;
import com.xoldium.xoldiummod.client.util.HudRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Menghitung FPS sendiri (bukan membaca field internal client) supaya tidak bergantung pada nama field yang bisa berubah antar versi. */
public final class FpsModule extends HudModule {

    private int frameCounter = 0;
    private int displayedFps = 0;
    private long windowStartMs = System.currentTimeMillis();

    public FpsModule() {
        super("fps", "module.xoldiummod.fps", true, 4f, 4f);
    }

    @Override
    public void render(DrawContext context, RenderTickCounter tickCounter) {
        frameCounter++;
        long now = System.currentTimeMillis();
        long elapsed = now - windowStartMs;
        if (elapsed >= 500) {
            displayedFps = (int) Math.round(frameCounter * 1000.0 / elapsed);
            frameCounter = 0;
            windowStartMs = now;
        }
        HudRenderUtil.drawLine(context, this, "FPS: " + displayedFps);
    }
}

package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.config.XoldiumConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Layar "Settings" tingkat-lanjut (raw config internal Xoldium) - dibuka
 * lewat tombol "Settings" pada {@link XoldiumHomeScreen}, atau lewat Mod
 * Menu/VulkanMod bila ter-install (lihat kelas compat). Dibangun murni
 * dari widget vanilla, sama seperti {@code FulconConfigScreen} pendahulunya.
 * Setiap toggle disimpan LANGSUNG ke {@link XoldiumConfig} saat diklik.
 */
public final class XoldiumConfigScreen extends Screen {

    private final Screen parent;
    private final List<ToggleEntry> toggles = new ArrayList<>();

    public XoldiumConfigScreen(Screen parent) {
        super(Text.translatable("xoldiummod.config.title"));
        this.parent = parent;
        registerToggles();
    }

    private void registerToggles() {
        XoldiumConfig cfg = XoldiumConfig.get();

        toggles.add(new ToggleEntry("xoldiummod.config.enabled", () -> cfg.enabled, v -> cfg.enabled = v));
        toggles.add(new ToggleEntry("xoldiummod.config.entity_frustum_culling", () -> cfg.entityFrustumCulling, v -> cfg.entityFrustumCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.player_culling", () -> cfg.playerCulling, v -> cfg.playerCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.block_entity_culling", () -> cfg.blockEntityCulling, v -> cfg.blockEntityCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.particle_frustum_culling", () -> cfg.particleFrustumCulling, v -> cfg.particleFrustumCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.tile_entity_distance_culling", () -> cfg.tileEntityDistanceCulling, v -> cfg.tileEntityDistanceCulling = v));
        toggles.add(new ToggleEntry("xoldiummod.config.fast_entity_rendering", () -> cfg.fastEntityRendering, v -> cfg.fastEntityRendering = v));
        toggles.add(new ToggleEntry("xoldiummod.config.direct_particle_fast_path", () -> cfg.directParticleFastPath, v -> cfg.directParticleFastPath = v));
        toggles.add(new ToggleEntry("xoldiummod.config.occlusion_culling_boost", () -> cfg.occlusionCullingBoost, v -> cfg.occlusionCullingBoost = v));
        toggles.add(new ToggleEntry("xoldiummod.config.mob_ai_throttling", () -> cfg.mobAiThrottling, v -> cfg.mobAiThrottling = v));
    }

    @Override
    protected void init() {
        int top = 28;
        int rowHeight = 22;
        int width = Math.min(this.width - 40, 360);
        int x = (this.width - width) / 2;

        int y = top;
        for (ToggleEntry entry : toggles) {
            CyclingButtonWidget<Boolean> widget = CyclingButtonWidget.onOffBuilder(entry.getter.get())
                    .build(x, y, width, 20, Text.translatable(entry.labelKey), (button, value) -> {
                        entry.setter.accept(value);
                        XoldiumConfig.save();
                    });
            this.addDrawableChild(widget);
            y += rowHeight;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> {
                    XoldiumConfig.save();
                    this.client.setScreen(this.parent);
                })
                .dimensions(x, y + 6, width, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);
    }

    @Override
    public void close() {
        XoldiumConfig.save();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    private record ToggleEntry(String labelKey, Supplier<Boolean> getter, Consumer<Boolean> setter) {
    }
}

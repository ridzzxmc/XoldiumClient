package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

/**
 * Fullbright: memaksa nilai gamma vanilla ({@link GameOptions#getGamma()})
 * jauh di atas batas slider Video Settings (yang dibatasi UI ke 1.0, tapi
 * TIDAK dibatasi pada {@code SimpleOption#setValue} itu sendiri). Murni
 * memakai API publik resmi - TIDAK ada Mixin ke internal
 * LightmapTextureManager sama sekali, sehingga risiko break antar versi
 * jauh lebih kecil dibanding pendekatan Mixin gamma yang umum dipakai
 * mod fullbright lain.
 */
public final class FullbrightModule extends Module {

    private static final double FULLBRIGHT_VALUE = 100.0;

    private double originalGamma = 1.0;
    private boolean storedOriginal = false;

    public FullbrightModule() {
        super("fullbright", "module.xoldiummod.fullbright", ModuleCategory.VISUAL, false);
    }

    @Override
    protected void onToggle(boolean enabled) {
        GameOptions options = MinecraftClient.getInstance().options;
        if (options == null) {
            return;
        }
        SimpleOption<Double> gamma = options.getGamma();
        if (enabled) {
            originalGamma = gamma.getValue();
            storedOriginal = true;
            gamma.setValue(FULLBRIGHT_VALUE);
        } else if (storedOriginal) {
            gamma.setValue(originalGamma);
        }
    }

    @Override
    public void onClientTick() {
        // Dipaksa ulang tiap tick (bukan hanya sekali saat toggle) supaya
        // tetap fullbright walau ada sistem lain yang mengubah opsi gamma
        // di antara tick (murah - satu write field per tick).
        GameOptions options = MinecraftClient.getInstance().options;
        if (options != null) {
            options.getGamma().setValue(FULLBRIGHT_VALUE);
        }
    }
}

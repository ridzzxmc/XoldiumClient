package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Layar daftar modul Xoldium ("Mod Menu") - tab kategori (ALL/HUD/
 * OPTIMIZATION/MOVEMENT/VISUAL), kotak pencarian, dan grid kartu modul
 * dengan ikon, toggle ON/OFF, dan tombol gear untuk membuka setting
 * per-modul - meniru tata letak referensi GUI yang dilampirkan (kartu
 * berjajar dalam grid, judul di kiri-atas, ikon di tengah, kontrol di
 * baris bawah kartu). Tab "Optimization" juga menampilkan tombol preset
 * "Auto FPS Boost" yang menyalakan seluruh toggle optimasi sekaligus.
 */
public final class ModListScreen extends Screen {

    private static final int CARD_WIDTH = 214;
    private static final int CARD_HEIGHT = 128;
    private static final int CARD_GAP = 14;
    private static final int MARGIN = 20;
    private static final int PANEL_BG = 0xF0101014;
    private static final int CARD_BG = 0xF01B1B22;
    private static final int CARD_BG_HOVER = 0xF0242430;
    private static final int CARD_BORDER = 0x30FFFFFF;
    private static final int CARD_BORDER_HOVER = 0xFFFFFFFF;

    private final Screen parent;
    private TextFieldWidget searchField;
    private ButtonWidget autoFpsBoostButton;
    private ModuleCategory currentCategory = ModuleCategory.ALL;
    private int scrollOffset = 0;
    private List<Module> visibleModules;

    // Bounding box tiap kartu yang sedang dirender frame ini, dipakai untuk hit-test klik.
    private final List<CardBounds> cardBoundsThisFrame = new java.util.ArrayList<>();
    private final List<TabBounds> tabBoundsThisFrame = new java.util.ArrayList<>();

    public ModListScreen(Screen parent) {
        super(Text.translatable("gui.xoldiummod.mod_menu.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int searchWidth = 200;
        int searchX = this.width - MARGIN - 12 - searchWidth;
        int searchY = MARGIN + 10;
        searchField = new TextFieldWidget(this.textRenderer, searchX, searchY, searchWidth, 20,
                Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setPlaceholder(Text.translatable("gui.xoldiummod.mod_menu.search"));
        searchField.setChangedListener(query -> {
            scrollOffset = 0;
            refreshVisibleModules();
        });
        this.addDrawableChild(searchField);

        int boostWidth = 110;
        autoFpsBoostButton = ButtonWidget.builder(Text.translatable("gui.xoldiummod.mod_menu.auto_fps_boost"),
                        button -> ModuleManager.applyAutoFpsBoostPreset())
                .dimensions(searchX - 8 - boostWidth, searchY, boostWidth, 20)
                .build();
        autoFpsBoostButton.visible = currentCategory == ModuleCategory.OPTIMIZATION;
        this.addDrawableChild(autoFpsBoostButton);

        refreshVisibleModules();
    }

    private void refreshVisibleModules() {
        String query = searchField != null ? searchField.getText() : "";
        visibleModules = ModuleManager.search(currentCategory, query);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.fill(MARGIN, MARGIN, this.width - MARGIN, this.height - MARGIN, PANEL_BG);

        renderTabs(context, mouseX, mouseY);

        int gridTop = MARGIN + 10 + 32 + 14;
        context.fill(MARGIN + 12, gridTop - 8, this.width - MARGIN - 12, gridTop - 7, 0x40FFFFFF);

        renderGrid(context, mouseX, mouseY, gridTop);

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderTabs(DrawContext context, int mouseX, int mouseY) {
        tabBoundsThisFrame.clear();
        int x = MARGIN + 12;
        int y = MARGIN + 8;
        int height = 24;
        for (ModuleCategory category : ModuleCategory.values()) {
            String label = Text.translatable(category.translationKey()).getString();
            int width = this.textRenderer.getWidth(label) + 20;
            boolean selected = category == currentCategory;
            boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;

            int bg = selected ? 0xFF2C2C36 : (hovered ? 0x502C2C36 : 0x00000000);
            context.fill(x, y, x + width, y + height, bg);
            if (selected) {
                context.fill(x, y + height - 2, x + width, y + height, 0xFF55C7F0);
            }
            int textColor = selected ? 0xFFFFFFFF : 0xFFAAAAAA;
            context.drawCenteredTextWithShadow(this.textRenderer, label, x + width / 2, y + 8, textColor);

            tabBoundsThisFrame.add(new TabBounds(category, x, y, width, height));
            x += width + 4;
        }
    }

    private void renderGrid(DrawContext context, int mouseX, int mouseY, int gridTop) {
        cardBoundsThisFrame.clear();

        int contentLeft = MARGIN + 12;
        int contentRight = this.width - MARGIN - 12;
        int contentBottom = this.height - MARGIN - 10;
        int availableWidth = contentRight - contentLeft;
        int columns = Math.max(1, (availableWidth + CARD_GAP) / (CARD_WIDTH + CARD_GAP));

        context.enableScissor(contentLeft, gridTop, contentRight, contentBottom);

        int col = 0;
        int row = 0;
        for (Module module : visibleModules) {
            int cardX = contentLeft + col * (CARD_WIDTH + CARD_GAP);
            int cardY = gridTop - scrollOffset + row * (CARD_HEIGHT + CARD_GAP);

            if (cardY + CARD_HEIGHT >= gridTop && cardY <= contentBottom) {
                renderCard(context, module, cardX, cardY, mouseX, mouseY);
            }
            cardBoundsThisFrame.add(new CardBounds(module, cardX, cardY));

            col++;
            if (col >= columns) {
                col = 0;
                row++;
            }
        }

        context.disableScissor();

        if (visibleModules.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.translatable("gui.xoldiummod.mod_menu.empty"),
                    (contentLeft + contentRight) / 2, gridTop + 20, 0xFFAAAAAA);
        }
    }

    private void renderCard(DrawContext context, Module module, int x, int y, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + CARD_WIDTH && mouseY >= y && mouseY <= y + CARD_HEIGHT;

        context.fill(x, y, x + CARD_WIDTH, y + CARD_HEIGHT, hovered ? CARD_BG_HOVER : CARD_BG);
        int borderColor = hovered ? CARD_BORDER_HOVER : CARD_BORDER;
        context.drawBorder(x, y, CARD_WIDTH, CARD_HEIGHT, borderColor);

        // Judul
        context.drawText(this.textRenderer, module.displayName(), x + 10, y + 10, 0xFFFFFFFF, true);
        if (module.isCrashed()) {
            context.drawText(this.textRenderer,
                    Text.translatable("gui.xoldiummod.mod_menu.crashed"), x + 10, y + 22, 0xFFFF5555, true);
        }

        // Ikon (badge inisial) di tengah kartu
        String initials = initialsFor(module);
        IconRenderer.drawBadge(context, this.textRenderer, x + CARD_WIDTH / 2, y + CARD_HEIGHT / 2 - 6, 28, initials,
                module.isEnabled() ? 0xFF3A6E86 : 0xFF33333A);

        // Baris bawah: gear (kiri) + toggle (kanan)
        int bottomY = y + CARD_HEIGHT - 26;
        if (module.hasSettings()) {
            IconRenderer.drawGearIcon(context, x + 12, bottomY, 16, 0xFFCCCCCC);
        }
        IconRenderer.drawToggleSwitch(context, x + CARD_WIDTH - 44, bottomY, 32, 16, module.isToggledOn());
    }

    private String initialsFor(Module module) {
        String id = module.id().replace("opt_", "").replace("_", " ");
        String[] parts = id.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0)));
            }
            if (sb.length() >= 2) break;
        }
        return sb.length() > 0 ? sb.toString() : "XD";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (TabBounds tab : tabBoundsThisFrame) {
                if (tab.contains(mouseX, mouseY)) {
                    currentCategory = tab.category();
                    scrollOffset = 0;
                    autoFpsBoostButton.visible = currentCategory == ModuleCategory.OPTIMIZATION;
                    refreshVisibleModules();
                    return true;
                }
            }

            for (CardBounds card : cardBoundsThisFrame) {
                int gearX = card.x() + 12;
                int gearY = card.y() + CARD_HEIGHT - 26;
                int toggleX = card.x() + CARD_WIDTH - 44;
                int toggleY = card.y() + CARD_HEIGHT - 26;

                if (card.module().hasSettings() && contains(mouseX, mouseY, gearX, gearY, 16, 16)) {
                    if (this.client != null) {
                        this.client.setScreen(new ModuleSettingsScreen(this, card.module()));
                    }
                    return true;
                }
                if (contains(mouseX, mouseY, toggleX, toggleY, 32, 16)) {
                    card.module().setEnabled(!card.module().isToggledOn());
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = Math.max(0, scrollOffset - (int) (verticalAmount * 24));
        return true;
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    private static boolean contains(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private record CardBounds(Module module, int x, int y) {
    }

    private record TabBounds(ModuleCategory category, int x, int y, int width, int height) {
        boolean contains(double mx, double my) {
            return mx >= x && mx <= x + width && my >= y && my <= y + height;
        }
    }
}

package com.xoldium.xoldiummod.client;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.compat.vulkanmod.XoldiumVulkanModIntegration;
import com.xoldium.xoldiummod.client.core.FrustumContext;
import com.xoldium.xoldiummod.client.gui.XoldiumHomeScreen;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.client.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Entry point client-only Xoldium Client.
 *
 * <ul>
 *   <li>Mendaftarkan {@link WorldRenderEvents#START} untuk {@link FrustumContext}
 *       (dipakai seluruh mixin culling).</li>
 *   <li>Mendaftarkan keybind pembuka menu Xoldium (default Right Shift, bisa
 *       diubah lewat Controls seperti keybind vanilla lainnya) yang membuka
 *       {@link XoldiumHomeScreen}.</li>
 *   <li>Menginisialisasi {@link ModuleManager} (seluruh modul HUD/
 *       Optimization/Movement/Visual).</li>
 *   <li>Mencoba integrasi opsional ke menu VulkanMod - gagal dengan aman
 *       bila VulkanMod tidak ter-install.</li>
 * </ul>
 *
 * <p>TIDAK ada mixin yang didaftarkan manual di sini (lewat
 * {@code xoldiummod.mixins.json}), dan TIDAK ada pemanggilan API OpenGL/
 * GlStateManager/RenderSystem langsung di seluruh mod ini.
 */
public final class XoldiumModClient implements ClientModInitializer {

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.START.register(FrustumContext::beginFrame);

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xoldiummod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.xoldiummod"
        ));

        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new XoldiumHomeScreen());
                }
            }
        });

        XoldiumVulkanModIntegration.tryRegister();
        XoldiumMod.LOGGER.info("[Xoldium] Modul client (GUI, HUD, culling, optimasi) aktif. Tekan Right Shift untuk membuka menu.");
    }
}

package com.xoldium.xoldiummod.client.module.movement;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Auto Sprint: memaksa {@code isSprinting = true} setiap tick selagi
 * pemain bergerak maju & tidak sedang menyelinap - menghilangkan
 * kebutuhan menekan Ctrl/double-tap W secara manual. Efek hunger/particle
 * sprint tetap mengikuti perilaku vanilla normal (modul ini hanya
 * menyalakan flag sprinting, tidak mem-bypass mekanisme lain).
 */
public final class SprintModule extends Module {

    public SprintModule() {
        super("auto_sprint", "module.xoldiummod.auto_sprint", ModuleCategory.MOVEMENT, false);
    }

    @Override
    public void onClientTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return;
        }
        boolean movingForward = client.options.forwardKey.isPressed();
        if (movingForward && !player.isSneaking() && !player.isSprinting()) {
            player.setSprinting(true);
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        if (!enabled && MinecraftClient.getInstance().player != null) {
            // Jangan paksa mematikan sprint yang sedang berjalan wajar -
            // biarkan vanilla yang menentukan sprint berikutnya secara normal.
        }
    }
}

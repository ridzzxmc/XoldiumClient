package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleManager;
import com.xoldium.xoldiummod.client.module.setting.BooleanSetting;
import com.xoldium.xoldiummod.client.module.setting.DoubleSetting;
import com.xoldium.xoldiummod.client.module.setting.ModuleSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Layar setting per-modul (dibuka lewat ikon gear pada kartu modul di
 * {@link ModListScreen}) - dibangun dari widget vanilla saja
 * (CyclingButtonWidget untuk BooleanSetting, SliderWidget untuk
 * DoubleSetting), sama seperti filosofi {@code FulconConfigScreen} asli:
 * tidak menambah dependency Cloth Config/YACL.
 */
public final class ModuleSettingsScreen extends Screen {

    private final Screen parent;
    private final Module module;

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(module.displayName());
        this.parent = parent;
        this.module = module;
    }

    @Override
    protected void init() {
        int width = Math.min(this.width - 40, 360);
        int x = (this.width - width) / 2;
        int y = 40;
        int rowHeight = 22;

        for (ModuleSetting<?> setting : module.settings()) {
            if (setting instanceof BooleanSetting boolSetting) {
                CyclingButtonWidget<Boolean> widget = CyclingButtonWidget.onOffBuilder(boolSetting.get())
                        .build(x, y, width, 20, boolSetting.displayName(), (button, value) -> boolSetting.set(value));
                this.addDrawableChild(widget);
            } else if (setting instanceof DoubleSetting doubleSetting) {
                this.addDrawableChild(new DoubleSettingSlider(x, y, width, 20, doubleSetting));
            }
            y += rowHeight;
        }

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.done"), button -> {
                    ModuleManager.saveState();
                    if (this.client != null) {
                        this.client.setScreen(this.parent);
                    }
                })
                .dimensions(x, y + 8, width, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        ModuleManager.saveState();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    /** Slider vanilla sederhana yang terikat langsung ke satu {@link DoubleSetting}. */
    private static final class DoubleSettingSlider extends SliderWidget {

        private final DoubleSetting setting;

        DoubleSettingSlider(int x, int y, int width, int height, DoubleSetting setting) {
            super(x, y, width, height, Text.empty(), setting.sliderProgress());
            this.setting = setting;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(setting.displayName().copy()
                    .append(": ")
                    .append(Text.literal(String.format("%.2f", setting.get()))));
        }

        @Override
        protected void applyValue() {
            setting.setFromSliderProgress(this.value);
        }
    }
}

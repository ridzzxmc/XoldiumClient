package com.xoldium.xoldiummod.client.module.optimization;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import com.xoldium.xoldiummod.config.XoldiumConfig;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Membungkus satu field boolean {@link XoldiumConfig} (culling/throttle
 * milik Xoldium sendiri) sebagai entri yang bisa di-toggle lewat Mod Menu,
 * kategori OPTIMIZATION. Toggle langsung menulis-tembus ke field config
 * yang sama yang dibaca oleh Mixin culling/throttle - tidak ada state
 * ganda yang bisa saling menyimpang.
 */
public final class OptimizationToggleModule extends Module {

    private final Consumer<Boolean> setter;

    public OptimizationToggleModule(String id, String nameKey,
                                     Supplier<Boolean> getter, Consumer<Boolean> setter,
                                     boolean fallbackDefault) {
        super(id, nameKey, ModuleCategory.OPTIMIZATION, safeGet(getter, fallbackDefault));
        this.setter = setter;
    }

    private static boolean safeGet(Supplier<Boolean> getter, boolean fallback) {
        try {
            Boolean v = getter.get();
            return v != null ? v : fallback;
        } catch (Exception e) {
            return fallback;
        }
    }

    @Override
    protected void onToggle(boolean enabled) {
        setter.accept(enabled);
        XoldiumConfig.save();
    }
}

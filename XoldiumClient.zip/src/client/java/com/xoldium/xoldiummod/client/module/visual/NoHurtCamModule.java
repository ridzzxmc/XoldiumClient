package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * No Hurt Cam: menahan {@code LivingEntity#hurtTime} pemain lokal tetap 0
 * setiap client tick - field publik yang sama yang dipakai vanilla untuk
 * animasi "squish"/tint merah dan tilt kamera saat kena damage. Pendekatan
 * ini SENGAJA tidak memakai Mixin ke {@code GameRenderer}/kalkulasi kamera
 * (yang jauh lebih rapuh & sering berubah antar versi) - field
 * {@code hurtTime} sudah stabil dipakai banyak mod lintas versi untuk
 * keperluan yang sama.
 */
public final class NoHurtCamModule extends Module {

    public NoHurtCamModule() {
        super("no_hurt_cam", "module.xoldiummod.no_hurt_cam", ModuleCategory.VISUAL, false);
    }

    @Override
    public void onClientTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null) {
            player.hurtTime = 0;
        }
    }
}

package com.xoldium.xoldiummod.client.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Ikon monokrom sederhana untuk kartu modul di {@link ModListScreen} -
 * digambar murni dari primitif {@code DrawContext#fill} (kotak/lingkaran
 * pendekatan), TIDAK memakai file tekstur eksternal apa pun selain logo
 * Xoldium sendiri. Ini sengaja dilakukan supaya GUI tidak pernah gagal
 * render karena tekstur ikon hilang/salah path - setiap ikon dijamin
 * selalu bisa digambar di device manapun.
 */
public final class IconRenderer {

    private IconRenderer() {
    }

    /** Badge bulat berisi 1-2 huruf inisial nama modul, dipakai sebagai "ikon" di tengah kartu. */
    public static void drawBadge(DrawContext context, TextRenderer textRenderer, int centerX, int centerY, int radius, String initials, int accentColor) {
        // Pendekatan lingkaran dengan menumpuk fill kotak semakin sempit ke tepi (cheap circle approximation).
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.round(Math.sqrt((double) radius * radius - (double) dy * dy));
            if (span <= 0) continue;
            context.fill(centerX - span, centerY + dy, centerX + span, centerY + dy + 1, accentColor);
        }
        int textWidth = textRenderer.getWidth(initials);
        context.drawText(textRenderer, initials, centerX - textWidth / 2, centerY - textRenderer.fontHeight / 2, 0xFFFFFFFF, true);
    }

    /** Toggle switch kecil ala iOS (pil dengan bulatan) - dipakai di pojok kanan-bawah tiap kartu modul. */
    public static void drawToggleSwitch(DrawContext context, int x, int y, int width, int height, boolean on) {
        int trackColor = on ? 0xFF55C7F0 : 0xFF3A3A3A;
        context.fill(x, y, x + width, y + height, trackColor);
        int knobDiameter = height - 4;
        int knobX = on ? x + width - knobDiameter - 2 : x + 2;
        context.fill(knobX, y + 2, knobX + knobDiameter, y + 2 + knobDiameter, 0xFFFFFFFF);
    }

    /** Ikon gear (roda gerigi) super sederhana: kotak + lingkaran kecil di tengah, cukup jadi penanda "settings". */
    public static void drawGearIcon(DrawContext context, int x, int y, int size, int color) {
        context.fill(x, y, x + size, y + size, 0x00000000); // no-op transparan, jaga area klik konsisten
        int cx = x + size / 2;
        int cy = y + size / 2;
        int outer = size / 2;
        int inner = Math.max(2, size / 5);
        for (int dy = -outer; dy <= outer; dy++) {
            int span = (int) Math.round(Math.sqrt((double) outer * outer - (double) dy * dy));
            if (span <= 0) continue;
            // Gigi gear: gambar hanya cincin luar tipis, bukan lingkaran penuh, dengan celah tiap ~45 derajat.
            for (int dx = -span; dx <= span; dx++) {
                double dist = Math.sqrt((double) dx * dx + (double) dy * dy);
                if (dist >= outer - 1.4 && dist <= outer) {
                    double angle = Math.toDegrees(Math.atan2(dy, dx));
                    if (((int) Math.floor(((angle + 360) % 360) / 45.0)) % 2 == 0) {
                        context.fill(cx + dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
                    }
                } else if (dist <= inner) {
                    context.fill(cx + dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
                }
            }
        }
    }
}

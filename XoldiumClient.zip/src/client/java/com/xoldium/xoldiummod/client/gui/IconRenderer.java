package com.xoldium.xoldiummod.client.gui;

import com.xoldium.xoldiummod.XoldiumMod;
import com.xoldium.xoldiummod.client.module.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.Set;

/**
 * Ikon kartu modul di {@link ModListScreen} & badge logo Xoldium.
 *
 * <p>SEBELUMNYA: seluruh ikon digambar murni dari primitif
 * {@code DrawContext#fill} (badge inisial 1-2 huruf) supaya tidak pernah
 * gagal render karena file tekstur hilang/salah path, dan supaya tidak
 * perlu memverifikasi overload {@code DrawContext#drawTexture} yang
 * berubah-ubah bentuk mengikuti perombakan render pipeline Minecraft
 * (butuh {@code RenderPipeline} eksplisit sejak render-pipeline rewrite
 * di rilis 1.21.6+/1.21.7+).
 *
 * <p>SEKARANG: overload itu SUDAH diverifikasi lewat Yarn API docs
 * {@code yarn-1.21.11+build.4} (build resmi paling dekat dengan
 * {@code yarn_mappings} proyek ini). Dipakai
 * {@code DrawContext#drawTexturedQuad(Identifier, int, int, int, int,
 * float, float, float, float)} - SATU-SATUNYA overload {@code drawTexturedQuad}
 * yang public DAN TIDAK butuh parameter {@code RenderPipeline} sama
 * sekali (overload lain yang butuh {@code RenderPipeline} statusnya
 * private di kelas game, jadi memang bukan API yang dimaksud dipakai
 * mod luar) - ini padanan langsung dari {@code drawTexture(Identifier,...)}
 * versi lama yang dulu dipakai mod manapun untuk menggambar PNG mentah
 * (logo/ikon custom) tanpa perlu terdaftar di sprite atlas GUI apa pun.
 * Badge inisial huruf TETAP disimpan sebagai fallback otomatis untuk
 * modul yang belum punya file ikon di {@link #MODULE_ICONS} (lihat
 * {@link #drawModuleIcon}), supaya GUI tetap tidak pernah gagal render.
 */
public final class IconRenderer {

    private IconRenderer() {
    }

    /**
     * Pemetaan id modul -> nama file PNG di
     * {@code assets/xoldiummod/textures/gui/modules/<file>.png} (ikon dari
     * paket "Logo Module" yang disiapkan pemakai). Modul yang TIDAK ada di
     * peta ini (mis. "biome_hud", "no_hurt_cam" - tidak ada file ikon yang
     * cocok di paket) otomatis jatuh ke badge inisial huruf sebagai fallback.
     */
    private static final Map<String, String> MODULE_ICONS = Map.ofEntries(
            Map.entry("memory_hud", "memory_hud"),
            Map.entry("pack_display", "pack_display"),
            Map.entry("direction_hud", "direction_hud"),
            Map.entry("fps", "fps"),
            Map.entry("cps_counter", "cps_counter"),
            Map.entry("combo_counter", "combo_counter"),
            Map.entry("armor_hud", "armor_hud"),
            Map.entry("saturation_hud", "saturation_hud"),
            Map.entry("server_info_hud", "server_info_hud"),
            Map.entry("coordinates", "coordinates"),
            Map.entry("day_counter", "day_counter"),
            Map.entry("ping_display", "ping_display"),
            Map.entry("clock_hud", "clock_hud"),
            Map.entry("array_list", "array_list"),
            Map.entry("keystrokes", "keystrokes"),
            Map.entry("potion_hud", "potion_hud"),
            Map.entry("block_overlay", "block_overlay"),
            Map.entry("damage_indicator", "damage_indicator"),
            Map.entry("fullbright", "fullbright"),
            Map.entry("auto_sprint", "auto_sprint"),
            Map.entry("chat_timestamps", "chat_timestamps")
    );

    /** "credit_hud" sengaja TIDAK dari paket ikon - pakai logo Xoldium sendiri (lebih pas, modul ini literal tentang branding Xoldium). */
    private static final Set<String> USE_XOLDIUM_LOGO = Set.of("credit_hud");

    private static final Identifier LOGO_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/logo.png");
    private static final Identifier GEAR_TEXTURE = Identifier.of(XoldiumMod.MOD_ID, "textures/gui/icons/settings.png");

    private static Identifier iconFor(Module module) {
        if (USE_XOLDIUM_LOGO.contains(module.id())) {
            return LOGO_TEXTURE;
        }
        String file = MODULE_ICONS.get(module.id());
        return file != null ? Identifier.of(XoldiumMod.MOD_ID, "textures/gui/modules/" + file + ".png") : null;
    }

    /**
     * Ikon kartu modul: gambar file PNG persegi dari {@link #MODULE_ICONS}
     * bila ada, kalau tidak jatuh ke badge inisial huruf (fallback lama).
     * {@code size} = lebar/tinggi kotak ikon (persegi, ikon sumber semuanya
     * 256x256/512x512 jadi aman di-scale ke ukuran berapa pun).
     */
    public static void drawModuleIcon(DrawContext context, TextRenderer textRenderer, Module module,
                                       int centerX, int centerY, int size, boolean enabled) {
        Identifier icon = iconFor(module);
        if (icon != null) {
            int half = size / 2;
            context.drawTexturedQuad(icon, centerX - half, centerY - half, centerX + half, centerY + half,
                    0.0F, 1.0F, 0.0F, 1.0F);
            if (!enabled) {
                // Overlay hitam semi-transparan sebagai penanda OFF (bukan tint biru) - murni hitam-putih.
                context.fill(centerX - half, centerY - half, centerX + half, centerY + half, 0x60000000);
            }
        } else {
            drawBadge(context, textRenderer, centerX, centerY, size / 2, initialsFor(module), enabled);
        }
    }

    /** Menggambar tekstur PNG mentah (mis. logo Xoldium) diregangkan pas ke kotak (x,y,width,height). */
    public static void drawTexture(DrawContext context, Identifier texture, int x, int y, int width, int height) {
        context.drawTexturedQuad(texture, x, y, x + width, y + height, 0.0F, 1.0F, 0.0F, 1.0F);
    }

    private static String initialsFor(Module module) {
        String id = module.id().replace("opt_", "").replace("_", " ");
        String[] parts = id.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0)));
            }
            if (sb.length() >= 2) break;
        }
        return sb.length() > 0 ? sb.toString() : "XD";
    }

    /**
     * Badge bulat berisi 1-2 huruf inisial - fallback untuk modul tanpa
     * file ikon di {@link #MODULE_ICONS}. Latar SELALU abu-gelap netral
     * (bukan biru); yang berubah mengikuti status ON/OFF hanya warna
     * hurufnya (putih terang saat ON, abu redup saat OFF) - hitam-putih
     * murni, tidak ada aksen warna lain.
     */
    public static void drawBadge(DrawContext context, TextRenderer textRenderer, int centerX, int centerY, int radius, String initials, boolean enabled) {
        int bgColor = 0xFF222222;
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.round(Math.sqrt((double) radius * radius - (double) dy * dy));
            if (span <= 0) continue;
            context.fill(centerX - span, centerY + dy, centerX + span, centerY + dy + 1, bgColor);
        }
        int textColor = enabled ? 0xFFFFFFFF : 0xFF8A8A8A;
        int textWidth = textRenderer.getWidth(initials);
        context.drawText(textRenderer, initials, centerX - textWidth / 2, centerY - textRenderer.fontHeight / 2, textColor, false);
    }

    /**
     * Toggle switch kecil ala iOS - HITAM/PUTIH murni (tanpa aksen biru):
     * ON = track putih + knob hitam, OFF = track hitam/gelap + knob abu-abu
     * terang (satu-satunya nuansa abu yang dipertahankan, sekadar supaya
     * knob tetap kebaca di atas track gelap).
     */
    public static void drawToggleSwitch(DrawContext context, int x, int y, int width, int height, boolean on) {
        int trackColor = on ? 0xFFF2F2F2 : 0xFF1A1A1A;
        context.drawBorder(x, y, width, height, 0xFFFFFFFF);
        context.fill(x + 1, y + 1, x + width - 1, y + height - 1, trackColor);
        int knobDiameter = height - 4;
        int knobX = on ? x + width - knobDiameter - 2 : x + 2;
        int knobColor = on ? 0xFF0A0A0A : 0xFFAFAFAF;
        context.fill(knobX, y + 2, knobX + knobDiameter, y + 2 + knobDiameter, knobColor);
    }

    /** Ikon gear (roda gerigi) dari {@code icons/settings.png} - dipakai tombol "buka setting" tiap kartu modul. */
    public static void drawGearIcon(DrawContext context, int x, int y, int size, int color) {
        drawTexture(context, GEAR_TEXTURE, x, y, size, size);
    }
}

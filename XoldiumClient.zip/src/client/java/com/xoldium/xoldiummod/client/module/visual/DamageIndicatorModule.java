package com.xoldium.xoldiummod.client.module.visual;

import com.xoldium.xoldiummod.client.module.Module;
import com.xoldium.xoldiummod.client.module.ModuleCategory;
import it.unimi.dsi.fastutil.longs.Long2FloatOpenHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Damage Indicator: menampilkan angka damage mengambang di atas entitas
 * yang kehilangan health, murni dari perbandingan health client-side antar
 * tick (TIDAK ada Mixin/event damage server) - jadi bekerja identik untuk
 * mob maupun pemain lain tanpa perlu hook packet apa pun.
 *
 * <p>CATATAN VERIFIKASI MAPPING: rendering teks 3D "billboard" (selalu
 * menghadap kamera) di bawah memakai {@link MatrixStack} dunia (BUKAN
 * {@code Matrix3x2fStack} 2D milik {@code DrawContext} - lihat catatan di
 * {@code HudRenderUtil}), {@code Camera#getRotation()}, dan overload
 * {@code TextRenderer#draw(..., Matrix4f, VertexConsumerProvider, ...)}
 * yang sama dipakai vanilla untuk name tag/sign - pola yang sudah lama
 * stabil, tapi tetap verifikasi ulang lewat {@code genSources}/IDE saat
 * pindah ke build Yarn baru.
 */
public final class DamageIndicatorModule extends Module {

    private static final long DURATION_NANOS = 900_000_000L;
    private static final double RISE_DISTANCE = 0.7;
    private static final int CLEANUP_INTERVAL_TICKS = 200;

    private final Long2FloatOpenHashMap lastHealth = new Long2FloatOpenHashMap();
    private final List<Popup> popups = new ArrayList<>();
    private int tickCounter = 0;

    public DamageIndicatorModule() {
        super("damage_indicator", "module.xoldiummod.damage_indicator", ModuleCategory.VISUAL, false);
        lastHealth.defaultReturnValue(-1f);
        WorldRenderEvents.AFTER_ENTITIES.register(this::onAfterEntities);
    }

    @Override
    public void onClientTick() {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null) {
            return;
        }

        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) {
                continue;
            }
            float health = living.getHealth();
            long id = living.getId();
            float prev = lastHealth.get(id);
            if (prev >= 0f && health < prev - 0.01f) {
                float damage = prev - health;
                popups.add(new Popup(
                        living.getPos().add(0, living.getHeight() * 0.5, 0),
                        damage,
                        System.nanoTime()));
            }
            lastHealth.put(id, health);
        }

        popups.removeIf(p -> (System.nanoTime() - p.startNanos) > DURATION_NANOS);

        if (++tickCounter >= CLEANUP_INTERVAL_TICKS) {
            tickCounter = 0;
            lastHealth.clear(); // pola cleanup sederhana yang sama dengan MobAiThrottleManager
        }
    }

    private void onAfterEntities(WorldRenderContext context) {
        if (!isEnabled() || popups.isEmpty()) {
            return;
        }
        try {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            Vec3d camPos = context.camera().getPos();
            MatrixStack matrices = context.matrixStack();
            long now = System.nanoTime();

            for (Popup p : popups) {
                float t = (now - p.startNanos) / (float) DURATION_NANOS;
                if (t > 1f) {
                    continue;
                }
                double rise = t * RISE_DISTANCE;
                int alpha = Math.max(0, Math.min(255, (int) (255 * (1f - t))));
                int color = (alpha << 24) | 0xFF5050; // merah - warna damage konvensional, dikembalikan sesuai permintaan.

                matrices.push();
                matrices.translate(p.pos.x - camPos.x, p.pos.y - camPos.y + rise, p.pos.z - camPos.z);
                matrices.multiply(context.camera().getRotation());
                matrices.scale(-0.025f, -0.025f, 0.025f);

                String text = "-" + formatAmount(p.amount);
                int width = tr.getWidth(text);
                Matrix4f matrix4f = new Matrix4f(matrices.peek().getPositionMatrix());
                tr.draw(text, -width / 2f, 0f, color, false, matrix4f, context.consumers(),
                        TextRenderer.TextLayerType.NORMAL, 0, LightmapTextureManager.MAX_LIGHT_COORDINATE);

                matrices.pop();
            }
        } catch (Throwable t) {
            markCrashed(t);
        }
    }

    private static String formatAmount(float amount) {
        int rounded = Math.round(amount);
        return Math.abs(amount - rounded) < 0.05f ? String.valueOf(rounded) : String.format("%.1f", amount);
    }

    private record Popup(Vec3d pos, float amount, long startNanos) {
    }
}

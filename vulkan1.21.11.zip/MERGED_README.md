# VulkanMod + Not Enough Vulkan (Sodium Extra) + ThreadTweak — target MC 1.21.11

> **STATUS: BELUM DIKOMPILASI DAN BELUM DIJALANKAN.**
> Sandbox pembuatnya tidak punya internet (Gradle/Minecraft tidak bisa diunduh).
> Yang sudah dicek: sintaks 352 file Java (0 error), semua import internal terselesaikan, semua JSON valid.
> Yang belum: kompilasi terhadap Minecraft 1.21.11, perilaku runtime, dan angka FPS.

## Dasar port
Source dasar adalah VulkanMod 0.6.0 yang dibuat untuk MC 1.21.10. Port ke 1.21.11 di sini mencakup:
- `ResourceLocation` diganti `Identifier` (rename Mojang di 1.21.11) di semua file, access widener, dan target mixin.
- Gradle: MC 1.21.11, Fabric Loader 0.18.4, Fabric API 0.141.1+1.21.11, Loom 1.14-SNAPSHOT.
- `fabric.mod.json`: `minecraft: 1.21.11`.
- Kode Sodium Extra / Not Enough Vulkan kembali memakai `Identifier` seperti aslinya (aslinya memang untuk 1.21.11).

**Risiko utama:** Minecraft 1.21.11 mengubah beberapa class internal selain `Identifier`. Mixin dan kode render inti
VulkanMod 0.6.0 belum diuji terhadap perubahan itu. Upstream sudah punya rilis resmi VulkanMod 0.6.7/0.6.8 untuk 1.21.11
dengan penyesuaian tersebut. Kalau build gagal, kirim log error dan perbaiki per file.

## Tambahan di versi ini
**ThreadTweak 0.1.8 (MIT) digabung** ke `net.vulkanmod.smoothboot` (dipetakan Yarn -> Mojang mappings):
- Executor latar belakang Minecraft (Main dan IO) diganti pool berprioritas rendah (jumlah thread = CPU-1)
- Prioritas thread game dan integrated server bisa diatur
- Config: `config/vulkanmod-threads.json`
- Mixin-nya `required: false`: jika nama method/field Mojang berbeda, mixin dilewati dengan peringatan di log, tidak crash.
  Nama yang saya pakai: `Util.backgroundExecutor()`, `Util.ioPool()`, `BACKGROUND_EXECUTOR`, `IO_POOL`,
  `onThreadException`, `TracingExecutor`, `IntegratedServer.initServer()`. Nama ini dari ingatan, belum diverifikasi.

**Optimasi lain:**
- Pipeline cache persisten ke `<folder game>/vulkanmod_cache/pipeline_cache.bin` (dari versi sebelumnya)
- Stack LWJGL dinaikkan dari 64 KB ke 256 KB bila belum diatur (mencegah `OutOfMemoryError: Out of stack space`
  pada atlas tekstur besar; masalah ini dilaporkan di issue upstream #880). Tidak berlaku jika `-Dorg.lwjgl.system.stackSize` sudah Anda set.
- Thread chunk builder diturunkan satu level (NORM-1), di bawah render thread (NORM+2), supaya lonjakan rebuild chunk tidak mengganggu frame time
- Halaman opsi Sodium Extra, UI halus, dan lain-lain dari versi sebelumnya

Tidak ada klaim angka FPS: belum diukur.

## Build
JDK 21 + internet: `./gradlew build` (Windows: `gradlew.bat build`).
Hasil: `build/libs/VulkanMod_NEV_Merged_1.21.11-0.6.0-merged.2.jar`.
Tanpa PC: unggah ke repo GitHub, workflow `.github/workflows/build.yml` membuild dan mengunggah artifact.

## Jika build gagal
1. Kirim log error (baris `error:` dari tab Actions atau terminal).
2. Mixin Sodium Extra yang tidak cocok bisa dihapus dari `sodium-extra.mixins.json`.

## Lisensi
VulkanMod dan Not Enough Vulkan/Sodium Extra: LGPL-3.0 (`LICENSE`, `LICENSE_NotEnoughVulkan_SodiumExtra.txt`).
ThreadTweak: MIT (`LICENSE_ThreadTweak.txt`). Sertakan source dan notice jika mendistribusikan jar.

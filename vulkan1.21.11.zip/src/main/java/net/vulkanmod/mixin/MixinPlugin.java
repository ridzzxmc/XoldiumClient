package net.vulkanmod.mixin;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public class MixinPlugin implements IMixinConfigPlugin {

    @Override
    public void onLoad(String mixinPackage) {
        // Stack LWJGL default (64 KB) bisa habis pada atlas tekstur besar (OutOfMemoryError: Out of stack space).
        // Naikkan ke 256 KB bila pengguna belum mengatur sendiri lewat -Dorg.lwjgl.system.stackSize.
        try {
            if (System.getProperty("org.lwjgl.system.stackSize") == null) {
                org.lwjgl.system.Configuration.STACK_SIZE.set(256);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {

    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }
}

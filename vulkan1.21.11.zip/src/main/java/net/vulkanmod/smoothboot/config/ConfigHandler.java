package net.vulkanmod.smoothboot.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import net.vulkanmod.smoothboot.SmoothBoot;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ConfigHandler {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static SmoothBootConfig readConfig() throws IOException {
		String configPath = System.getProperty("user.dir") + "/config/vulkanmod-threads.json";
		SmoothBoot.LOGGER.debug("Config path: {}", configPath);

		SmoothBootConfig config;
		try (FileReader reader = new FileReader(configPath)) {
			config = GSON.fromJson(reader, SmoothBootConfig.class);
			if (config == null) {
				throw new NullPointerException();
			}
			config.validate();
			try (FileWriter writer = new FileWriter(configPath)) {
				GSON.toJson(config, writer);
			}
		} catch (NullPointerException | JsonParseException | IOException e) {
			// Buat config baru
			config = new SmoothBootConfig();
			File file = new File(configPath);
			file.getParentFile().mkdirs();
			try (FileWriter writer = new FileWriter(configPath)) {
				GSON.toJson(config, writer);
				SmoothBoot.LOGGER.debug("New config file created");
			}
		}
		return config;
	}
}

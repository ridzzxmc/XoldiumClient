package net.vulkanmod.smoothboot.config;

import net.minecraft.util.Mth;
import net.vulkanmod.smoothboot.SmoothBoot;

public class SmoothBootConfig {
	public ThreadCount threadCount = new ThreadCount();

	public ThreadPriority threadPriority = new ThreadPriority();

	public static class ThreadCount {
		public int bootstrap = 1;
		public int main = Mth.clamp(Runtime.getRuntime().availableProcessors() - 1, 1,
				SmoothBoot.getMaxBackgroundThreads());
	}

	public static class ThreadPriority {
		public int game = 5;
		public int bootstrap = 1;
		public int main = 1;
		public int io = 1;
		public int integratedServer = 5;
	}

	public void validate() {
		threadCount.bootstrap = Math.max(threadCount.bootstrap, 1);
		threadCount.main = Math.max(threadCount.main, 1);

		threadPriority.game = Mth.clamp(threadPriority.game, 1, 10);
		threadPriority.integratedServer = Mth.clamp(threadPriority.integratedServer, 1, 10);
		threadPriority.bootstrap = Mth.clamp(threadPriority.bootstrap, 1, 10);
		threadPriority.main = Mth.clamp(threadPriority.main, 1, 10);
		threadPriority.io = Mth.clamp(threadPriority.io, 1, 10);
	}
}

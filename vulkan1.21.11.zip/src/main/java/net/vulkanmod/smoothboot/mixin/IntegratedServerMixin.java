package net.vulkanmod.smoothboot.mixin;

import net.minecraft.client.server.IntegratedServer;
import net.vulkanmod.smoothboot.SmoothBoot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public class IntegratedServerMixin {
	// initServer() berjalan di thread server, jadi tidak bergantung pada signature konstruktor yang sering berubah antar versi
	@Inject(method = "initServer", at = @At("HEAD"))
	private void vulkanmod$onInitServer(CallbackInfoReturnable<Boolean> cir) {
		SmoothBoot.regConfig();
		Thread.currentThread().setPriority(SmoothBoot.config.threadPriority.integratedServer);
		SmoothBoot.LOGGER.debug("Initialized integrated server thread");
	}
}

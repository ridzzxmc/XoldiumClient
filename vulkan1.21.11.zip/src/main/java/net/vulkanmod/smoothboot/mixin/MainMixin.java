package net.vulkanmod.smoothboot.mixin;

import net.minecraft.client.main.Main;
import net.vulkanmod.smoothboot.SmoothBoot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Main.class)
public class MainMixin {
	@Inject(method = "main", at = @At("HEAD"), remap = false)
	private static void vulkanmod$onMain(CallbackInfo ci) {
		SmoothBoot.regConfig();

		Thread.currentThread().setPriority(SmoothBoot.config.threadPriority.game);
		SmoothBoot.LOGGER.debug("Initialized client game thread");
	}
}

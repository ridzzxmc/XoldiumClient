package net.vulkanmod.smoothboot.mixin;

import net.minecraft.Util;
import net.minecraft.util.Mth;
import net.minecraft.util.TracingExecutor;
import net.vulkanmod.smoothboot.SmoothBoot;
import net.vulkanmod.smoothboot.util.LoggingForkJoinWorkerThread;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.atomic.AtomicInteger;

/** Dari ThreadTweak (MIT). Nama dipetakan ke Mojang mappings untuk MC 1.21.11. */
@Mixin(Util.class)
public abstract class UtilMixin {
	@Shadow @Final @Mutable
	private static TracingExecutor BACKGROUND_EXECUTOR;

	@Shadow @Final @Mutable
	private static TracingExecutor IO_POOL;

	@Shadow
	private static void onThreadException(Thread thread, Throwable throwable) {}

	@Inject(method = "backgroundExecutor", at = @At("HEAD"))
	private static void vulkanmod$onBackgroundExecutor(CallbackInfoReturnable<Executor> ci) {
		if (!SmoothBoot.initMainWorker) {
			SmoothBoot.initMainWorker = true;
			BACKGROUND_EXECUTOR = vulkanmod$replWorker();
			SmoothBoot.LOGGER.debug("Main worker replaced");
		}
	}

	@Inject(method = "ioPool", at = @At("HEAD"))
	private static void vulkanmod$onIoPool(CallbackInfoReturnable<Executor> ci) {
		if (!SmoothBoot.initIOWorker) {
			SmoothBoot.initIOWorker = true;
			IO_POOL = vulkanmod$replIoWorker();
			SmoothBoot.LOGGER.debug("IO worker replaced");
		}
	}

	@Unique
	private static TracingExecutor vulkanmod$replWorker() {
		SmoothBoot.regConfig();

		AtomicInteger counter = new AtomicInteger(1);

		ExecutorService service = new ForkJoinPool(Mth.clamp(SmoothBoot.config.threadCount.main, 1, 0x7fff), pool -> {
			String workerName = "Worker-Main-" + counter.getAndIncrement();
			SmoothBoot.LOGGER.debug("Initialized {}", workerName);

			ForkJoinWorkerThread thread = new LoggingForkJoinWorkerThread(pool, SmoothBoot.LOGGER);
			thread.setPriority(SmoothBoot.config.threadPriority.main);
			thread.setName(workerName);
			return thread;
		}, UtilMixin::onThreadException, true);

		return new TracingExecutor(service);
	}

	@Unique
	private static TracingExecutor vulkanmod$replIoWorker() {
		SmoothBoot.regConfig();

		AtomicInteger counter = new AtomicInteger(1);

		ExecutorService service = Executors.newCachedThreadPool(runnable -> {
			String workerName = "IO-Worker-" + counter.getAndIncrement();
			SmoothBoot.LOGGER.debug("Initialized {}", workerName);

			Thread thread = new Thread(runnable);
			thread.setName(workerName);
			thread.setDaemon(true);
			thread.setPriority(SmoothBoot.config.threadPriority.io);
			thread.setUncaughtExceptionHandler(UtilMixin::onThreadException);
			return thread;
		});

		return new TracingExecutor(service);
	}
}

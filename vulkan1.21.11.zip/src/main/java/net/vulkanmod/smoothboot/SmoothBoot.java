package net.vulkanmod.smoothboot;

import net.vulkanmod.smoothboot.config.ConfigHandler;
import net.vulkanmod.smoothboot.config.SmoothBootConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * Penjadwalan thread dari ThreadTweak 0.1.8 (MIT, getchoo / UltimateBoomer / fantahund),
 * dipetakan ke Mojang mappings dan digabung ke dalam VulkanMod.
 * Mengganti executor latar belakang Minecraft (Main/IO) dengan pool berprioritas rendah
 * supaya render thread tidak berebut CPU saat loading dan saat chunk/IO sibuk.
 */
public class SmoothBoot {
	public static final String NAME = "VulkanMod ThreadTweak";
	public static final Logger LOGGER = LogManager.getLogger(NAME);

	public static SmoothBootConfig config;

	public static boolean initConfig = false;
	public static boolean initMainWorker = false;
	public static boolean initIOWorker = false;

	/** Dipanggil sebelum worker pertama dibuat. */
	public static synchronized void regConfig() {
		if (initConfig) {
			return;
		}
		try {
			config = ConfigHandler.readConfig();
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
		initConfig = true;
		LOGGER.info("{} config initialized", NAME);
	}

	public static int getMaxBackgroundThreads() {
		String string = System.getProperty("max.bg.threads");
		if (string != null) {
			try {
				int i = Integer.parseInt(string);
				if (i >= 1 && i <= 255) {
					return i;
				}
			} catch (NumberFormatException ignored) {
			}
		}
		return 255;
	}
}

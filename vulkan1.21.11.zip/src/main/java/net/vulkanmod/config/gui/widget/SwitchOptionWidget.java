package net.vulkanmod.config.gui.widget;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.vulkanmod.config.gui.GuiTheme;
import net.vulkanmod.config.gui.render.GuiRenderer;
import net.vulkanmod.config.option.SwitchOption;
import net.vulkanmod.vulkan.util.ColorUtil;

public class SwitchOptionWidget extends OptionWidget<SwitchOption> {
    private boolean focused;

    public SwitchOptionWidget(SwitchOption option, Component name) {
        super(option, name);
        updateDisplayedValue();
    }

    private float anim = -1.0f;

    @Override
    protected void renderControls(double mouseX, double mouseY) {
        float target = this.option.getNewValue() ? 1.0f : 0.0f;
        this.anim = this.anim < 0.0f ? target : GuiTheme.approach(this.anim, target, 18.0f, GuiTheme.dt());

        int center = controlX + controlWidth / 2;
        int halfWidth = 12;
        int x0 = center - halfWidth;
        int y0 = y + 4;
        int height = this.height - 8;
        int color;

        int w1 = halfWidth - 4;
        int h1 = height - 4;

        // Latar jalur: memudar ke warna aksen saat ON
        if (this.anim > 0.01f) {
            color = ColorUtil.ARGB.multiplyAlpha(GuiTheme.ACCENT, 0.55f * this.anim);
            GuiRenderer.fillBox(x0 + 2, y0 + 2, halfWidth * 2 - 4, h1, color);
        }

        // Knob bergeser halus antara posisi OFF dan ON
        int knobX = x0 + 2 + Math.round(halfWidth * this.anim);
        color = ColorUtil.ARGB.pack(1.0f, 1.0f, 1.0f, 0.45f + 0.55f * this.anim);
        GuiRenderer.fillBox(knobX, y0 + 2, w1, h1, color);

        color = ColorUtil.ARGB.pack(0.6f, 0.6f, 0.6f, 1.0f);
        GuiRenderer.renderBoxBorder(x0, y0, halfWidth * 2, height, 1,  color);

        color = this.active ? 0xFFFFFFFF : 0xFFA0A0A0;
        Font textRenderer = Minecraft.getInstance().font;
        int margin = Math.max(
                textRenderer.width(Component.translatable("options.on").getString()) / 3,
                textRenderer.width(Component.translatable("options.off").getString()) / 3
        );

        int x = this.controlX + this.controlWidth / 2 - (int) (halfWidth * 1.5f) - 4 - margin;
        int y = this.y + (this.height - 8) / 2;
        GuiRenderer.drawCenteredString(textRenderer, this.getDisplayedValue(), x, y, color);
    }

    public void onClick(double mouseX, double mouseY) {
        this.option.setNewValue(!this.option.getNewValue());
        updateDisplayedValue();
    }

    @Override
    public void onRelease(double mouseX, double mouseY) {

    }

    @Override
    protected void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {

    }

    protected void updateDisplayedValue() {
        this.displayedValue = option.getNewValue()
                ? Component.translatable("options.on")
                : Component.translatable("options.off");
    }

    @Override
    public void setFocused(boolean bl) {
        this.focused = bl;
    }

    @Override
    public boolean isFocused() {
        return this.focused;
    }

}

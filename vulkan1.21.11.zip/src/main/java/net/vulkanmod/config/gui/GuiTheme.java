package net.vulkanmod.config.gui;

import net.minecraft.Util;
import net.minecraft.util.Mth;
import net.vulkanmod.vulkan.util.ColorUtil;

/**
 * Warna tema dan helper animasi untuk layar opsi VulkanMod.
 * Semua animasi berbasis waktu (bukan frame), jadi kecepatannya sama di 30 FPS maupun 300 FPS.
 */
public final class GuiTheme {
    public static final int ACCENT = ColorUtil.ARGB.pack(0.88f, 0.20f, 0.24f, 1.0f);
    public static final int ACCENT_SOFT = ColorUtil.ARGB.pack(0.88f, 0.20f, 0.24f, 0.35f);
    public static final int PANEL = ColorUtil.ARGB.pack(0.0f, 0.0f, 0.0f, 0.45f);

    private static long lastFrameTime = 0L;
    private static float frameDelta = 0.0f;

    private GuiTheme() {
    }

    /** Dipanggil sekali per frame oleh layar opsi sebelum merender widget. */
    public static void beginFrame() {
        long now = Util.getMillis();
        frameDelta = lastFrameTime == 0L ? 0.0f : Math.min((now - lastFrameTime) / 1000.0f, 0.1f);
        lastFrameTime = now;
    }

    /** Selisih waktu frame terakhir dalam detik (dibatasi 0.1 s agar tidak "melompat" setelah jeda). */
    public static float dt() {
        return frameDelta;
    }

    public static float smoothstep(float t) {
        t = Mth.clamp(t, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }

    /** Mendekati target secara eksponensial dan independen terhadap frame rate. */
    public static float approach(float current, float target, float speedPerSecond, float dtSeconds) {
        float k = 1.0f - (float) Math.exp(-speedPerSecond * dtSeconds);
        float v = current + (target - current) * k;
        return Math.abs(target - v) < 0.002f ? target : v;
    }
}

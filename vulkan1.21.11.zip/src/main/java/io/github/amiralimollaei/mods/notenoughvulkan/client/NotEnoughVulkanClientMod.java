package io.github.amiralimollaei.mods.notenoughvulkan.client;

import io.github.amiralimollaei.mods.notenoughvulkan.config.NotEnoughVulkanGameOptions;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Bagian "Not Enough Vulkan" yang tersisa setelah digabung ke dalam VulkanMod.
 * Hook berbasis mixin ke internal VulkanMod sudah diganti dengan perubahan langsung di kode VulkanMod.
 */
public class NotEnoughVulkanClientMod {
    private static NotEnoughVulkanGameOptions CONFIG;
    private static Logger LOGGER;

    public static Logger logger() {
        if (LOGGER == null) {
            LOGGER = LoggerFactory.getLogger("Not Enough Vulkan");
        }
        return LOGGER;
    }

    public static NotEnoughVulkanGameOptions options() {
        if (CONFIG == null) {
            CONFIG = NotEnoughVulkanGameOptions.load(
                    FabricLoader.getInstance().getConfigDir().resolve("not-enough-vulkan-options.json").toFile());
        }
        return CONFIG;
    }
}
